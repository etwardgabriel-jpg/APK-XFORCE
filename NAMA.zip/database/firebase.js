const admin = require('firebase-admin');
const { cert } = require('firebase-admin/app');

const serviceAccount = require('../firebase-adminsdk.json');

admin.initializeApp({
  credential: cert(serviceAccount),
});

module.exports = admin;